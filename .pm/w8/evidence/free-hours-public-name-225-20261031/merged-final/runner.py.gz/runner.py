import datetime,hashlib,json,os,shutil,signal,subprocess,sys,time
from pathlib import Path
proof=Path(__file__).resolve().parent
repo=Path('/Users/tianpan/projects/bex7')
old=Path('/private/tmp/bex-w8-225-free-hours-name-20261031-a3k0xnwg')
limits=json.loads((proof/'BUDGET.json').read_text())
expected={'lego/backend/internal/apps/free_hours.go':'5e289d5b65d0649ddc312c261596c985f174e2f43b1b99cbd8f0943bbec84785','lego/backend/internal/apps/free_hours_test.go':'131c733673d0b16fa4404ff888de7cd6b0dd91016add465cdc4442e5dc91bfe2','lego/go.work.sum':'efb45a8fffa3eaa979709e70e7e8c6660b207181450ac5f17febc6d0365f4ff6'}
for name,want in expected.items():
 if hashlib.sha256((repo/name).read_bytes()).hexdigest()!=want:
  raise SystemExit('input hash changed: '+name)
commands={'candidate':['/opt/homebrew/bin/go','test','-p','1','-mod=readonly','./internal/apps','-run','^TestFreeHours','-count=1','-v'],'baseline':['/opt/homebrew/bin/go','test','-p','1','-mod=readonly','-overlay',str(old/'before-fix-overlay.json'),'./internal/apps','-run','^TestFreeHoursRefusalNamesThePublicService$','-count=1','-v'],'lint':[str(repo/'lego/operator/bin/golangci-lint'),'run','./internal/apps','--timeout=3m']}
stage=sys.argv[1]
if stage not in commands: raise SystemExit('unknown fixed stage')
cmd=commands[stage]
free=shutil.disk_usage(repo).free
if free<limits['start_threshold_bytes']:
 (proof/(stage+'.receipt.json')).write_text(json.dumps({'status':'NOT_STARTED_CAPACITY','free_bytes':free,'command':cmd},indent=2)+'\n')
 raise SystemExit(125)
def allocated(p):
 total=p.lstat().st_blocks*512
 if p.is_dir():
  for child in p.iterdir(): total+=allocated(child)
 return total
scratch=proof/'GOTMPDIR'
if any(scratch.iterdir()): raise SystemExit('own scratch not empty')
env=os.environ.copy()
env.update({'GOWORK':'off','GOTOOLCHAIN':'local','GOPROXY':'off','GOSUMDB':'off','GOMAXPROCS':'2','GOMEMLIMIT':'384MiB','GOTMPDIR':str(scratch)})
start=time.monotonic(); started=datetime.datetime.now(datetime.timezone.utc).isoformat()
proc=None; reason=None; minfree=free; maxtmp=0; maxown=0
try:
 with (proof/(stage+'.stdout.log')).open('wb') as stdout,(proof/(stage+'.stderr.log')).open('wb') as stderr,(proof/(stage+'.samples.jsonl')).open('w') as samples:
  proc=subprocess.Popen(cmd,cwd=repo/'lego/backend',env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  while True:
   nowfree=shutil.disk_usage(repo).free; tmpbytes=allocated(scratch); ownbytes=allocated(proof)
   minfree=min(minfree,nowfree); maxtmp=max(maxtmp,tmpbytes); maxown=max(maxown,ownbytes)
   samples.write(json.dumps({'seconds':round(time.monotonic()-start,3),'free_bytes':nowfree,'own_tmp_allocated_bytes':tmpbytes,'own_proof_allocated_bytes':ownbytes})+'\n');samples.flush()
   if nowfree<=limits['active_free_floor_bytes']: reason='free-space active floor'
   elif limits['initial_free_bytes']-nowfree>=limits['cumulative_free_drop_stop_bytes']: reason='cumulative free-space decline, attribution not assumed'
   elif tmpbytes>=limits['GOTMPDIR_stop_bytes']: reason='own temporary allocation stop threshold'
   elif ownbytes>=limits['new_own_physical_cap_bytes']: reason='own physical allocation cap'
   elif datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(limits['all_stages_deadline_utc']): reason='bounded all-stages ten-minute deadline'
   elif time.monotonic()-start>=240: reason='bounded stage timeout'
   status=proc.poll()
   if status is not None: break
   if reason:
    os.killpg(proc.pid,signal.SIGTERM)
    try: proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
     os.killpg(proc.pid,signal.SIGKILL);proc.wait()
    break
   time.sleep(1)
except BaseException:
 if proc is not None and proc.poll() is None:
  os.killpg(proc.pid,signal.SIGTERM)
  try: proc.wait(timeout=5)
  except subprocess.TimeoutExpired:
   os.killpg(proc.pid,signal.SIGKILL);proc.wait()
 raise
finally:
 if proc is not None:
  child_exit=proc.wait()
  scratch_before_cleanup=[str(p.relative_to(scratch)) for p in scratch.iterdir()]
  for path in list(scratch.iterdir()):
   if path.is_dir() and not path.is_symlink(): shutil.rmtree(path)
   else: path.unlink()
  source_after={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in expected}
  receipt={'stage':stage,'started_utc':started,'duration_seconds':round(time.monotonic()-start,3),'command':cmd,'environment_overrides':{k:env[k] for k in ['GOWORK','GOTOOLCHAIN','GOPROXY','GOSUMDB','GOMAXPROCS','GOMEMLIMIT','GOTMPDIR']},'child_pid':proc.pid,'child_reaped':True,'actual_exit_code':child_exit,'guard_stop_reason':reason,'minimum_observed_free_bytes':minfree,'maximum_observed_own_GOTMPDIR_allocated_bytes':maxtmp,'maximum_observed_own_proof_allocated_bytes':maxown,'own_temporary_entries_removed_after_reap':scratch_before_cleanup,'own_GOTMPDIR_empty':not any(scratch.iterdir()),'source_after_sha256':source_after,'source_unchanged':source_after==expected}
  (proof/(stage+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
  print(json.dumps(receipt,sort_keys=True))
if reason: raise SystemExit(124)
raise SystemExit(child_exit)
