from pathlib import Path
import datetime,hashlib,json,os,re,shutil,signal,subprocess,time
P=Path(__file__).resolve().parent;ROOT=Path('/Users/tianpan/projects/bex7');os.umask(0o077)
floor=1<<30;cap=896<<20;margin=128<<20;start=shutil.disk_usage(P).free
assert start>=floor+(512<<20)+margin,('realDB budget does not fit',start)
workflow=(ROOT/'.github/workflows/backend-test.yml').read_text()
images=[]
for pattern in [r'postgres:17@sha256:[0-9a-f]{64}',r'openfga/openfga:[^ @\n]+@sha256:[0-9a-f]{64}',r'quay.io/openbao/openbao:[^ @\n]+@sha256:[0-9a-f]{64}',r'grafana/loki:[^ @\n]+@sha256:[0-9a-f]{64}']:
 m=re.search(pattern,workflow);assert m,pattern;images.append(m[0])
if not shutil.which('promtool'):
 images.append(re.search(r'^promtool_image=(.+)$',(ROOT/'scripts/backend-test-deps.sh').read_text(),re.M)[1])
for image in images:
 r=subprocess.run(['docker','image','inspect',image],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15)
 if r.returncode!=0:assert image=='grafana/loki:3.6.7@sha256:3c8fd3570dd9219951a60d3f919c7f31923d10baee578b77bc26c4a0b32d092d',('unqualified missing dependency; stop before automatic pull',image)
prefix='bex-test-'+hashlib.sha1(str(ROOT).encode()).hexdigest()[:8]
handoff=Path('/private/tmp/bex-w8-store-focused-amended-20261031-d050yrks/DEPENDENCY-HANDOFF.json')
assert hashlib.sha256(handoff.read_bytes()).hexdigest()=='a50ddfb44727184457cc107a99354c7ad8a5c7c4f87a00f6ae4d2892974d3da2'
expected=json.loads(handoff.read_text())['fresh4_after_focused_tests']
rows=subprocess.check_output(['docker','ps','-a','--format','{{.Names}}'],text=True).splitlines();existing={x for x in rows if x.startswith(prefix)}
if existing:
 assert existing=={x['name'].lstrip('/') for x in expected},'unexpected checkout dependency names; do not reset'
 current=json.loads(subprocess.check_output(['docker','inspect',*sorted(existing)],text=True))
 mapping={x['name']:x for x in expected}
 for c in current:
  e=mapping[c['Name']];assert c['Id']==e['id'] and c['Image']==e['config_id'] and c['Config']['Image']==e['image_ref'] and c['Created']==e['created'],'dependency ownership changed; do not reset'
(P/'OWNED-RESET-HANDOFF.json').write_text(json.dumps({'handoff_sha256':hashlib.sha256(handoff.read_bytes()).hexdigest(),'preexisting_names':sorted(existing),'only_exact_previously_owned_dependencies_may_be_refreshed':True},indent=2)+'\n')
env=dict(os.environ,GOWORK='off',GOTOOLCHAIN='local',GOPROXY='off',GOSUMDB='off',GOMAXPROCS='2',GOMEMLIMIT='512MiB',GOTMPDIR=str(P/'tmp'),TMPDIR=str(P/'tmp')+'/')
env.pop('KUBECONFIG',None);env.pop('BEX_TEST_PG_IMAGE',None)
source={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['lego/backend/internal/apps/free_hours.go','lego/backend/internal/apps/free_hours_test.go','lego/backend/internal/store/webhooks_display_name_pg_test.go','lego/backend/internal/store/workspace_creation_account_pg_test.go','lego/backend/internal/store/workspace_state_cascades_pg_test.go','lego/backend/internal/usage/service.go','lego/backend/internal/usage/service_test.go','lego/go.work.sum']}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
(P/'BUDGET.json').write_text(json.dumps({'reserve':floor,'own_cap':cap,'margin':margin,'start_free':start,'tmp_cap':768<<20,'observer':'one-second physical-free/owned-tmp observation, not a kernel quota','scope':'unmodified mandatory ship-gates.sh with exact preexisting CI-pinned real dependencies; no automatic image/module/toolchain downloads','head':head,'sources':source,'checkout_prefix':prefix},indent=2)+'\n')
started=time.monotonic();stop=None;samples=[]
with (P/'full-gate.log').open('wb') as log:
 process=subprocess.Popen(['bash','scripts/ship-gates.sh','origin/main'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  (P/'PROCESS.json').write_text(json.dumps({'pid':process.pid,'pgid':process.pid,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
  while process.poll() is None:
   free=shutil.disk_usage(P).free;own=sum(x.stat().st_blocks*512 for x in (P/'tmp').rglob('*') if x.is_file());samples.append({'seconds':round(time.monotonic()-started,3),'physical_free':free,'owned_tmp':own})
   if free<=floor+margin or start-free>=832<<20 or own>=704<<20 or time.monotonic()-started>1800:
    stop='bounded resource/deadline stop';os.killpg(process.pid,signal.SIGTERM);break
   time.sleep(1)
  try:code=process.wait(timeout=15)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);code=process.wait()
 finally:
  try:os.killpg(process.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  if process.poll() is None:
   try:process.wait(timeout=5)
   except subprocess.TimeoutExpired:
    try:os.killpg(process.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    process.wait()
  for _ in range(50):
   try:os.killpg(process.pid,0)
   except ProcessLookupError:break
   time.sleep(.1)
  else:
   try:os.killpg(process.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   raise RuntimeError('owned command process group remained after cleanup; investigate exact group')
(P/'samples.json').write_text(json.dumps(samples,indent=2)+'\n')
current={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in source};assert current==source,'source changed during required gate'
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'command':['bash','scripts/ship-gates.sh','origin/main'],'exit':code,'stop':stop,'seconds':round(time.monotonic()-started,3),'minimum_free':min(x['physical_free'] for x in samples),'peak_owned_tmp':max(x['owned_tmp'] for x in samples),'source_unchanged':True,'log_sha256':hashlib.sha256((P/'full-gate.log').read_bytes()).hexdigest(),'dependency_cleanup_expected':code==0 and stop is None,'scope':'full real Postgres/OpenFGA/OpenBao/Loki backend suite plus main-CI advisory; no production resources/auth'}
(P/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if code==0 and stop is None:
 remaining=subprocess.check_output(['docker','ps','-a','--format','{{.Names}}'],text=True).splitlines();assert not any(x.startswith(prefix) for x in remaining),'own dependencies remain after successful gate'
 shutil.rmtree(P/'tmp');print('success: exact checkout dependency names absent; owned temporary tree removed',flush=True)
else:print('gate not passed; retained exact owned dependency/temp evidence for root diagnosis',flush=True)

if code==0 and stop is None:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==head
 assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT).strip()
 if 'ship-gates: warning: main is red' in (P/'full-gate.log').read_text():
  print('gate passed; main-CI advisory needs root diagnosis before push',flush=True)
 else:
  push=subprocess.run(['git','push','origin','main'],cwd=ROOT,capture_output=True,text=True,timeout=90)
  (P/'PUSH.json').write_text(json.dumps({'head':head,'exit':push.returncode,'stdout':push.stdout,'stderr':push.stderr},indent=2)+'\n')
  print(json.dumps({'push_exit':push.returncode,'head':head,'needs_rebase':push.returncode!=0}),flush=True)
