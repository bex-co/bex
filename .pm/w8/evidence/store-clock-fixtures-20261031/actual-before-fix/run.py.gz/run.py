from pathlib import Path
import datetime,hashlib,json,os,re,shutil,signal,subprocess,time
P=Path(__file__).resolve().parent;ROOT=Path('/Users/tianpan/projects/bex7');os.umask(0o077)
floor=1<<30;cap=1<<30;margin=128<<20;start=shutil.disk_usage(P).free
assert start>=floor+cap+margin,('realDB budget does not fit',start)
workflow=(ROOT/'.github/workflows/backend-test.yml').read_text()
images=[]
for pattern in [r'postgres:17@sha256:[0-9a-f]{64}',r'openfga/openfga:[^ @\n]+@sha256:[0-9a-f]{64}',r'quay.io/openbao/openbao:[^ @\n]+@sha256:[0-9a-f]{64}',r'grafana/loki:[^ @\n]+@sha256:[0-9a-f]{64}']:
 m=re.search(pattern,workflow);assert m,pattern;images.append(m[0])
if not shutil.which('promtool'):
 images.append(re.search(r'^promtool_image=(.+)$',(ROOT/'scripts/backend-test-deps.sh').read_text(),re.M)[1])
for image in images:
 r=subprocess.run(['docker','image','inspect',image],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15);assert r.returncode==0,('required pinned dependency image absent; do not auto-pull under this budget',image)
prefix='bex-test-'+hashlib.sha1(str(ROOT).encode()).hexdigest()[:8]
rows=subprocess.check_output(['docker','ps','-a','--format','{{.Names}}'],text=True).splitlines();assert not any(x.startswith(prefix) for x in rows),'existing checkout test dependencies are not this run'
env=dict(os.environ,GOWORK='off',GOTOOLCHAIN='local',GOPROXY='off',GOSUMDB='off',GOMAXPROCS='2',GOMEMLIMIT='512MiB',GOTMPDIR=str(P/'tmp'),TMPDIR=str(P/'tmp')+'/')
env.pop('KUBECONFIG',None);env.pop('BEX_TEST_PG_IMAGE',None)
source={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['lego/backend/internal/apps/free_hours.go','lego/backend/internal/apps/free_hours_test.go','lego/go.work.sum']}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
(P/'BUDGET.json').write_text(json.dumps({'reserve':floor,'own_cap':cap,'margin':margin,'start_free':start,'tmp_cap':768<<20,'observer':'one-second physical-free/owned-tmp observation, not a kernel quota','scope':'unmodified mandatory ship-gates.sh with exact preexisting CI-pinned real dependencies; no automatic image/module/toolchain downloads','head':head,'sources':source,'checkout_prefix':prefix},indent=2)+'\n')
started=time.monotonic();stop=None;samples=[]
with (P/'full-gate.log').open('wb') as log:
 process=subprocess.Popen(['bash','scripts/ship-gates.sh','origin/main'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  (P/'PROCESS.json').write_text(json.dumps({'pid':process.pid,'pgid':process.pid,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
  while process.poll() is None:
   free=shutil.disk_usage(P).free;own=sum(x.stat().st_blocks*512 for x in (P/'tmp').rglob('*') if x.is_file());samples.append({'seconds':round(time.monotonic()-started,3),'physical_free':free,'owned_tmp':own})
   if free<=floor+margin or start-free>=960<<20 or own>=704<<20 or time.monotonic()-started>1800:
    stop='bounded resource/deadline stop';os.killpg(process.pid,signal.SIGTERM);break
   time.sleep(1)
  try:code=process.wait(timeout=15)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);code=process.wait()
 finally:
  try:os.killpg(process.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  if process.poll() is None:
   try:process.wait(timeout=5)
   except subprocess.TimeoutExpired:
    try:os.killpg(process.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    process.wait()
  for _ in range(50):
   try:os.killpg(process.pid,0)
   except ProcessLookupError:break
   time.sleep(.1)
  else:
   try:os.killpg(process.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   raise RuntimeError('owned command process group remained after cleanup; investigate exact group')
(P/'samples.json').write_text(json.dumps(samples,indent=2)+'\n')
current={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in source};assert current==source,'source changed during required gate'
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'command':['bash','scripts/ship-gates.sh','origin/main'],'exit':code,'stop':stop,'seconds':round(time.monotonic()-started,3),'minimum_free':min(x['physical_free'] for x in samples),'peak_owned_tmp':max(x['owned_tmp'] for x in samples),'source_unchanged':True,'log_sha256':hashlib.sha256((P/'full-gate.log').read_bytes()).hexdigest(),'dependency_cleanup_expected':code==0 and stop is None,'scope':'full real Postgres/OpenFGA/OpenBao/Loki backend suite plus main-CI advisory; no production resources/auth'}
(P/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if code==0 and stop is None:
 remaining=subprocess.check_output(['docker','ps','-a','--format','{{.Names}}'],text=True).splitlines();assert not any(x.startswith(prefix) for x in remaining),'own dependencies remain after successful gate'
 shutil.rmtree(P/'tmp');print('success: exact checkout dependency names absent; owned temporary tree removed',flush=True)
else:print('gate not passed; retained exact owned dependency/temp evidence for root diagnosis',flush=True)
