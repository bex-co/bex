import datetime,hashlib,json,os,re,shlex,shutil,signal,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=Path('/Users/tianpan/projects/bex7')
B=json.loads((P/'SCOPE-AMENDMENT.json').read_text());TMP=P/'tmp'
def interrupt(sig,frame):raise KeyboardInterrupt('runner signal '+str(sig))
for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,interrupt)
def allocation(path):
 n=path.lstat().st_blocks*512
 if path.is_dir():
  for child in path.iterdir():n+=allocation(child)
 return n
def source_hashes():return {name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in B['source_files']}
expected={name:row['sha256'] for name,row in B['source_files'].items()}
if source_hashes()!=expected:raise SystemExit('source precondition changed')
free=shutil.disk_usage(ROOT).free
if free<B['start_threshold_bytes']:raise SystemExit('fresh amended launch threshold not met')
B['actual_run_start_free_bytes']=free;B['actual_run_started_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(P/'RUN-START.json').write_text(json.dumps(B,indent=2)+'\n')
env=os.environ.copy();env.update({'GOWORK':'off','GOTOOLCHAIN':'local','GOPROXY':'off','GOSUMDB':'off','BEX_TEST_REQUIRE_DEPS':'1','GOMAXPROCS':'2','GOMEMLIMIT':'512MiB','GOTMPDIR':str(TMP),'TMPDIR':str(TMP)+'/'})
env.pop('BEX_TEST_PG_IMAGE',None);env.pop('KUBECONFIG',None)
command=['/opt/homebrew/bin/go','test','-p','1','-mod=readonly','-count=1','./internal/store','-run',B['focused_pattern'],'-v']
shell='set -euo pipefail\nbash scripts/backend-test-deps.sh up\neval "$(bash scripts/backend-test-deps.sh env)"\ncd lego/backend\nexec '+shlex.join(command)
# The maintained env helper expands only inside this shell; its credential values never enter receipts.
phases=[('focused',['bash','-c',shell],ROOT),('lint',[str(ROOT/'lego/operator/bin/golangci-lint'),'run','./internal/store','--timeout=3m'],ROOT/'lego/backend')]
results=[];overall_started=time.monotonic()
for label,cmd,cwd in phases:
 if source_hashes()!=expected:raise SystemExit('source changed before phase')
 if any(TMP.iterdir()):raise SystemExit('own temp not empty before phase')
 nowfree=shutil.disk_usage(ROOT).free;decline=max(0,free-nowfree)
 if label=='lint' and (nowfree<=B['active_free_floor_bytes'] or B['new_own_cap_bytes']-decline<128*1024**2):
  results.append({'phase':label,'status':'NOT_STARTED_REMAINING_CAPACITY','free_bytes':nowfree,'remaining_own_cap_bytes':B['new_own_cap_bytes']-decline});break
 proc=None;stop=None;started=time.monotonic();minfree=nowfree;maxtmp=0;maxdecline=decline
 try:
  with (P/(label+'.log')).open('wb') as log,(P/(label+'.samples.jsonl')).open('w') as samples:
   mask=signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGTERM,signal.SIGINT})
   try:proc=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   finally:signal.pthread_sigmask(signal.SIG_SETMASK,mask)
   while True:
    avail=shutil.disk_usage(ROOT).free;temp=allocation(TMP);own=allocation(P);growth=free-avail
    minfree=min(minfree,avail);maxtmp=max(maxtmp,temp);maxdecline=max(maxdecline,growth)
    samples.write(json.dumps({'seconds':round(time.monotonic()-started,3),'free_bytes':avail,'own_tmp_allocated_bytes':temp,'own_proof_allocated_bytes':own,'cumulative_free_decline_bytes':growth})+'\n');samples.flush()
    if avail<=B['active_free_floor_bytes']:stop='physical free floor+128MiB'
    elif growth>=B['total_free_decline_stop_bytes']:stop='cumulative totalfree decline448MiB, attribution not assumed'
    elif temp>=B['tmp_stop_bytes']:stop='own temporary allocation320MiB stop'
    elif own>=B['new_own_cap_bytes']:stop='own physical512MiB cap'
    elif time.monotonic()-started>=B['phase_seconds']:stop='fifteen-minute phase bound'
    if proc.poll() is not None:break
    if stop:
     os.killpg(proc.pid,signal.SIGTERM)
     try:proc.wait(timeout=5)
     except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
     break
    time.sleep(1)
 except BaseException:
  if proc is not None and proc.poll() is None:
   os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
  raise
 finally:
  if proc is not None:
   code=proc.wait()
   remaining=[]
   ps=subprocess.run(['ps','-axo','pid=,ppid=,pgid=,stat='],capture_output=True,text=True,check=True)
   for line in ps.stdout.splitlines():
    fields=line.split()
    if len(fields)==4 and int(fields[2])==proc.pid:remaining.append({'pid':int(fields[0]),'state':fields[3]})
   removed=[]
   if not remaining:
    for path in list(TMP.iterdir()):
     removed.append(path.name)
     if path.is_dir() and not path.is_symlink():shutil.rmtree(path)
     else:path.unlink()
   result={'phase':label,'command':cmd,'actual_exit_code':code,'guard_stop_reason':stop,'duration_seconds':round(time.monotonic()-started,3),'child_pid':proc.pid,'child_reaped':True,'remaining_exact_process_group':remaining,'own_tmp_removed_after_reap':removed,'own_tmp_empty':not any(TMP.iterdir()),'minimum_observed_free_bytes':minfree,'maximum_observed_own_tmp_bytes':maxtmp,'maximum_observed_cumulative_free_decline_bytes':maxdecline,'source_after_sha256':source_hashes(),'source_unchanged':source_hashes()==expected,'opaque_dependency_env':'Consumed by maintained helper inside shell; no values persisted.','environment_overrides':{k:env[k] for k in ['GOWORK','GOTOOLCHAIN','GOPROXY','GOSUMDB','BEX_TEST_REQUIRE_DEPS','GOMAXPROCS','GOMEMLIMIT','GOTMPDIR','TMPDIR']}}
   (P/(label+'.receipt.json')).write_text(json.dumps(result,indent=2)+'\n');results.append(result);print(json.dumps(result,sort_keys=True),flush=True)
 if stop or code!=0 or remaining or not result['source_unchanged']:break
 if label=='focused':
  log=(P/'focused.log').read_text();runs=re.findall(r'^=== RUN   ([^\s/]+)$',log,re.M);passes=re.findall(r'^--- PASS: ([^\s/]+) ',log,re.M);skips=re.findall(r'^\s*--- SKIP:.*$',log,re.M)
  parsed={'top_level_run_names':runs,'top_level_pass_names':passes,'all_RUN_lines':len(re.findall(r'^=== RUN',log,re.M)),'all_SKIP_lines':skips,'expected_exact_top_level_names':B['expected_top_level_test_names'],'all7_pass_no_skip':set(runs)==set(passes)==set(B['expected_top_level_test_names']) and len(runs)==len(passes)==7 and not skips}
  (P/'focused-case-count.json').write_text(json.dumps(parsed,indent=2)+'\n')
  if not parsed['all7_pass_no_skip']:raise SystemExit('focused actual case/skip contract failed')
(P/'PHASES.json').write_text(json.dumps({'phases':results,'elapsed_seconds':round(time.monotonic()-overall_started,3),'exact4_refreshed_dependencies_left_for_root':True,'Loki_alias_was_not_retagged_or_pulled':True},indent=2)+'\n')
raise SystemExit(0 if len(results)==2 and all(x.get('actual_exit_code')==0 and not x.get('guard_stop_reason') for x in results) else 1)
