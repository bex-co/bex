package driver

import (
	"fmt"
	"github.com/hetznercloud/csi-driver/internal/volumes"
	"strconv"
)

func boundedBytesFromSecret(secret map[string]string) (int64, error) {
	if secret["boundedFilesystem"] != "ext4-v1" {
		return 0, fmt.Errorf("bounded filesystem requires node capacity Secret")
	}
	if secret[encryptionPassphraseKey] == "" {
		return 0, fmt.Errorf("bounded filesystem requires encryption passphrase")
	}
	bytes, err := strconv.ParseInt(secret["filesystemSizeBytes"], 10, 64)
	if err != nil {
		return 0, fmt.Errorf("invalid filesystemSizeBytes")
	}
	if err = volumes.ValidateFilesystemBytes(bytes); err != nil {
		return 0, err
	}
	return bytes, nil
}
