package driver

import (
	"context"
	"testing"

	proto "github.com/container-storage-interface/spec/lib/go/csi"
	"github.com/hetznercloud/csi-driver/internal/mock"
	"github.com/hetznercloud/csi-driver/internal/volumes"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

// Private regression against unchanged published source; no real device/API.
func TestBoundedPublishMissingPassphraseMustRefuse(t *testing.T) {
	for _, empty := range []bool{false, true} {
		name := "missing"
		if empty {
			name = "empty"
		}
		t.Run(name, func(t *testing.T) {
			env := newNodeServerTestEnv()
			calls := 0
			env.volumeMountService.PublishFunc = func(_ context.Context, _, _ string, opts volumes.MountOpts) error {
				calls++
				t.Logf("actual mount callback: FilesystemBytes=%d EncryptionPassphraseEmpty=%t", opts.FilesystemBytes, opts.EncryptionPassphrase == "")
				return nil
			}
			secret := map[string]string{"boundedFilesystem": "ext4-v1", "filesystemSizeBytes": "1073741824"}
			if empty {
				secret[encryptionPassphraseKey] = ""
			}
			_, err := env.service.NodePublishVolume(env.ctx, &proto.NodePublishVolumeRequest{
				VolumeId: "bounded-ext4-v1:42", TargetPath: "owned-synthetic-target",
				VolumeCapability: boundedCapability(), PublishContext: map[string]string{"devicePath": "owned-synthetic-device"},
				VolumeContext: map[string]string{"boundedFilesystem": "ext4-v1"}, Secrets: secret,
			})
			if status.Code(err) != codes.InvalidArgument || calls != 0 {
				t.Fatalf("missing passphrase must fail before mount: status=%s mountCalls=%d", status.Code(err), calls)
			}
		})
	}
}

type missingKeyResizeCapture struct {
	*mock.VolumeResizeService
	calls int
}

func (capture *missingKeyResizeCapture) ResizeBounded(context.Context, string, int64) error {
	capture.calls++
	return nil
}

func TestBoundedExpandMissingPassphraseMustRefuse(t *testing.T) {
	for _, empty := range []bool{false, true} {
		name := "missing"
		if empty {
			name = "empty"
		}
		t.Run(name, func(t *testing.T) {
			env := newNodeServerTestEnv()
			capture := &missingKeyResizeCapture{VolumeResizeService: env.volumeResizeService}
			env.service.volumeResizeService = capture
			env.volumeMountService.PathExistsFunc = func(string) (bool, error) { return true, nil }
			secret := map[string]string{"boundedFilesystem": "ext4-v1", "filesystemSizeBytes": "5368709120"}
			if empty {
				secret[encryptionPassphraseKey] = ""
			}
			_, err := env.service.NodeExpandVolume(env.ctx, &proto.NodeExpandVolumeRequest{
				VolumeId: "bounded-ext4-v1:42", VolumePath: "owned-synthetic-target", CapacityRange: &proto.CapacityRange{RequiredBytes: 5 << 30},
				VolumeCapability: boundedCapability(), Secrets: secret,
			})
			t.Logf("actual expand callback count=%d status=%s", capture.calls, status.Code(err))
			if status.Code(err) != codes.InvalidArgument || capture.calls != 0 {
				t.Fatalf("missing passphrase must fail before resize: status=%s resizeCalls=%d", status.Code(err), capture.calls)
			}
		})
	}
}

func TestBoundedAuditLegacyPlaintextStillAllowed(t *testing.T) {
	env := newNodeServerTestEnv()
	publish, resize := 0, 0
	env.volumeMountService.PublishFunc = func(_ context.Context, _, _ string, opts volumes.MountOpts) error {
		publish++
		if opts.FilesystemBytes != 0 || opts.EncryptionPassphrase != "" {
			t.Fatal("legacy plaintext options changed")
		}
		return nil
	}
	env.volumeMountService.PathExistsFunc = func(string) (bool, error) { return true, nil }
	env.volumeResizeService.ResizeFunc = func(context.Context, string) error { resize++; return nil }
	_, err := env.service.NodePublishVolume(env.ctx, &proto.NodePublishVolumeRequest{VolumeId: "42", TargetPath: "owned-synthetic-target", VolumeCapability: boundedCapability(), PublishContext: map[string]string{"devicePath": "owned-synthetic-device"}})
	if err != nil {
		t.Fatal(err)
	}
	_, err = env.service.NodeExpandVolume(env.ctx, &proto.NodeExpandVolumeRequest{VolumeId: "42", VolumePath: "owned-synthetic-target", CapacityRange: &proto.CapacityRange{RequiredBytes: 5 << 30}, VolumeCapability: boundedCapability()})
	if err != nil || publish != 1 || resize != 1 {
		t.Fatalf("legacy plaintext: publish=%d resize=%d err=%v", publish, resize, err)
	}
	t.Logf("legacy plaintext controls: publish=%d resize=%d", publish, resize)
}
