#!/bin/sh
set -eu
major="$1"; minor="$2"; mapping="$3"
printf 'tenant-status\n'
awk '/^(CapInh|CapPrm|CapEff|CapBnd|CapAmb|NoNewPrivs):/' /proc/self/status
test ! -e /disk-b
test ! -e "/dev/mapper/$mapping"
test "$(cat /disk/sentinel)" = owned-t006-volume-A
mkdir /tmp/mount-attempt
deny() {
  name="$1"; shift
  if "$@" > /tmp/attempt.log 2>&1; then
    printf 'FAIL unexpected success: %s\n' "$name"
    exit 1
  fi
  printf 'denied %s: ' "$name"
  head -c 512 /tmp/attempt.log
  printf '\n'
}
deny mknod mknod /disk/attempt-node b "$major" "$minor"
deny open-loop dd if=/disk/device-inode-a of=/dev/null bs=1 count=1
deny resize resize2fs /disk/device-inode-a 128M
deny reformat mkfs.ext4 -F /disk/device-inode-a
deny mount mount -t ext4 /disk/device-inode-a /tmp/mount-attempt
dd if=/dev/zero of=/disk/tenant-normal-write-"$$" bs=1M count=1
stat -f -c 'filesystem block-size=%S blocks=%b' /disk
printf 'PASS: ordinary write works; device/resize/reformat/mount denied\n'
