#!/usr/bin/env python3
"""Disposable local capability/device-isolation proof, not Kubernetes emulation."""
import hashlib
import json
from pathlib import Path
import re
import secrets
import shutil
import subprocess
import time

BASE = Path(__file__).resolve().parent
REPO = Path('/Users/tianpan/projects/bex7')
IMAGE = 'ghcr.io/bex-co/bex-operator@sha256:0807342734d3c327f689f4054916646562199d36d3e29153bb6cb871e4452ee7'
nonce = secrets.token_hex(8)
proof = BASE / ('isolation-' + nonce)
proof.mkdir(mode=0o700)
owner, holder, volume = None, None, None
attackers = []
receipt = {'schema': 'm144-local-isolation-v1', 'nonce': nonce, 'publishedRuntime': IMAGE,
           'scope': 'two own small local loop/LUKS volumes; no Kubernetes, cloud, real tenant, 1GiB or billing claim',
           'beforeFreeBytes': shutil.disk_usage(BASE).free}
assert receipt['beforeFreeBytes'] >= 6 * 1024**3, 'stop: preserve other worker and host disk margin'

def docker(*args, check=True):
    result = subprocess.run(['docker', '--config', str(BASE / 'docker-config'), '--host', 'unix:///Users/tianpan/.orbstack/run/docker.sock', *args], text=True, capture_output=True, timeout=90)
    if check and result.returncode:
        print(result.stderr, flush=True)
        result.check_returncode()
    return result

def metadata(container):
    return json.loads(docker('inspect', container, '--format', '{{json .}}').stdout)

def await_file(name, container):
    until = time.monotonic() + 30
    while time.monotonic() < until:
        path = proof / name
        if path.exists():
            return json.loads(path.read_text())
        state = metadata(container)['State']
        if not state['Running']:
            raise RuntimeError('owned owner exited before ' + name)
        time.sleep(.1)
    raise RuntimeError('bounded local owner wait expired: ' + name)

try:
    policy_path = REPO / 'lego/types/v1alpha1/container_policy.go'
    policy = policy_path.read_text()
    table = re.search(r'case ContainerPolicyRenderV1:\s*return \[\]string\{([^}]+)\}', policy)
    caps = re.findall(r'"([A-Z_]+)"', table[1])
    assert caps and not {'SYS_ADMIN', 'SYS_RESOURCE', 'MKNOD'} & set(caps)
    receipt['renderCapabilities'] = caps
    receipt['policySourceSha256'] = hashlib.sha256(policy_path.read_bytes()).hexdigest()
    if docker('image', 'inspect', IMAGE, check=False).returncode:
        pulled = docker('pull', IMAGE)
        (proof / 'anonymous-fixed-runtime-pull.log').write_text(pulled.stdout + pulled.stderr)
    holder = docker('create', '--name', 'bex-m144-t006-holder-' + nonce, '--label', 'bex.local-proof=' + nonce,
                    '--network', 'none', '--entrypoint', '/bin/true', IMAGE).stdout.strip()
    receipt['holderId'] = holder
    owner = docker('run', '-d', '--pull=never', '--name', 'bex-m144-t006-owner-' + nonce,
                   '--label', 'bex.local-proof=' + nonce, '--privileged', '--network', 'none',
                   '--memory', '512m', '--tmpfs', '/scratch:rw,size=384m', '--tmpfs', '/run:rw,size=16m', '--tmpfs', '/tmp:rw,size=16m',
                   '--mount', 'type=bind,src=' + str(proof) + ',dst=/proof',
                   '--mount', 'type=bind,src=' + str(BASE / 'isolation-owner.sh') + ',dst=/owner.sh,readonly',
                   '--entrypoint', '/bin/sh', IMAGE, '/owner.sh', nonce).stdout.strip()
    receipt['ownerId'] = owner
    ready = await_file('ready.json', owner)
    receipt['ownedDevices'] = ready
    owner_pid = metadata(owner)['State']['Pid']
    volume = 'bex-m144-t006-volume-a-' + nonce
    docker('volume', 'create', '--label', 'bex.local-proof=' + nonce, '--driver', 'local',
           '--opt', 'type=ext4', '--opt', 'device=/proc/' + str(owner_pid) + '/root/dev/mapper/' + ready['mappingA'], '--opt', 'o=rw', volume)
    receipt['ownedVolumeA'] = volume
    for label, allowed in [('capless', []), ('render', caps)]:
        state = metadata(owner)['State']
        assert state['Running'] and state['Pid'] == owner_pid
        # Mount only the same owned A filesystem through Docker's local driver.
        args = ['create', '--pull=never', '--name', 'bex-m144-t006-' + label + '-' + nonce,
                '--label', 'bex.local-proof=' + nonce, '--network', 'none', '--read-only', '--cap-drop', 'ALL',
                '--security-opt', 'no-new-privileges=true', '--pids-limit', '64', '--memory', '128m',
                '--tmpfs', '/tmp:rw,size=16m', '--mount', 'type=volume,src=' + volume + ',dst=/disk',
                '--mount', 'type=bind,src=' + str(BASE / 'isolation-attacker.sh') + ',dst=/attack.sh,readonly',
                '--entrypoint', '/bin/sh']
        for capability in allowed:
            args.extend(['--cap-add', capability])
        args.extend(['kindest/node:v1.36.1', '/attack.sh', str(ready['majorA']), str(ready['minorA']), ready['mappingA']])
        attacker = docker(*args).stdout.strip()
        attackers.append(attacker)
        config = metadata(attacker)['HostConfig']
        assert not config['Privileged'] and not config['Devices'] and not config['DeviceCgroupRules']
        receipt[label + 'Policy'] = {key: config[key] for key in ('Privileged', 'CapAdd', 'CapDrop', 'Devices', 'DeviceCgroupRules', 'SecurityOpt', 'NetworkMode')}
        result = docker('start', '--attach', attacker, check=False)
        (proof / (label + '.log')).write_text(result.stdout + result.stderr)
        exit_code = metadata(attacker)['State']['ExitCode']
        receipt[label + 'Exit'] = exit_code
        assert exit_code == 0, label + ' negative isolation proof failed'
    (proof / 'check').touch()
    receipt['verification'] = await_file('checked.json', owner)
finally:
    for container in attackers:
        docker('rm', '-f', container, check=False)
    if volume:
        removed = docker('volume', 'rm', volume, check=False)
        receipt['ownedVolumeRemoved'] = removed.returncode == 0
    if owner:
        (proof / 'stop').touch()
        until = time.monotonic() + 20
        while metadata(owner)['State']['Running'] and time.monotonic() < until:
            time.sleep(.1)
        state = metadata(owner)['State']
        receipt['ownerFinalState'] = {key: state[key] for key in ('Running', 'ExitCode')}
        logs = docker('logs', owner, check=False)
        (proof / 'owner.log').write_text(logs.stdout + logs.stderr)
        receipt['cleanup'] = json.loads((proof / 'cleanup.json').read_text()) if (proof / 'cleanup.json').exists() else {'state': 'unproved; owner retained for own cleanup'}
        if not state['Running'] and receipt['cleanup'].get('cleanupExit') == 0:
            docker('rm', owner)
    receipt['afterFreeBytes'] = shutil.disk_usage(BASE).free
    if holder:
        docker('rm', holder)
    (proof / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(proof)

assert receipt['cleanup']['cleanupExit'] == 0 and not receipt['ownerFinalState']['Running']
assert receipt['afterFreeBytes'] >= 4 * 1024**3
