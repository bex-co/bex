"""Fixed private m144 deadline cleanup; importing performs no I/O or HTTP."""
from datetime import datetime, timedelta, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent


def when(value):
    value = datetime.fromisoformat(value.replace('Z', '+00:00'))
    assert value.tzinfo is not None
    return value.astimezone(timezone.utc)


def target(spec, ledger):
    if not ledger.get('create_intent'):
        return None
    intent = ledger['create_intent']
    created, expiry = when(intent['created_at']), when(ledger['fixture_expires_at'])
    assert created < expiry <= created + timedelta(seconds=7200)
    assert (intent['name'], intent['workspace']) == (spec['name'], spec['workspace'])
    if not ledger.get('owned'):
        return {'state': 'ambiguous-create', 'cleanupAt': expiry - timedelta(seconds=900), 'expiresAt': expiry}
    proof = ledger['create_proof']
    assert proof['HTTP'] == 201 and proof['request']['body_sha256'] == intent['body_sha256']
    service = json.loads(proof['response'])['service']
    assert service == ledger['owned']
    assert service['id'] not in ledger['baseline_ids'] + spec['protected_existing_services'] + spec['historical_deleted_215_ids']
    assert (service['name'], service['ownerId'], service['serviceDetails']['plan']) == (spec['name'], spec['workspace'], 'starter')
    assert service['serviceDetails']['disk'] == {'name': spec['disk_name'], 'mountPath': spec['mount'], 'sizeGB': 1}
    return {'state': 'owned', 'serviceId': service['id'], 'diskId': ledger.get('disk_id'), 'cleanupAt': expiry - timedelta(seconds=900), 'expiresAt': expiry, 'proofSha256': hashlib.sha256(proof['response'].encode()).hexdigest()}


def decision(spec, ledger, now):
    owned = target(spec, ledger)
    if owned is None:
        return 'await-create', owned
    if ledger.get('cleanup_api_verified'):
        return 'complete', owned
    if ledger.get('cleanup_response', {}).get('HTTP') == 204:
        return 'cleanup-check', owned
    if ledger.get('cleanup_intent'):
        return 'cleanup-check', owned
    if now < owned['cleanupAt']:
        return 'wait', owned
    return ('cleanup' if owned['state'] == 'owned' else 'ambiguous-create'), owned


def main():
    assert __debug__
    os.umask(0o077)
    with (ROOT / 'cleanup-watchdog.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        spec = json.loads((ROOT / 'spec.json').read_text())
        prepare_deadline = time.monotonic() + 600
        last = None
        busy_since = None
        while True:
            ledger = json.loads((ROOT / 'ledger.json').read_text())
            now = datetime.now(timezone.utc)
            action, owned = decision(spec, ledger, now)
            state = {'action': action, 'at': now.isoformat(), 'run': spec['run'], 'owned': {k: v.isoformat() if isinstance(v, datetime) else v for k, v in (owned or {}).items()}}
            if action != last:
                raw = json.dumps(state, indent=2) + '\n'
                temporary = ROOT / 'cleanup-watchdog-state.next'
                temporary.write_text(raw)
                temporary.replace(ROOT / 'cleanup-watchdog-state.json')
                print(json.dumps(state), flush=True)
                last = action
            if action == 'complete':
                return
            if action.startswith('ambiguous-'):
                raise RuntimeError(action + ': root reconciliation required; no mutation replayed')
            if action == 'await-create' and time.monotonic() >= prepare_deadline:
                raise RuntimeError('no actual create intent within bounded preparation window')
            if owned and now > owned['expiresAt'] + timedelta(seconds=60):
                raise RuntimeError('deadline exceeded without verified API absence; root cleanup required')
            if action in ('cleanup', 'cleanup-check'):
                remaining = (owned['expiresAt'] + timedelta(seconds=60) - now).total_seconds()
                if remaining <= 0:
                    raise RuntimeError('cleanup deadline reached; state remains unknown')
                timed_out = False
                try:
                    result = subprocess.run([str(ROOT / 'q'), action], capture_output=True, timeout=min(300, remaining))
                    stdout, stderr, code = result.stdout, result.stderr, result.returncode
                except subprocess.TimeoutExpired as error:
                    timed_out = True
                    stdout, stderr, code = error.stdout or b'', error.stderr or b'', None
                stamp = time.time_ns()
                (ROOT / ('cleanup-watchdog-' + str(stamp) + '.txt')).write_bytes(stdout + stderr)
                if code != 0:
                    latest = json.loads((ROOT / 'ledger.json').read_text())
                    if action == 'cleanup-check' or latest.get('cleanup_intent'):
                        # Read-only pending/transport/timeout checks may repeat
                        # inside the fixed deadline. Never repeat the DELETE.
                        time.sleep(2)
                        continue
                    # A held writer lock precedes credentials, HTTP and mutation.
                    # Only that no-side-effect startup refusal can be retried.
                    busy = not timed_out and b'BlockingIOError' in stderr
                    busy_since = busy_since or time.monotonic()
                    if not busy or time.monotonic() - busy_since > 180:
                        raise RuntimeError('cleanup command failed before a DELETE intent; root reconciliation required')
                else:
                    busy_since = None
            time.sleep(2 if action in ('cleanup', 'cleanup-check') else 1)


if __name__ == '__main__':
    main()
