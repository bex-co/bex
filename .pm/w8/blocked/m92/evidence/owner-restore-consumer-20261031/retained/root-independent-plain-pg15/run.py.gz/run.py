from pathlib import Path
import subprocess,uuid,time,json,datetime,hashlib
root=Path('/private/tmp/bex-w8-restore-client-proof-20261031');name='bex-w8-restore-'+uuid.uuid4().hex[:12];events=[];container=None
script=Path('deploy/pg-operand/restore.sh').resolve();source_hash=hashlib.sha256(script.read_bytes()).hexdigest()
def run(args,check=True):
 p=subprocess.run(args,capture_output=True,text=True,timeout=45);events.append({'args':args,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 if check and p.returncode:raise RuntimeError(str(args[:3])+': '+p.stderr)
 return p
def execute(args,check=True):return run(['docker','exec',container,*args],check)
def sql(db,text,user='postgres'):return execute(['psql','-X','-At','-v','ON_ERROR_STOP=1','-U',user,'-d',db,'-c',text]).stdout.strip()
try:
 container=run(['docker','run','-d','--name',name,'--network','none','--memory','256m','--cpus','1','--label','co.bex.w8-restore='+name,'--tmpfs','/var/lib/postgresql/data:rw,size=128m','-e','POSTGRES_HOST_AUTH_METHOD=trust','f490b1e1368a']).stdout.strip()
 for attempt in range(30):
  if execute(['pg_isready','-U','postgres'],False).returncode==0:break
  time.sleep(.5)
 else:raise RuntimeError('owned Postgres not ready')
 versions=execute(['psql','--version']).stdout.strip()
 sql('postgres','CREATE ROLE app LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE;')
 for db in ['source','restored','failed','lob_target']:sql('postgres','CREATE DATABASE '+db+' OWNER app;')
 sql('source',"CREATE TABLE public.base (id integer PRIMARY KEY, payload text); INSERT INTO public.base VALUES(1,'你好'),(2,'quote '' and $'),(3,'row3');",'app')
 execute(['mkdir','-p','/tmp/export dir']);execute(['pg_dump','-U','app','-F','d','-f','/tmp/export dir/source database','source'])
 run(['docker','cp',str(script),container+':/tmp/restore.sh'])
 # A real psql sidecar error must roll back the entire previously restored dump.
 execute(['sh','-c',"printf '%s\n' 'SELECT 1/0;' > '/tmp/export dir/pg_ivm_restore.sql'"])
 failed=execute(['env','PGUSER=app','PGDATABASE=failed','sh','/tmp/restore.sh','/tmp/export dir/source database'],False)
 assert failed.returncode!=0 and 'division by zero'in failed.stderr
 assert sql('failed',"SELECT count(*) FROM pg_tables WHERE schemaname='public';",'app')=='0'
 # Generic sidecar transaction proof only, not a synthetic pg_ivm substitute.
 execute(['sh','-c',"printf '%s\n' 'CREATE VIEW public.proof AS SELECT count(*) AS n FROM public.base;' > '/tmp/export dir/pg_ivm_restore.sql'"])
 execute(['env','PGUSER=app','PGDATABASE=restored','sh','/tmp/restore.sh','/tmp/export dir/source database'])
 expected=sql('source','SELECT json_agg(t ORDER BY id) FROM public.base t;','app');actual=sql('restored','SELECT json_agg(t ORDER BY id) FROM public.base t;','app');assert actual==expected
 assert sql('restored',"SELECT current_user,current_setting('is_superuser'),n FROM proof;",'app')=='app|off|3'
 # A genuine directory archive containing a PostgreSQL large object is refused intact.
 sql('source',"SELECT lo_from_bytea(0,decode('0102030405','hex'));",'app');execute(['pg_dump','-U','app','-F','d','-f','/tmp/export dir/large objects','source'])
 rejected=execute(['env','PGUSER=app','PGDATABASE=lob_target','sh','/tmp/restore.sh','/tmp/export dir/large objects'],False);assert rejected.returncode==1 and 'Large-object archives'in rejected.stderr
 assert sql('lob_target',"SELECT count(*) FROM pg_tables WHERE schemaname='public';",'app')=='0'
 result={'state':'REAL_PG_CLIENT_TRANSACTION_CONTROLS_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'psql':versions,'restore_source_sha256':source_hash,'owned_container':container,'data_equal':True,'actual_sidecar_failure_rolled_back_all_dump_tables':True,'actual_large_object_dump_refused_without_target_tables':True,'actor':'app; is_superuser=off','limits':'Plain PostgreSQL15 only. No actual pg_ivm/Timescale/CNPG/image/publication/production claim.'}
 (root/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
finally:
 if container:
  cleanup=run(['docker','rm','-f',container],False);(root/'CLEANUP.json').write_text(json.dumps({'container':container,'exit':cleanup.returncode,'stdout':cleanup.stdout,'stderr':cleanup.stderr},indent=2)+'\n')
 (root/'commands.json').write_text(json.dumps(events,indent=2)+'\n')
