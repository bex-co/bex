// Public fixture requests only. Source prepared; not run against production.
const http = require('node:http'), https = require('node:https');
const http2 = require('node:http2'), zlib = require('node:zlib');
const [url, marker, offer, protocol, kind] = process.argv.slice(2);
if (!['1.1','2'].includes(protocol) || !['sse','ndjson'].includes(kind)) throw Error('Invalid fixed probe');
const parsed = new URL(url);
if (parsed.protocol !== 'https:' || !parsed.hostname.endsWith('.onbex.co') || parsed.username ||
    parsed.password || parsed.search || parsed.hash || parsed.pathname !== (kind === 'sse' ? '/stream' : '/ndjson')) throw Error('Not owned fixture URL');
const start = performance.now();
let done = false, request, session, raw = [], bytes = 0, text = '', pending = '', events = [], chunks = [];
const record = {url, marker, offer, requested_protocol: protocol, kind};
const finish = error => {
  if (done) return;
  done = true; clearTimeout(timer);
  record.error = error || null; record.complete = !error;
  record.elapsed_ms = Math.round(performance.now() - start);
  record.raw_entity_base64 = Buffer.concat(raw).toString('base64');
  record.text = text; record.events = events; record.chunks = chunks;
  if (request) request.destroy(); if (session) session.destroy();
  console.log(JSON.stringify(record)); process.exitCode = error ? 1 : 0;
};
function receive(stream, status, headers, actualProtocol) {
  record.status = status; record.headers = headers; record.actual_protocol = actualProtocol;
  record.headers_ms = Math.round(performance.now() - start);
  const encoding = headers['content-encoding'] || 'identity';
  if (!['identity','gzip'].includes(encoding)) {finish('Unexpected encoding'); return;}
  const decoded = encoding === 'gzip' ? zlib.createGunzip() : stream;
  stream.on('data', chunk => {
    bytes += chunk.length;
    if (bytes > 16384) {finish('Raw stream bound'); return;}
    raw.push(Buffer.from(chunk));
  });
  if (decoded !== stream) stream.pipe(decoded);
  decoded.setEncoding('utf8');
  decoded.on('data', chunk => {
    const at_ms = Math.round(performance.now() - start);
    chunks.push({at_ms, characters: chunk.length}); text += chunk; pending += chunk;
    if (Buffer.byteLength(text) > 16384) {finish('Decoded stream bound'); return;}
    let end;
    const delimiter = kind === 'sse' ? '\n\n' : '\n';
    while ((end = pending.indexOf(delimiter)) >= 0) {
      const block = pending.slice(0, end); pending = pending.slice(end + delimiter.length);
      const data = kind === 'sse' ? block.split('\n').find(line => line.startsWith('data: '))?.slice(6) : block;
      if (data) {
        try {events.push({at_ms, value: JSON.parse(data), frame: block});}
        catch (_) {finish('Malformed finite event'); return;}
      }
    }
  });
  decoded.on('error', error => finish(error.code || 'Decode error'));
  decoded.on('end', () => finish(pending ? 'Incomplete final frame' : null));
  stream.on('aborted', () => finish('Aborted stream'));
  stream.on('error', error => finish(error.code || 'Transport error'));
}
const timer = setTimeout(() => finish('Observation timeout'), 15000);
const headers = {'accept': kind === 'sse' ? 'text/event-stream' : 'application/x-ndjson',
  'accept-encoding': offer, 'user-agent': 'bex-functional-qa/m83'};
if (protocol === '2') {
  session = http2.connect(parsed.origin);
  session.on('error', error => finish(error.code || 'HTTP2 session error'));
  session.on('connect', () => {
    if (session.alpnProtocol !== 'h2') {finish('HTTP2 was not negotiated'); return;}
    request = session.request({...headers, ':path': parsed.pathname, ':method': 'GET'});
    request.on('response', response => receive(request, response[':status'], response, '2'));
    request.on('error', error => finish(error.code || 'HTTP2 request error')); request.end();
  });
} else {
  request = https.get(url, {headers}, response => receive(response, response.statusCode, response.headers, response.httpVersion));
  request.on('error', error => finish(error.code || 'HTTP1 request error'));
}
