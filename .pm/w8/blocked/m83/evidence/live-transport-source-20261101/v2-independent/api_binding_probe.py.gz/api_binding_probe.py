"""Pure supplied-state proof-binding controls; no crypto/network/API calls."""
import copy,json,sys
from pathlib import Path
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'work'))
import controller as c
import test_controller as fixtures
existing=Path('/private/tmp/bex-w8-m83-ready-admission-prep-20261031-bo8cxu7u/context/old218-signature-receipt.json')
raw=existing.read_bytes();actual=json.loads(raw)
results=[]
for name in ('valid-existing-API-receipt','wrong-approved-image','wrong-approved-source'):
 oracle=fixtures.Controls();oracle.setUp();ready=oracle.readiness()
 image=actual['image'] if name!='wrong-approved-image' else 'ghcr.io/bex-co/bex-operator@sha256:'+'b'*64
 source=actual['source'] if name!='wrong-approved-source' else 'f'*40
 ready['API']['image']=image
 for pod in ready['APIReadyPods']:pod['image']=pod['imageID']=image
 ready['APIApproval']={'source':source,'image':image,'signedReady':True,'signature_receipt':{'path':str(existing),'sha256':c.sha(raw)}}
 def reader(path):return raw if path==str(existing) else b'CONTROL ONLY'
 result=c.gate_readiness(ready,fixtures.NOW,lambda left,right:True,reader)
 results.append({'case':name,'result':result['state'],'receipt_source':actual['source'],'approved_source':source,'receipt_image':actual['image'],'approved_image':image,'source_matches_receipt':source==actual['source'],'image_matches_receipt':image==actual['image'],'scope':'otherwise-valid SYNTHETIC operator/rollout gate, retained actual old218 public receipt bytes read only; no fresh verification or actual Ready claim'})
(r/'api-binding-probe.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
