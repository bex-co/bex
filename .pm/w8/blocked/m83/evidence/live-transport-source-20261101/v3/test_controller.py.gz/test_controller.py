"""Pure local controls. No login, socket, tenant, image or production claim."""
import base64
import copy
import datetime
import gzip
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

import controller as c
import proof_fixtures


PUBLIC = json.loads((Path(__file__).parent / 'PUBLIC-SOURCE.json').read_text())
NOW = datetime.datetime(2026, 11, 1, 0, 5, tzinfo=datetime.timezone.utc)


class Controls(unittest.TestCase):
    def setUp(self):
        self.spec = c.specification('bex', '0123456789ab', PUBLIC)

    def post(self):
        s = self.spec
        return {'name': s['name'], 'ownerId': c.WORKSPACE, 'type': 'web_service',
                'repo': s['source']['repo'], 'branch': s['source']['branch'], 'autoDeploy': 'no',
                'envVars': [{'key': 'NODE_VERSION', 'value': '24'}], 'serviceDetails': {
                    'plan': 'free', 'runtime': 'node', 'region': 'frankfurt', 'healthCheckPath': '/snapshot',
                    'envSpecificDetails': {'buildCommand': s['build'], 'startCommand': s['start']}}}

    def view(self):
        return {**self.post(), 'id': 'srv-owned123'}

    def capture(self, row):
        expected = b'' if row.get('empty') else c.expected_payload(self.spec)
        if row.get('slice'):
            expected = expected[slice(*row['slice'])]
        raw = gzip.compress(expected, mtime=0) if row['encoding'] == 'gzip' else expected
        headers = {'x-qa-marker': self.spec['marker']}
        if row['encoding'] == 'gzip':
            headers.update({'content-encoding': 'gzip', 'vary': 'Accept-Encoding'})
        if row.get('etag'):
            headers['etag'] = row['etag']
        if row['path'] == '/no-transform':
            headers['cache-control'] = 'no-cache, no-transform'
        if row['status'] == 206:
            start, end = row['slice']
            headers['content-range'] = 'bytes ' + str(start) + '-' + str(end-1) + '/' + str(self.spec['payload_bytes'])
        headers['content-length'] = str(len(raw))
        return {'exit_code': 0, 'complete': True, 'bound': None, 'signal': None,
                'status': row['status'], 'actual_protocol': row['protocol'], 'headers': headers,
                'headers_raw': 'HTTP/' + row['protocol'] + ' ' + str(row['status']) + '\r\n\r\n',
                'raw_entity_gzip_base64': base64.b64encode(gzip.compress(raw, mtime=0)).decode(),
                'raw_bytes': len(raw), 'raw_sha256': c.sha(raw)}

    def stream(self, kind='sse', protocol='2'):
        frames, events = [], []
        for index in range(3):
            value = {'marker': self.spec['marker'], 'seq': index, 'text': 'café 日本語', 'emitted': 1000 + index * 1100}
            if kind == 'ndjson':
                value['pad'] = 'x' * 2048
            frame = json.dumps(value, ensure_ascii=False)
            if kind == 'sse':
                frame = 'id: ' + str(index) + '\nevent: tick\ndata: ' + frame
            frames.append(frame)
            events.append({'at_ms': 200 + index * 1100, 'value': value, 'frame': frame})
        delimiter = '\n\n' if kind == 'sse' else '\n'
        text = delimiter.join(frames) + delimiter
        raw = text.encode() if kind == 'sse' else gzip.compress(text.encode(), mtime=0)
        return {'exit_code': 0, 'complete': True, 'error': None, 'bound': None, 'signal': None,
                'actual_protocol': protocol, 'status': 200, 'headers_ms': 100, 'elapsed_ms': 3500,
                'headers': {'x-qa-marker': self.spec['marker'], **({'content-encoding': 'gzip'} if kind == 'ndjson' else {})},
                'raw_entity_base64': base64.b64encode(raw).decode(), 'text': text, 'events': events}

    def test_both_native_commands_exact_source_free_and_distinct_artifacts(self):
        other = c.specification('render', '0123456789ab', PUBLIC)
        self.assertNotEqual(self.spec['program_sha256'], other['program_sha256'])
        for spec in (self.spec, other):
            args = spec['args']
            self.assertEqual(args[args.index('--plan')+1], 'free')
            self.assertEqual(args[args.index('--env-var')+1], 'NODE_VERSION=24')
            self.assertIn('--auto-deploy=false', args)
            self.assertNotIn('--from', args)
            self.assertEqual(len(c.expected_payload(spec)), spec['payload_bytes'])
        c.validate_post(self.post(), self.spec)
        for change in ('plan', 'repo', 'build', 'environment', 'disk'):
            body = self.post()
            if change == 'plan': body['serviceDetails']['plan'] = 'starter'
            if change == 'repo': body['repo'] = 'https://unowned.example/repo'
            if change == 'build': body['serviceDetails']['envSpecificDetails']['buildCommand'] += '\nwrong'
            if change == 'environment': body['envVars'].append({'key': 'SECRET', 'value': 'CONTROL_ONLY'})
            if change == 'disk': body['serviceDetails']['diskSizeGB'] = 1
            with self.subTest(change=change), self.assertRaises(c.Unproved):
                c.validate_post(body, self.spec)

    def test_actual_shell_heredoc_emits_exact_program_bytes_without_executing_Node(self):
        for client in ('bex', 'render'):
            spec = c.specification(client, '0123456789ab', PUBLIC)
            terminal = 'node m83-server.js --build'
            self.assertTrue(spec['build'].endswith(terminal))
            shell = spec['build'][:-len(terminal)] + ':\n'
            with tempfile.TemporaryDirectory() as directory:
                process = subprocess.run(['bash', '-euo', 'pipefail', '-c', shell], cwd=directory,
                                         env={'PATH': os.defpath}, capture_output=True, timeout=5)
                self.assertEqual(process.returncode, 0, process.stderr)
                actual = (Path(directory) / 'm83-server.js').read_bytes()
                self.assertEqual(actual, spec['program'].encode())
                self.assertEqual(c.sha(actual), spec['program_sha256'])

    def test_two_protocol_matrix_and_signed_differences_pass_exact_decoding(self):
        rows = c.matrix(self.spec)
        self.assertEqual(len(rows), 38)
        self.assertEqual({row['protocol'] for row in rows}, {'1.1', '2'})
        for row in rows:
            capture = self.capture(row)
            raw = c.restore_entity(capture)
            authored = {'authored_gzip_bytes': len(raw), 'authored_gzip_sha256': c.sha(raw)}
            with self.subTest(name=row['name'], protocol=row['protocol']):
                self.assertEqual(c.assess_http(self.spec, row, capture, authored)['state'], 'PASS')

    def test_curl_keeps_encoded_entities_bounds_and_distinguishes_absent_empty_offer(self):
        base = 'https://' + self.spec['name'] + '.onbex.co'
        for row in c.matrix(self.spec):
            command = c.curl_argv(self.spec, row, base, '/private/tmp/CONTROL_ONLY/scratch')
            self.assertNotIn('--compressed', command)
            self.assertIn('--disable', command)
            self.assertEqual(command[command.index('--max-time')+1], '15')
            self.assertEqual(command[command.index('--max-filesize')+1], str(c.MAX_BODY))
            if row['name'] == 'absent': self.assertFalse(any('Accept-Encoding' in arg for arg in command))
            if row['name'] == 'empty': self.assertIn('Accept-Encoding;', command)
            if row.get('method') == 'HEAD': self.assertEqual(command[command.index('--output')+1], '/dev/null')
        for invalid in ('https://foreign.onbex.co', 'http://' + self.spec['name'] + '.onbex.co', base + '/path', base + '?token=CONTROL'):
            with self.subTest(invalid=invalid), self.assertRaises(c.Unproved): c.public_url(self.spec, invalid, '/text')

    def test_partial_transport_timeout_signal_outputbound_never_pass_with_correct_body(self):
        row = c.matrix(self.spec)[19]
        for change in ('exit-timeout', 'bound', 'signal', 'incomplete', 'bool-exit', 'fallback', 'status-line'):
            capture = self.capture(row)
            if change == 'exit-timeout': capture['exit_code'] = 124
            if change == 'bound': capture['bound'] = 'output'
            if change == 'signal': capture['signal'] = 15
            if change == 'incomplete': capture['complete'] = False
            if change == 'bool-exit': capture['exit_code'] = False
            if change == 'fallback': capture['actual_protocol'] = '1.1'
            if change == 'status-line': capture['headers_raw'] = 'HTTP/1.1 200\r\n\r\n'
            with self.subTest(change=change):
                self.assertEqual(c.assess_http(self.spec, row, capture)['state'], 'UNPROVED')

    def test_exact_body_headers_range_and_artifact_controls_detect_bad_results(self):
        rows = {row['name']: row for row in c.matrix(self.spec) if row['protocol'] == '1.1'}
        for name, change in [('gzip', 'vary'), ('large-range', 'content-range'),
                ('strong-etag-signed-difference', 'etag'), ('no-transform-signed-difference', 'directive'),
                ('authored-gzip', 'authored-artifact'), ('identity', 'body')]:
            row = rows[name]; capture = self.capture(row)
            if change == 'vary': capture['headers'].pop('vary')
            elif change == 'content-range': capture['headers']['content-range'] = 'bytes 0-1/2'
            elif change == 'etag': capture['headers']['etag'] = 'W/' + row['etag']
            elif change == 'directive': capture['headers']['cache-control'] = 'no-cache'
            elif change == 'body':
                raw = b'wrong body'; capture.update(raw_bytes=len(raw), raw_sha256=c.sha(raw),
                    raw_entity_gzip_base64=base64.b64encode(gzip.compress(raw)).decode())
            authored = {'authored_gzip_bytes': 1, 'authored_gzip_sha256': '0' * 64}
            with self.subTest(change=change):
                self.assertEqual(c.assess_http(self.spec, row, capture, authored)['state'], 'FAIL')

    def test_custody_truncated_and_oversized_gzip_are_unproved(self):
        row = c.matrix(self.spec)[0]
        for change in ('hash', 'truncated', 'oversized', 'invalid-base64'):
            capture = self.capture(row)
            if change == 'hash': capture['raw_sha256'] = '0' * 64
            elif change == 'invalid-base64': capture['raw_entity_gzip_base64'] = '%%'
            else:
                raw = gzip.compress(b'x' * (c.MAX_BODY + 1)) if change == 'oversized' else b'incomplete-gzip'
                capture.update(raw_bytes=len(raw), raw_sha256=c.sha(raw),
                    raw_entity_gzip_base64=base64.b64encode(gzip.compress(raw)).decode())
            with self.subTest(change=change):
                self.assertEqual(c.assess_http(self.spec, row, capture)['state'], 'UNPROVED')

    def test_sse_and_compressed_ndjson_complete_separate_events_on_both_protocols(self):
        for protocol in ('1.1', '2'):
            for kind in ('sse', 'ndjson'):
                with self.subTest(protocol=protocol, kind=kind):
                    self.assertEqual(c.assess_stream(self.spec, self.stream(kind, protocol), protocol, kind)['state'], 'PASS')

    def test_buffered_or_forged_stream_events_are_not_passing(self):
        for change in ('buffered', 'timeout', 'fake-value', 'fake-frame', 'raw-content', 'partial-frame'):
            capture = self.stream()
            if change == 'buffered':
                for event in capture['events']: event['at_ms'] = 3400
            elif change == 'timeout': capture.update(exit_code=124, bound='timeout', complete=False)
            elif change == 'fake-value': capture['events'][0]['value']['seq'] = 99
            elif change == 'fake-frame': capture['events'][0]['frame'] = 'different'
            elif change == 'raw-content': capture['raw_entity_base64'] = base64.b64encode(b'other stream').decode()
            else:
                capture['text'] = capture['text'].rstrip('\n')
                capture['raw_entity_base64'] = base64.b64encode(capture['text'].encode()).decode()
            with self.subTest(change=change):
                self.assertNotEqual(c.assess_stream(self.spec, capture, '2', 'sse')['state'], 'PASS')

    def readiness(self):
        self.ready_facts=proof_fixtures.Facts(NOW)
        return self.ready_facts.ready

    def proof(self,path):return self.ready_facts.read(path)

    def test_fresh_ready_requires_actual_operator_image_pods_source_and_proof(self):
        for change in ('valid', 'api-only', 'old-source', 'stale', 'pod', 'image', 'proof', 'generation','missing-API','API-pod','critical'):
            ready = self.readiness()
            ancestor = lambda left, right: change != 'old-source'
            if change == 'api-only': ready['Operator']['name'] = 'bex-api'
            if change == 'stale': ready['at'] = (NOW - datetime.timedelta(hours=2)).isoformat()
            if change == 'pod': ready['ReadyPods'][0]['ready'] = False
            if change == 'image': ready['ReadyPods'][0]['imageID'] = 'wrong'
            if change == 'proof': ready['signature_receipt'] = dict(ready['signature_receipt'], sha256='0' * 64)
            if change == 'generation': ready['Operator']['observedGeneration'] = 2
            if change == 'missing-API':ready.pop('API')
            if change == 'API-pod':ready['APIReadyPods'][0]['ready']=False
            if change == 'critical':ready['critical_source']={}
            with self.subTest(change=change):
                if change == 'valid':
                    self.assertEqual(c.gate_readiness(ready, NOW, ancestor, self.proof)['state'], 'PASS')
                else:
                    with self.assertRaises(c.Unproved): c.gate_readiness(ready, NOW, ancestor, self.proof)

    def test_unobserved_live_proxy_version_is_unknown_and_never_a_checked_in_pin_gate(self):
        ready=self.readiness();ready['traefikVersion']='agent-added-pin-without-observation'
        for value in (None,{'observed':False,'version':'v3.7.5'},{'observed':True,'version':'v3.8.0'}):
            ready['actual_proxy_observation']=value
            result=c.gate_readiness(ready,NOW,lambda left,right:True,self.proof)
            self.assertEqual(result['actualProxyVersion'],'v3.8.0' if value and value.get('observed') is True else 'UNKNOWN')

    def test_free_gate_requires_current_qa_workspace_meter_budget_and_capacity(self):
        owner = {'id': c.WORKSPACE, 'name': c.WORKSPACE_NAME}
        usage = {'workspaceId': c.WORKSPACE, 'period': '2026-11',
                 'coverage': {'state': 'complete', 'through': (NOW-datetime.timedelta(seconds=30)).isoformat(), 'degradedSources': []},
                 'freeInstanceHours': {'used': 0.1, 'included': 750}}
        limits = {'services': {'used': 0, 'terminating': 0, 'limit': 25}}
        self.assertEqual(c.gate_free(owner, usage, limits, NOW)['state'], 'PASS')
        unlimited=copy.deepcopy(limits);unlimited['services'].update(used=100,limit=0)
        self.assertEqual(c.gate_free(owner,usage,unlimited,NOW)['state'],'PASS')
        for change in ('before-reset', 'workspace', 'period', 'unknown-meter', 'budget', 'capacity', 'stale-meter'):
            own, use, cap = copy.deepcopy(owner), copy.deepcopy(usage), copy.deepcopy(limits)
            now = NOW
            if change == 'before-reset': now = c.RESET - datetime.timedelta(seconds=1)
            if change == 'workspace': own['id'] = 'tea-foreign'
            if change == 'period': use['period'] = '2026-10'
            if change == 'unknown-meter': use['coverage']['state'] = 'unknown'
            if change == 'budget': use['freeInstanceHours']['used'] = 750
            if change == 'capacity': cap['services']['terminating'] = 1
            if change == 'stale-meter': use['coverage']['through'] = (NOW-datetime.timedelta(minutes=10)).isoformat()
            with self.subTest(change=change), self.assertRaises(c.Unproved): c.gate_free(own, use, cap, now)

    def test_intent_once_before_forwarding_unknown_blocks_second_create_and_exact201_owns(self):
        stored = []
        data = {'workspace': c.WORKSPACE, 'baseline_ids': ['srv-baseline'], 'resources': []}
        journal = c.Journal(data, lambda value: stored.append(copy.deepcopy(value)))
        row = journal.intent(self.spec, {'state': 'PASS'}, {'state': 'PASS'})
        journal.forward_once(row, self.post(), self.spec)
        self.assertTrue(stored[-1]['resources'][0]['forwarded_once'])
        with self.assertRaises(c.Unproved): journal.forward_once(row, self.post(), self.spec)
        with self.assertRaises(c.Unproved): journal.intent(c.specification('render', '0123456789ab', PUBLIC), {'state': 'PASS'}, {'state': 'PASS'})
        with self.assertRaises(c.Unproved): journal.bind201(row, 500, self.view())
        journal.bind201(row, 201, self.view())
        journal.record_children(row['id'], [{'id': 'dep-first123'}])
        with self.assertRaises(c.Unproved): journal.deleted(row['id'], 404, {}, 404)
        journal.deleted(row['id'], 404, {'dep-first123': 404}, 404)
        journal.intent(c.specification('render', '0123456789ab', PUBLIC), {'state': 'PASS'}, {'state': 'PASS'})
        with self.assertRaises(c.Unproved): journal.own('srv-baseline')
        row['create_view']['ownerId'] = 'tea-foreign'
        with self.assertRaises(c.Unproved): journal.own(row['id'])

    def test_first_live_binds_one_real_commit_program_package_and_build_artifact(self):
        snapshot = {'marker': self.spec['marker'], 'node': 'v24.11.0', 'package_sha256': PUBLIC['package_sha256'],
                    'program_sha256': self.spec['program_sha256'], 'payload_bytes': self.spec['payload_bytes'],
                    'payload_sha256': self.spec['payload_sha256']}
        runtime = {**snapshot, 'built': copy.deepcopy(snapshot)}
        deploys = [{'id': 'dep-first123', 'status': 'live', 'commit': {'id': PUBLIC['commit']}}]
        marker = self.spec['marker'] + '_BUILD_SOURCE_CONFIRMED'
        self.assertEqual(c.validate_first_live(self.spec, deploys, runtime, marker)['state'], 'PASS')
        for change in ('second-child', 'wrong-source', 'wrong-artifact', 'missing-build-log'):
            deps, run, log = copy.deepcopy(deploys), copy.deepcopy(runtime), marker
            if change == 'second-child': deps.append({'id': 'dep-second456'})
            if change == 'wrong-source': deps[0]['commit']['id'] = 'f' * 40
            if change == 'wrong-artifact': run['built']['program_sha256'] = '0' * 64
            if change == 'missing-build-log': log = ''
            with self.subTest(change=change), self.assertRaises(c.Unproved): c.validate_first_live(self.spec, deps, run, log)

    def test_three_surface_settings_are_bound_to_own_exact_source_commands(self):
        for surface in ('REST', 'GraphQL', 'MCP'):
            view = self.view()
            if surface == 'GraphQL':
                details = view.pop('serviceDetails'); view.update(details); view.update(details['envSpecificDetails'])
            self.assertEqual(c.validate_settings(self.spec, 'srv-owned123', surface, view)['state'], 'PASS')
            view['branch'] = 'other'
            with self.assertRaises(c.Unproved): c.validate_settings(self.spec, 'srv-owned123', surface, view)

    def test_cleanup_requires_baseline_and_own_absence_and_zero_terminating(self):
        rows = {'postgres': {'used': 0, 'terminating': 0, 'limit': 1, 'freeUsed':0, 'freeLimit':1},
                'keyValues': {'used': 0, 'terminating': 0, 'limit': 1, 'freeUsed':0, 'freeLimit':1}}
        before = {'workspace': c.WORKSPACE, 'complete': True, 'ids': ['srv-baseline'],
                  'limits': {**rows, 'services': {'used': 1, 'terminating': 0, 'limit': 25, 'freeUsed':0, 'freeLimit':0}}}
        after = {'workspace': c.WORKSPACE, 'complete': True, 'ids': ['srv-baseline', 'srv-concurrent'],
                 'limits': {**rows, 'services': {'used': 2, 'terminating': 0, 'limit': 25, 'freeUsed':0, 'freeLimit':0}}}
        resources = [{'id': 'srv-owned123', 'state': 'deleted'}]
        self.assertEqual(c.compare_cleanup(before, after, resources)['concurrent_additions'], ['srv-concurrent'])
        for change in ('missing-baseline', 'owned-left', 'terminating', 'unknown'):
            end, rows = copy.deepcopy(after), copy.deepcopy(resources)
            if change == 'missing-baseline': end['ids'].remove('srv-baseline')
            if change == 'owned-left': end['ids'].append('srv-owned123')
            if change == 'terminating': end['limits']['services']['terminating'] = 1
            if change == 'unknown': rows[0]['state'] = 'forwarded-unknown'
            with self.subTest(change=change), self.assertRaises(c.Unproved): c.compare_cleanup(before, end, rows)

    def test_empty_untyped_incomplete_and_inconsistent_quota_counterexamples_are_unproved(self):
        limits = {name: {'used': 1 if name == 'services' else 0, 'terminating': 0, 'limit': 0, 'freeUsed':0, 'freeLimit':0}
                  for name in ('services', 'postgres', 'keyValues')}
        before = {'workspace': c.WORKSPACE, 'complete': True, 'ids': ['srv-baseline'], 'limits': limits}
        for change in ('empty', 'untyped', 'missing', 'used-drift', 'bool', 'incomplete'):
            after = copy.deepcopy(before)
            if change == 'empty': after['limits'] = {}
            if change == 'untyped': after['limits']['services'] = 'unobserved'
            if change == 'missing': after['limits'].pop('postgres')
            if change == 'used-drift': after['limits']['services']['used'] = 2
            if change == 'bool': after['limits']['services']['used'] = True
            if change == 'incomplete': after['complete'] = False
            with self.subTest(change=change), self.assertRaises(c.Unproved):
                c.compare_cleanup(before, after, [])


if __name__ == '__main__':
    unittest.main()
