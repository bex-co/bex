"""Host-only fake-provider/child-group controls. No real credential or API calls."""
import base64
import copy
import gzip
import json
import os
from pathlib import Path
import signal
import sys
import tempfile
import threading
import time
import types
import unittest
from unittest.mock import patch

import controller as c
import host
import transport as t
import test_controller as oracle_module


def completed(stdout=b''):
    return {'stdout':stdout,'stderr':b'','exit_code':0,'complete':True,'bound':None,'signal':None,
            'elapsed_seconds':0,'group_cleanup':{'CONTROL_ONLY':True,'group_absent':True}}


class FakeRunner:
    def __init__(self,owner):self.owner=owner
    def stop_all(self):return []
    def capture(self,argv,timeout,**kwargs):
        self.owner.events.append(('command',str(argv[1])))
        if str(argv[1]).endswith('stream-observer.js'):
            _,_,url,marker,offer,protocol,kind=argv
            oracle=oracle_module.Controls();oracle.setUp();oracle.spec=self.owner.current_spec
            row=oracle.stream(kind,protocol)
            result=completed(json.dumps(row,ensure_ascii=False).encode())
            if self.owner.mode=='bad-stream' and protocol=='2' and offer=='br, gzip':
                result.update(exit_code=124,complete=False,bound='timeout')
            if self.owner.mode=='missing-stream':result['stdout']=b'{}'
            return result
        if str(argv[1]).endswith('upgrade-observer.js'):
            return completed(json.dumps({'complete':True,'pass':True,'status':101,'actual_protocol':'1.1'}).encode())
        raise AssertionError('fake must not launch actual command:'+repr(argv))


REAL_RELAY=t.NativeRelay


class FakeRelay:
    def __init__(self,transport,spec,row):
        self.transport,self.spec,self.row=transport,spec,row
        self.real=REAL_RELAY(transport,spec,row)
    def __enter__(self):
        self.transport.current_relay=self;self.transport.current_spec=self.spec
        self.transport.active_relays.append(self);self.host='http://127.0.0.1:1/v1/'
        return self
    def close(self):
        if self in self.transport.active_relays:self.transport.active_relays.remove(self)
    def __exit__(self,*args):self.close()


class FakeTransport(t.Transport):
    def __init__(self,root,mode='happy'):
        ready=root/'CONTROL_ONLY_READY.json';ready.write_text('{}')
        super().__init__(root,ready)
        self.budget=host.Budget(root,free=lambda root:10**12)
        self.runner=FakeRunner(self)
        self.mode,self.events,self.remote,self.specs,self.views=mode,[],{}, {},{}
        self.logged_out=False

    def setup(self):
        (self.root/'private').mkdir(exist_ok=True)
        self.events.append(('setup',))
    def check_ready(self):self.events.append(('ready',));return {'state':'PASS','CONTROL_ONLY':True}
    def auth(self):self.auth_started=True;self.events.append(('own-auth',))
    def free_gate(self):self.events.append(('free',));return {'state':'PASS','CONTROL_ONLY':True}
    def public_head(self):self.events.append(('public-head',))
    def collect(self,cleanup=False):
        self.budget.check(cleanup)
        ids=['srv-baseline']+sorted(sid for sid,value in self.remote.items() if value)
        rows={name:{'used':len(ids) if name=='services' else 0,'terminating':0,'limit':0,'freeUsed':0,'freeLimit':0}
              for name in ('services','postgres','keyValues')}
        if self.mode=='quota-drift' and self.data.get('resources'):rows['services']['used']+=1
        return {'workspace':c.WORKSPACE,'complete':True,'ids':ids,'names':['baseline'],
                'limits':rows,'limits_observed_at':'CONTROL_ONLY','metadata':{'/v1/projects':['prj-baseline']}}
    def native(self,client,args,host,cleanup=False):
        self.events.append(('native-create',client))
        self.current_spec=self.current_relay.spec
        spec=self.current_spec
        body={'ownerId':c.WORKSPACE,'name':spec['name'],'type':'web_service','repo':spec['source']['repo'],
              'branch':spec['source']['branch'],'autoDeploy':'no','envVars':[{'key':'NODE_VERSION','value':'24'}],
              'serviceDetails':{'runtime':'node','plan':'free','region':'frankfurt','healthCheckPath':'/snapshot',
                               'envSpecificDetails':{'buildCommand':spec['build'],'startCommand':spec['start']}}}
        status,headers,raw=self.current_relay.real.dispatch('POST','/v1/services',json.dumps(body).encode(),{'Authorization':'Bearer CONTROL_ONLY_FAKE'})
        result=completed(raw)
        if self.mode=='native-timeout-after201':result.update(exit_code=124,complete=False,bound='timeout')
        return result
    def https(self,method,url,headers,body=None,cleanup=False,maximum=c.MAX_METADATA,on_response=None):
        self.events.append(('provider-POST',self.current_spec['client']))
        if self.mode=='unknown-post':raise host.Stop('CONTROL_ONLY upstream outcome unknown')
        spec=self.current_spec;sid='srv-'+spec['client']+'123'
        view=json.loads(body);view['id']=sid;view['serviceDetails']['url']='https://'+spec['name']+'.onbex.co'
        self.remote[sid]=True;self.specs[sid]=spec;self.views[sid]=view
        raw=json.dumps(view).encode()
        if on_response:on_response(201,raw)
        return {'status':201,'headers':{'content-type':'application/json'},'raw':raw,'body':raw,'transport':completed()}
    def api(self,method,path,body=None,cleanup=False):
        self.events.append(('API',method,path,cleanup))
        if not self.allowed_api(method,path,body,cleanup):raise AssertionError('outside actual fixed API guard:'+path)
        parsed=t.urlsplit(path)
        if method=='DELETE':
            sid=parsed.path.rsplit('/',1)[-1]
            self.journal.own(sid);self.remote[sid]=False
            return {'status':204,'body':b'','raw':b'','transport':completed()}
        sid=next((sid for sid in self.remote if sid in path),None)
        if method=='POST' and path=='/graphql':
            sid=next(sid for sid in self.remote if sid in body['query']);view=copy.deepcopy(self.views[sid])
            details=view.pop('serviceDetails');view.update(details);view.update(details['envSpecificDetails'])
            data={'data':{'service':view}};status=200
        elif method=='POST' and path=='/mcp':
            sid=body['params']['arguments']['serviceId'];data={'result':{'structuredContent':copy.deepcopy(self.views[sid])}};status=200
        elif parsed.path=='/v1/logs':
            sid=t.parse_qs(parsed.query)['resource'][0];data={'logs':[{'message':self.specs[sid]['marker']+'_BUILD_SOURCE_CONFIRMED'}]};status=200
        elif '/deploys' in path:
            child='dep-'+sid.removeprefix('srv-')
            if parsed.path.endswith('/deploys'):
                data=[{'deploy':{'id':child,'status':'live','commit':{'id':self.public['commit']}}}];status=200
            else:data={};status=404 if not self.remote[sid] else 200
        else:
            data=copy.deepcopy(self.views[sid]) if self.remote[sid] else {};status=200 if self.remote[sid] else 404
        raw=json.dumps(data).encode()
        return {'status':status,'body':raw,'raw':raw,'transport':completed(),'event':{'at':'CONTROL_ONLY'}}
    def public_capture(self,spec,path,row=None,cleanup=False):
        if self.mode=='observer-stop' and row is not None:
            self.budget.error='CONTROL_ONLY observer stop'
        self.budget.check(cleanup)
        sid='srv-'+spec['client']+'123'
        oracle=oracle_module.Controls();oracle.setUp();oracle.spec=spec
        if row is not None:
            capture=oracle.capture(row)
            if self.mode=='bad-http' and row['name']=='gzip' and row['protocol']=='2':capture.update(exit_code=124,complete=False,bound='timeout')
            return capture,c.restore_entity(capture)
        if not self.remote[sid]:return {**completed(),'status':404},b'not found'
        raw=c.expected_payload(spec);authored=gzip.compress(raw,mtime=0)
        snapshot={'marker':spec['marker'],'node':'v24.11.0','package_sha256':spec['source']['package_sha256'],
                  'program_sha256':spec['program_sha256'],'payload_bytes':len(raw),'payload_sha256':c.sha(raw),
                  'authored_gzip_bytes':len(authored),'authored_gzip_sha256':c.sha(authored)}
        snapshot['built']=copy.deepcopy(snapshot)
        return {**{key:value for key,value in completed().items() if key not in ('stdout','stderr')},'status':200},json.dumps(snapshot).encode()
    def logout(self):
        self.events.append(('logout-attempt',))
        c.require(all(row.get('state') in ('deleted','not-created') for row in self.data['resources']),'CONTROL_ONLY retain own auth for reconciliation')
        self.logged_out=True


class TransportControls(unittest.TestCase):
    def case(self,mode='happy',late=False):
        temporary=tempfile.TemporaryDirectory(prefix='m83-fake-control-');self.addCleanup(temporary.cleanup)
        root=Path(temporary.name).resolve();owned=FakeTransport(root,mode)
        if late:
            original=owned.budget.close
            def close():
                original();owned.budget.error='CONTROL_ONLY late monitor error';return None
            owned.budget.close=close
        before=signal.getsignal(signal.SIGTERM)
        with patch.object(t,'NativeRelay',FakeRelay):report=owned.execute()
        self.assertEqual(signal.getsignal(signal.SIGTERM),before)
        self.assertFalse(owned.budget.thread and owned.budget.thread.is_alive())
        return owned,report

    def test_happy_concrete_controller_runs_all38_plus6_streams_per_native_role_and_cleanup(self):
        owned,report=self.case()
        self.assertTrue(report['PASS'],{'failure':report['failure'],'cleanup_errors':report['cleanup_errors']})
        self.assertEqual([event[1] for event in owned.events if event[0]=='provider-POST'],['bex','render'])
        for client in ('bex','render'):
            self.assertEqual(len(report['results'][client]['checks']['HTTP']),38)
            self.assertEqual(len(report['results'][client]['checks']['streams']),6)
        self.assertTrue(owned.logged_out)
        self.assertTrue(all(not live for live in owned.remote.values()))
        self.assertTrue((owned.root/'evidence/MANIFEST.json').is_file())
        self.assertFalse(any(name.startswith('private/') for name in t.read_json(owned.root/'evidence/MANIFEST.json')['files']))

    def test_partial_http_or_missing_stream_cannot_green_and_known_sid_cleans_before_logout(self):
        for mode in ('bad-http','bad-stream','missing-stream','native-timeout-after201','observer-stop','quota-drift'):
            with self.subTest(mode=mode):
                owned,report=self.case(mode)
                self.assertFalse(report['PASS'])
                self.assertEqual([event[1] for event in owned.events if event[0]=='provider-POST'],['bex'])
                self.assertTrue(owned.logged_out,report)
                self.assertTrue(all(not live for live in owned.remote.values()),report)
                deletes=[event for event in owned.events if event[:2]==('API','DELETE')]
                self.assertEqual(len(deletes),1)
                self.assertEqual(deletes[0][2],'/v1/services/srv-bex123')

    def test_unknown_forwarded_post_is_never_replayed_inferred_deleted_or_logged_out(self):
        owned,report=self.case('unknown-post')
        self.assertFalse(report['PASS'])
        self.assertEqual([event for event in owned.events if event[0]=='provider-POST'],[('provider-POST','bex')])
        self.assertEqual(report['resources'][0]['state'],'forwarded-unknown')
        self.assertFalse(owned.logged_out)
        self.assertFalse(any(event[:2]==('API','DELETE') for event in owned.events))

    def test_late_monitor_error_after_exact_cleanup_and_logout_fails_final_result(self):
        owned,report=self.case(late=True)
        self.assertFalse(report['PASS'])
        self.assertTrue(owned.logged_out)
        self.assertTrue(all(not live for live in owned.remote.values()))
        self.assertTrue(any('late monitor' in error for error in report['cleanup_errors']))
        self.assertFalse(t.read_json(owned.root/'evidence/RESULT.json')['PASS'])

    def test_api_scope_refuses_foreign_resource_mutations_and_read_lookalikes(self):
        temporary=tempfile.TemporaryDirectory();self.addCleanup(temporary.cleanup)
        owned=FakeTransport(Path(temporary.name).resolve())
        owned.data['baseline_ids']=['srv-baseline'];owned.journal=c.Journal(owned.data,lambda data:None)
        for method,path,body in [('GET','/v1/services/srv-foreign',None),('DELETE','/v1/services/srv-baseline',None),
            ('GET','/v1/usage?ownerId=tea-foreign',None),('POST','/graphql',{'query':'mutation {deleteService(id:"srv-x")}'})]:
            with self.subTest(path=path):
                try:allowed=owned.allowed_api(method,path,body,True)
                except c.Unproved:allowed=False
                self.assertFalse(allowed)

    def test_real_https_binds_complete201_before_optional_artifact_write(self):
        temporary=tempfile.TemporaryDirectory();self.addCleanup(temporary.cleanup)
        root=Path(temporary.name).resolve();owned=FakeTransport(root)
        (root/'scratch').mkdir();order=[]
        class ControlledCurl:
            def capture(self,argv,**kwargs):
                Path(argv[argv.index('--dump-header')+1]).write_bytes(b'HTTP/2 201\r\nContent-Type: application/json\r\n\r\n')
                Path(argv[argv.index('--output')+1]).write_bytes(b'{"id":"srv-control"}')
                return completed(b'201\n2')
        owned.runner=ControlledCurl()
        owned.record=lambda *args,**kwargs:order.append('artifact')
        result=t.Transport.https(owned,'POST',t.API+'/v1/services',{'Authorization':'Bearer CONTROL_ONLY'},
                b'{}',on_response=lambda status,entity:order.append(('bind',status,json.loads(entity)['id'])))
        self.assertEqual(order[0],('bind',201,'srv-control'))
        self.assertEqual(result['raw'],b'{"id":"srv-control"}')

    def test_cleanup_HTTP_uses_bounded_memory_after_guard_stop_without_scratch_writes(self):
        temporary=tempfile.TemporaryDirectory();self.addCleanup(temporary.cleanup)
        root=Path(temporary.name).resolve();owned=FakeTransport(root)
        owned.budget.error='CONTROL_ONLY observer failure'
        class MemoryCurl:
            def capture(self,argv,cleanup,input_bytes,limit,**kwargs):
                assert cleanup is True and '--include' in argv and '--dump-header' not in argv
                assert argv[argv.index('--output')+1]=='-'
                assert b'CONTROL_ONLY_TOKEN' in input_bytes and 'CONTROL_ONLY_TOKEN' not in ' '.join(argv)
                marker=argv[argv.index('--write-out')+1].split('%{http_code}')[0]
                wire=b'HTTP/1.1 200 Connection established\r\n\r\nHTTP/2 404\r\nContent-Type: application/json\r\n\r\n{}'
                return completed(wire+marker.encode()+b'404\n2')
        owned.runner=MemoryCurl()
        result=t.Transport.https(owned,'GET',t.API+'/v1/services/srv-control',
                                {'Authorization':'Bearer CONTROL_ONLY_TOKEN'},cleanup=True)
        self.assertEqual((result['status'],result['body']),(404,b'{}'))
        self.assertFalse((root/'scratch').exists())

    def test_concrete_ready_binding_checks_actual_critical_source_bytes_before_auth(self):
        for wrong in (False,True):
            with self.subTest(wrong=wrong),tempfile.TemporaryDirectory(prefix='m83-ready-control-',dir='/private/tmp') as directory:
                root=Path(directory).resolve();owned=FakeTransport(root)
                oracle=oracle_module.Controls();oracle.setUp();owned.ready=oracle.readiness()
                owned.ready=oracle.ready_facts.materialize(root)
                critical=t.read_json(t.HERE/'CRITICAL-SOURCE.json')['files']
                owned.ready['critical_source']=copy.deepcopy(critical)
                if wrong:owned.ready['critical_source'][next(iter(critical))]['sha256']='0'*64
                owned.ready_path.write_text(json.dumps(owned.ready));owned.ready_bytes_sha=t.digest(owned.ready_path)
                class ReadOnlyGit:
                    def capture(self,argv,**kwargs):
                        if 'merge-base' in argv:return completed()
                        assert argv[:4]==['git','-C',str(t.REPO),'show']
                        path=argv[-1].split(':',1)[1]
                        assert path in critical
                        return completed((t.REPO/path).read_bytes())
                owned.runner=ReadOnlyGit()
                with patch.object(t,'now',return_value=oracle_module.NOW):
                    if wrong:
                        with self.assertRaises(c.Unproved):t.Transport.check_ready(owned)
                    else:
                        result=t.Transport.check_ready(owned)
                        self.assertEqual(result['state'],'PASS')
                        self.assertEqual(result['actualProxyVersion'],'UNKNOWN')
                self.assertFalse(owned.auth_started)

    def test_actual_native_wrapper_keeps_tokens_in_own_configs_and_redacts_rotated_values(self):
        temporary=tempfile.TemporaryDirectory();self.addCleanup(temporary.cleanup)
        root=Path(temporary.name).resolve();owned=FakeTransport(root)
        config=root/'private/credentials/cli.yaml';config.parent.mkdir(parents=True)
        config.write_text(json.dumps({'api':{'key':'CONTROL_ONLY_OLD_TOKEN','host':t.API+'/v1/'}}));config.chmod(0o600)
        fake_yaml=types.SimpleNamespace(safe_load=json.loads,safe_dump=json.dumps)
        class Native:
            def capture(self,argv,env,**kwargs):
                self.assertion=argv
                path=Path(env['RENDER_CLI_CONFIG_PATH'])
                assert path.parent==root/'private/config-render'
                assert env['RENDER_HOST']=='http://127.0.0.1:1/v1/'
                assert 'CONTROL_ONLY' not in ' '.join(argv)
                doc=json.loads(path.read_text());doc['api']['key']='CONTROL_ONLY_ROTATED_TOKEN'
                path.write_text(json.dumps(doc));path.chmod(0o600)
                result=completed(b'{"controlled":true}')
                result['stderr']=b'CONTROL_ONLY_ROTATED_TOKEN CONTROL_ONLY_OLD_TOKEN'
                return result
        owned.runner=Native()
        with patch.dict(sys.modules,{'yaml':fake_yaml}):
            result=t.Transport.native(owned,'render',['services','create'],'http://127.0.0.1:1/v1/')
        self.assertEqual(result['exit_code'],0)
        self.assertFalse((root/'private/config-render/cli.yaml').exists())
        self.assertEqual(json.loads(config.read_text())['api'],{'key':'CONTROL_ONLY_ROTATED_TOKEN','host':t.API+'/v1/'})
        raw=b''.join(path.read_bytes() for path in (root/'evidence').rglob('*.json'))
        self.assertNotIn(b'CONTROL_ONLY_ROTATED_TOKEN',raw)
        self.assertNotIn(b'CONTROL_ONLY_OLD_TOKEN',raw)

    def test_auth_window_refuses_before_any_login_command_even_with_fake_ready(self):
        temporary=tempfile.TemporaryDirectory();self.addCleanup(temporary.cleanup)
        owned=FakeTransport(Path(temporary.name).resolve())
        with patch.object(t,'now',return_value=c.RESET-t.datetime.timedelta(seconds=1)),self.assertRaises(c.Unproved):
            t.Transport.auth(owned)
        self.assertFalse(owned.auth_started)
        self.assertFalse(any(event[0]=='command' for event in owned.events))

    def test_opaque_logout_checks_actual_own_file_absence_and_preserves_foreign_sentinel(self):
        for leave in (False,True):
            with self.subTest(leave=leave),tempfile.TemporaryDirectory() as directory:
                root=Path(directory).resolve();owned=FakeTransport(root)
                owned.auth_started=True;owned.auth_completed=True
                own_repo=root/'CONTROL_ONLY_REPO';jar_parent=own_repo/'.playwright-mcp';jar_parent.mkdir(parents=True)
                jar=jar_parent/'qa-session-0123456789ab.jar';jar.write_text('CONTROL_ONLY_COOKIE');jar.chmod(0o600)
                foreign=jar_parent/'qa-session-aaaaaaaaaaaa.jar';foreign.write_text('foreign sentinel');foreign.chmod(0o600)
                state=root/'private/qa-state.json';state.parent.mkdir(exist_ok=True);state.write_text('{}');state.chmod(0o600)
                config=root/'private/credentials/cli.yaml';config.parent.mkdir();config.write_text('CONTROL_ONLY_TOKEN');config.chmod(0o600)
                handle=root/'private/qa-session-handle.json';handle.write_text(json.dumps({'logout_jar':str(jar),'state':str(state)}));handle.chmod(0o600)
                class Logout:
                    def capture(self,argv,**kwargs):
                        assert argv==[sys.executable,str(root/'private/cleanup-auth.py')]
                        state.unlink();handle.unlink();config.unlink()
                        if not leave:jar.unlink()
                        (root/'private/auth-cleanup-receipt.json').write_text(json.dumps({'own_credential_files_removed':True,
                            'native_logout_exit':0,'Kratos_logout_exit':0}))
                        return completed()
                owned.runner=Logout()
                with patch.object(t,'REPO',own_repo):
                    if leave:
                        with self.assertRaises(c.Unproved):t.Transport.logout(owned)
                    else:t.Transport.logout(owned)
                self.assertEqual(foreign.read_text(),'foreign sentinel')


class HostControls(unittest.TestCase):
    def make(self):
        temporary=tempfile.TemporaryDirectory(prefix='m83-host-control-');self.addCleanup(temporary.cleanup)
        budget=host.Budget(Path(temporary.name).resolve(),free=lambda root:10**12)
        runner=host.Runner(budget);self.addCleanup(runner.stop_all)
        return budget,runner

    def test_exited_leader_pipeholder_timeout_reaps_exact_owned_group(self):
        budget,runner=self.make()
        script='import os,time\np=os.fork()\nif p==0:time.sleep(30)\nelse:print(p,flush=True);os._exit(0)\n'
        result=runner.capture([sys.executable,'-c',script],timeout=.2,limit=1024)
        self.assertEqual(result['bound'],'timeout')
        self.assertTrue(result['group_cleanup']['group_absent'])
        self.assertFalse(host.group_exists(result['group_cleanup']['pgid']))
        child=int(result['stdout'].decode().strip())
        with self.assertRaises(ProcessLookupError):os.kill(child,0)

    def test_normal_exit_with_background_descendant_is_stopped_and_not_success(self):
        budget,runner=self.make()
        script='import os,time\np=os.fork()\nif p==0:\n os.close(1);os.close(2);time.sleep(30)\nelse:os._exit(0)\n'
        result=runner.capture([sys.executable,'-c',script],timeout=2,limit=1024)
        self.assertEqual(result['bound'],'unexpected-background-descendant')
        self.assertTrue(result['group_cleanup']['group_absent'])

    def test_output_and_resource_stop_have_no_leaked_owned_process_group(self):
        for mode in ('output','resource'):
            budget,runner=self.make()
            if mode=='resource':
                original=budget.check;calls=[0]
                def check(cleanup=False):
                    calls[0]+=1
                    if calls[0]>2 and not cleanup:raise host.Stop('CONTROL_ONLY guard')
                    return original(cleanup)
                budget.check=check
            script='import sys,time\nsys.stdout.write("x"*20000);sys.stdout.flush();time.sleep(30)'
            result=runner.capture([sys.executable,'-c',script],timeout=2,limit=128)
            self.assertIn(result['bound'],('output','resource'))
            self.assertTrue(result['group_cleanup']['group_absent'])

    def test_budget_close_reports_inflight_late_monitor_error(self):
        budget,_=self.make();entered,release=threading.Event(),threading.Event()
        def check(cleanup=False):
            entered.set();release.wait(1);raise host.Stop('CONTROL_ONLY in-flight late error')
        budget.check=check;budget.start();self.assertTrue(entered.wait(1))
        closed=[]
        thread=threading.Thread(target=lambda:closed.append(budget.close()));thread.start()
        release.set();thread.join(2)
        self.assertFalse(thread.is_alive())
        self.assertIn('in-flight late error',closed[0])

    def test_one_second_observer_detects_free_floor_and_cleanup_capture_remains_possible(self):
        budget,runner=self.make();available=[10**12]
        budget.free=lambda root:available[0];budget.start()
        deadline=time.monotonic()+1
        while not (budget.root/'evidence/capacity.jsonl').exists() and time.monotonic()<deadline:time.sleep(.01)
        available[0]=host.FLOOR+host.MARGIN
        deadline=time.monotonic()+1.5
        while budget.error is None and time.monotonic()<deadline:time.sleep(.01)
        self.assertIsNotNone(budget.error)
        result=runner.capture([sys.executable,'-c','print("CONTROL_ONLY cleanup")'],timeout=2,cleanup=True)
        self.assertEqual(result['exit_code'],0)
        self.assertTrue(result['group_cleanup']['group_absent'])
        budget.close()

    def test_exact_own_jar_disappearance_during_logout_is_not_a_monitor_error(self):
        budget,_=self.make()
        jar=budget.root/'qa-session-0123456789ab.jar';jar.write_text('CONTROL_ONLY_COOKIE');jar.chmod(0o600)
        budget.register_jar(jar,budget.root)
        original=Path.lstat
        def observed(path):
            if path==jar:raise FileNotFoundError('CONTROL_ONLY concurrent own unlink')
            return original(path)
        with patch.object(Path,'lstat',observed):
            counts,available=budget.observation()
        self.assertGreater(available,host.START_FREE)


if __name__=='__main__':unittest.main()
