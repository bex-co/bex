from pathlib import Path
import datetime,hashlib,importlib.util,json,re,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from read import ROOT,dump,sha,size
follow=Path('/private/tmp/bex-w8-m83-ready-proxy-scope-followon-20261031-peyjsldn/admission.py')
assert sha(follow)=='4fbbb17b2fe5a0d3951415b7abbda5e5c1a3b6f3854a0a1fd2df8c14758a543a'
spec=importlib.util.spec_from_file_location('m83_source_admission',follow);admission=importlib.util.module_from_spec(spec);spec.loader.exec_module(admission)
run=json.loads((ROOT/'run.stdout').read_text());job=json.loads((ROOT/'job.stdout').read_text());inventory=json.loads((ROOT/'inventory.json').read_text())
now=datetime.datetime.now(datetime.timezone.utc);at=admission.inventory_observation(run,job,now)
sig=json.loads((ROOT/'SIGNATURE-RECEIPT.json').read_text());assert sig['actual_strict_crypto']=='PASS' and sig['stop'] is None
capture={'command':sig['argv'],'exit':sig['exit'],'source':sig['source'],'image':sig['image'],'tool_sha256':sig['tool_sha256'],'stdout_sha256':sig['stdout']['sha256'],'actual_process_receipt':str(ROOT/'SIGNATURE-RECEIPT.json'),'scope':'Projected real fresh process metadata into existing strictvalidator shape; raw process receipt/stdout unchanged.'}
dump(ROOT/'strict-signature-capture.json',capture)
admission.signature_capture(capture,(ROOT/'strict-signature.stdout').read_bytes(),sig['source'],sig['image'])

def role(name,container):
 facts=inventory['platformImages'];deps=[x for x in facts['deployments'] if x.get('namespace')=='bex-system' and x.get('name')==name]
 assert len(deps)==1;dep=deps[0]
 assert dep.get('uid') and type(dep.get('generation')) is int and dep['generation']>0 and dep.get('observedGeneration')==dep['generation']
 count=dep.get('replicas');assert type(count) is int and count>0
 assert all(dep.get(k)==count for k in ('updatedReplicas','readyReplicas','availableReplicas'))
 image=dep['containerImages'][container];assert image==sig['image']
 pods=[x for x in facts['pods'] if x.get('namespace')=='bex-system' and container in x.get('containerImages',{}) and x.get('deletingAt') in ('',None)]
 assert len(pods)==count and len({x.get('uid') for x in pods})==count and all(x.get('uid') for x in pods)
 for pod in pods:
  assert pod.get('phase')=='Running' and pod.get('containerReady',{}).get(container) is True
  assert pod['containerImages'][container]==image and pod.get('containerImageIds',{}).get(container)==image
 return {'state':'PASS','observed_at':at,'Deployment':dep,'ActivePods':pods,'immutable_image':image,'actual_fresh_signature_receipt':str(ROOT/'SIGNATURE-RECEIPT.json'),'scope':'Actual collected Deployment/pod generation+spec+runtimeID+readiness and real signedimage; existingcollectorselection only, not absentownerReferences/architecture claims.'}
operator=role('bex-controller-manager','manager');api=role('bex-api','api')
dump(ROOT/'ROLLOUT-HEALTH.json',{'operator':operator,'api':api,'api_m83_ancestry_required':False,'reason':'m83fix is operator-only. API must be actuallyhealthy with signedimmutableidentity; no invented APIa154 ancestry predicate.'})
source=json.loads((ROOT/'SOURCE-REVIEW.json').read_text())
assert not source['fix_is_ancestor'] and not source['all_critical_files_exact']
result={'state':'BLOCKED_ACTUAL_OPERATOR_SOURCE','ready_admission':False,'at':now.isoformat(),'observation_at':at,'observation_fresh_until':'2026-11-01T00:30:23Z','inventory_run':run['id'],'inventory_job':job['id'],'inventory_source':run['head_sha'],'operator_rollout_health':'PASS','api_rollout_health_and_signed_identity':'PASS','actual_signed_carrier_source':sig['source'],'actual_image':sig['image'],'actual_fresh_crypto':'PASS','required_m83_fix':source['required_fix'],'fix_is_ancestor':False,'compression_source':'edge_compression.go absent in signedsource; app_controller.go differs (actualc23131f2.. versus required5ea97813..).','source_receipt':str(ROOT/'SOURCE-REVIEW.json'),'proxy_version':{'state':'UNKNOWN','blocking':False,'reason':'Existinginventory does not observeactualproxyversion; no pininference, no observer added.'},'concrete_next_step':'Root must obtain actualrolled-outsignedoperator source includinga154 with bothcriticalfiles exact (or reviewedsourceequivalence) and a freshactualinventory. Currenthealthyoldcarrier is not eligible for m83nativefixturecreation. No retry/dispatch/deploy performed by thisreview.','not_established':['No newcarrier buildrun output/digest source proof was pursued because actualcurrent signedsource already fails m83 ancestry/criticalbytes.','No Freebudget/auth/product/nativecreate/HTTPstreams/tenantacceptance performed.','No actualcurrentproxy3.7.5 identity observed.'],'scope':'One actualread-only readiness review, freshrealstrictCosign+exactGit source check; NOm83ReadyPASS, no copiedoldcrypto pass, no proxyversioninventedgate. Stopafterthisconcreteactualgate.'}
dump(ROOT/'READINESS-REVIEW.json',result)
dump(ROOT/'REVIEW-INPUTS.json',{'admission_source':{'path':str(follow),'sha256':sha(follow)},'corrected_controller':{'path':str(follow.parent/'context/controller.py'),'sha256':sha(follow.parent/'context/controller.py')},'required_source':{'path':str(follow.parent/'REQUIRED-SOURCE.json'),'sha256':sha(follow.parent/'REQUIRED-SOURCE.json')},'parent_scope':'onecompletedjoblog<=16MiB, otherownedoutputs<=3MiB; no cluster/product/auth/resource/CI mutations; no SSH/trust relaxation','used_prior_discovery_only':'Old218signature receipt identifies candidate d147 matching actualinventoryimage; newstrictverification was actuallyexecuted and is retained separately.'})
print(json.dumps({'state':result['state'],'operator_health':'PASS','api_health_and_signature':'PASS','actual_crypto':'PASS','source':sig['source'],'proxy_version':'UNKNOWN_NONBLOCKING','nonlog_owned_bytes':size()}))
