from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from reader import ROOT,command,dump
fix='a15472735e63d9217b4db49f873ceaa69324f5d3';rows={}
for name,source in [('active','ea5a901daf6b78e7da116c4e363b95847dad5110'),('pending','99cdc5c5a5b53629e2a98963d43d373511a91c1f')]:
 result=command(name+'-m83-ancestry',['git','merge-base','--is-ancestor',fix,source],seconds=10,cap=16384)
 workflow=command(name+'-deploy-source',['git','show',source+':.github/workflows/deploy.yml'],seconds=10,cap=256*1024)
 assert result['exit'] in (0,1) and result['stop'] is None and workflow['exit']==0 and workflow['stop'] is None
 rows[name]={'source':source,'m83fix_is_ancestor':result['exit']==0,'workflow':workflow['stdout']}
dump(ROOT/'SOURCE-FACTS.json',rows)
print(json.dumps({name:{'source':row['source'],'m83fix_is_ancestor':row['m83fix_is_ancestor']} for name,row in rows.items()}))
