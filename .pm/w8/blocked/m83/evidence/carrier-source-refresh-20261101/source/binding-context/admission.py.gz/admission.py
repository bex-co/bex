"""Pure/local-source m83 admission preparation; no transport or executable runner.

The caller must supply actual reviewed CI/inventory and successful strict Cosign
outputs later. Reading JSON does not perform cryptographic verification. This
module imports only the already-reviewed, side-effect-free m83 controller gate.
"""
import datetime
import importlib.util
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('m83_pure_gate', HERE/'context/controller.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
REQUIREMENTS = json.loads((HERE/'REQUIRED-SOURCE.json').read_text())
FIX = REQUIREMENTS['required_fix']
INVENTORY_RUN = 41251157373
INVENTORY_SOURCE = 'e392c101b74329428fd1f1a058fbdb233a049924'
INVENTORY_STEP = 'inventory service-disk binding and capacity metadata (read-only)'
COSIGN = '/private/tmp/bex7-native-acceptance-novb586u/cosign'
COSIGN_SHA = '9f9b8cd557cf2e5b3df3373a00baa005a86b02391e3e06dd0ce37b3a1533d3a4'
IDENTITY = 'https://github.com/bex-co/bex/.github/workflows/deploy.yml@refs/heads/main'
ISSUER = 'https://token.actions.githubusercontent.com'


def signature_command(source, image):
    gate.require(re.fullmatch('[a-f0-9]{40}', source) and re.fullmatch(r'ghcr.io/bex-co/bex-operator@sha256:[a-f0-9]{64}', image), 'invalid candidate source/image')
    # Same strict exact-identity/issuer/source recipe as actual218, no trust bypass.
    return [COSIGN, 'verify', '--certificate-identity', IDENTITY,
            '--certificate-oidc-issuer', ISSUER,
            '--certificate-github-workflow-sha', source, image]


def signature_capture(receipt, stdout, source, image):
    """Bind actual, later executed strict command output; not crypto verification."""
    gate.require(receipt.get('command') == signature_command(source, image)
                 and type(receipt.get('exit')) is int and receipt['exit'] == 0
                 and receipt.get('source') == source and receipt.get('image') == image
                 and receipt.get('tool_sha256') == COSIGN_SHA
                 and receipt.get('stdout_sha256') == gate.sha(stdout), 'strict signature process/subject/source custody differs')
    rows = json.loads(stdout)
    gate.require(isinstance(rows, list) and rows, 'no verified image signature claims')
    for row in rows:
        critical = row.get('critical', {})
        gate.require(critical.get('identity', {}).get('docker-reference') == image
                     and critical.get('image', {}).get('docker-manifest-digest') == image.split('@')[1],
                     'verified signature claims bind a different image')
    gate.require(any(row.get('critical', {}).get('type') == 'https://sigstore.dev/cosign/sign/v1' for row in rows), 'no image signature claim')
    return {'source': source, 'image': image, 'strict_command_output_bound': True}


def source_blobs(repo, source):
    gate.require(re.fullmatch('[a-f0-9]{40}', source), 'invalid candidate Git source')
    process = subprocess.run(['git', 'merge-base', '--is-ancestor', FIX, source], cwd=repo,
                             stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=10)
    gate.require(process.returncode == 0, 'signed source does not descend required m83 fix')
    observed = {}
    for path in REQUIREMENTS['runtime_critical_paths']:
        body = subprocess.check_output(['git', 'show', source+':'+path], cwd=repo, timeout=10)
        row = subprocess.check_output(['git', 'ls-tree', source, '--', path], cwd=repo, text=True, timeout=10).split()
        observed[path] = {'bytes': len(body), 'sha256': gate.sha(body), 'git_mode': row[0], 'git_blob': row[2]}
    critical_blobs(observed)
    return observed


def critical_blobs(observed):
    gate.require(observed == REQUIREMENTS['runtime_critical_paths'],
                 'm83 runtime critical source bytes/mode/blob differ; ancestry alone is insufficient')


def inventory_fields(inventory, image):
    """Use immutable existing inventory maps; do not rewrite runtime image IDs."""
    facts = inventory['platformImages']
    deployments = [d for d in facts['deployments'] if d.get('namespace') == 'bex-system'
                   and d.get('name') == 'bex-controller-manager']
    gate.require(len(deployments) == 1, 'unique actual operator Deployment absent')
    dep = dict(deployments[0])
    gate.require(dep.get('uid') and dep.get('containerImages', {}).get('manager') == image,
                 'manager Deployment image/UID missing or different')
    dep['image'] = dep['containerImages']['manager']
    active = [p for p in facts['pods'] if p.get('namespace') == 'bex-system'
              and 'manager' in p.get('containerImages', {}) and p.get('deletingAt') in ('', None)]
    pods = []
    for pod in active:
        pods.append({**{key: pod.get(key) for key in ('namespace','name','uid','phase','deletingAt')},
                     'ready': pod.get('containerReady', {}).get('manager'),
                     'image': pod['containerImages']['manager'],
                     'imageID': pod.get('containerImageIds', {}).get('manager')})
    return dep, pods


def inventory_observation(run, job, now):
    gate.require(run.get('id') == INVENTORY_RUN and run.get('head_sha') == INVENTORY_SOURCE
                 and run.get('path') == '.github/workflows/hcloud-csi-rollout.yml'
                 and run.get('event') == 'workflow_dispatch' and run.get('status') == 'completed'
                 and run.get('conclusion') == 'success', 'fresh expected inventory run not fully successful')
    gate.require(type(job.get('id')) is int and job.get('run_id') == INVENTORY_RUN
                 and job.get('head_sha') == INVENTORY_SOURCE and job.get('name') == 'cluster'
                 and job.get('status') == 'completed' and job.get('conclusion') == 'success', 'inventory cluster job differs or incomplete')
    steps = [s for s in job.get('steps', []) if s.get('name') == INVENTORY_STEP]
    gate.require(len(steps) == 1 and steps[0].get('status') == 'completed'
                 and steps[0].get('conclusion') == 'success', 'actual inventory collection step not successful')
    start, end = (gate.instant(steps[0][key]) for key in ('started_at','completed_at'))
    gate.require(start <= end <= now and 0 <= (now-start).total_seconds() <= 3600,
                 'inventory collection window stale/future/invalid')
    return start.isoformat()  # Conservative earliest collection time, not packaging time.


def operator_gate(inventory, image, source, run, job, proof_paths, proxy_proof, now,
                  signature_receipt, signature_stdout, source_records):
    """Adapter to existing pure gate; never supplies missing runtime facts."""
    critical_blobs(source_records)
    signature_capture(signature_receipt, signature_stdout, source, image)
    observed_at = inventory_observation(run, job, now)
    reader = proof_paths['reader']
    gate.require(json.loads(reader(proof_paths['inventory_proof']['path'])) == inventory
                 and json.loads(reader(proof_paths['signature_receipt']['path'])) == signature_receipt,
                 'normalized inventory/signature receipt differs from retained proof bytes')
    dep, pods = inventory_fields(inventory, image)
    # Exact live proxy-version identity was an agent-added gate, not the m83
    # user/board acceptance. Pins are never substituted for observations.
    actual_proxy_version = 'UNKNOWN'
    proxy_limit = 'Inventory does not observe proxy version; all actual wire/stream checks remain required.'
    if proxy_proof.get('actual_observed') is True:
        proxy = proxy_proof.get('proof', {})
        try:
            if (isinstance(proxy_proof.get('version'), str) and proxy_proof['version']
                    and proxy.get('sha256') == gate.sha(reader(proxy.get('path')))):
                actual_proxy_version = proxy_proof['version']
                proxy_limit = 'Separately supplied observation; all actual wire/stream checks remain required.'
            else:
                proxy_limit = 'Supplied proxy observation lacks exact custody; version UNKNOWN.'
        except (OSError, KeyError, TypeError):
            proxy_limit = 'Supplied proxy observation unavailable; version UNKNOWN.'
    ready = {'requiredAncestor': FIX, 'source': source, 'image': image, 'at': observed_at,
             'ready': True, 'signedReady': True, 'Operator': dep, 'ReadyPods': pods,
             'signature_receipt': proof_paths['signature_receipt'],
             'readiness_proof': proof_paths['inventory_proof']}
    # This callback only checks the already validated source relation; source_blobs
    # and real signature verification remain mandatory separate prerequisites.
    result = gate.gate_readiness(ready, now, proof_paths['ancestor_check'], reader)
    return dict(result, actualProxyVersion=actual_proxy_version, proxyObservationLimit=proxy_limit,
                scope='manager readiness adapter only; separate actual signed APIReady proof remains mandatory before create')
