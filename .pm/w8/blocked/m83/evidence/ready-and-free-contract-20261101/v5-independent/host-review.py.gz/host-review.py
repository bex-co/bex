from pathlib import Path
import contextlib, hashlib, json, stat, subprocess, sys, unittest
from unittest.mock import patch
OUT=Path(__file__).resolve().parent
V=Path('/private/tmp/bex-w8-m83-live-transport-v5-free-contract-source-20261101-iqm0ez1e')
REPO=Path('/Users/tianpan/projects/bex7')
SOURCE='a9c66371978abe00c8b16fb5463e4fa9be11917c'
def sha(x):return hashlib.sha256(x).hexdigest()
source_rows=[]
for item in json.loads((V/'V5-PRIMARY-SOURCE-RECORDS.json').read_text()):
    result=subprocess.run(item['argv'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10,check=False)
    retained=Path(item['stdout']['path']).read_bytes()
    assert result.returncode==0 and result.stderr==b''
    assert result.stdout==retained and len(retained)==item['stdout']['bytes'] and sha(retained)==item['stdout']['sha256']
    source_rows.append({'argv':item['argv'],'exit_code':result.returncode,'bytes':len(retained),'sha256':sha(retained),'exact_retained_bytes':True})
fixture=OUT/'actual-a9-two-file-fixture';fixture.mkdir(mode=0o700)
critical=json.loads((V/'CRITICAL-SOURCE.json').read_text())['files']
for path,desc in critical.items():
    argv=['git','-C',str(REPO),'show',SOURCE+':'+path]
    result=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10,check=False)
    assert result.returncode==0 and result.stderr==b''
    assert len(result.stdout)==desc['bytes'] and sha(result.stdout)==desc['sha256']
    target=fixture/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(result.stdout);target.chmod(0o400)
    source_rows.append({'argv':argv,'exit_code':0,'bytes':len(result.stdout),'sha256':sha(result.stdout),'fixture_path':str(target)})
actual=json.loads((V/'V5-ACTUAL-SAFE-FREE-INPUTS.json').read_text())
rawpath=Path(actual['source']['path']);assert stat.S_ISREG(rawpath.lstat().st_mode) and not rawpath.is_symlink()
raw=rawpath.read_bytes();assert len(raw)==actual['source']['bytes'] and sha(raw)==actual['source']['sha256']
rawdoc=json.loads(raw)
for key in ('owner','usage','limits'):assert actual[key]==rawdoc[key]
(OUT/'SOURCE-AND-SAFE-PROJECTION.json').write_text(json.dumps({'actual_backend_carrier':SOURCE,'local_git_reads':source_rows,'safe_projection_exact':True,'raw_input':actual['source']},indent=2)+'\n')
sys.path.insert(0,str(V))
import transport as t
import test_transport
cls=test_transport.Controls if hasattr(test_transport,'Controls') else None
method='test_concrete_ready_binding_checks_actual_critical_source_bytes_before_auth'
classes=[obj for obj in vars(test_transport).values() if isinstance(obj,type) and issubclass(obj,unittest.TestCase) and method in obj.__dict__]
assert len(classes)==1
cls=classes[0];original=getattr(cls,method);calls=[]
def contextual(self):
    calls.append(self.id())
    with patch.object(t,'REPO',fixture):return original(self)
setattr(cls,method,contextual)
suite=unittest.defaultTestLoader.discover(str(V),pattern='test_*.py',top_level_dir=str(V))
assert suite.countTestCases()==59,suite.countTestCases()
with (OUT/'HOST.stdout').open('w') as stdout,(OUT/'HOST.stderr').open('w') as stderr:
    with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
        result=unittest.TextTestRunner(stream=stderr,verbosity=2).run(suite)
assert len(calls)==1,calls
record={'interpreter':sys.executable,'version':sys.version,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'PASS':result.wasSuccessful(),'context':'Exactly one unchanged preexisting fakeGit test method wrapped in transport.REPO patch to fresh two-file actual-a9 fixture. Both original branches unchanged; no other test or global file reader patched. No product/auth/API/CI/Cosign calls.','context_test_calls':calls}
(OUT/'HOST-RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
sys.exit(0 if result.wasSuccessful() else 1)
