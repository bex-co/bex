"""Independent injected-I/O three-response admission probes; no API/auth."""
from pathlib import Path
import copy, datetime, json, sys, tempfile
from unittest.mock import patch
OUT=Path(__file__).resolve().parent
V=Path('/private/tmp/bex-w8-m83-live-transport-v5-free-contract-source-20261101-iqm0ez1e')
sys.path.insert(0,str(V))
import controller as c
import transport as t
import test_transport as f
import test_controller as facts
actual=json.loads((V/'V5-ACTUAL-SAFE-FREE-INPUTS.json').read_text())
at=facts.NOW.replace(hour=7,minute=27)
paths=['/v1/owners/'+c.WORKSPACE,'/v1/usage?ownerId='+c.WORKSPACE,'/v1/owners/'+c.WORKSPACE+'/limits']
values=dict(zip(paths,(actual['owner'],actual['usage'],actual['limits'])))
rows=[]
changes=['exit1','exit-bool','exit-float','partial','bound','signal','missing-transport','non200','age301','future','age300','age0']
for target in paths:
    for change in changes:
        with tempfile.TemporaryDirectory(prefix='probe-',dir=OUT) as directory:
            owned=f.FakeTransport(Path(directory).resolve());requests=[]
            def get_json(path,cleanup=False):
                requests.append(path)
                event={'at':(at-datetime.timedelta(seconds=1)).isoformat(),'status':200,
                       'transport':t.command_receipt(f.completed(),['CONTROL_ONLY_RESPONSE'],include_output=False)}
                if path==target:
                    if change=='exit1':event['transport']['exit_code']=1
                    if change=='exit-bool':event['transport']['exit_code']=False
                    if change=='exit-float':event['transport']['exit_code']=0.0
                    if change=='partial':event['transport']['complete']=False
                    if change=='bound':event['transport']['bound']='output-limit'
                    if change=='signal':event['transport']['signal']=15
                    if change=='missing-transport':event.pop('transport')
                    if change=='non200':event['status']=503
                    if change=='age301':event['at']=(at-datetime.timedelta(seconds=301)).isoformat()
                    if change=='future':event['at']=(at+datetime.timedelta(microseconds=1)).isoformat()
                    if change=='age300':event['at']=(at-datetime.timedelta(seconds=300)).isoformat()
                    if change=='age0':event['at']=at.isoformat()
                owned.last_metadata_event=event
                return copy.deepcopy(values[path])
            owned.get_json=get_json;accepted=False
            with patch.object(t,'now',return_value=at):
                try:
                    result=t.Transport.free_gate(owned);accepted=result['state']=='PASS'
                except c.Unproved:pass
            expected=change in ('age300','age0')
            assert accepted is expected,(target,change,accepted)
            assert requests==paths and owned.data['resources']==[]
            evidence=list((owned.root/'evidence').glob('free-gate-inputs-*.json'))
            assert len(evidence)==1
            assert json.loads(evidence[0].read_text())['usage']['coverage']==actual['usage']['coverage']
            rows.append({'target':target,'mutation':change,'expected_acceptance':expected,'accepted':accepted,'resources':[],'diagnostic_coverage_exact':True})
(OUT/'PROBE-RESULTS.json').write_text(json.dumps({'count':len(rows),'PASS':True,'rows':rows,'scope':'Injected I/O only; fresh timestamps synthetic. No actual allowance/coverage/live authority.'},indent=2)+'\n')
print(json.dumps({'count':len(rows),'PASS':True}))
