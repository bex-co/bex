from pathlib import Path
import ast, hashlib, json, stat, subprocess, sys
OUT=Path(__file__).resolve().parent
V=Path('/private/tmp/bex-w8-m83-live-transport-v5-free-contract-source-20261101-iqm0ez1e')
OLD=Path('/private/tmp/bex-w8-m83-live-transport-v4-free-source-20261101-d3q2zmdg')
REPO=Path('/Users/tianpan/projects/bex7')
ACTUAL='a9c66371978abe00c8b16fb5463e4fa9be11917c'
def sha(x):return hashlib.sha256(x).hexdigest()
def regular(p):
    assert stat.S_ISREG(p.lstat().st_mode) and not p.is_symlink(),str(p)
    return p.read_bytes()
def verify(root,expected=None):
    raw=regular(root/'MANIFEST.json')
    if expected:assert sha(raw)==expected
    rows=json.loads(raw)
    for path,desc in rows.items():
        p=Path(path);assert not p.is_absolute() and '..' not in p.parts
        data=regular(root/p);assert len(data)==desc['bytes'] and sha(data)==desc['sha256'],path
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p!=root/'MANIFEST.json'}
    assert actual==set(rows),(actual-set(rows),set(rows)-actual)
    return rows,sha(raw)
rows,manifest=verify(V,'3170ac92b9114f7846ae96d8f893a2068552816103d92cb46d3a7abed75f85a8')
old,oldmanifest=verify(OLD,'665ba3da921ec9724d01cf057efdb51b080e9b3b19090e2f79b1cdff33167d7f')
changed=[key for key in old if regular(V/key)!=regular(OLD/key)]
assert set(changed)=={'PLAN.json','controller.py','transport.py','test_controller.py','test_transport_v2.py'},changed
assert all(rows[p]==old[p] for p in old if p not in changed)
def functions(p):
    tree=ast.parse(regular(p));result={}
    for n in tree.body:
        if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):result[n.name]=ast.dump(n,include_attributes=False)
        if isinstance(n,ast.ClassDef):
            for f in n.body:
                if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef)):result[n.name+'.'+f.name]=ast.dump(f,include_attributes=False)
    return result
astchanges={}
for name in ('controller.py','transport.py','test_controller.py','test_transport_v2.py'):
    a,b=functions(OLD/name),functions(V/name)
    astchanges[name]=[key for key in sorted(set(a)|set(b)) if a.get(key)!=b.get(key)]
assert astchanges['controller.py']==['gate_free'],astchanges
assert astchanges['transport.py']==['Transport.free_gate'],astchanges
assert astchanges['test_controller.py']==['Controls.test_free_gate_requires_current_qa_workspace_meter_budget_and_capacity'],astchanges
assert astchanges['test_transport_v2.py']==['FreeBudgetContractControls.test_actual_partial_direct_values_are_budget_valid_only_with_fresh_successful_responses','FreeGateDiagnosticControls.test_refused_and_passing_real_gate_get_unchanged_inputs_after_safe_capture'],astchanges
primary=json.loads(regular(V/'V5-PRIMARY-SOURCE-RECORDS.json'))
print(type(primary).__name__)
print(json.dumps(primary)[:200])
result={'candidate':str(V),'manifest_sha256':manifest,'payload_count':len(rows),'payload_bytes':sum(d['bytes'] for d in rows.values()),'baseline':str(OLD),'baseline_manifest_sha256':oldmanifest,'baseline_payload_count':len(old),'changed_original_paths':changed,'unchanged_original_payloads':len(old)-len(changed),'function_AST_changes':astchanges}
(OUT/'BYTE-VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
