"""R5 retained-proof regressions only; no crypto, auth, network or real Ready claim."""
import copy
import datetime
import json
from pathlib import Path
import unittest
from unittest.mock import patch

import controller as c
import proof_binding as b
import proof_fixtures as f
import test_controller as prior
import test_transport as transport_facts
import transport as t
import tempfile


class ProofBindingControls(unittest.TestCase):
    def make(self):return f.Facts(prior.NOW,separate=True)
    def gate(self,facts):return c.gate_readiness(facts.ready,prior.NOW,lambda left,right:True,facts.read)
    def test_actual_retained218_signature_bytes_bind_exact_own_source_and_subject(self):
        facts=self.make();approval=facts.ready['APIApproval']
        expected=json.loads((f.HERE/'binding-context/actual218-signature-receipt.json').read_bytes())
        self.assertEqual(b.bind_signature(approval,facts.read)['source'],expected['source'])
        self.assertEqual(self.gate(facts)['APIApproval']['image'],expected['image'])
        self.assertNotEqual(approval['source'],facts.ready['source'])
        self.assertNotEqual(approval['image'],facts.ready['image'])

    def test_actual_new_raw_signature_schema_binds_without_unverified_projected_capture(self):
        raw=(f.HERE/'binding-context/actual-current-SIGNATURE-RECEIPT.json').read_bytes()
        actual=json.loads(raw);stdout=(f.HERE/'binding-context/actual218-signature-stdout.json').read_bytes()
        self.assertTrue(b.signature_capture(actual,stdout,actual['source'],actual['image'])['strict_command_output_bound'])
        for change in ('stop','argv','stdout','exit','claim','projection'):
            receipt=copy.deepcopy(actual)
            if change=='stop':receipt['stop']='timeout'
            if change=='argv':receipt['argv'][5]='https://foreign.invalid'
            if change=='stdout':receipt['stdout']['bytes']=True
            if change=='exit':receipt['exit']=False
            if change=='claim':receipt['actual_strict_crypto']='UNPROVED'
            if change=='projection':receipt['actual_process_receipt']='/private/tmp/unrelated.json'
            with self.subTest(change=change),self.assertRaises(b.ProofError):
                b.signature_capture(receipt,stdout,actual['source'],actual['image'])

    def test_actual_retained_inventory_run_job_log_extract_binds_without_fresh_Ready_claim(self):
        facts=self.make();ctx=f.HERE/'binding-context'
        run=json.loads((ctx/'actual-current-run.stdout').read_bytes())
        job=json.loads((ctx/'actual-current-job.stdout').read_bytes())
        raw=(ctx/'actual-current-inventory.json').read_bytes();log=(ctx/'actual-current-job.log').read_bytes()
        import re
        lines=log.splitlines(keepends=True)
        clean=[re.sub(rb'^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z ',b'',line) for line in lines]
        count=len(raw.splitlines());starts=[i for i in range(len(clean)-count+1) if b''.join(clean[i:i+count])==raw]
        self.assertEqual(len(starts),1)
        step=next(row for row in job['steps'] if row['name']==b.STEP)
        at=b.instant(step['started_at']);now=b.instant(step['completed_at'])+datetime.timedelta(seconds=10)
        inventory=json.loads(raw);r=facts.ready;r['at']=at.isoformat();r['readiness_proof']=facts.put('actual-full-inventory',raw)
        for field,podfield,container,name in [('Operator','ReadyPods','manager','bex-controller-manager'),('API','APIReadyPods','api','bex-api')]:
            r[field],r[podfield]=b.inventory_fields(inventory,container,name)
        entry={'repository':'bex-co/bex','operation':'inventory','workflow':b.WORKFLOW,'job_name':'cluster','step_name':b.STEP,
               'run_id':run['id'],'job_id':job['id'],'source':run['head_sha'],'attempt':run['run_attempt'],
               'run':facts.put('actual-run',(ctx/'actual-current-run.stdout').read_bytes()),
               'job':facts.put('actual-job',(ctx/'actual-current-job.stdout').read_bytes()),
               'log':facts.put('actual-job-log',log,'.log'),'inventory':r['readiness_proof'],
               'extraction':{'format':'github-timestamp-lines-v1','first_line':starts[0],'last_line':starts[0]+count}}
        r['observer_entry']=facts.put('actual-observer-entry',f.encoded(entry))
        result=b.bind_inventory(r,now,facts.read)
        self.assertEqual(result['inventory_sha256'],'4b3ac86c33429ce89ffb535c017712d64bf2b5c22c03dc3078cbbbb592f25d87')
        self.assertEqual(result['raw_log_sha256'],'23ea6f7427b9572c2a55d0654b1a152d3422d882a018f626274fe344a3ef591d')
        self.assertEqual(result['at'],at.isoformat())
        # Custody/health is separate from source eligibility and real current age.
        r['source']='d147703d7657f8795593deb2e74c9e7eac426cd2';r['image']=r['Operator']['image']
        with self.assertRaises(c.Unproved):c.gate_readiness(r,now,lambda left,right:False,facts.read)

    def test_operator_and_API_wrong_declared_source_or_image_reject_actual_unchanged_receipt(self):
        for role in ('operator','API'):
            for change in ('source','image'):
                facts=self.make();approval=facts.ready if role=='operator' else facts.ready['APIApproval']
                approval[change]='f'*40 if change=='source' else 'ghcr.io/bex-co/bex-operator@sha256:'+'b'*64
                with self.subTest(role=role,change=change),self.assertRaises(c.Unproved):self.gate(facts)

    def test_each_signature_receipt_requires_exact_identity_issuer_source_command_and_canonical_success(self):
        for role in ('operator','API'):
            for change in ('identity','issuer','command-source','command-image','extra-flag','tool','source','image',
                           'exit-bool','exit-str','exit-float','exit-failure','exit-timeout','partial','bound','signal',
                           'missing-exit','missing-command','missing-tool','missing-source','missing-image','proof-count'):
                facts=self.make();approval=facts.ready if role=='operator' else facts.ready['APIApproval']
                ref=approval['signature_receipt'];receipt=facts.document(ref)
                if change=='identity':receipt['command'][3]='https://github.com/foreign/repo/.github/workflows/deploy.yml@refs/heads/main'
                elif change=='issuer':receipt['command'][5]='https://foreign.invalid'
                elif change=='command-source':receipt['command'][7]='f'*40
                elif change=='command-image':receipt['command'][8]='ghcr.io/bex-co/bex-operator@sha256:'+'b'*64
                elif change=='extra-flag':receipt['command'].insert(2,'--insecure-ignore-tlog=true')
                elif change=='tool':receipt['tool_sha256']='f'*64
                elif change=='source':receipt['source']='f'*40
                elif change=='image':receipt['image']='ghcr.io/bex-co/bex-operator@sha256:'+'b'*64
                elif change.startswith('exit-'):receipt['exit']={'exit-bool':False,'exit-str':'0','exit-float':0.0,'exit-failure':1,'exit-timeout':124}[change]
                elif change=='partial':receipt['complete']=False
                elif change=='bound':receipt['bound']='output'
                elif change=='signal':receipt['signal']=15
                elif change.startswith('missing-'):receipt.pop('tool_sha256' if change=='missing-tool' else change[8:])
                elif change=='proof-count':receipt['proof_count']=True
                facts.replace(ref,receipt) # Outer file SHA is VALID for the adversarial receipt.
                with self.subTest(role=role,change=change),self.assertRaises(c.Unproved):self.gate(facts)

    def test_verified_stdout_needs_matching_subject_digest_signature_kind_and_complete_custody(self):
        for role in ('operator','API'):
            for change in ('subject','digest','no-signature','empty','not-list','malformed','raw-hash','missing-stdout'):
                facts=self.make();approval=facts.ready if role=='operator' else facts.ready['APIApproval']
                ref=approval['signature_stdout'];rows=facts.document(ref)
                if change=='subject':rows[0]['critical']['identity']['docker-reference']='ghcr.io/bex-co/bex-operator@sha256:'+'b'*64
                elif change=='digest':rows[0]['critical']['image']['docker-manifest-digest']='sha256:'+'b'*64
                elif change=='no-signature':
                    for row in rows:row['critical']['type']='https://spdx.dev/Document'
                elif change=='empty':rows=[]
                elif change=='not-list':rows={'critical':'wrong'}
                elif change=='malformed':rows=[{'critical':None}]
                elif change=='missing-stdout':approval.pop('signature_stdout')
                elif change=='raw-hash':rows[0]['optional']['CONTROL_ONLY']='changed-bytes'
                if change!='missing-stdout':
                    facts.replace(ref,rows)
                    receipt_ref=approval['signature_receipt'];receipt=facts.document(receipt_ref)
                    if change!='raw-hash':receipt['stdout_sha256']=ref['sha256']
                    receipt['proof_count']=len(rows);facts.replace(receipt_ref,receipt)
                with self.subTest(role=role,change=change),self.assertRaises(c.Unproved):self.gate(facts)

    def test_metadata_claims_cannot_relabel_actual_inventory_deployment_or_pods(self):
        for change in ('Operator.uid','Operator.generation','Operator.observedGeneration','Operator.image','Operator.name',
                       'API.uid','API.generation','API.image','ReadyPods.uid','ReadyPods.name','ReadyPods.imageID',
                       'ReadyPods.ready','APIReadyPods.uid','APIReadyPods.imageID','APIReadyPods.ready','omit-operator','omit-API'):
            facts=self.make()
            if change.startswith('omit-'):facts.ready['ReadyPods' if change=='omit-operator' else 'APIReadyPods']=[]
            else:
                field,key=change.split('.');row=facts.ready[field][0] if isinstance(facts.ready[field],list) else facts.ready[field]
                row[key]=False if key=='ready' else 4 if key in ('generation','observedGeneration') else 'CONTROL_ONLY_RELABELED'
            with self.subTest(change=change),self.assertRaises(c.Unproved):self.gate(facts)

    def test_observer_source_is_independent_but_exact_run_job_step_attempt_success_time_is_mandatory(self):
        self.assertEqual(self.gate(self.make())['inventory_observation']['source'],'e'*40)
        for target,changes in [('run',{'id':123,'head_sha':'f'*40,'path':'.github/workflows/foreign.yml','event':'push',
                                      'status':'in_progress','conclusion':'failure','run_attempt':2,'repository':{'full_name':'foreign/repo'}}),
                               ('job',{'id':123,'run_id':123,'head_sha':'f'*40,'name':'foreign','status':'in_progress',
                                       'conclusion':'failure','run_attempt':2})]:
            for key,value in changes.items():
                facts=self.make();entry=facts.document(facts.ready['observer_entry']);doc=facts.document(entry[target]);doc[key]=value
                facts.replace(entry[target],doc);facts.replace(facts.ready['observer_entry'],entry)
                with self.subTest(target=target,key=key),self.assertRaises(c.Unproved):self.gate(facts)
        for change in ('wrong-step','missing-step','duplicate-step','incomplete','failure','stale','future','reversed','packaging-time'):
            facts=self.make();entry=facts.document(facts.ready['observer_entry']);job=facts.document(entry['job']);step=job['steps'][0]
            if change=='wrong-step':step['name']='foreign'
            elif change=='missing-step':job['steps']=[]
            elif change=='duplicate-step':job['steps'].append(copy.deepcopy(step))
            elif change=='incomplete':step['status']='in_progress'
            elif change=='failure':step['conclusion']='failure'
            elif change=='stale':step['started_at']=(prior.NOW-datetime.timedelta(hours=2)).isoformat()
            elif change=='future':step['completed_at']=(prior.NOW+datetime.timedelta(seconds=1)).isoformat()
            elif change=='reversed':step['completed_at']=(prior.NOW-datetime.timedelta(seconds=5)).isoformat()
            elif change=='packaging-time':facts.ready['at']=prior.NOW.isoformat()
            facts.replace(entry['job'],job);facts.replace(facts.ready['observer_entry'],entry)
            with self.subTest(change=change),self.assertRaises(c.Unproved):self.gate(facts)

    def test_log_extraction_requires_exact_complete_inventory_and_bounded_descriptors(self):
        for change in ('inventory-rewritten','unrelated-log','range','bool-range','format','missing-run','missing-log',
                       'entry-source','entry-job','entry-workflow','entry-repository','ref-size','ref-hash','ref-relative','missing-entry'):
            facts=self.make();entry=facts.document(facts.ready['observer_entry'])
            if change=='inventory-rewritten':
                inventory=facts.document(entry['inventory']);inventory['appsWithDisks'].append({'CONTROL_ONLY':'changed'})
                facts.replace(entry['inventory'],inventory);facts.ready['readiness_proof']=entry['inventory']
            elif change=='unrelated-log':facts.docs[entry['log']['path']]=b'CONTROL_ONLY unrelated\n';entry['log'].update(bytes=23,sha256=b.sha(b'CONTROL_ONLY unrelated\n'))
            elif change=='range':entry['extraction']['first_line']=0
            elif change=='bool-range':entry['extraction']['first_line']=True
            elif change=='format':entry['extraction']['format']='arbitrary-python'
            elif change.startswith('missing-') and change!='missing-entry':entry.pop(change[8:])
            elif change.startswith('entry-'):entry[change[6:]]='CONTROL_ONLY different'
            elif change=='ref-size':entry['run']['bytes']=True
            elif change=='ref-hash':entry['run']['sha256']='0'*64
            elif change=='ref-relative':entry['run']['path']='relative.json'
            facts.replace(facts.ready['observer_entry'],entry)
            if change=='missing-entry':facts.ready.pop('observer_entry')
            with self.subTest(change=change),self.assertRaises(c.Unproved):self.gate(facts)

    def test_complete_active_pod_selection_cannot_omit_wrong_or_unready_actual_row(self):
        for container in ('manager','api'):
            facts=self.make();entry=facts.document(facts.ready['observer_entry']);inventory=facts.document(entry['inventory'])
            raw=next(p for p in inventory['platformImages']['pods'] if container in p['containerImages'])
            extra=copy.deepcopy(raw);extra['uid']='CONTROL_ONLY_EXTRA';extra['containerReady'][container]=False
            inventory['platformImages']['pods'].append(extra)
            actual=b.inventory_fields(inventory,container,'bex-controller-manager' if container=='manager' else 'bex-api')[1]
            self.assertEqual(len(actual),2);self.assertFalse(actual[1]['ready'])
            # Fully byte-qualified log/inventory; only the wrapper omits the extra live row.
            facts.replace_inventory(inventory)
            with self.assertRaises(c.Unproved):self.gate(facts)

    def test_full_bound_inventory_still_requires_real_typed_healthy_generation_spec_and_runtime(self):
        for change in ('bool-generation','bool-observed','float-count','old-generation','zero-count','runtime','phase','unready'):
            facts=self.make();entry=facts.document(facts.ready['observer_entry']);inventory=facts.document(entry['inventory'])
            d=inventory['platformImages']['deployments'][0];p=inventory['platformImages']['pods'][0]
            if change=='bool-generation':d['generation']=True
            elif change=='bool-observed':d['observedGeneration']=True
            elif change=='float-count':d['replicas']=1.0
            elif change=='old-generation':d['observedGeneration']=2
            elif change=='zero-count':d['replicas']=0
            elif change=='runtime':p['containerImageIds']['manager']='CONTROL_ONLY wrong'
            elif change=='phase':p['phase']='Pending'
            elif change=='unready':p['containerReady']['manager']=False
            facts.replace_inventory(inventory)
            dep,pods=b.inventory_fields(inventory,'manager','bex-controller-manager') if not change.startswith(('bool-','float-')) else (None,None)
            if dep is not None:facts.ready['Operator']=dep;facts.ready['ReadyPods']=pods
            with self.subTest(change=change),self.assertRaises(c.Unproved):self.gate(facts)

    def test_concrete_transport_rejects_actual_API_receipt_relabel_before_auth_even_with_critical_git_success(self):
        for change in ('API-image','API-source','operator-source','operator-image','operator-inventory'):
            with self.subTest(change=change),tempfile.TemporaryDirectory(prefix='m83-v3-proof-') as directory:
                root=Path(directory).resolve();owned=transport_facts.FakeTransport(root);facts=self.make()
                if change=='API-image':facts.ready['APIApproval']['image']='ghcr.io/bex-co/bex-operator@sha256:'+'b'*64
                if change=='API-source':facts.ready['APIApproval']['source']='f'*40
                if change=='operator-source':facts.ready['source']='f'*40
                if change=='operator-image':facts.ready['image']='ghcr.io/bex-co/bex-operator@sha256:'+'b'*64
                if change=='operator-inventory':facts.ready['Operator']['uid']='CONTROL_ONLY_WRONG_UID'
                owned.ready=facts.materialize(root);owned.ready_path.write_text(json.dumps(owned.ready));owned.ready_bytes_sha=t.digest(owned.ready_path)
                class Git:
                    def capture(self,*args,**kwargs):return transport_facts.completed()
                owned.runner=Git()
                with patch.object(t,'now',return_value=prior.NOW),self.assertRaises(c.Unproved):t.Transport.check_ready(owned)
                self.assertFalse(owned.auth_started)


if __name__=='__main__':unittest.main()
