// Harmless single first-deploy fixture. No dependencies or install step.
const fs = require('node:fs'), http = require('node:http');
const crypto = require('node:crypto'), zlib = require('node:zlib');
const MARKER = '__M83_MARKER__';
const PACKAGE_SHA256 = '4f2884fa761dee155f31cb960d792c2900dbaa6aecbe6ebcc3bcfd7e754706b8';
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const packageBytes = fs.readFileSync('package.json');
if (hash(packageBytes) !== PACKAGE_SHA256) throw Error('Public package bytes changed');
const programBytes = fs.readFileSync(__filename);
const payload = Buffer.from((MARKER + ' | plain web response | café 日本語\n').repeat(5000));
const authoredGzip = zlib.gzipSync(payload);
const etag = '"m83-' + hash(payload) + '"';
const snapshot = () => ({marker: MARKER, node: process.version, architecture: process.arch,
  package_sha256: hash(packageBytes), program_sha256: hash(programBytes),
  payload_bytes: payload.length, payload_sha256: hash(payload),
  authored_gzip_bytes: authoredGzip.length, authored_gzip_sha256: hash(authoredGzip)});
if (process.argv.includes('--build')) {
  fs.writeFileSync('m83-built.json', JSON.stringify(snapshot()));
  console.log(MARKER + '_BUILD_SOURCE_CONFIRMED');
  process.exit(0);
}
const built = JSON.parse(fs.readFileSync('m83-built.json', 'utf8'));
const server = http.createServer((req, res) => {
  const path = new URL(req.url, 'http://owned.example').pathname;
  res.setHeader('X-QA-Marker', MARKER);
  if (path === '/stream' || path === '/ndjson') {
    const sse = path === '/stream';
    res.writeHead(200, {'Content-Type': sse ? 'text/event-stream; charset=utf-8' : 'application/x-ndjson',
      'Cache-Control': 'no-cache'});
    res.flushHeaders();
    let seq = 0;
    const send = () => {
      const value = {marker: MARKER, seq, text: 'café 日本語', emitted: Date.now()};
      if (!sse) value.pad = 'x'.repeat(2048);
      res.write(sse ? 'id: ' + seq + '\nevent: tick\ndata: ' + JSON.stringify(value) + '\n\n'
        : JSON.stringify(value) + '\n');
      seq++;
    };
    send();
    const timer = setInterval(() => {
      if (seq < 3) send(); else {clearInterval(timer); res.end();}
    }, 1100);
    res.on('close', () => clearInterval(timer));
    return;
  }
  if (path === '/snapshot') {
    const body = Buffer.from(JSON.stringify({...snapshot(), built}));
    res.writeHead(200, {'Content-Type': 'application/json', 'Content-Length': body.length});
    res.end(req.method === 'HEAD' ? undefined : body);
    return;
  }
  let body = path === '/small' ? payload.subarray(0, 500) : payload;
  let status = 200;
  res.setHeader('Content-Type', path === '/png' ? 'image/png' : path === '/grpc'
    ? 'application/grpc' : 'text/plain; charset=utf-8');
  res.setHeader('Cache-Control', path === '/no-transform' ? 'no-cache, no-transform' : 'no-cache');
  res.setHeader('ETag', etag);
  if (path === '/etag' && req.headers['if-none-match'] === etag) {
    res.writeHead(304); res.end(); return;
  }
  if (path === '/range' && req.headers.range &&
      (!req.headers['if-range'] || req.headers['if-range'] === etag)) {
    const match = /^bytes=(\d+)-(\d+)$/.exec(req.headers.range);
    if (!match || +match[1] > +match[2] || +match[2] >= body.length) {
      res.writeHead(416, {'Content-Range': 'bytes */' + body.length}); res.end(); return;
    }
    const first = +match[1], last = +match[2], size = body.length;
    body = body.subarray(first, last + 1); status = 206;
    res.setHeader('Content-Range', 'bytes ' + first + '-' + last + '/' + size);
    res.setHeader('Accept-Ranges', 'bytes');
  }
  if (path === '/origin-gzip') {
    body = authoredGzip;
    res.setHeader('Content-Encoding', 'gzip');
    res.setHeader('Vary', 'Accept-Encoding');
  }
  res.setHeader('Content-Length', body.length);
  res.writeHead(status);
  res.end(req.method === 'HEAD' ? undefined : body);
});
// A finite upgrade control, no persistent shell or outbound connection.
server.on('upgrade', (req, socket) => {
  if (req.url !== '/upgrade' || req.headers.upgrade?.toLowerCase() !== 'websocket') {
    socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n'); return;
  }
  const accept = crypto.createHash('sha1').update(req.headers['sec-websocket-key'] +
    '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n' +
    'Sec-WebSocket-Accept: ' + accept + '\r\nX-QA-Marker: ' + MARKER + '\r\n\r\n');
  socket.end(Buffer.from([0x88, 0x00]));
});
server.listen(Number(process.env.PORT || 10000), '0.0.0.0');
