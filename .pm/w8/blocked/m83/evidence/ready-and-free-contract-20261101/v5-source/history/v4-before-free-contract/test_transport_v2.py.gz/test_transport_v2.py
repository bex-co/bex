"""Real owned parser/thread regressions and supplied Ready facts only. No network/auth."""
import copy
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

import controller as c
import transport as t
import test_controller as facts
import test_transport as fixtures
import proof_fixtures


def evidence_bytes(root):
    return b''.join(path.read_bytes() for path in (root/'evidence').rglob('*') if path.is_file())


class ParserRegressionControls(unittest.TestCase):
    def test_actual_partial_master_YAML_error_never_copies_control_token_into_RESULT(self):
        import yaml
        token='CONTROL_ONLY_YAML_TOKEN_42'
        raw='api:\n  key: '+token+': [\n'
        with self.assertRaises(yaml.YAMLError) as original:
            yaml.safe_load(raw)
        self.assertIn(token,str(original.exception))  # Actual PyYAML reproduction, not a synthetic error class.
        with tempfile.TemporaryDirectory(prefix='m83-v2-parser-control-') as directory:
            root=Path(directory).resolve();owned=fixtures.FakeTransport(root)
            config=root/'private/credentials/cli.yaml';config.parent.mkdir(parents=True)
            config.write_text(raw);config.chmod(0o600)
            owned.auth=lambda:t.Transport.credentials(owned)
            report=owned.execute()
            self.assertFalse(report['PASS'])
            self.assertEqual(report['failure'],'credential-master-read:ScannerError')
            self.assertNotIn(token,json.dumps(report))
            self.assertNotIn(token.encode(),evidence_bytes(root))
            self.assertEqual(config.read_text(),raw)  # No unqualified overwrite of the own recovery file.
            self.assertEqual(owned.tokens,set())

    def test_partial_rotated_config_keeps_only_output_hashes_and_preserves_valid_master(self):
        import yaml
        old='CONTROL_ONLY_OLD';rotated='CONTROL_ONLY_UNKNOWN_ROTATION'
        with tempfile.TemporaryDirectory(prefix='m83-v2-rotation-control-') as directory:
            root=Path(directory).resolve();owned=fixtures.FakeTransport(root)
            master=root/'private/credentials/cli.yaml';master.parent.mkdir(parents=True)
            master.write_text(yaml.safe_dump({'api':{'key':old,'host':t.API+'/v1/'}}));master.chmod(0o600)
            class Native:
                def capture(self,argv,env,**kwargs):
                    config=Path(env['RENDER_CLI_CONFIG_PATH'])
                    config.write_text('api:\n  key: '+rotated+': [\n');config.chmod(0o600)
                    result=fixtures.completed((old+' '+rotated).encode())
                    result['stderr']=(rotated+' parser fragment').encode()
                    return result
            owned.runner=Native()
            with self.assertRaises(t.PrivateConfigError) as caught:
                t.Transport.native(owned,'render',['services','create'],'http://127.0.0.1:1/v1/')
            self.assertEqual(str(caught.exception),'native-render-rotated-config-read:ScannerError')
            self.assertNotIn(rotated.encode(),evidence_bytes(root))
            self.assertNotIn(old.encode(),evidence_bytes(root))
            retained=list((root/'evidence/outputs').glob('native-opaque-failure-*.json'))
            self.assertEqual(len(retained),1)
            receipt=json.loads(retained[0].read_text())
            self.assertNotIn('stdout',receipt);self.assertNotIn('stderr',receipt)
            self.assertIn('stdout_sha256',receipt);self.assertIn('stderr_sha256',receipt)
            self.assertEqual(yaml.safe_load(master.read_text())['api']['key'],old)
            self.assertTrue((root/'private/config-render/cli.yaml').exists())

    def test_cleanup_parser_exception_is_static_phase_class_and_still_nonpassing(self):
        import yaml
        token='CONTROL_ONLY_CLEANUP_TOKEN'
        with tempfile.TemporaryDirectory(prefix='m83-v2-cleanup-parser-') as directory:
            root=Path(directory).resolve();owned=fixtures.FakeTransport(root)
            def bad_logout():yaml.safe_load('api:\n  key: '+token+': [\n')
            owned.logout=bad_logout
            with patch.object(t,'NativeRelay',fixtures.FakeRelay):report=owned.execute()
            self.assertFalse(report['PASS'])
            self.assertIn('own-auth-cleanup:ScannerError',report['cleanup_errors'])
            self.assertNotIn(token,json.dumps(report))
            self.assertNotIn(token.encode(),evidence_bytes(root))
            self.assertTrue(all(not live for live in owned.remote.values()))

    def test_complete_rotation_redacts_new_access_refresh_and_secret_values_before_logging(self):
        import yaml
        values={'key':'CONTROL_ONLY_ACCESS_NEW','refresh_token':'CONTROL_ONLY_REFRESH_NEW','client_secret':'CONTROL_ONLY_SECRET_NEW'}
        with tempfile.TemporaryDirectory(prefix='m83-v2-valid-rotation-') as directory:
            root=Path(directory).resolve();owned=fixtures.FakeTransport(root)
            master=root/'private/credentials/cli.yaml';master.parent.mkdir(parents=True)
            master.write_text(yaml.safe_dump({'api':{'key':'CONTROL_ONLY_ACCESS_OLD','host':t.API+'/v1/'}}));master.chmod(0o600)
            class Native:
                def capture(self,argv,env,**kwargs):
                    config=Path(env['BEX_CLI_CONFIG_PATH'])
                    config.write_text(yaml.safe_dump({'api':{**values,'host':env['BEX_HOST']}}));config.chmod(0o600)
                    return fixtures.completed((' '.join(values.values())+' CONTROL_ONLY_ACCESS_OLD').encode())
            owned.runner=Native()
            result=t.Transport.native(owned,'bex',['workspaces','-o','json'],t.API+'/v1/')
            self.assertEqual(result['exit_code'],0)
            for value in list(values.values())+['CONTROL_ONLY_ACCESS_OLD']:
                self.assertNotIn(value.encode(),evidence_bytes(root))
            restored=yaml.safe_load(master.read_text())['api']
            self.assertEqual({key:restored[key] for key in values},values)


class ListenerRegressionControls(unittest.TestCase):
    def owner(self,root):return fixtures.FakeTransport(root)

    def server_class(self,owned,events,fail_close=False):
        class Server:
            server_port=1
            def __init__(self,*args,**kwargs):
                if not owned.active_relays:raise AssertionError('listener not registered before allocation')
                events.append('registered-before-allocation');events.append('allocated-listener')
                self.stopped=threading.Event();self.close_calls=0
            def handle_request(self):self.stopped.wait(.01)
            def shutdown(self):raise AssertionError('shutdown must never run in partial startup')
            def server_close(self):
                self.close_calls+=1;events.append('server-close')
                if fail_close and self.close_calls==1:raise OSError('CONTROL_ONLY first close failure')
                self.stopped.set()
        return Server

    def test_thread_constructor_and_before_start_failures_close_without_shutdown_or_unstarted_join(self):
        for phase in ('constructor','start'):
            with self.subTest(phase=phase),tempfile.TemporaryDirectory(prefix='m83-v2-listener-') as directory:
                root=Path(directory).resolve();owned=self.owner(root);events=[]
                class Thread:
                    ident=None
                    def __init__(self,*args,**kwargs):
                        if phase=='constructor':raise RuntimeError('CONTROL_ONLY thread construction')
                    def start(self):raise RuntimeError('CONTROL_ONLY before start')
                    def is_alive(self):return False
                    def join(self,*args,**kwargs):raise AssertionError('never-started thread joined')
                relay=t.NativeRelay(owned,{}, {})
                with patch.object(t.http.server,'ThreadingHTTPServer',self.server_class(owned,events)),patch.object(t.threading,'Thread',Thread):
                    with self.assertRaises(RuntimeError):relay.__enter__()
                self.assertTrue(relay.listener_closed)
                self.assertNotIn(relay,owned.active_relays)
                self.assertEqual(events,['registered-before-allocation','allocated-listener','server-close'])

    def test_real_owned_thread_start_then_error_or_signal_is_stopped_and_joined(self):
        RealThread=threading.Thread
        for failure in (RuntimeError,KeyboardInterrupt):
            with self.subTest(failure=failure.__name__),tempfile.TemporaryDirectory(prefix='m83-v2-started-thread-') as directory:
                root=Path(directory).resolve();owned=self.owner(root);events=[]
                class StartedThread(RealThread):
                    def start(self):
                        super().start()
                        raise failure('CONTROL_ONLY after actual thread start')
                relay=t.NativeRelay(owned,{}, {})
                with patch.object(t.http.server,'ThreadingHTTPServer',self.server_class(owned,events)),patch.object(t.threading,'Thread',StartedThread):
                    with self.assertRaises(failure):relay.__enter__()
                self.assertTrue(relay.listener_closed)
                self.assertIsNotNone(relay.thread.ident)
                self.assertFalse(relay.thread.is_alive())
                self.assertNotIn(relay,owned.active_relays)
                self.assertEqual(events.count('server-close'),1)

    def test_failed_partial_close_retains_exact_owner_for_bounded_final_retry(self):
        with tempfile.TemporaryDirectory(prefix='m83-v2-retry-close-') as directory:
            root=Path(directory).resolve();owned=self.owner(root);events=[]
            class Thread:
                ident=None
                def __init__(self,*args,**kwargs):pass
                def start(self):raise RuntimeError('CONTROL_ONLY no start')
                def is_alive(self):return False
            relay=t.NativeRelay(owned,{}, {})
            with patch.object(t.http.server,'ThreadingHTTPServer',self.server_class(owned,events,fail_close=True)),patch.object(t.threading,'Thread',Thread):
                with self.assertRaises(RuntimeError):relay.__enter__()
            self.assertIn(relay,owned.active_relays)
            self.assertFalse(relay.listener_closed)
            relay.close()
            self.assertTrue(relay.listener_closed)
            self.assertNotIn(relay,owned.active_relays)
            self.assertEqual(events.count('server-close'),2)


class SeparateAPICarrierControls(unittest.TestCase):
    def ready(self):
        self.ready_facts=proof_fixtures.Facts(facts.NOW,separate=True)
        return self.ready_facts.ready
    def proof(self,path):return self.ready_facts.read(path)

    def test_healthy_independently_signed_older_API_is_valid_without_API_m83_ancestry(self):
        ready=self.ready();calls=[]
        def ancestor(left,right):calls.append((left,right));return True
        result=c.gate_readiness(ready,facts.NOW,ancestor,self.proof)
        self.assertEqual(result['state'],'PASS')
        self.assertEqual(result['APIApproval']['image'],ready['API']['image'])
        self.assertEqual(result['APIApproval']['source'],ready['APIApproval']['source'])
        self.assertFalse(result['APIApproval']['reused_operator_proof'])
        self.assertEqual(calls,[(c.FIX_SOURCE,ready['source'])])
        oracle=facts.Controls();oracle.setUp();shared=oracle.readiness()
        reused=c.gate_readiness(shared,facts.NOW,lambda left,right:True,oracle.proof)
        self.assertTrue(reused['APIApproval']['reused_operator_proof'])

    def test_separate_API_signature_spec_runtime_health_mismatches_and_old_operator_still_fail(self):
        for change in ('missing-approval','unsigned','bad-proof','wrong-approved-image','wrong-runtime-image','unready','old-operator'):
            ready=self.ready()
            if change=='missing-approval':ready.pop('APIApproval')
            if change=='unsigned':ready['APIApproval']['signedReady']=False
            if change=='bad-proof':ready['APIApproval']['signature_receipt']['sha256']='0'*64
            if change=='wrong-approved-image':ready['APIApproval']['image']=ready['image']
            if change=='wrong-runtime-image':ready['APIReadyPods'][0]['imageID']=ready['image']
            if change=='unready':ready['APIReadyPods'][0]['ready']=False
            with self.subTest(change=change),self.assertRaises(c.Unproved):
                c.gate_readiness(ready,facts.NOW,lambda left,right:change!='old-operator',self.proof)


class FreeGateDiagnosticControls(unittest.TestCase):
    def test_refused_and_passing_real_gate_get_unchanged_inputs_after_safe_capture(self):
        paths=['/v1/owners/'+c.WORKSPACE,'/v1/usage?ownerId='+c.WORKSPACE,
               '/v1/owners/'+c.WORKSPACE+'/limits']
        for refuse in (False,True):
            with self.subTest(refuse=refuse),tempfile.TemporaryDirectory(prefix='m83-v4-free-control-') as directory:
                root=Path(directory).resolve();owned=fixtures.FakeTransport(root)
                owner={'id':c.WORKSPACE,'name':c.WORKSPACE_NAME,'email':'CONTROL_ONLY_EMAIL_NOT_RETAINED'}
                usage={'workspaceId':c.WORKSPACE,'period':'2026-11',
                       'freeInstanceHours':{'used':10 if refuse else 0,'included':10},
                       'coverage':{'state':'complete','degradedSources':[],'through':facts.NOW.isoformat()},
                       'billing':'CONTROL_ONLY_BILLING_NOT_RETAINED'}
                limits={'services':{'used':1,'terminating':0,'limit':25},'postgres':{'used':0}}
                values=dict(zip(paths,(owner,usage,limits)));events={};requests=[]
                def get_json(path,cleanup=False):
                    requests.append((path,cleanup));raw=json.dumps(values[path]).encode()
                    event={'at':facts.NOW.isoformat(),'request':{'method':'GET','path':path,'authorization':'[REDACTED]'},
                           'raw_bytes':len(raw),'raw_sha256':c.sha(raw),'decoded_bytes':len(raw),'decoded_sha256':c.sha(raw)}
                    events[path]=event;owned.last_metadata_event=event
                    return copy.deepcopy(values[path])
                owned.get_json=get_json
                original=c.gate_free;calls=[]
                def gate(observed_owner,observed_usage,observed_limits,at):
                    retained=list((root/'evidence').glob('free-gate-inputs-*.json'))
                    self.assertEqual(len(retained),1)  # Exists before real gate returns or refuses.
                    doc=json.loads(retained[0].read_text())
                    self.assertEqual(doc['owner'],{'id':c.WORKSPACE,'name':c.WORKSPACE_NAME})
                    self.assertEqual(doc['usage'],{key:usage[key] for key in ('workspaceId','period','freeInstanceHours','coverage')})
                    self.assertEqual(doc['limits'],{'services':limits['services']})
                    self.assertEqual(doc['observations'],dict(zip(('owner','usage','limits'),(events[path] for path in paths))))
                    self.assertNotIn('CONTROL_ONLY_EMAIL',retained[0].read_text())
                    self.assertNotIn('CONTROL_ONLY_BILLING',retained[0].read_text())
                    self.assertEqual((observed_owner,observed_usage,observed_limits),(owner,usage,limits))
                    calls.append(True)
                    return original(observed_owner,observed_usage,observed_limits,at)
                with patch.object(t,'now',return_value=facts.NOW),patch.object(c,'gate_free',side_effect=gate):
                    if refuse:
                        with self.assertRaisesRegex(c.Unproved,'less than1h legal Free budget remains'):
                            t.Transport.free_gate(owned)
                    else:
                        self.assertEqual(t.Transport.free_gate(owned),original(owner,usage,limits,facts.NOW))
                self.assertEqual(requests,[(path,False) for path in paths]);self.assertEqual(calls,[True])
                refusal=list((root/'evidence').glob('free-gate-refusal-*.json'))
                self.assertEqual(len(refusal),int(refuse))
                if refuse:
                    doc=json.loads(refusal[0].read_text());self.assertEqual(doc['reason'],'less than1h legal Free budget remains')
                    self.assertTrue((root/'evidence'/doc['inputs']).is_file())
                self.assertEqual(owned.data['resources'],[])


if __name__=='__main__':unittest.main()
