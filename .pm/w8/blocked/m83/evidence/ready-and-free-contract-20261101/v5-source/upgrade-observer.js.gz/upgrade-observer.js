// Finite HTTP1 WebSocket handshake/close control, source only in this phase.
const https = require('node:https'), crypto = require('node:crypto');
const [url, marker] = process.argv.slice(2), parsed = new URL(url);
if (parsed.protocol !== 'https:' || !parsed.hostname.endsWith('.onbex.co') || parsed.username ||
    parsed.password || parsed.search || parsed.hash || parsed.pathname !== '/upgrade') throw Error('Not fixed public fixture');
const key = Buffer.from('m83-control-only').toString('base64');
let done = false;
const finish = row => {if (!done) {done = true; clearTimeout(timer); console.log(JSON.stringify(row)); request.destroy();}};
const request = https.request(url, {headers: {'Connection': 'Upgrade', 'Upgrade': 'websocket',
  'Sec-WebSocket-Key': key, 'Sec-WebSocket-Version': '13', 'Accept-Encoding': 'gzip',
  'User-Agent': 'bex-functional-qa/m83'} });
const timer = setTimeout(() => {finish({complete: false, error: 'Observation timeout'}); process.exitCode = 1;}, 10000);
request.on('upgrade', (response, socket, head) => {
  const chunks = [head]; let bytes = head.length;
  socket.on('data', chunk => {bytes += chunk.length; if (bytes > 1024) {socket.destroy(); finish({complete: false, error: 'Upgrade bound'}); return;} chunks.push(chunk);});
  socket.on('error', () => finish({complete: false, error: 'Upgraded socket error'}));
  socket.on('end', () => {
    const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
    const raw = Buffer.concat(chunks);
    finish({complete: true, status: response.statusCode, actual_protocol: response.httpVersion,
      headers: response.headers, raw_entity_base64: raw.toString('base64'),
      pass: response.statusCode === 101 && response.headers['x-qa-marker'] === marker &&
        response.headers['sec-websocket-accept'] === accept && !response.headers['content-encoding'] && raw.equals(Buffer.from([0x88,0x00]))});
  });
});
request.on('response', response => {response.resume(); finish({complete: false, status: response.statusCode, error: 'Upgrade refused'}); process.exitCode = 1;});
request.on('error', () => {finish({complete: false, error: 'Upgrade request error'}); process.exitCode = 1;});
request.end();
