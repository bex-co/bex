"""Pure main-only observer contract mutation; no external metadata fetch."""
import copy,json,pathlib,sys
r=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(r/'work'))
import proof_binding as b
ctx=r/'work/binding-context';run=json.loads((ctx/'actual-current-run.stdout').read_bytes());job=json.loads((ctx/'actual-current-job.stdout').read_bytes());entry=json.loads((r/'own-observer-entry.json').read_bytes())
now=b.instant(next(x for x in job['steps'] if x['name']==b.STEP)['completed_at'])
checks=[]
for target in ('run','job'):
 a=copy.deepcopy(run);z=copy.deepcopy(job);doc=a if target=='run' else z;actual=doc.get('head_branch');doc['head_branch']='independent-wrong-branch'
 try:b.inventory_observation(entry,a,z,now);accepted=True
 except b.ProofError:accepted=False
 checks.append({'metadata':target,'actual_retained_head_branch':actual,'mutated_head_branch':doc['head_branch'],'accepted':accepted})
(r/'BRANCH-PROBE.json').write_text(json.dumps({'scope':'Pure host metadata mutation only. Actual collected metadata is main; this is not an actual observer failure.','baseline_note':'Original bo8 admission.inventory_observation does not explicitly test head_branch; actual hcloud-csi-rollout cluster job has main-only workflow condition.','results':checks},indent=2)+'\n')
print(json.dumps(checks))
