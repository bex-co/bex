"""SYNTHETIC host facts, plus actual retained public218 API signature bytes.

No assertion of actual current Ready or fresh crypto. Never used by transport.
"""
import copy
import datetime
import json
from pathlib import Path
import proof_binding as b

HERE=Path(__file__).resolve().parent

def encoded(value):return (json.dumps(value,indent=2)+'\n').encode()

class Facts:
    def __init__(self,now,separate=False):
        self.docs={};self.now=now
        image='ghcr.io/bex-co/bex-operator@sha256:'+'d'*64;source='c'*40
        rows=[{'critical':{'identity':{'docker-reference':image},'image':{'docker-manifest-digest':image.split('@')[1]},'type':'https://sigstore.dev/cosign/sign/v1'},'optional':{}}]
        stdout=encoded(rows)
        signature={'source':source,'image':image,'command':b.signature_command(source,image),'exit':0,
                   'proof_count':len(rows),'tool_sha256':b.COSIGN_SHA,'stdout_sha256':b.sha(stdout)}
        at=now-datetime.timedelta(seconds=2)
        r={'requiredAncestor':'a15472735e63d9217b4db49f873ceaa69324f5d3','source':source,'image':image,
           'at':at.isoformat(),'ready':True,'signedReady':True,
           'signature_receipt':self.put('operator-signature',encoded(signature)),
           'signature_stdout':self.put('operator-stdout',stdout)}
        for field,pods,name,container in [('Operator','ReadyPods','bex-controller-manager','manager'),('API','APIReadyPods','bex-api','api')]:
            r[field]={'namespace':'bex-system','name':name,'uid':'CONTROL_ONLY_'+container+'_DEP_UID',
                      'generation':3,'observedGeneration':3,'replicas':1,'updatedReplicas':1,
                      'readyReplicas':1,'availableReplicas':1,'image':image}
            r[pods]=[{'namespace':'bex-system','name':name+'-CONTROL_ONLY','uid':'CONTROL_ONLY_'+container+'_POD_UID',
                      'phase':'Running','deletingAt':'','ready':True,'image':image,'imageID':image}]
        if separate:
            receipt=(HERE/'binding-context/actual218-signature-receipt.json').read_bytes()
            stdout=(HERE/'binding-context/actual218-signature-stdout.json').read_bytes()
            actual=json.loads(receipt)
            r['APIApproval']={'source':actual['source'],'image':actual['image'],'signedReady':True,
                              'signature_receipt':self.put('actual218-API-signature',receipt),
                              'signature_stdout':self.put('actual218-API-stdout',stdout)}
            r['API']['image']=actual['image']
            for p in r['APIReadyPods']:p['image']=p['imageID']=actual['image']
        r['critical_source']={path:{'bytes':1,'sha256':'a'*64} for path in
            ('lego/operator/internal/controller/edge_compression.go','lego/operator/internal/controller/app_controller.go')}
        inventory={'appsWithDisks':[],'claimsWhoseOwnerIsNotInDiskInventory':[],'storageClasses':[],
                   'platformImages':{'deployments':[],'pods':[]}}
        for field,podfield,container in [('Operator','ReadyPods','manager'),('API','APIReadyPods','api')]:
            d=copy.deepcopy(r[field]);d['containerImages']={container:d.pop('image')}
            inventory['platformImages']['deployments'].append(d)
            for p in r[podfield]:
                p=copy.deepcopy(p);p['containerImages']={container:p.pop('image')}
                p['containerImageIds']={container:p.pop('imageID')};p['containerReady']={container:p.pop('ready')}
                inventory['platformImages']['pods'].append(p)
        raw=encoded(inventory);r['readiness_proof']=self.put('inventory',raw)
        stamp=(at+datetime.timedelta(microseconds=100000)).isoformat().replace('+00:00','Z').encode()
        log=b'CONTROL_ONLY preamble\n'+b''.join(stamp+b' '+line for line in raw.splitlines(keepends=True))+b'CONTROL_ONLY footer\n'
        run={'id':800123,'head_sha':'e'*40,'path':b.WORKFLOW,'event':'workflow_dispatch',
             'status':'completed','conclusion':'success','run_attempt':1,'repository':{'full_name':'bex-co/bex'}}
        job={'id':900456,'run_id':run['id'],'head_sha':run['head_sha'],'name':'cluster','status':'completed',
             'conclusion':'success','run_attempt':1,'steps':[{'name':b.STEP,'status':'completed','conclusion':'success',
             'started_at':at.isoformat(),'completed_at':(at+datetime.timedelta(seconds=1)).isoformat()}]}
        entry={'repository':'bex-co/bex','operation':'inventory','workflow':b.WORKFLOW,'job_name':'cluster','step_name':b.STEP,
               'run_id':run['id'],'job_id':job['id'],'source':run['head_sha'],'attempt':1,
               'run':self.put('run',encoded(run)),'job':self.put('job',encoded(job)),'log':self.put('job-log',log,'.log'),
               'inventory':r['readiness_proof'],'extraction':{'format':'github-timestamp-lines-v1','first_line':1,'last_line':1+len(raw.splitlines())}}
        r['observer_entry']=self.put('observer-entry',encoded(entry));self.ready=r

    def put(self,name,raw,suffix='.json'):
        path='/private/tmp/CONTROL_ONLY_M83_V3/'+name+suffix;self.docs[path]=raw
        return {'path':path,'bytes':len(raw),'sha256':b.sha(raw)}
    def read(self,path):return self.docs[path]
    def document(self,ref):return json.loads(self.read(ref['path']))
    def replace(self,ref,value):
        raw=encoded(value);self.docs[ref['path']]=raw;ref.update(bytes=len(raw),sha256=b.sha(raw))
    def replace_inventory(self,inventory):
        entry=self.document(self.ready['observer_entry']);raw=encoded(inventory)
        inventory_ref=entry['inventory'];self.docs[inventory_ref['path']]=raw
        inventory_ref.update(bytes=len(raw),sha256=b.sha(raw));self.ready['readiness_proof']=dict(inventory_ref)
        at=b.instant(self.ready['at']);stamp=(at+datetime.timedelta(microseconds=100000)).isoformat().replace('+00:00','Z').encode()
        log=b'CONTROL_ONLY preamble\n'+b''.join(stamp+b' '+line for line in raw.splitlines(keepends=True))+b'CONTROL_ONLY footer\n'
        log_ref=entry['log'];self.docs[log_ref['path']]=log;log_ref.update(bytes=len(log),sha256=b.sha(log))
        entry['extraction']['last_line']=1+len(raw.splitlines())
        self.replace(self.ready['observer_entry'],entry)

    def materialize(self,root):
        refs={old:{'path':str(root/Path(old).name),'bytes':len(raw),'sha256':b.sha(raw)} for old,raw in self.docs.items()}
        def remap(value):
            if isinstance(value,dict):
                if value.get('path') in refs:return dict(refs[value['path']])
                return {k:remap(v) for k,v in value.items()}
            if isinstance(value,list):return [remap(v) for v in value]
            return value
        # Entry is the only JSON containing other refs; write it after leaf proofs.
        entry=self.document(self.ready['observer_entry']);entry_raw=encoded(remap(entry))
        entry_old=self.ready['observer_entry']['path'];refs[entry_old].update(bytes=len(entry_raw),sha256=b.sha(entry_raw))
        for old,raw in self.docs.items():(root/Path(old).name).write_bytes(entry_raw if old==entry_old else raw)
        return remap(self.ready)
