"""Source-only m83 phase controller and capture oracles. No network/login on import.

The CLI emits the exact plan or assesses supplied captures. It does not run a
live transport. A later reviewed execution harness must provide the real native
POST captures, current private-session metadata reads and public HTTP captures.
This separation makes this preparation safe to inspect before either live gate.
"""
import argparse
import base64
import datetime
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
import zlib
from urllib.parse import urlsplit

HERE = Path(__file__).resolve().parent
WORKSPACE = 'tea-da2isimlm39c739m4ofg'
WORKSPACE_NAME = 'bex-canary'
FIX_SOURCE = 'a15472735e63d9217b4db49f873ceaa69324f5d3'
RESET = datetime.datetime(2026, 11, 1, tzinfo=datetime.timezone.utc)
MAX_BODY = 1024 * 1024
MAX_METADATA = 2 * 1024 * 1024
MAX_SSE = 16384
SERVICE_ID = re.compile(r'srv-[a-z0-9]+\Z')
DEPLOY_ID = re.compile(r'dep-[a-z0-9]+\Z')
NONCE = re.compile(r'[a-f0-9]{12}\Z')


class Unproved(ValueError):
    pass


def require(condition, reason):
    if not condition:
        raise Unproved(reason)


def sha(body):
    return hashlib.sha256(body).hexdigest()


def instant(value):
    parsed = datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(parsed.utcoffset() is not None, 'UTC offset required')
    return parsed.astimezone(datetime.timezone.utc)


def completed(capture):
    require(type(capture.get('exit_code')) is int and capture['exit_code'] == 0,
            'capture did not complete with canonical exit0')
    require(capture.get('complete') is True and capture.get('bound') is None
            and capture.get('signal') is None, 'capture was partial, signaled or bounded')


def gate_readiness(receipt, now, ancestor_check, proof_reader):
    require(receipt.get('requiredAncestor') == FIX_SOURCE, 'wrong required m83 source')
    require(receipt.get('ready') is True and receipt.get('signedReady') is True,
            'actual signed Ready operator proof missing')
    source, image = receipt.get('source', ''), receipt.get('image', '')
    require(re.fullmatch('[a-f0-9]{40}', source) and
            re.fullmatch(r'ghcr.io/bex-co/bex-operator@sha256:[a-f0-9]{64}', image),
            'source or immutable operator image missing')
    require(ancestor_check(FIX_SOURCE, source) is True, 'source does not include m83')
    age = (now - instant(receipt['at'])).total_seconds()
    require(0 <= age <= 3600, 'Ready observation is not fresh within1h')
    for field in ('signature_receipt', 'readiness_proof'):
        proof = receipt.get(field, {})
        require(isinstance(proof.get('path'), str) and Path(proof['path']).is_absolute()
                and re.fullmatch('[a-f0-9]{64}', proof.get('sha256', ''))
                and proof['sha256'] == sha(proof_reader(proof['path'])),
                field + ' bytes differ')
    deployment = receipt.get('Operator', {})
    require(deployment.get('namespace') == 'bex-system' and
            deployment.get('name') == 'bex-controller-manager', 'proof is not the operator Deployment')
    require(type(deployment.get('generation')) is int and deployment['generation'] > 0
            and deployment.get('observedGeneration') == deployment['generation'],
            'operator generation was not observed')
    count = deployment.get('replicas')
    require(type(count) is int and count > 0 and all(deployment.get(key) == count for key in
            ('updatedReplicas', 'readyReplicas', 'availableReplicas')), 'operator rollout incomplete')
    require(deployment.get('image') == image, 'operator Deployment image differs')
    pods = receipt.get('ReadyPods', [])
    require(len(pods) == count, 'operator Ready pod set incomplete')
    require(len({row.get('uid') for row in pods}) == count and all(row.get('uid') and
            row.get('namespace') == 'bex-system' and row.get('deletingAt') in ('', None)
            and row.get('phase') == 'Running' and row.get('ready') is True
            and row.get('image') == image and row.get('imageID') == image for row in pods),
            'actual operator pod identity/readiness differs')
    require(receipt.get('traefikVersion') == 'v3.7.5', 'reviewed proxy version unbound')
    return {'state': 'PASS', 'source': source, 'image': image, 'at': receipt['at']}


def gate_free(owner, usage, limits, now):
    require(now >= RESET, 'recorded legal Free window has not opened')
    require(owner.get('id') == WORKSPACE and owner.get('name') == WORKSPACE_NAME,
            'current selected QA workspace differs')
    require(usage.get('workspaceId') == WORKSPACE and usage.get('period') == now.strftime('%Y-%m'),
            'usage is not current-month selected-workspace evidence')
    coverage = usage.get('coverage', {})
    require(coverage.get('state') == 'complete' and coverage.get('degradedSources') == [],
            'Free-hours coverage is incomplete; reset clock alone is insufficient')
    through = instant(coverage['through'])
    require(0 <= (now - through).total_seconds() <= 300, 'Free-hours observation stale')
    hours = usage.get('freeInstanceHours', {})
    used, included = hours.get('used'), hours.get('included')
    require(type(used) in (int, float) and type(included) in (int, float)
            and math.isfinite(used) and math.isfinite(included)
            and used >= 0 and included > 0 and included - used >= 1,
            'less than1h legal Free budget remains')
    service = limits.get('services', {})
    require(all(type(service.get(key)) is int and service[key] >= 0 for key in ('used', 'terminating', 'limit'))
            and service['terminating'] == 0 and service['used'] < service['limit'],
            'no clean Free service capacity')
    return {'state': 'PASS', 'workspace': WORKSPACE, 'period': usage['period'],
            'free_hours_remaining': included - used, 'services_before': dict(service)}


def specification(client, nonce, public_source, fixture=None):
    require(client in ('bex', 'render') and NONCE.fullmatch(nonce), 'invalid client/nonce')
    marker = 'QA_M83_' + nonce + '_' + client
    program = (fixture if fixture is not None else (HERE / 'fixture.js').read_text()).replace('__M83_MARKER__', marker)
    require('__M83_MARKER__' not in program and marker in program, 'marker substitution failed')
    require(public_source['package_sha256'] == '4f2884fa761dee155f31cb960d792c2900dbaa6aecbe6ebcc3bcfd7e754706b8',
            'public package source differs from fixture')
    payload = ((marker + ' | plain web response | café 日本語\n') * 5000).encode()
    require(len(payload) < MAX_BODY, 'fixture body exceeds cap')
    name = 'qa-20261101-' + nonce + '-m83-' + client
    build = "set -e\ncat > m83-server.js <<'M83_OWNED_NODE_FIXTURE'\n" + program + "\nM83_OWNED_NODE_FIXTURE\nnode m83-server.js --build"
    args = ['services', 'create', '--name', name, '--type', 'web_service', '--runtime', 'node',
            '--repo', public_source['repo'], '--branch', public_source['branch'], '--build-command', build,
            '--start-command', 'node m83-server.js', '--env-var', 'NODE_VERSION=24', '--plan', 'free',
            '--region', 'frankfurt', '--health-check-path', '/snapshot', '--auto-deploy=false', '--confirm', '-o', 'json']
    return {'client': client, 'name': name, 'marker': marker, 'workspace': WORKSPACE,
            'program': program, 'program_sha256': sha(program.encode()), 'build': build,
            'start': 'node m83-server.js', 'command': [client, *args], 'args': args,
            'source': public_source, 'payload_bytes': len(payload), 'payload_sha256': sha(payload)}


def expected_payload(spec):
    body = ((spec['marker'] + ' | plain web response | café 日本語\n') * 5000).encode()
    require(len(body) == spec['payload_bytes'] and sha(body) == spec['payload_sha256'], 'independent payload binding differs')
    return body


def validate_post(body, spec):
    require(body.get('ownerId') == WORKSPACE and body.get('name') == spec['name']
            and body.get('type') == 'web_service' and body.get('repo') == spec['source']['repo']
            and body.get('branch') == spec['source']['branch'] and body.get('autoDeploy') in ('no', False),
            'native POST outside exact first-deploy source intent')
    details = body.get('serviceDetails', {})
    commands = details.get('envSpecificDetails', {})
    require(details.get('plan') == 'free' and details.get('runtime') == 'node'
            and details.get('region') == 'frankfurt' and details.get('healthCheckPath') == '/snapshot'
            and commands.get('buildCommand') == spec['build'] and commands.get('startCommand') == spec['start']
            and not commands.get('preDeployCommand'), 'native POST runtime/Free/commands differ')
    require(body.get('envVars') == [{'key': 'NODE_VERSION', 'value': '24'}], 'unexpected environment request')
    require(not any(body.get(key) for key in ('disk', 'diskId', 'secretFiles', 'envGroupIds',
            'registryCredentialId', 'environmentId', 'projectId', 'image')) and
            not any(details.get(key) for key in ('disk', 'diskId', 'diskSizeGB', 'autoscaling')) and
            details.get('numInstances', 1) in (0, 1), 'fixture dependency, paid scaling or image not permitted')
    return True


class Journal:
    """Persist callback must atomically commit before forwarding the one native POST."""
    def __init__(self, data, persist):
        self.data, self.persist = data, persist
        require(data.get('workspace') == WORKSPACE and 'baseline_ids' in data, 'actual baseline missing')

    def intent(self, spec, ready, free):
        require(ready.get('state') == free.get('state') == 'PASS', 'live gates unproved')
        resources = self.data.setdefault('resources', [])
        require(len(resources) < 2 and not any(row['client'] == spec['client'] for row in resources),
                'two total creates; role may not be retried')
        require(all(row.get('state') in ('deleted', 'not-created') for row in resources),
                'one owned or uncertain service at a time')
        row = {'client': spec['client'], 'name': spec['name'], 'workspace': WORKSPACE,
               'state': 'intent', 'forwarded_once': False, 'children': []}
        resources.append(row); self.persist(self.data)
        return row

    def forward_once(self, row, body, spec):
        require(row in self.data['resources'] and row['state'] == 'intent' and not row['forwarded_once'],
                'POST already attempted; reconcile without replay')
        validate_post(body, spec)
        row.update(forwarded_once=True, state='forwarded-unknown', request=body)
        self.persist(self.data)  # Must finish before any external POST.

    def bind201(self, row, status, response):
        require(type(status) is int and status == 201 and row['forwarded_once']
                and row['state'] == 'forwarded-unknown', 'no unique actual HTTP201 forwarded intent')
        view = response.get('data', response).get('service', response.get('data', response))
        sid = view.get('id', '')
        require(SERVICE_ID.fullmatch(sid) and sid not in self.data['baseline_ids']
                and not any(other is not row and other.get('id') == sid for other in self.data['resources'])
                and view.get('ownerId') == WORKSPACE and view.get('name') == row['name']
                and view.get('type') == 'web_service' and view.get('serviceDetails', {}).get('plan') == 'free',
                'actual HTTP201 identity is not exact owned Free service')
        row.update(id=sid, HTTP=201, create_view=view, state='created'); self.persist(self.data)

    def own(self, sid):
        rows = [row for row in self.data['resources'] if row.get('id') == sid]
        require(len(rows) == 1 and sid not in self.data['baseline_ids'] and rows[0].get('HTTP') == 201,
                'not an exact actually captured own201 SID')
        row = rows[0]
        view = row.get('create_view', {})
        require(row.get('workspace') == WORKSPACE and row.get('forwarded_once') is True
                and view.get('id') == sid and view.get('name') == row.get('name')
                and view.get('ownerId') == WORKSPACE and view.get('type') == 'web_service'
                and view.get('serviceDetails', {}).get('plan') == 'free', 'stored ownership receipt differs')
        return row

    def deleted(self, sid, detail_status, child_statuses, final_url_status):
        row = self.own(sid)
        require(detail_status == 404 and final_url_status == 404 and
                set(child_statuses) == set(row['children']) and all(value == 404 for value in child_statuses.values()),
                'parent, former URL or recorded child absence unproved')
        row['state'] = 'deleted'; self.persist(self.data)

    def record_children(self, sid, deployments):
        row = self.own(sid)
        for deploy in deployments:
            identity = deploy.get('id', '')
            require(DEPLOY_ID.fullmatch(identity), 'invalid actual owned deploy child identity')
            if identity not in row['children']:
                row['children'].append(identity)
        self.persist(self.data)


def validate_first_live(spec, deployments, runtime_snapshot, build_log):
    require(len(deployments) == 1, 'first deployment only; no update/redeploy child allowed')
    deploy = deployments[0]
    require(DEPLOY_ID.fullmatch(deploy.get('id', '')) and deploy.get('status') == 'live'
            and deploy.get('commit', {}).get('id') == spec['source']['commit'], 'first Live/source commit differs')
    for snapshot in (runtime_snapshot, runtime_snapshot.get('built', {})):
        require(snapshot.get('marker') == spec['marker'] and re.fullmatch(r'v24\.\d+\.\d+', snapshot.get('node', ''))
                and snapshot.get('package_sha256') == spec['source']['package_sha256']
                and snapshot.get('program_sha256') == spec['program_sha256']
                and snapshot.get('payload_bytes') == spec['payload_bytes']
                and snapshot.get('payload_sha256') == spec['payload_sha256'], 'build/runtime artifact binding differs')
    require(spec['marker'] + '_BUILD_SOURCE_CONFIRMED' in build_log, 'actual build artifact marker missing')
    return {'state': 'PASS', 'first_deploy': deploy['id']}


def validate_settings(spec, sid, surface, view):
    require(surface in ('REST', 'GraphQL', 'MCP') and SERVICE_ID.fullmatch(sid), 'invalid metadata surface/SID')
    require(view.get('id') == sid and view.get('name') == spec['name']
            and view.get('repo') == spec['source']['repo'] and view.get('branch') == spec['source']['branch']
            and view.get('autoDeploy') in ('no', False), 'shared source/identity/autodeploy differs')
    if surface == 'GraphQL':
        details, commands = view, view
    else:
        require(view.get('ownerId') == WORKSPACE, 'shared service owner differs')
        details = view.get('serviceDetails', {})
        commands = details.get('envSpecificDetails', {})
    require(details.get('runtime') == 'node' and details.get('plan') == 'free'
            and commands.get('buildCommand') == spec['build'] and commands.get('startCommand') == spec['start'],
            'shared API runtime/Free/build/start settings differ')
    return {'state': 'PASS', 'surface': surface, 'id': sid}


def matrix(spec):
    etag = '"m83-' + spec['payload_sha256'] + '"'
    rows = []
    for name, offer, encoding in [('gzip', 'gzip', 'gzip'), ('br-gzip', 'br, gzip', 'gzip'),
            ('br-only', 'br', 'identity'), ('identity', 'identity', 'identity'),
            ('absent', None, 'identity'), ('empty', '', 'identity'),
            ('refused', 'gzip;q=0, br;q=0', 'identity')]:
        rows.append({'name': name, 'path': '/text', 'offer': offer, 'encoding': encoding, 'status': 200})
    rows.extend([
        {'name': 'no-transform-signed-difference', 'path': '/no-transform', 'offer': 'gzip', 'encoding': 'gzip', 'status': 200, 'etag': etag},
        {'name': 'strong-etag-signed-difference', 'path': '/etag', 'offer': 'gzip', 'encoding': 'gzip', 'status': 200, 'etag': etag},
        {'name': 'authored-gzip', 'path': '/origin-gzip', 'offer': 'br, gzip', 'encoding': 'gzip', 'status': 200, 'authored': True},
        {'name': 'head', 'path': '/text', 'offer': 'gzip', 'method': 'HEAD', 'encoding': 'identity', 'status': 200, 'empty': True},
        {'name': 'not-modified', 'path': '/etag', 'offer': 'gzip', 'headers': {'If-None-Match': etag}, 'encoding': 'identity', 'status': 304, 'empty': True},
        {'name': 'small', 'path': '/small', 'offer': 'gzip', 'encoding': 'identity', 'status': 200, 'slice': [0, 500]},
        {'name': 'excluded-image-type', 'path': '/png', 'offer': 'br, gzip', 'encoding': 'identity', 'status': 200},
        {'name': 'excluded-grpc-type', 'path': '/grpc', 'offer': 'gzip', 'encoding': 'identity', 'status': 200},
        {'name': 'small-range', 'path': '/range', 'offer': 'br, gzip', 'headers': {'Range': 'bytes=0-99'}, 'encoding': 'identity', 'status': 206, 'slice': [0, 100]},
        {'name': 'large-range', 'path': '/range', 'offer': 'br, gzip, zstd', 'headers': {'Range': 'bytes=100-200099'}, 'encoding': 'identity', 'status': 206, 'slice': [100, 200100]},
        {'name': 'if-range-match', 'path': '/range', 'offer': 'gzip', 'headers': {'Range': 'bytes=0-99', 'If-Range': etag}, 'encoding': 'identity', 'status': 206, 'slice': [0, 100]},
        {'name': 'if-range-mismatch', 'path': '/range', 'offer': 'gzip', 'headers': {'Range': 'bytes=0-99', 'If-Range': '"different"'}, 'encoding': 'gzip', 'status': 200},
    ])
    return [dict(row, protocol=protocol) for protocol in ('1.1', '2') for row in rows]


def public_url(spec, base, path):
    parsed = urlsplit(base)
    require(parsed.scheme == 'https' and parsed.hostname == spec['name'] + '.onbex.co'
            and parsed.port is None and not parsed.username and not parsed.password
            and parsed.path in ('', '/') and not parsed.query and not parsed.fragment,
            'not the exact created fixture public URL')
    require(path in {row['path'] for row in matrix(spec)} | {'/snapshot', '/stream', '/ndjson', '/upgrade'},
            'outside fixed public HTTP probes')
    return base.rstrip('/') + path


def curl_argv(spec, row, base, scratch):
    """Entity bytes, never curl --compressed; transfer framing is curl-decoded."""
    require(row in matrix(spec), 'unreviewed HTTP row')
    stem = row['protocol'].replace('.', '') + '-' + row['name']
    directory = Path(scratch)
    args = ['curl', '--disable', '--http1.1' if row['protocol'] == '1.1' else '--http2',
            '--silent', '--show-error', '--connect-timeout', '5', '--max-time', '15',
            '--max-filesize', str(MAX_BODY), '--max-redirs', '0', '--proto', '=https',
            '--header', 'User-Agent: bex-functional-qa/m83', '--dump-header', str(directory / (stem + '.headers')),
            '--output', str(directory / (stem + '.body')) if row.get('method') != 'HEAD' else '/dev/null',
            '--write-out', '%{http_code}\n%{http_version}']
    if row.get('method') == 'HEAD':
        args.append('--head')
    if row['offer'] is not None:
        args += ['--header', 'Accept-Encoding;' if row['offer'] == '' else 'Accept-Encoding: ' + row['offer']]
    for key, value in row.get('headers', {}).items():
        args += ['--header', key + ': ' + value]
    return [*args, public_url(spec, base, row['path'])]


def gunzip_bounded(body, limit=MAX_BODY):
    decoder = zlib.decompressobj(16 + zlib.MAX_WBITS)
    output = decoder.decompress(body, limit + 1)
    require(len(output) <= limit and not decoder.unconsumed_tail and decoder.eof and not decoder.unused_data,
            'gzip is oversized, incomplete or has unqualified trailing data')
    return output


def restore_entity(capture):
    wrapped = base64.b64decode(capture['raw_entity_gzip_base64'], validate=True)
    require(len(wrapped) <= MAX_BODY, 'capture wrapper exceeds bound')
    raw = gunzip_bounded(wrapped)
    require(len(raw) == capture['raw_bytes'] and sha(raw) == capture['raw_sha256'], 'raw entity custody differs')
    return raw


def assess_http(spec, row, capture, runtime_snapshot=None):
    try:
        completed(capture)
        raw = restore_entity(capture)
        require(capture.get('actual_protocol') == row['protocol'], 'HTTP2 offer fell back or protocol unobserved')
        status_lines = re.findall(r'(?m)^HTTP/(1\.1|2)(?:\.0)?\s+(\d{3})[^\r\n]*', capture.get('headers_raw', ''))
        require(status_lines and status_lines[-1] == (row['protocol'], str(capture.get('status'))),
                'raw status line does not bind actual protocol/status')
        headers = {name.lower(): value for name, value in capture.get('headers', {}).items()}
        encoding = headers.get('content-encoding', 'identity')
        require(encoding in ('identity', 'gzip'), 'unqualified response encoding')
        decoded = gunzip_bounded(raw) if encoding == 'gzip' else raw
        expected = b'' if row.get('empty') else expected_payload(spec)
        if row.get('slice'):
            expected = expected[slice(*row['slice'])]
        errors = []
        if capture.get('status') != row['status']: errors.append('status')
        if headers.get('x-qa-marker') != spec['marker']: errors.append('owned marker')
        if encoding != row['encoding']: errors.append('negotiated coding')
        if decoded != expected: errors.append('exact decoded entity')
        if row.get('etag') and headers.get('etag') != row['etag']: errors.append('signed ETag behavior')
        if row['path'] == '/no-transform' and 'no-transform' not in headers.get('cache-control', ''):
            errors.append('origin no-transform directive missing')
        if encoding == 'gzip' and not row.get('empty'):
            if len(raw) >= len(decoded): errors.append('no byte saving')
            if 'accept-encoding' not in [value.strip().lower() for value in headers.get('vary', '').split(',')]:
                errors.append('Vary')
        if row.get('authored'):
            require(runtime_snapshot is not None, 'authored gzip artifact binding missing')
            if sha(raw) != runtime_snapshot.get('authored_gzip_sha256') or len(raw) != runtime_snapshot.get('authored_gzip_bytes'):
                errors.append('authored representation changed')
        if row['status'] == 206:
            first, end = row['slice']
            if headers.get('content-range') != 'bytes ' + str(first) + '-' + str(end - 1) + '/' + str(spec['payload_bytes']):
                errors.append('Content-Range')
        if row['protocol'] == '2' and 'transfer-encoding' in headers: errors.append('HTTP2 transfer framing')
        if 'content-length' in headers and not row.get('empty'):
            if not headers['content-length'].isdigit() or int(headers['content-length']) != len(raw): errors.append('Content-Length')
        return {'state': 'FAIL' if errors else 'PASS', 'errors': errors, 'raw_bytes': len(raw),
                'raw_sha256': sha(raw), 'decoded_bytes': len(decoded), 'decoded_sha256': sha(decoded)}
    except (Unproved, ValueError, KeyError, TypeError, zlib.error) as error:
        return {'state': 'UNPROVED', 'reason': str(error)}


def assess_stream(spec, capture, protocol, kind):
    try:
        completed(capture)
        require(capture.get('error') is None and capture.get('actual_protocol') == protocol,
                'finite stream did not complete on required protocol')
        raw = base64.b64decode(capture['raw_entity_base64'], validate=True)
        require(len(raw) <= MAX_SSE and len(capture.get('text', '').encode()) <= MAX_SSE, 'finite stream exceeds bound')
        headers = {key.lower(): value for key, value in capture['headers'].items()}
        encoding = headers.get('content-encoding', 'identity')
        require(encoding in ('identity', 'gzip'), 'unqualified stream coding')
        decoded = gunzip_bounded(raw, MAX_SSE) if encoding == 'gzip' else raw
        require(decoded.decode() == capture['text'], 'raw stream and decoded observation differ')
        events = capture['events']
        require(len(events) == 3, 'three complete finite events not observed')
        frames = capture['text'].split('\n\n') if kind == 'sse' else capture['text'].split('\n')
        require(frames[-1] == '' and len(frames) == 4, 'complete exact finite event framing missing')
        for index, (frame, event) in enumerate(zip(frames[:-1], events)):
            require(event.get('frame') == frame, 'observed event frame differs from raw stream')
            if kind == 'sse':
                lines = frame.splitlines()
                require(lines[:2] == ['id: ' + str(index), 'event: tick'] and len(lines) == 3
                        and lines[2].startswith('data: '), 'finite SSE id/event/data framing differs')
                value = json.loads(lines[2][6:])
            else:
                value = json.loads(frame)
            require(value == event['value'], 'event value differs from raw frame')
        errors = []
        if capture['status'] != 200 or headers.get('x-qa-marker') != spec['marker']: errors.append('status/owned marker')
        if encoding != ('identity' if kind == 'sse' else 'gzip'): errors.append('stream coding')
        if any(event['value'].get('marker') != spec['marker'] or event['value'].get('seq') != index
               or event['value'].get('text') != 'café 日本語' or type(event['value'].get('emitted')) is not int
               for index, event in enumerate(events)): errors.append('event contents')
        arrivals = [event['at_ms'] for event in events]
        if not 0 <= arrivals[0] - capture['headers_ms'] <= 1000 or arrivals[-1] > capture['elapsed_ms'] or any(not 500 <= end - start <= 3500 for start, end in zip(arrivals, arrivals[1:])):
            errors.append('events buffered or timing outside observation contract')
        return {'state': 'FAIL' if errors else 'PASS', 'errors': errors, 'arrivals_ms': arrivals}
    except (Unproved, ValueError, KeyError, TypeError, zlib.error) as error:
        return {'state': 'UNPROVED', 'reason': str(error)}


def compare_cleanup(before, after, resources):
    require(before['workspace'] == after['workspace'] == WORKSPACE, 'baseline workspace changed')
    require(all(row.get('state') in ('deleted', 'not-created') for row in resources), 'own or uncertain fixture remains')
    missing = set(before['ids']) - set(after['ids'])
    require(not missing, 'baseline resources disappeared; do not repair foreign state')
    require(not ({row['id'] for row in resources if row.get('id')} & set(after['ids'])), 'own resource remains listed')
    require(all(value.get('terminating') == 0 for value in after['limits'].values() if isinstance(value, dict)),
            'quota termination has not converged to0')
    return {'state': 'PASS', 'baseline_preserved': True, 'own_resources_absent': True,
            'concurrent_additions': sorted(set(after['ids']) - set(before['ids']))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['emit-spec'])
    parser.add_argument('--nonce', default='0123456789ab')
    args = parser.parse_args()
    public = json.loads((HERE / 'PUBLIC-SOURCE.json').read_text())
    specs = [specification(client, args.nonce, public) for client in ('bex', 'render')]
    print(json.dumps({'source_only': True, 'live_execution_exposed': False,
                      'external_gates': ['fresh actual signed Ready m83 operator', 'current legal Free-hours QA window'],
                      'cases': [{**spec, 'HTTP_matrix': matrix(spec)} for spec in specs]}, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
