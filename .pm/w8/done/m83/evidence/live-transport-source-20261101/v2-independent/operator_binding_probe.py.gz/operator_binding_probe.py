"""Actual retained receipt + local Git only; otherwise SYNTHETIC Ready input."""
import copy,json,subprocess,sys,tempfile
from pathlib import Path
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'work'))
import controller as c
import transport as t
import test_controller as facts
import test_transport as fixtures
receipt=Path('/private/tmp/bex-w8-m83-ready-admission-prep-20261031-bo8cxu7u/context/old218-signature-receipt.json')
actual=json.loads(receipt.read_text());image=actual['image'];source='e392c101b74329428fd1f1a058fbdb233a049924'
with tempfile.TemporaryDirectory(prefix='m83-own-operator-proof-control-',dir='/private/tmp') as directory:
 root=Path(directory).resolve();obj=fixtures.FakeTransport(root);oracle=facts.Controls();oracle.setUp();ready=oracle.readiness()
 ready['source']=source;ready['image']=image
 ready['Operator']['image']=ready['API']['image']=image
 for pod in ready['ReadyPods']+ready['APIReadyPods']:pod['image']=pod['imageID']=image
 proof=root/'SYNTHETIC-INVENTORY.json';proof.write_text('{}')
 ready['readiness_proof']={'path':str(proof),'sha256':c.sha(proof.read_bytes())}
 ready['signature_receipt']={'path':str(receipt),'sha256':c.sha(receipt.read_bytes())}
 ready['APIApproval']={'source':actual['source'],'image':image,'signedReady':True,'signature_receipt':ready['signature_receipt']}
 ready['critical_source']=t.read_json(r/'work/CRITICAL-SOURCE.json')['files']
 obj.ready=ready;obj.ready_path.write_text(json.dumps(ready));obj.ready_bytes_sha=t.digest(obj.ready_path)
 class LocalGit:
  def capture(self,argv,**kwargs):
   assert argv[:3]==['git','-C',str(t.REPO)] and argv[3] in ('merge-base','show')
   p=subprocess.run(argv,capture_output=True,timeout=10)
   out=fixtures.completed(p.stdout);out['exit_code']=p.returncode;out['stderr']=p.stderr
   return out
 obj.runner=LocalGit()
 from unittest.mock import patch
 with patch.object(t,'now',return_value=facts.NOW):result=t.Transport.check_ready(obj)
 output={'result':result['state'],'claimed_operator_source':source,'actual_retained_signature_receipt_source':actual['source'],'signature_image_matches':image==actual['image'],'claimed_source_has_actual_a154_ancestry_and_critical_bytes':True,'API_approval_source_is_correct_old_signed_source':ready['APIApproval']['source'],'scope':'Actual old218 receipt bytes and genuine local Git checks; normalized rollout/inventory/time/proof are SYNTHETIC only. No actual Ready, auth, network or crypto claim.'}
(r/'operator-binding-probe.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
