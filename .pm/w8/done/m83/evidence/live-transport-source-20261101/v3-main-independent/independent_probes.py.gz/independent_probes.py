"""Independent old real-proof relabel controls. No crypto, live Ready or external action."""
import copy,datetime,hashlib,json,pathlib,re,sys
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'work'))
import proof_binding as b
import controller as c
ctx=ROOT/'work/binding-context';rows=[]
def record(name,call,expected_reject=True):
 try:
  result=call();out={'rejected':False,'result_scope':'retained-byte binder only; NOT live Ready'}
 except (b.ProofError,c.Unproved) as error:out={'rejected':True,'exception':type(error).__name__,'reason':str(error)}
 assert out['rejected'] is expected_reject,(name,out)
 rows.append({'name':name,**out})
stdout=(ctx/'actual218-signature-stdout.json').read_bytes()
for role,name in [('old218','actual218-signature-receipt.json'),('oldm83','actual-current-SIGNATURE-RECEIPT.json')]:
 actual=json.loads((ctx/name).read_bytes())
 record(role+'_unchanged_byte_binding',lambda a=actual:b.signature_capture(a,stdout,a['source'],a['image']),False)
 record(role+'_claimed_new_fixed_source',lambda a=actual:b.signature_capture(a,stdout,c.FIX_SOURCE,a['image']))
 record(role+'_claimed_new_immutable_image',lambda a=actual:b.signature_capture(a,stdout,a['source'],'ghcr.io/bex-co/bex-operator@sha256:'+'b'*64))
 # Validly rehashed declaration cannot rewrite the exact actual command/output.
 forged=copy.deepcopy(actual);forged['source']=c.FIX_SOURCE
 record(role+'_relabeled_source_field_only',lambda a=forged:b.signature_capture(a,stdout,a['source'],a['image']))

def ref(p):
 body=p.read_bytes();return {'path':str(p),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
run=json.loads((ctx/'actual-current-run.stdout').read_bytes());job=json.loads((ctx/'actual-current-job.stdout').read_bytes())
raw=(ctx/'actual-current-inventory.json').read_bytes();log=(ctx/'actual-current-job.log').read_bytes()
lines=log.splitlines(keepends=True);clean=[re.sub(rb'^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z ',b'',x) for x in lines]
count=len(raw.splitlines());matches=[i for i in range(len(clean)-count+1) if b''.join(clean[i:i+count])==raw];assert len(matches)==1
step=next(x for x in job['steps'] if x['name']==b.STEP);start=b.instant(step['started_at']);simulated_observation_time=b.instant(step['completed_at'])+datetime.timedelta(seconds=10)
wrapper={'at':start.isoformat(),'readiness_proof':ref(ctx/'actual-current-inventory.json')};inventory=json.loads(raw)
for field,podfield,container,name in [('Operator','ReadyPods','manager','bex-controller-manager'),('API','APIReadyPods','api','bex-api')]:wrapper[field],wrapper[podfield]=b.inventory_fields(inventory,container,name)
entry={'repository':'bex-co/bex','operation':'inventory','source':run['head_sha'],'run_id':run['id'],'job_id':job['id'],'attempt':run['run_attempt'],'workflow':b.WORKFLOW,'job_name':'cluster','step_name':b.STEP,'run':ref(ctx/'actual-current-run.stdout'),'job':ref(ctx/'actual-current-job.stdout'),'log':ref(ctx/'actual-current-job.log'),'inventory':wrapper['readiness_proof'],'extraction':{'format':'github-timestamp-lines-v1','first_line':matches[0],'last_line':matches[0]+count}}
p=ROOT/'own-observer-entry.json';p.write_text(json.dumps(entry,indent=2)+'\n');wrapper['observer_entry']=ref(p)
reader=lambda p:pathlib.Path(p).read_bytes()
record('oldm83_complete_actual_inventory_custody_at_historical_time',lambda:b.bind_inventory(wrapper,simulated_observation_time,reader),False)
for name,mutate in [('new_operator_image',lambda x:x['Operator'].update(image='ghcr.io/bex-co/bex-operator@sha256:'+'b'*64)),('new_operator_runtime',lambda x:x['ReadyPods'][0].update(imageID='ghcr.io/bex-co/bex-operator@sha256:'+'b'*64)),('new_API_uid',lambda x:x['API'].update(uid='INDEPENDENT_CONTROL_DIFFERENT_UID')),('new_packaging_time',lambda x:x.update(at=simulated_observation_time.isoformat()))]:
 w=copy.deepcopy(wrapper);mutate(w);record('oldm83_inventory_cannot_claim_'+name,lambda w=w:b.bind_inventory(w,simulated_observation_time,reader))
# Full controller must reject relabeled fixed source with genuine old strict proof,
# even when a host stub marks ancestry eligible. This is NOT a real ancestry proof.
a=json.loads((ctx/'actual-current-SIGNATURE-RECEIPT.json').read_bytes());full=copy.deepcopy(wrapper);full.update(requiredAncestor=c.FIX_SOURCE,source=c.FIX_SOURCE,image=a['image'],ready=True,signedReady=True,signature_receipt=ref(ctx/'actual-current-SIGNATURE-RECEIPT.json'),signature_stdout=ref(ctx/'actual218-signature-stdout.json'))
record('full_gate_rejects_oldm83_signature_as_fixed_operator_despite_ancestry_stub',lambda:c.gate_readiness(full,simulated_observation_time,lambda *_:True,reader))
# Bind full actual inventory directly; a current clock must not refresh old evidence.
record('oldm83_actual_step_stale_at_current_UTC',lambda:b.bind_inventory(wrapper,datetime.datetime.now(datetime.timezone.utc),reader))
(ROOT/'INDEPENDENT-PROBES.json').write_text(json.dumps({'scope':'Actual retained old proof byte/shape controls only. Positive checks are historical custody at simulated observation time, never fresh live or cryptographic verification. All declared newer identities are explicit negative controls.','results':rows},indent=2)+'\n')
print(json.dumps({'checks':len(rows),'negative_controls_rejected':sum(x['rejected'] for x in rows),'historical_byte_binding_positives':sum(not x['rejected'] for x in rows),'all_expected_outcomes':True}))
