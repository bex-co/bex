from pathlib import Path
import ast, datetime, hashlib, json, stat
OUT=Path(__file__).resolve().parent
V=Path('/private/tmp/bex-w8-m83-live-transport-v5-free-contract-source-20261101-iqm0ez1e')
OLD=Path('/private/tmp/bex-w8-m83-live-transport-v4-free-source-20261101-d3q2zmdg')
def sha(x):return hashlib.sha256(x).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
for root,expected in ((V,'3170ac92b9114f7846ae96d8f893a2068552816103d92cb46d3a7abed75f85a8'),(OLD,'665ba3da921ec9724d01cf057efdb51b080e9b3b19090e2f79b1cdff33167d7f')):
    raw=(root/'MANIFEST.json').read_bytes();assert sha(raw)==expected
    for path,d in json.loads(raw).items():
        p=root/path;assert stat.S_ISREG(p.lstat().st_mode) and not p.is_symlink()
        data=p.read_bytes();assert len(data)==d['bytes'] and sha(data)==d['sha256']
    assert not any(p.is_symlink() for p in root.rglob('*'))
# Check all nonfunction executable module nodes, too: only the declared workspace name changes.
for file,allowed in [('controller.py','gate_free'),('transport.py','Transport')]:
    a,b=ast.parse((OLD/file).read_bytes()),ast.parse((V/file).read_bytes())
    def normalize(tree):
        for n in tree.body:
            if file=='controller.py' and isinstance(n,ast.FunctionDef) and n.name=='gate_free':n.body=[]
            if file=='controller.py' and isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='WORKSPACE_NAME' for t in n.targets):n.value=ast.Constant(value='NORMALIZED_DECLARED_WORKSPACE_NAME')
            if file=='transport.py' and isinstance(n,ast.ClassDef) and n.name=='Transport':
                for f in n.body:
                    if isinstance(f,ast.FunctionDef) and f.name=='free_gate':f.body=[]
        return ast.dump(tree,include_attributes=False)
    assert normalize(a)==normalize(b),file
host=json.loads((OUT/'HOST-RESULT.json').read_text());probe=json.loads((OUT/'PROBE-RESULTS.json').read_text())
assert host['PASS'] and host['tests']==59 and host['failures']==0 and host['errors']==0 and host['skips']==0
assert probe['PASS'] and probe['count']==36
review={
 'schema':'bex.m83.v5-free-contract-independent-source-review/v1',
 'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'verdict':'CLEAN_SOURCE_ONLY_NOT_LIVE_ADMISSION',
 'candidate':str(V),'candidate_manifest_sha256':'3170ac92b9114f7846ae96d8f893a2068552816103d92cb46d3a7abed75f85a8',
 'findings':[],
 'custody':{'candidate_payloads':164,'candidate_payload_bytes':1218690,'all_SHA_size_regular_files_verified_before_and_after':True,'all_original_V4_137_payloads_verified':True,'V5_changed_original_paths':['PLAN.json','controller.py','transport.py','test_controller.py','test_transport_v2.py'],'other132_original_payloads_exact':True,'all_nonfunction_executable_nodes_exact_except_declared_WORKSPACE_NAME':True,'production_function_AST_changes_only':['controller.gate_free','transport.Transport.free_gate'],'no_readiness_auth_create_wire_cleanup_logout_AST_change':True},
 'source_contract':{'carrier':'a9c66371978abe00c8b16fb5463e4fa9be11917c','four_retained_backend_files_exact_local_Git_bytes':True,'allowance':'usage/service.go:1647-1660 sums Free service instance_seconds; freehours/freehours.go:95-123 sweeps the same monthly unit; store/usage.go:568-595 filters Free service instance_seconds in hourly/monthly totals.','coverage':'usage/service.go:177-179 and store/usage.go:309-312,414-450 define explicit aggregate source health and contiguous hourly Through. usage/service.go:1388-1420 uses direct only for egress evidence. REST coverage serialization is independent at usage/rest.go:111-119. No Free enforcement coverage condition is introduced.','safe_actual_input_projection_exact_to_original_hash':True,'same_fixed_workspace_ID_actual_name':'tea-da2isimlm39c739m4ofg / tian-personal','retained_coverage':'partial / direct / Through2026-11-01T00:00:00Z remains diagnostic; no aggregate-health claim'},
 'admission_logic':{'remaining_threshold_hours':1,'unchanged':'post-reset wall clock, same fixed workspace ID/name, current UTC month, finite non-bool numeric used>=0/included>0, remaining>=1h, typed nonnegative integer service fields, terminating0 and spare or unlimited capacity','three_actual_response_events':'owner/usage/limits actual GET event; status200, int exit0, completeTrue, signalNone, boundNone, timestamp age0..300 seconds with no future. Single checked_at snapshot.','coverage_diagnostic':'safe projection retained before refusal; aggregate state/Through are not substituted for response freshness.','all_38_HTTP_6_streams_finite_upgrade_original_client_first201_cleanup_contracts_unchanged':True},
 'validation':{'full_host_run':{'tests':59,'failures':0,'errors':0,'skips':0,'seconds':2.738,'runs':1,'interpreter':host['interpreter'],'version':host['version'],'context':host['context']},'independent_three_response_probes':{'count':36,'PASS':True,'negative_axes':['exit1','bool_exit','float_exit','partial','bound','signal','missing_transport','non200','age301','future_microsecond'],'positive_boundary_axes':['age300','age0'],'all_three_inputs_checked':True,'no_resources_and_exact_diagnostic_coverage':True},'read_only_candidate_and_V4_postcheck':True},
 'scope':{'repo_edits':False,'candidate_or_old_edits':False,'auth_network_API_Cosign_CI_Go_Docker_Kube_actions':False,'original28_edits':False,'prior_actual_attempts_not_reclassified':True},
 'not_established':{'current_legal_Free':None,'coverage_health':None,'fresh_runtime_Ready':None,'live_functional_PASS':None,'retry_authorization':None},
 'notes':'Source correction only. Future execution still needs fresh actual Ready, current legal Free observations and Root authorization. Review harness preparation errors were reviewer-only label/inventory assertions; scripts/history retained. No failed candidate host controls.'
}
write(OUT/'REVIEW.json',review)
rows={}
for p in sorted(OUT.rglob('*')):
    if p.is_file() and p!=OUT/'MANIFEST.json':
        assert stat.S_ISREG(p.lstat().st_mode) and not p.is_symlink()
        data=p.read_bytes();rows[p.relative_to(OUT).as_posix()]={'bytes':len(data),'sha256':sha(data)}
assert sum(x['bytes'] for x in rows.values())<1024*1024
write(OUT/'MANIFEST.json',rows)
for p in OUT.rglob('*'):
    if p.is_file():p.chmod(0o400)
print(json.dumps({'root':str(OUT),'payload_count':len(rows),'payload_bytes':sum(x['bytes'] for x in rows.values()),'REVIEW_sha256':sha((OUT/'REVIEW.json').read_bytes()),'MANIFEST_sha256':sha((OUT/'MANIFEST.json').read_bytes()),'verdict':review['verdict']},indent=2))
