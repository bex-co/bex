"""Pure supplied-state/owned filesystem controls; no product calls or real auth."""
import copy,json,sys,tempfile
from pathlib import Path
from unittest.mock import patch
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'work'))
import controller as c
import transport as t
import test_controller as fixtures
import test_transport as tests
results={}
# Known independently signed API image may stay healthy independently of the
# actual operator carrier. Root's current contract does not require API a154.
oracle=fixtures.Controls();oracle.setUp();ready=oracle.readiness()
api_image='ghcr.io/bex-co/bex-operator@sha256:'+'b'*64
ready['API']['image']=api_image
for pod in ready['APIReadyPods']:pod['image']=pod['imageID']=api_image
try:c.gate_readiness(ready,fixtures.NOW,lambda left,right:True,lambda path:b'CONTROL ONLY')
except c.Unproved as e:results['healthy_independent_API_carrier']={'current_result':'REJECT','reason':str(e),'scope':'synthetic otherwise-valid manager gate and healthy different signed API carrier; no live proof or crypto executed'}
else:results['healthy_independent_API_carrier']={'current_result':'PASS'}
# A partial native YAML write can raise an actual PyYAML error before tokens
# are collected; execute currently puts its unredacted str(error) into evidence.
try:import yaml
except ImportError:results['YAML_exception_redaction']={'state':'NOT_RUN','reason':'PyYAML absent; no dependency installed'}
else:
 with tempfile.TemporaryDirectory(prefix='m83-own-yaml-error-control-') as directory:
  own=Path(directory).resolve();obj=tests.FakeTransport(own)
  config=own/'private/credentials/cli.yaml';config.parent.mkdir(parents=True)
  token='CONTROL_ONLY_YAML_TOKEN_42'
  config.write_text('api:\n  key: '+token+': [\n');config.chmod(0o600)
  obj.auth=lambda:t.Transport.credentials(obj)
  with patch.object(t,'NativeRelay',tests.FakeRelay):report=obj.execute()
  evidence=(own/'evidence/RESULT.json').read_text()
  results['YAML_exception_redaction']={'actual_parser':'PyYAML '+yaml.__version__,'PASS':report['PASS'],'control_token_in_failure':token in str(report['failure']),'control_token_in_evidence':token in evidence,'failure_class':report['failure'].split(':',1)[0],'no_actual_auth':True}
# Thread.start failure before registration leaves an allocated listening server
# unclosed. Substitute only the local server/thread, never bind a socket.
with tempfile.TemporaryDirectory(prefix='m83-own-relay-init-control-') as directory:
 obj=tests.FakeTransport(Path(directory).resolve());events=[]
 class Server:
  daemon_threads=False
  server_port=1
  def __init__(self,*a,**k):events.append('allocated-listener')
  def serve_forever(self):pass
  def shutdown(self):events.append('shutdown')
  def server_close(self):events.append('server-close')
 class Thread:
  def __init__(self,*a,**k):pass
  def start(self):raise RuntimeError('CONTROL_ONLY thread start failure')
 relay=t.NativeRelay(obj,{}, {})
 with patch.object(t.http.server,'ThreadingHTTPServer',Server),patch.object(t.threading,'Thread',Thread):
  try:relay.__enter__()
  except RuntimeError:pass
 results['relay_partial_start']={'events':events,'registered_for_finish_cleanup':relay in obj.active_relays,'server_closed':'server-close' in events,'no_real_socket_or_thread_created':True}
(root/'counterexamples.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
