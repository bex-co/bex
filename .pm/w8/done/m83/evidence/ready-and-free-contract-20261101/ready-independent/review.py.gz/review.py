import ast, datetime, hashlib, importlib.util, json, os, pathlib, stat, subprocess, sys, time
R=pathlib.Path(__file__).resolve().parent
S=pathlib.Path('/private/tmp/bex-w8-m83-live-transport-v3-main-source-20261101-9b2_pe4q')
P=pathlib.Path('/private/tmp/bex-w8-m83-actual-ready-v3-20261101-7sjz7gxz')
C=pathlib.Path('/private/tmp/bex-w8-m83-fresh-inventory-collect-20261101-nei306je')
REPO=pathlib.Path('/Users/tianpan/projects/bex7')
custody={}
def body(p,cap=2<<20):
 p=pathlib.Path(p); st=p.lstat();assert stat.S_ISREG(st.st_mode) and st.st_size<=cap,str(p)
 b=p.read_bytes();assert len(b)==st.st_size
 custody[str(p)]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};return b
def doc(p,cap=2<<20):return json.loads(body(p,cap))
smanifest=doc(S/'MANIFEST.json');assert custody[str(S/'MANIFEST.json')]['sha256']=='c21baaee32695b92f765d62484daffad446738b83a308aab0312b00f61d69f26'
for name in ('controller.py','proof_binding.py','CRITICAL-SOURCE.json','V3-PROTOCOL.json'):
 b=body(S/name);assert custody[str(S/name)]==smanifest[name]
for name in ('controller.py','proof_binding.py'):
 tree=ast.parse(body(S/name)); allowed=(ast.Import,ast.ImportFrom,ast.Assign,ast.ClassDef,ast.FunctionDef)
 for node in tree.body:
  if isinstance(node,ast.Expr):assert isinstance(node.value,ast.Constant) and isinstance(node.value.value,str)
  elif isinstance(node,ast.If):assert name=='controller.py' and ast.unparse(node.test)=="__name__ == '__main__'"
  else:assert isinstance(node,allowed),(name,type(node).__name__)
 # Reviewed bodies contain ordinary stdlib imports/constants/definitions and controller main guard only.
raw=body(P/'READY.json');assert len(raw)==3921 and hashlib.sha256(raw).hexdigest()=='79a1722dcca5505c766d8d902ad46e4fd7f52785497f66cce1a61fbca8d6c440'
ready=json.loads(raw);approved=doc(S/'CRITICAL-SOURCE.json');assert ready['critical_source']==approved['files']
pm=doc(P/'MANIFEST.json')
for row in pm.values():assert custody.get(row['path'])=={k:row[k] for k in ('bytes','sha256')} or (body(row['path']) and custody[row['path']]=={k:row[k] for k in ('bytes','sha256')})
assessment=doc(P/'ASSESSMENT.json')
entry=doc(ready['observer_entry']['path']);assert custody[ready['observer_entry']['path']]=={k:ready['observer_entry'][k] for k in ('bytes','sha256')}
assert entry['inventory']==ready['readiness_proof']
allowedrefs={ready[k]['path']:ready[k] for k in ('signature_receipt','signature_stdout','observer_entry','readiness_proof')}
allowedrefs.update({entry[k]['path']:entry[k] for k in ('run','job','log','inventory')})
for path,ref in allowedrefs.items():
 p=pathlib.Path(path);assert p.is_absolute() and str(p).startswith('/private/tmp/') and p.suffix in ('.json','.log')
 b=body(p);assert type(ref['bytes']) is int and 0<ref['bytes']<=2<<20 and custody[path]=={k:ref[k] for k in ('bytes','sha256')}
cmanifest=doc(C/'MANIFEST.json');assert custody[str(C/'MANIFEST.json')]['sha256']=='57b8c4e43032d7b0be8d943eedf06b232ec36b60df958994ffcba11d17c132ef'
for row in cmanifest['files']:
 p=C/row['path'];body(p);assert custody[str(p)]=={k:row[k] for k in ('bytes','sha256')}
sig=doc(ready['signature_receipt']['path']);stdout=body(ready['signature_stdout']['path']);claims=json.loads(stdout)
assert sig['stdout']==ready['signature_stdout'] and sig['proof_count']==len(claims)==2
stderr=body(sig['stderr']['path']);assert custody[sig['stderr']['path']]=={k:sig['stderr'][k] for k in ('bytes','sha256')}
assert stat.S_IMODE(pathlib.Path(sig['empty_docker_config']).stat().st_mode)==0o700 and not list(pathlib.Path(sig['empty_docker_config']).iterdir())
assert stat.S_ISDIR(pathlib.Path(sig['fresh_private_tuf']).lstat().st_mode) and stat.S_IMODE(pathlib.Path(sig['fresh_private_tuf']).stat().st_mode)==0o700
assert sig['argv'][0]=='/private/tmp/bex7-native-acceptance-novb586u/cosign' and sig['actual_strict_crypto']=='PASS' and type(sig['exit']) is int and sig['exit']==0 and sig['stop'] is None
local_source=doc(pathlib.Path('/private/tmp/bex-w8-m83-a9-source-check-20261101-ym69itpe/SOURCE-REVIEW.json'))
assert custody['/private/tmp/bex-w8-m83-a9-source-check-20261101-ym69itpe/SOURCE-REVIEW.json']['sha256']=='424b9cdc19b227a4b93b7e54f91f20bddb19037dabc2937947c4b65578bd3c88'
assert local_source['source']==ready['source'] and local_source['required_ancestor']==ready['requiredAncestor'] and local_source['all_full_critical_bytes_modes_blobs_exact'] is True
for path,row in local_source['files'].items():
 assert ready['critical_source'][path]=={'bytes':row['bytes'],'sha256':row['sha256']} and row['git_mode']=='100644'
 body(row['retained_source']['path']);assert custody[row['retained_source']['path']]=={k:row['retained_source'][k] for k in ('bytes','sha256')}
sys.dont_write_bytecode=True;sys.path.insert(0,str(S))
spec=importlib.util.spec_from_file_location('_independent_m83_final_gate',S/'controller.py');gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
assert pathlib.Path(gate.proof_binding.__file__)==S/'proof_binding.py'
ancestry=[]
def ancestor(left,right):
 assert left==ready['requiredAncestor'] and right==ready['source']
 argv=['git','-C',str(REPO),'merge-base','--is-ancestor',left,right];at=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'))
 ancestry.append({'argv':argv,'at':at,'seconds':time.monotonic()-t,'exit_code':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'stdout_bytes':len(p.stdout),'stderr_bytes':len(p.stderr)})
 return type(p.returncode) is int and p.returncode==0
cache={path:pathlib.Path(path).read_bytes() for path in allowedrefs}
def reader(path):assert path in allowedrefs;return cache[path]
evaluated=datetime.datetime.now(datetime.timezone.utc);result=gate.gate_readiness(ready,evaluated,ancestor,reader)
assert result['state']=='PASS' and result==assessment['actual_gate'] and len(ancestry)==1 and ancestry[0]['exit_code']==0
(R/'GATE-RESULT.json').write_text(json.dumps({'evaluated_at':evaluated.isoformat(),'observation_age_seconds':(evaluated-gate.instant(ready['at'])).total_seconds(),'gate':result,'local_ancestry':ancestry,'source_import_safety':'Exact frozen modules reviewed: stdlib imports/constants/functions/classes plus controller main guard only; no auth/hosted/transport import, no top-level external action. Bytecode disabled.','execution_scope':'Existing pure readiness gate plus one bounded local read-only Git ancestry command; no signature rerun, network, auth, Free call or live resource action.'},indent=2)+'\n')
(R/'PROOF-CUSTODY.json').write_text(json.dumps(custody,indent=2)+'\n')
print(json.dumps({'gate':'PASS','evaluated_at':evaluated.isoformat(),'age_seconds':round((evaluated-gate.instant(ready['at'])).total_seconds(),3),'operator_replicas':ready['Operator']['replicas'],'API_replicas':ready['API']['replicas'],'same_actual_image':ready['Operator']['image']==ready['API']['image'],'signature_proofs':len(claims),'proof_paths_hashed':len(custody)}))
