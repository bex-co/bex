/*
Copyright 2026.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

// Package usage is the metering feature (w8/m1–m2, retention m4): an hourly
// pipeline that rolls Prometheus cAdvisor/Traefik data and build-Job durations
// into durable usage_hourly rows (internal/store), keyed per workspace. The
// Service exposes month-to-date aggregates as REST/GraphQL/MCP adapters (m2)
// and bounds usage_hourly's growth by compacting months older than the hot
// window into usage_monthly aggregates daily (m4, docs/ADR023-usage-metering.md).
// The loop needs BEX_CP_DB_URI (store); metering additionally needs
// BEX_PROM_URL (Prometheus). Without the store the loop never starts and the
// read verbs answer core.ErrUsageUnavailable (503).
package usage

import (
	"cmp"
	"context"
	"fmt"
	"log"
	"math"
	"net/http"
	"sort"
	"strings"
	"sync"
	"time"

	batchv1 "k8s.io/api/batch/v1"
	"k8s.io/apimachinery/pkg/api/meta"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"sigs.k8s.io/controller-runtime/pkg/client"

	"github.com/bex-co/bex/lego/backend/internal/billing"
	"github.com/bex-co/bex/lego/backend/internal/core"
	"github.com/bex-co/bex/lego/backend/internal/egressquery"
	"github.com/bex-co/bex/lego/backend/internal/pricing"
	"github.com/bex-co/bex/lego/backend/internal/store"
	appv1alpha1 "github.com/bex-co/bex/lego/types/v1alpha1"
)

// UsageStore is the slice of internal/store the usage feature needs: the
// write/read methods over the usage_hourly + usage_monthly tables, plus a
// read for the store's apps list (workspace attribution) and tenant lookup.
type UsageStore interface {
	ListApps(ctx context.Context) ([]store.App, error)
	// Deleted resources still owed their final hours (w4/m173).
	ListRetiredUsageResources(ctx context.Context, since time.Time) ([]store.RetiredUsageResource, error)
	PruneRetiredUsageResources(ctx context.Context, before time.Time) (int64, error)
	CloseUsageSourceStreams(ctx context.Context, ref store.UsageResourceRef, through time.Time) error
	UpsertUsageHourly(ctx context.Context, row store.HourlyRow) error
	RecordUsageSourceHealth(ctx context.Context, records []store.UsageSourceRecord) error
	ReconcileUsageSourceStreams(ctx context.Context, active []store.UsageResourceRef, through time.Time) error
	CurrentUsageCoverage(ctx context.Context, workspaceID string, now time.Time) (store.UsageCoverage, error)
	LatestUsageWindow(ctx context.Context, resourceKind, serviceID, kind string) (time.Time, error)
	// The provisioned-disk meter reads control-plane rows rather than the
	// cluster, so it needs its own window integration and its own cursor.
	DiskUsageForWindow(ctx context.Context, from, to time.Time) ([]store.DiskUsageRow, error)
	LatestUsageWindowForKind(ctx context.Context, kind string) (time.Time, bool, error)
	UsageMonthToDate(ctx context.Context, workspaceID string, now time.Time) ([]store.UsageSummaryRow, error)
	CompactUsage(ctx context.Context, before time.Time) (store.UsageCompaction, error)
	// The retained-name record (w2/m96): billing lines outlive their resources,
	// so names are read from here when the resource is gone and written back
	// here while it is still alive.
	ResourceDisplayNames(ctx context.Context, tenantID string, refs []store.ResourceDisplayName) (map[string]string, error)
	RecordResourceDisplayNames(ctx context.Context, tenantID string, records []store.ResourceDisplayName) error
	SandboxUsageMetadata(ctx context.Context, tenantID string, sandboxIDs []string) (map[string]store.SandboxUsageMetadata, error)
}

// Service is the usage feature. Base carries the Kubernetes client, namespace,
// and the authz gate every verb calls first. Store is the control-plane
// backing; nil means the store isn't wired and usage verbs report unavailable.
type Service struct {
	*core.Base
	Store    UsageStore
	PromBase string // BEX_PROM_URL, empty means no Prometheus
	// RetentionMonths is the hot window: how many calendar months (current
	// month included) stay at hourly granularity before compaction folds them
	// into usage_monthly (BEX_USAGE_RETENTION_MONTHS). Values < 1 mean
	// DefaultRetentionMonths.
	RetentionMonths int
	// FreeInstanceHours overrides the monthly Free instance-hours allowance the
	// summary reports; non-positive means DefaultFreeInstanceHours.
	FreeInstanceHours float64
	// Billing reads real Stripe cost/invoices to surface beside the advisory
	// estimate (m48, ADR040 Phase 2). nil ⇒ billing surface off: every summary is
	// estimate-only, byte-identical to ADR030. A read failure degrades to
	// estimate-only too (logged, never a 500).
	Billing BillingReader
	// billingCache memoizes the Stripe reads BillingFor makes, keyed by
	// (tenant, period), for a short TTL: /v1/usage is polled (dashboard every 60s)
	// across three surfaces, but the billing figure only moves ~hourly, so this
	// keeps that hot path off Stripe. Positive results only — errors are never
	// cached, preserving the poll-as-retry graceful-degradation contract.
	billingCache *core.TTLCache[*billing.Billing]
	promHTTP     *http.Client
	// BuildNamespace is BEX_BUILD_NAMESPACE — the namespace the operator runs
	// build Jobs in, which is where build_seconds must look for them. Empty
	// means the operator co-locates them with the App (app_controller.go's
	// buildNamespace()), so the meter falls back to the App's own namespace.
	BuildNamespace string
}

// BillingReader reads a workspace's real Stripe cost + finalized invoices
// for [periodStart, periodEnd). Returns (nil, nil) when there is nothing real
// to show (no contract / comped Mode A / excluded) so the caller falls back to
// estimate-only. Implemented by *billing.Client.
type BillingReader interface {
	BillingFor(ctx context.Context, customerID string, periodStart, periodEnd time.Time) (*billing.Billing, error)
}

// NewService constructs a Service, normalising PromBase (strips trailing slash
// so every Prometheus URL is canonical) and resolving a nil HTTP client to the
// bounded core.UpstreamClient (codex round-8 #10). Callers in tests may pass
// their own *http.Client to target an httptest.Server.
func NewService(base *core.Base, st UsageStore, promBase string, hc *http.Client) *Service {
	if hc == nil {
		hc = core.UpstreamClient
	}
	return &Service{
		Base:         base,
		Store:        st,
		PromBase:     strings.TrimRight(promBase, "/"),
		billingCache: core.NewTTLCache[*billing.Billing](),
		promHTTP:     hc,
	}
}

// --- Month-to-date verb (m2) ---

// Summary is the month-to-date usage for one workspace — the core result the
// three adapters present. Total values are in the natural unit of each kind
// (seconds/bytes/seconds/GB-seconds).
type Summary struct {
	WorkspaceID   string
	Period        string // "YYYY-MM" — the calendar month this summary covers
	Services      []ServiceUsage
	EstimatedCost pricing.EstimatedCost
	// Billing is the real Stripe-computed cost + finalized invoices (m48/m50).
	// nil ⇒ estimate-only: no contract, comped/excluded, billing off, or a
	// degraded Stripe read — clients show EstimatedCost alone.
	Billing  *billing.Billing
	Coverage Coverage
	// FreeInstanceHours is the workspace's Render-style "Monthly included
	// usage" for the period (w8/m139): hours its Free web services ran against
	// the monthly allowance.
	FreeInstanceHours FreeInstanceHours
}

// DefaultFreeInstanceHours is Render's monthly Free instance-hours allowance
// per workspace.
const DefaultFreeInstanceHours = 750

// FreeInstanceHours is Free instance hours used against the allowance.
type FreeInstanceHours struct {
	Used     float64
	Included float64
}

const (
	CoverageComplete = "complete"
	CoveragePartial  = "partial"
	CoverageUnknown  = "unknown"
)

// Coverage describes the evidence behind current-month totals. Through is the
// common end of every active source stream's contiguous hourly prefix. It is
// zero for unknown evidence and never inferred for historical periods.
type Coverage struct {
	State           string
	Through         time.Time
	DegradedSources []string
}

// ServiceUsage is one service's contribution to the workspace's month-to-date
// totals, broken out by kind (and tier for instance_seconds).
type ServiceUsage struct {
	ServiceID string
	// ServiceName is the user-facing display name. It is resolved from the live
	// resource when one exists, and otherwise from the retained-name record
	// (w2/m96) — so a charge keeps naming its resource after deletion. Empty
	// only when bex never recorded a name for the id at all, in which case
	// presenters fall back to ServiceID.
	ServiceName string
	// Deleted reports confirmed absence or a terminated sandbox meter state,
	// independently of name retention. Unknown inventory remains false.
	Deleted      bool
	ResourceKind string // store.ResourceKind* — "service", "postgres", "key_value", "sandbox"
	Rows         []store.UsageSummaryRow
}

// monthToDateAt is the implementation used by adapters. now controls both the
// calendar month (monthStart is derived from it) and the inclusive upper bound
// of the query. Adapters pass s.Now().UTC() for the live query or the start of
// the next month for a full historical-month query. ownerID names the
// workspace to query (Render's `ownerId`, w6/m18): empty means the caller's
// default workspace, honored via core.WithWorkspace/Base.Tenant the same way
// every other read-side verb resolves an explicit target — a workspace the
// caller is not a member of is core.ErrForbidden.
func (s *Service) monthToDateAt(ctx context.Context, ownerID string, now time.Time) (Summary, error) {
	ctx = core.WithWorkspace(ctx, ownerID)
	if err := s.Authorize(ctx, core.RelCanView); err != nil {
		return Summary{}, err
	}
	if s.Store == nil {
		return Summary{}, core.ErrUsageUnavailable
	}
	tenantID, ok := s.Base.Tenant(ctx)
	if !ok {
		// Store is off or caller has no tenant: return an empty summary rather
		// than an error — the same pattern as apps.List returning all apps in the
		// store-off mode.
		return Summary{}, nil
	}
	rows, err := s.Store.UsageMonthToDate(ctx, tenantID, now)
	if err != nil {
		return Summary{}, fmt.Errorf("usage: %w", err)
	}
	sum := summarise(tenantID, rows)
	s.resolveServiceNames(ctx, tenantID, sum.Services)
	sum.Period = now.Format(periodLayout)
	sum.FreeInstanceHours = s.freeInstanceHours(rows)
	sum.EstimatedCost = pricing.Default.Estimate(rows)
	nameResourceEstimates(&sum.EstimatedCost, sum.Services)
	// The Stripe projection (real cost, invoices, credit grants) is a billing
	// capability, not part of the general usage read: model.fga reserves
	// can_manage_billing for billing/admin, while can_view extends to viewers
	// and contributors. Attach it only for callers holding the billing relation;
	// everyone else still gets usage + the advisory estimate (round-13 #5).
	if s.mayManageBilling(ctx, tenantID) {
		sum.Billing = s.readBilling(ctx, tenantID, now)
	}
	sum.Coverage = Coverage{State: CoverageUnknown, DegradedSources: []string{}}
	current := s.Now().UTC()
	if now.Year() == current.Year() && now.Month() == current.Month() {
		evidence, err := s.Store.CurrentUsageCoverage(ctx, tenantID, current)
		if err != nil {
			return Summary{}, fmt.Errorf("usage coverage: %w", err)
		}
		if evidence.Known {
			sum.Coverage.State = CoveragePartial
			if evidence.Complete {
				sum.Coverage.State = CoverageComplete
			}
			sum.Coverage.Through = evidence.Through
			sum.Coverage.DegradedSources = append([]string(nil), evidence.DegradedSources...)
		}
	}
	return sum, nil
}

// mayManageBilling reports whether the caller holds the workspace's billing
// relation (billing or admin), with an authoritative (uncached) decision when
// the wired checker supports core.FreshChecker — this gates the reveal of real
// invoices and credit grants, so a just-revoked billing member must not ride a
// positive cached on another replica. It also composes the relation's mapped
// OAuth capability (Identity.RequireCapability): a third-party human token
// carrying only bex.read is treated as NOT privileged even when OpenFGA grants
// the delegated billing/admin relation. It deliberately uses the raw checker,
// not Authorize: the verb's gate stays can_view (audited there), and this is a
// field-level projection decision — a denial must not emit a denial audit row
// for every ordinary viewer usage read (the isWorkspaceAdmin precedent).
// No checker wired (authz off) keeps the prior billing-on behavior.
func (s *Service) mayManageBilling(ctx context.Context, tenantID string) bool {
	if s.Authz == nil {
		return true
	}
	id, ok := core.IdentityFrom(ctx)
	if !ok {
		return false
	}
	if err := id.RequireCapability(core.RelCanManageBilling); err != nil {
		return false
	}
	check := s.Authz.Check
	if fresh, ok := s.Authz.(core.FreshChecker); ok {
		check = fresh.CheckFresh
	}
	allowed, err := check(ctx, "user:"+id.Subject, core.RelCanManageBilling, core.WorkspaceObject(tenantID))
	return err == nil && allowed
}

// readBilling fetches the workspace's real Stripe cost for the month containing
// now. Any failure (Stripe off/unreachable, no subscription) yields
// nil — the summary stays estimate-only and never 500s (ADR040 graceful
// degradation). The estimate always remains for the in-flight window.
func (s *Service) readBilling(ctx context.Context, tenantID string, now time.Time) *billing.Billing {
	if s.Billing == nil {
		return nil
	}
	key := tenantID + "|" + now.Format(periodLayout)
	if s.billingCache != nil {
		if b, ok := s.billingCache.Get(key); ok {
			return b
		}
	}
	monthStart := time.Date(now.Year(), now.Month(), 1, 0, 0, 0, 0, time.UTC)
	b, err := s.Billing.BillingFor(ctx, tenantID, monthStart, now)
	if err != nil {
		log.Printf("usage: billing read for %s: %v (estimate-only)", tenantID, err)
		return nil // never cache an error — the next poll retries
	}
	if s.billingCache != nil {
		// Real wall-clock expiry (the cache's own clock), independent of s.Now().
		s.billingCache.Put(key, b, time.Now().Add(core.PositiveTTL))
	}
	return b
}

// resolveServiceNames keeps attribution separate from existence: retained names
// survive deletion, while only successful inventory reads establish absence.
// Read-time capture refreshes names; collectors retain datastore names before
// recording usage so deletion before the first billing read cannot lose them.
func (s *Service) resolveServiceNames(ctx context.Context, tenantID string, svcs []ServiceUsage) {
	if len(svcs) == 0 {
		return
	}
	wanted := map[string]bool{}
	for _, svc := range svcs {
		wanted[svc.ResourceKind] = true
	}
	names := map[string]string{}
	live := map[string]bool{}
	known := map[string]bool{}
	if wanted[store.ResourceKindService] {
		if apps, err := s.Store.ListApps(ctx); err != nil {
			log.Printf("usage: resolve names: list apps: %v", err)
		} else {
			known[store.ResourceKindService] = true
			for _, app := range apps {
				if app.TenantID == tenantID {
					key := store.ResourceDisplayNameKey(store.ResourceKindService, app.ID)
					live[key] = true
					// The displayed name, not the immutable creation name: a
					// renamed service bills under its current label, and
					// recapturing app.Name here would overwrite the name
					// SetAppDisplayName retained (w2/m96 t008 live finding).
					names[key] = app.Name
					if app.DisplayName != "" {
						names[key] = app.DisplayName
					}
				}
			}
		}
	}
	if s.Client != nil && (wanted[store.ResourceKindPostgres] || wanted[store.ResourceKindKeyValue]) {
		if datastores, err := s.listDatastores(ctx); err != nil {
			log.Printf("usage: resolve names: list datastores: %v", err)
		} else {
			known[store.ResourceKindPostgres], known[store.ResourceKindKeyValue] = true, true
			for _, ds := range datastores {
				if ds.TenantID == tenantID {
					key := store.ResourceDisplayNameKey(ds.Kind, ds.ID)
					live[key] = true
					names[key] = ds.Display
				}
			}
		}
	}
	refs := make([]store.ResourceDisplayName, 0, len(svcs))
	var sandboxIDs []string
	for _, svc := range svcs {
		refs = append(refs, store.ResourceDisplayName{Kind: svc.ResourceKind, ID: svc.ServiceID})
		if svc.ResourceKind == store.ResourceKindSandbox {
			sandboxIDs = append(sandboxIDs, svc.ServiceID)
		}
	}
	sandboxMetadata := map[string]store.SandboxUsageMetadata{}
	if len(sandboxIDs) > 0 {
		if metadata, err := s.Store.SandboxUsageMetadata(ctx, tenantID, sandboxIDs); err != nil {
			log.Printf("usage: resolve names: sandbox metadata: %v", err)
		} else {
			sandboxMetadata = metadata
			for id, m := range metadata {
				key := store.ResourceDisplayNameKey(store.ResourceKindSandbox, id)
				names[key] = m.Name
				live[key] = m.Phase != "" && m.Phase != "terminated"
			}
		}
	}
	retained, err := s.Store.ResourceDisplayNames(ctx, tenantID, refs)
	if err != nil {
		log.Printf("usage: resolve names: retained names: %v", err)
	}
	var capture []store.ResourceDisplayName
	for i := range svcs {
		svc := &svcs[i]
		key := store.ResourceDisplayNameKey(svc.ResourceKind, svc.ServiceID)
		svc.ServiceName = names[key]
		if svc.ServiceName == "" {
			svc.ServiceName = retained[key]
		} else if live[key] && retained[key] != svc.ServiceName {
			capture = append(capture, store.ResourceDisplayName{Kind: svc.ResourceKind, ID: svc.ServiceID, Name: svc.ServiceName})
		}
		svc.Deleted = known[svc.ResourceKind] && !live[key]
		if svc.ResourceKind == store.ResourceKindSandbox {
			svc.Deleted = sandboxMetadata[svc.ServiceID].Phase == "terminated"
			if svc.ServiceName == "" {
				tier := sandboxMetadata[svc.ServiceID].Tier
				if tier == "" {
					candidates := map[string]bool{}
					for _, row := range svc.Rows {
						if row.Tier != "" {
							candidates[row.Tier] = true
						}
					}
					if len(candidates) == 1 {
						for candidate := range candidates {
							tier = candidate
						}
					}
				}
				if tier != "" {
					svc.ServiceName = tier + " sandbox"
				}
			}
		}
	}
	if len(capture) > 0 {
		if err := s.Store.RecordResourceDisplayNames(ctx, tenantID, capture); err != nil {
			log.Printf("usage: retain names: %v", err)
		}
	}
}

// nameResourceEstimates copies the display names already resolved onto
// Services across to the per-resource estimates. The price sheet is a pure
// rate table with no way to look a name up, and the two views describe the
// same resources, so the join happens once here rather than in each of the
// three adapters (or each client).
func nameResourceEstimates(est *pricing.EstimatedCost, svcs []ServiceUsage) {
	if len(est.Resources) == 0 || len(svcs) == 0 {
		return
	}
	type resolved struct {
		name    string
		deleted bool
	}
	names := make(map[string]resolved, len(svcs))
	for _, svc := range svcs {
		names[store.ResourceDisplayNameKey(svc.ResourceKind, svc.ServiceID)] = resolved{svc.ServiceName, svc.Deleted}
	}
	for i := range est.Resources {
		r := &est.Resources[i]
		got := names[store.ResourceDisplayNameKey(r.ResourceKind, r.ServiceID)]
		r.ServiceName = got.name
		r.Deleted = got.deleted
	}
}

// MonthToDate returns ownerID's month-to-date usage summary for the current
// calendar month ("" => the caller's default workspace).
func (s *Service) MonthToDate(ctx context.Context, ownerID string) (Summary, error) {
	return s.monthToDateAt(ctx, ownerID, s.Now().UTC())
}

// summarise groups flat summary rows by resource identity. ResourceKind is
// required because different Kubernetes kinds may legally share a service_id.
func summarise(workspaceID string, rows []store.UsageSummaryRow) Summary {
	rows = append([]store.UsageSummaryRow(nil), rows...)
	for i := range rows {
		rows[i].ResourceKind = store.NormalizeResourceKind(rows[i].ResourceKind)
	}
	sort.Slice(rows, func(i, j int) bool {
		a, b := rows[i], rows[j]
		if a.ServiceID != b.ServiceID {
			return a.ServiceID < b.ServiceID
		}
		if a.ResourceKind != b.ResourceKind {
			return a.ResourceKind < b.ResourceKind
		}
		if a.Kind != b.Kind {
			return a.Kind < b.Kind
		}
		return a.Tier < b.Tier
	})
	type resourceKey struct {
		serviceID, resourceKind string
	}
	var order []resourceKey
	byResource := map[resourceKey][]store.UsageSummaryRow{}
	for _, r := range rows {
		key := resourceKey{r.ServiceID, r.ResourceKind}
		if _, seen := byResource[key]; !seen {
			order = append(order, key)
		}
		byResource[key] = append(byResource[key], r)
	}
	svcs := make([]ServiceUsage, 0, len(order))
	for _, key := range order {
		svcs = append(svcs, ServiceUsage{
			ServiceID:    key.serviceID,
			ResourceKind: key.resourceKind,
			Rows:         byResource[key],
		})
	}
	return Summary{WorkspaceID: workspaceID, Services: svcs}
}

// --- Metering + retention loop ---

// Interval is the default rollup cadence.
const Interval = time.Hour

// CompactInterval is the default retention-compaction cadence (w8/m4). Daily
// is plenty: eligibility only changes at month boundaries.
const CompactInterval = 24 * time.Hour

// DefaultRetentionMonths is the default hot window (t001): the current month
// plus the prior two stay hourly — the common historical-comparison range.
const DefaultRetentionMonths = 3

// catchupLimit caps how far back a restart can catch up (48 h covers
// Prometheus's typical retention + a weekend outage).
const catchupLimit = 48 * time.Hour

// CatchupWindow exports catchupLimit so the billing seal horizon can be clamped
// to never fall inside the rollup's rewrite window (w7/m57): a usage_hourly row
// is rewritable for up to CatchupWindow, so the Stripe seal horizon must be at
// least this long, else an already-exported row could be silently rewritten and
// never re-emitted (under/over-billing). The two constants lived in separate
// packages coupled only by the coincidence 48h == 48h; this makes the coupling
// explicit (billing.ClampSealHours reads it, main.go enforces it).
const CatchupWindow = catchupLimit

// Run is the metering + retention loop: catches up missed windows on startup,
// rolls up every Interval, and compacts spent months every CompactInterval,
// until ctx is cancelled. Only call when Store is set; with PromBase empty the
// metering side is skipped and only compaction runs.
func (s *Service) Run(ctx context.Context) {
	s.RunWithIntervals(ctx, Interval, CompactInterval)
}

// RunWithIntervals is like Run but with explicit cadences — for tests.
func (s *Service) RunWithIntervals(ctx context.Context, rollup, compact time.Duration) {
	// The rollup tick runs whenever anything is meterable. Prometheus-backed
	// meters (instance, egress, build, datastore storage) stay structurally off
	// without a Prometheus base — catchUp and rollup skip them — but the
	// provisioned-disk meter is derived from control-plane rows alone, so it
	// has to keep billing while the cluster or Prometheus is unreachable
	// (docs/ADR082-persistent-disks.md D9). Gating the whole loop on
	// Prometheus would silently stop charging for volumes that still exist.
	rollupTicker := time.NewTicker(rollup)
	defer rollupTicker.Stop()
	rollupC := rollupTicker.C
	s.catchUp(ctx)
	compactTicker := time.NewTicker(compact)
	defer compactTicker.Stop()
	s.compact(ctx) // once at startup so restarts don't defer compaction a day
	for {
		select {
		case <-ctx.Done():
			return
		case t := <-rollupC:
			s.rollup(ctx, t)
		case <-compactTicker.C:
			s.compact(ctx)
		}
	}
}

// compact folds hourly rows older than the hot window into usage_monthly and
// purges them (w8/m4). The boundary is the start of the oldest hot month,
// clamped to catchupLimit ago: the rollup's restart catch-up can rewrite any
// window inside that limit, and re-metering an already-compacted window would
// double-count against the additive monthly upsert. Rows the clamp defers are
// compacted by a later pass once they age out of the catch-up range.
func (s *Service) compact(ctx context.Context) {
	months := s.RetentionMonths
	if months < 1 {
		months = DefaultRetentionMonths
	}
	now := s.Now().UTC()
	before := time.Date(now.Year(), now.Month(), 1, 0, 0, 0, 0, time.UTC).AddDate(0, 1-months, 0)
	if clamp := now.Add(-catchupLimit); before.After(clamp) {
		before = clamp
	}
	// A deleted resource retired before the catch-up window can no longer be
	// metered (w4/m173). Pruned here because compaction runs with or without
	// Prometheus, while the App delete trigger always records.
	if _, err := s.Store.PruneRetiredUsageResources(ctx, now.Add(-catchupLimit)); err != nil {
		log.Printf("usage: prune retired resources: %v", err)
	}
	res, err := s.Store.CompactUsage(ctx, before)
	if err != nil {
		log.Printf("usage: compact before %s: %v", before.Format(time.RFC3339), err)
		return
	}
	if res.HourlyRows > 0 {
		log.Printf("usage: compacted %d months (%d hourly rows) into usage_monthly (boundary %s)",
			res.Months, res.HourlyRows, before.Format(time.RFC3339))
	}
}

// datastoreEntry holds the metering attributes for one Database or KeyValue CR.
type datastoreEntry struct {
	ID        string // immutable CR name (== service_id in usage rows)
	Name      string // immutable data-plane name used in Prometheus selectors
	Namespace string // the CR's OWN namespace (ADR043 D8) — Prometheus series are namespace-labeled
	Display   string // required mutable user-facing spec.name
	TenantID  string // from core.LabelTenant
	Plan      string // Spec.Plan (== tier in usage rows)
	Kind      string // store.ResourceKindPostgres or store.ResourceKindKeyValue
	Public    bool   // whether the public proxy source applies
	CreatedAt time.Time
	// Through, when set, is a deleted datastore's last owed hour (w4/m173).
	Through time.Time
}

// listDatastores returns all tenant-owned Database and KeyValue CRs via the k8s
// client. Skips unlabeled CRs (not tenant-owned). Returns nil when the k8s
// client is not wired.
//
// The lists are CLUSTER-WIDE: metering runs fleet-wide with no caller identity,
// and under ADR043 D8 each workspace's datastores sit in its own namespace, so
// a namespace-scoped list would meter only the un-migrated ones — under-billing
// silently, which is the worst failure mode this loop has.
func (s *Service) listDatastores(ctx context.Context) ([]datastoreEntry, error) {
	if s.Client == nil {
		return nil, nil
	}
	var out []datastoreEntry
	var dbs appv1alpha1.DatabaseList
	if err := s.Client.List(ctx, &dbs); err != nil {
		return nil, fmt.Errorf("list databases: %w", err)
	}
	for _, d := range dbs.Items {
		tenantID := d.Labels[core.LabelTenant]
		if tenantID == "" {
			continue
		}
		out = append(out, datastoreEntry{
			ID:        d.Name,
			Name:      d.Name,
			Namespace: d.Namespace,
			Display:   d.Spec.Name,
			TenantID:  tenantID,
			Plan:      d.Spec.Plan,
			Kind:      store.ResourceKindPostgres,
			Public:    d.Spec.Public,
			CreatedAt: d.CreationTimestamp.Time,
		})
	}
	var kvs appv1alpha1.KeyValueList
	if err := s.Client.List(ctx, &kvs); err != nil {
		return nil, fmt.Errorf("list keyvalues: %w", err)
	}
	for _, kv := range kvs.Items {
		tenantID := kv.Labels[core.LabelTenant]
		if tenantID == "" {
			continue
		}
		out = append(out, datastoreEntry{
			ID:        kv.Name,
			Name:      kv.Name,
			Namespace: kv.Namespace,
			Display:   kv.Spec.Name,
			TenantID:  tenantID,
			Plan:      kv.Spec.Plan,
			Kind:      store.ResourceKindKeyValue,
			Public:    kv.Spec.Public,
			CreatedAt: kv.CreationTimestamp.Time,
		})
	}
	return out, nil
}

var datastoreMeterKinds = [...]string{
	store.UsageKindInstanceSeconds,
	store.UsageKindStorageGBSeconds,
	store.UsageKindEgressBytes,
}

// processDatastoreWindow measures every applicable meter for one datastore.
// The live loop gives each meter an independent cursor; this seam runs them
// together for tests and explicit one-window processing.
func (s *Service) processDatastoreWindow(ctx context.Context, ds datastoreEntry, window time.Time) bool {
	var wg sync.WaitGroup
	results := make(chan bool, len(datastoreMeterKinds))
	for _, kind := range datastoreMeterKinds {
		wg.Add(1)
		go func() {
			defer wg.Done()
			results <- s.processDatastoreMeterWindow(ctx, ds, kind, window)
		}()
	}
	wg.Wait()
	close(results)
	ok := true
	for result := range results {
		ok = ok && result
	}
	return ok
}

func (s *Service) processDatastoreMeterWindow(ctx context.Context, ds datastoreEntry, kind string, window time.Time) bool {
	end := window.Add(time.Hour)
	var quantity int64
	var ok bool
	var health []store.UsageSourceObservation
	expectedFrom := usageExpectedFrom(ds.CreatedAt)
	switch kind {
	case store.UsageKindInstanceSeconds:
		quantity, ok = s.queryInstanceSecondsStateful(ctx, ds.Name, ds.Namespace, window, end)
		health = oneSourceHealth(store.UsageSourceInstance, ok, expectedFrom)
	case store.UsageKindStorageGBSeconds:
		quantity, ok = s.queryStorageGBSeconds(ctx, ds, window, end)
		health = oneSourceHealth(store.UsageSourceStorage, ok, expectedFrom)
	case store.UsageKindEgressBytes:
		quantity, health, ok = s.queryDatastoreEgressBytesEvidence(ctx, ds, window, end)
		for i := range health {
			health[i].ExpectedFrom = expectedFrom
		}
	default:
		return false
	}
	if !ok {
		s.recordSourceHealth(ctx, ds.TenantID, ds.Kind, ds.ID, kind, window, health)
		return false
	}
	// Storage rows carry the plan too, so pricing and Stripe can exempt a
	// Free datastore's included storage (w4/427). Each meter has its own
	// forward cursor, so no window already written is re-keyed.
	tier := ""
	if kind == store.UsageKindInstanceSeconds || kind == store.UsageKindStorageGBSeconds {
		tier = ds.Plan
	}
	if err := s.Store.UpsertUsageHourly(ctx, store.HourlyRow{
		WorkspaceID: ds.TenantID, ServiceID: ds.ID, ResourceKind: ds.Kind,
		Kind: kind, Tier: tier, WindowStart: window, Quantity: quantity,
		SourceHealth: health,
	}); err != nil {
		log.Printf("usage: upsert %s datastore %s: %v", kind, ds.ID, err)
		return false
	}
	return true
}

// catchUpDatastoreThrough advances every datastore meter independently. A
// proxy outage can hold egress back without blocking compute or storage, and
// each meter retries its oldest gap before writing a newer window.
func (s *Service) catchUpDatastoreThrough(ctx context.Context, ds datastoreEntry, last time.Time) {
	var wg sync.WaitGroup
	for _, kind := range datastoreMeterKinds {
		wg.Add(1)
		go func() {
			defer wg.Done()
			s.catchUpDatastoreMeterThrough(ctx, ds, kind, last)
		}()
	}
	wg.Wait()
}

func (s *Service) catchUpDatastoreMeterThrough(ctx context.Context, ds datastoreEntry, kind string, last time.Time) {
	latest, err := s.Store.LatestUsageWindow(ctx, ds.Kind, ds.ID, kind)
	if err != nil {
		log.Printf("usage: catch-up: latest %s window for datastore %s: %v", kind, ds.ID, err)
		return
	}
	floor := last.Add(time.Hour - catchupLimit)
	if created := ds.CreatedAt.UTC().Truncate(time.Hour); !created.IsZero() && created.After(floor) {
		floor = created
	}
	start := latest.UTC().Truncate(time.Hour)
	if start.IsZero() || start.Before(floor) {
		start = floor
	} else {
		start = start.Add(time.Hour)
	}
	for w := start; !w.After(ds.meterThrough(last)); w = w.Add(time.Hour) {
		if !s.processDatastoreMeterWindow(ctx, ds, kind, w) {
			return
		}
	}
}

// meterThrough is the last hour to meter ds in a pass through last: a deleted
// datastore owes nothing after its deletion hour.
func (ds datastoreEntry) meterThrough(last time.Time) time.Time {
	if !ds.Through.IsZero() && ds.Through.Before(last) {
		return ds.Through
	}
	return last
}

// catchUp finds the latest recorded window per service and fills any gap since
// then (bounded to catchupLimit so a long-dead service doesn't sweep months).
func (s *Service) catchUp(ctx context.Context) {
	now := time.Now().UTC()
	last := now.Truncate(time.Hour).Add(-time.Hour)
	s.catchUpDisksThrough(ctx, last)
	if s.PromBase == "" {
		return
	}
	apps, err := s.Store.ListApps(ctx)
	if err != nil {
		log.Printf("usage: catch-up: list apps: %v", err)
		return
	}
	for _, app := range apps {
		s.catchUpAppThrough(ctx, app, last)
	}
	datastores, err := s.listDatastores(ctx)
	if err != nil {
		log.Printf("usage: catch-up: list datastores: %v", err)
		return
	}
	s.meterDatastoresThrough(ctx, datastores, last)
	s.meterRetiredThrough(ctx, apps, last)
	s.reconcileSourceInventory(ctx, apps, datastores, last.Add(time.Hour))
}

// rollup processes the window that just closed (the hour ending at t).
func (s *Service) rollup(ctx context.Context, t time.Time) {
	window := t.UTC().Truncate(time.Hour).Add(-time.Hour)
	s.catchUpDisksThrough(ctx, window)
	if s.PromBase == "" {
		return
	}
	apps, err := s.Store.ListApps(ctx)
	if err != nil {
		log.Printf("usage: rollup: list apps: %v", err)
		return
	}
	for _, app := range apps {
		s.catchUpAppThrough(ctx, app, window)
	}
	datastores, err := s.listDatastores(ctx)
	if err != nil {
		log.Printf("usage: rollup: list datastores: %v", err)
		return
	}
	s.meterDatastoresThrough(ctx, datastores, window)
	s.meterRetiredThrough(ctx, apps, window)
	s.reconcileSourceInventory(ctx, apps, datastores, window.Add(time.Hour))
	log.Printf("usage: rolled up window %s for %d services + %d datastores",
		window.Format(time.RFC3339), len(apps), len(datastores))
}

// meterDatastoresThrough retains attribution before writing usage. A failed
// workspace is left retryable without stopping other workspaces' meters.
func (s *Service) meterDatastoresThrough(ctx context.Context, datastores []datastoreEntry, last time.Time) {
	byTenant := map[string][]datastoreEntry{}
	for _, ds := range datastores {
		byTenant[ds.TenantID] = append(byTenant[ds.TenantID], ds)
	}
	for tenant, entries := range byTenant {
		var captureErr error
		records := make([]store.ResourceDisplayName, 0, len(entries))
		for _, ds := range entries {
			if ds.Display == "" {
				captureErr = fmt.Errorf("datastore %s/%s has no display name", ds.Kind, ds.ID)
				break
			}
			records = append(records, store.ResourceDisplayName{Kind: ds.Kind, ID: ds.ID, Name: ds.Display})
		}
		if captureErr == nil {
			captureErr = s.Store.RecordResourceDisplayNames(ctx, tenant, records)
		}
		if captureErr != nil {
			log.Printf("usage: retain datastore names for workspace %s before metering: %v", tenant, captureErr)
		}
		var health []store.UsageSourceRecord
		for _, ds := range entries {
			if captureErr == nil {
				s.catchUpDatastoreThrough(ctx, ds, last)
				continue
			}
			egressSource := store.UsageSourcePostgres
			if ds.Kind == store.ResourceKindKeyValue {
				egressSource = store.UsageSourceKeyValue
			}
			for kind, source := range map[string]string{store.UsageKindInstanceSeconds: store.UsageSourceInstance, store.UsageKindStorageGBSeconds: store.UsageSourceStorage, store.UsageKindEgressBytes: egressSource} {
				health = append(health, store.UsageSourceRecord{WorkspaceID: tenant, ResourceKind: ds.Kind, ServiceID: ds.ID, Kind: kind, WindowStart: ds.meterThrough(last), UsageSourceObservation: store.UsageSourceObservation{Source: source, State: store.UsageSourceUnavailable, ExpectedFrom: usageExpectedFrom(ds.CreatedAt)}})
			}
		}
		if len(health) > 0 {
			if err := s.Store.RecordUsageSourceHealth(ctx, health); err != nil {
				log.Printf("usage: record unavailable datastore health for workspace %s: %v", tenant, err)
			}
		}
	}
}

// retiredAppMeterKinds are the App meters a deleted App can still be measured
// by: pods and build Jobs are named from the derived CR identity, but egress
// is keyed by router names only the live CR can supply, so a deleted App's
// final-hour egress stays unmetered.
var retiredAppMeterKinds = [...]string{
	store.UsageKindInstanceSeconds,
	store.UsageKindBuildSeconds,
}

// meterRetiredThrough meters each resource deleted within the catch-up window
// through the hour it was deleted in (w4/m173): the live passes list only what
// still exists. Each meter's cursor makes a repeat pass a no-op, and each
// resource's coverage streams end at its deletion hour.
func (s *Service) meterRetiredThrough(ctx context.Context, live []store.App, last time.Time) {
	floor := last.Add(time.Hour - catchupLimit)
	retired, err := s.Store.ListRetiredUsageResources(ctx, floor)
	if err != nil {
		log.Printf("usage: list retired resources: %v", err)
		return
	}
	var datastores []datastoreEntry
	closeAt := make(map[store.UsageResourceRef]time.Time, len(retired))
	for _, r := range retired {
		through := r.RetiredAt.UTC().Truncate(time.Hour)
		if through.After(last) {
			through = last
		}
		if r.ResourceKind != store.ResourceKindService {
			datastores = append(datastores, datastoreEntry{
				ID: r.ResourceID, Name: r.Name, Namespace: r.Namespace, Display: r.Display, Public: r.Public,
				TenantID: r.WorkspaceID, Plan: r.Tier, Kind: r.ResourceKind, CreatedAt: r.CreatedAt, Through: through,
			})
		} else if !podIdentityReused(r, through, live, retired) {
			app := store.App{ID: r.ResourceID, TenantID: r.WorkspaceID, Name: r.Name, Tier: r.Tier, CreatedAt: r.CreatedAt}
			for _, kind := range retiredAppMeterKinds {
				s.catchUpAppMeter(ctx, app, kind, floor, through)
			}
		}
		closeAt[store.UsageResourceRef{ResourceKind: r.ResourceKind, ServiceID: r.ResourceID}] = through.Add(time.Hour)
	}
	s.meterDatastoresThrough(ctx, datastores, last)
	for ref, through := range closeAt {
		if err := s.Store.CloseUsageSourceStreams(ctx, ref, through); err != nil {
			log.Printf("usage: close %s %s coverage at its deletion: %v", ref.ResourceKind, ref.ServiceID, err)
		}
	}
}

// podIdentityReused reports whether another App — live, or deleted later —
// with r's workspace and name existed by r's last owed hour. App pods and
// build Jobs are named from that pair, so such an App's meters already count
// everything r's would in that hour, under its own ID; metering r too would
// bill those pods twice.
func podIdentityReused(r store.RetiredUsageResource, through time.Time, live []store.App, retired []store.RetiredUsageResource) bool {
	overlaps := func(tenant, name string, created time.Time) bool {
		return tenant == r.WorkspaceID && name == r.Name && !created.UTC().Truncate(time.Hour).After(through)
	}
	for _, app := range live {
		if overlaps(app.TenantID, app.Name, app.CreatedAt) {
			return true
		}
	}
	for _, other := range retired {
		if other.ResourceKind == store.ResourceKindService && other.ResourceID != r.ResourceID &&
			other.RetiredAt.After(r.RetiredAt) && overlaps(other.WorkspaceID, other.Name, other.CreatedAt) {
			return true
		}
	}
	return false
}

func (s *Service) reconcileSourceInventory(ctx context.Context, apps []store.App, datastores []datastoreEntry, through time.Time) {
	active := make([]store.UsageResourceRef, 0, len(apps)+len(datastores))
	for _, app := range apps {
		active = append(active, store.UsageResourceRef{ResourceKind: store.ResourceKindService, ServiceID: app.ID})
	}
	for _, ds := range datastores {
		active = append(active, store.UsageResourceRef{ResourceKind: ds.Kind, ServiceID: ds.ID})
	}
	if err := s.Store.ReconcileUsageSourceStreams(ctx, active, through); err != nil {
		log.Printf("usage: reconcile source inventory through %s: %v", through.Format(time.RFC3339), err)
	}
}

var appMeterKinds = [...]string{
	store.UsageKindInstanceSeconds,
	store.UsageKindEgressBytes,
	store.UsageKindBuildSeconds,
}

// processWindow measures one (app, window) triplet and upserts all three kinds.
// It is kept as the direct one-window seam used by acceptance tests. The live
// loop calls catchUpAppThrough so each meter owns an independent contiguous
// cursor. A failure in one source never holds the other two meters back.
func (s *Service) processWindow(ctx context.Context, app store.App, window time.Time) {
	var wg sync.WaitGroup
	for _, kind := range appMeterKinds {
		wg.Add(1)
		go func() {
			defer wg.Done()
			s.processAppMeterWindow(ctx, app, kind, window)
		}()
	}
	wg.Wait()
}

// catchUpAppThrough advances each App meter independently through last. Each
// meter processes oldest-first and stops at its first unavailable source or
// failed store write, preserving a contiguous cursor without blocking healthy
// meters. The next hourly pass retries the failed window (restart not needed).
func (s *Service) catchUpAppThrough(ctx context.Context, app store.App, last time.Time) {
	var wg sync.WaitGroup
	for _, kind := range appMeterKinds {
		wg.Add(1)
		go func() {
			defer wg.Done()
			s.catchUpAppMeterThrough(ctx, app, kind, last)
		}()
	}
	wg.Wait()
}

func (s *Service) catchUpAppMeterThrough(ctx context.Context, app store.App, kind string, last time.Time) {
	s.catchUpAppMeter(ctx, app, kind, last.Add(time.Hour-catchupLimit), last)
}

// catchUpAppMeter meters app's kind from its cursor (no earlier than floor or
// the App's creation hour) through last.
func (s *Service) catchUpAppMeter(ctx context.Context, app store.App, kind string, floor, last time.Time) {
	latest, err := s.Store.LatestUsageWindow(ctx, store.ResourceKindService, app.ID, kind)
	if err != nil {
		log.Printf("usage: catch-up: latest %s window for %s: %v", kind, app.ID, err)
		return
	}
	if created := app.CreatedAt.UTC().Truncate(time.Hour); !created.IsZero() && created.After(floor) {
		floor = created
	}
	start := latest.UTC().Truncate(time.Hour)
	initializing := start.IsZero() || start.Before(floor)
	if initializing {
		start = floor
	} else {
		start = start.Add(time.Hour)
	}
	for window := start; !window.After(last); window = window.Add(time.Hour) {
		result := s.processAppMeterWindowResult(ctx, app, kind, window)
		if result == appMeterWindowSuccess {
			initializing = false
			continue
		}
		// A newly introduced egress composition has no meaningful cursor before
		// all of its sources exist. Probe forward through source-unavailable
		// history until the first measurable hour establishes the evidence
		// origin. Once any row exists, every later failure still stops the cursor
		// and is retried before a newer window. Store failures are never skipped.
		if kind == store.UsageKindEgressBytes && initializing && result == appMeterWindowSourceUnavailable {
			continue
		}
		return
	}
}

type appMeterWindowResult uint8

const (
	appMeterWindowSuccess appMeterWindowResult = iota
	appMeterWindowSourceUnavailable
	appMeterWindowStoreFailure
)

// processAppMeterWindow persists a successful measurement even when it is
// zero. Zero is real coverage evidence; source unavailability is represented
// by no row so the per-meter cursor retries the window later.
func (s *Service) processAppMeterWindow(ctx context.Context, app store.App, kind string, window time.Time) bool {
	return s.processAppMeterWindowResult(ctx, app, kind, window) == appMeterWindowSuccess
}

func (s *Service) processAppMeterWindowResult(ctx context.Context, app store.App, kind string, window time.Time) appMeterWindowResult {
	end := window.Add(time.Hour)
	var quantity int64
	var ok bool
	var health []store.UsageSourceObservation
	expectedFrom := usageExpectedFrom(app.CreatedAt)
	switch kind {
	case store.UsageKindInstanceSeconds:
		// The pods are named after the App's Kubernetes object, NOT after
		// store.App.Name (the workspace-scoped public service name) — w6/m110
		// Defect A: passing the store name built a matcher that hit zero pods for
		// every App at every name length, so App compute was metered as a healthy
		// zero for the meter's whole life while Postgres/Key Value (which pass a
		// real CR name) billed correctly. Resolving the CR also supplies the
		// per-tenant namespace its pods actually live in under ADR043; the shared
		// namespace holds none of them after the migration.
		cr, resolved := s.resolveAppCR(ctx, app, store.UsageKindInstanceSeconds)
		if crName, namespace, identified := s.appPodIdentity(app, cr); identified {
			quantity, ok = s.queryInstanceSeconds(ctx, crName, namespace, window, end)
		}
		health = oneSourceHealth(store.UsageSourceInstance, ok, expectedFrom)
		// A zero from an App that is supposed to be running is not coverage
		// evidence, it is a selector that found nothing — the exact signal that
		// stayed silent for the life of this meter. Keep the row so the cursor
		// still advances (a genuinely-down App must not stall the meter forever),
		// but stop the health record from asserting the zero is sound.
		if ok && quantity == 0 && resolved && expectsRunningPods(cr, window) {
			health = degradeSourceHealth(health)
		}
	case store.UsageKindEgressBytes:
		quantity, health, ok = s.queryEgressBytesEvidence(ctx, app, window, end)
		for i := range health {
			health[i].ExpectedFrom = expectedFrom
		}
	case store.UsageKindBuildSeconds:
		// Same identity defect as instance_seconds above: the operator stamps
		// app.bex.co/build with the App CR's name (operator/internal/build/build.go),
		// and the Job lives in BEX_BUILD_NAMESPACE — never the store name in the
		// shared namespace.
		cr, _ := s.resolveAppCR(ctx, app, store.UsageKindBuildSeconds)
		if crName, namespace, identified := s.appPodIdentity(app, cr); identified {
			var exempt map[string]bool
			if exempt, ok = s.platformRebuildRevisions(ctx, app.ID); ok {
				quantity, ok = s.queryBuildSeconds(ctx, crName, cmp.Or(s.BuildNamespace, namespace), window, end, exempt)
			}
		}
		health = oneSourceHealth(store.UsageSourceBuild, ok, expectedFrom)
	default:
		log.Printf("usage: unknown App meter %q for %s", kind, app.ID)
		return appMeterWindowSourceUnavailable
	}
	if !ok {
		s.recordSourceHealth(ctx, app.TenantID, store.ResourceKindService, app.ID, kind, window, health)
		return appMeterWindowSourceUnavailable
	}
	tier := ""
	if kind == store.UsageKindInstanceSeconds {
		tier = app.Tier
	}
	if err := s.Store.UpsertUsageHourly(ctx, store.HourlyRow{
		WorkspaceID:  app.TenantID,
		ServiceID:    app.ID,
		ResourceKind: store.ResourceKindService,
		Kind:         kind,
		Tier:         tier,
		WindowStart:  window,
		Quantity:     quantity,
		SourceHealth: health,
	}); err != nil {
		log.Printf("usage: upsert %s %s: %v", kind, app.ID, err)
		return appMeterWindowStoreFailure
	}
	return appMeterWindowSuccess
}

func usageExpectedFrom(created time.Time) time.Time {
	if created.IsZero() {
		return time.Unix(0, 0).UTC()
	}
	return created.UTC().Truncate(time.Hour)
}

func oneSourceHealth(source string, healthy bool, expectedFrom time.Time) []store.UsageSourceObservation {
	state := store.UsageSourceHealthy
	if !healthy {
		state = store.UsageSourceUnavailable
	}
	return []store.UsageSourceObservation{{Source: source, State: state, ExpectedFrom: expectedFrom}}
}

func (s *Service) recordSourceHealth(ctx context.Context, workspaceID, resourceKind, serviceID, kind string, window time.Time, observations []store.UsageSourceObservation) {
	records := make([]store.UsageSourceRecord, 0, len(observations))
	for _, observation := range observations {
		records = append(records, store.UsageSourceRecord{
			WorkspaceID: workspaceID, ResourceKind: resourceKind, ServiceID: serviceID,
			Kind: kind, WindowStart: window, UsageSourceObservation: observation,
		})
	}
	if err := s.Store.RecordUsageSourceHealth(ctx, records); err != nil {
		log.Printf("usage: record %s source health for %s: %v", kind, serviceID, err)
	}
}

// --- t002: Prometheus rollup queries ---

// queryInstanceSeconds returns the app's pods' running seconds in [start, end),
// summed per pod (instanceSecondsQuery), using cAdvisor's
// container_memory_working_set_bytes as a presence signal (the same matcher as
// the metrics feature's instance-count query — egressquery.PodNameMatcher is
// shared with metrics/source.go precisely so a service can never be charged for
// pods its Metrics page does not chart, or the reverse).
//
// crName is the App's Kubernetes object name (core.CRName(tenant, name)), which
// is what its ReplicaSet pods are named after — not the workspace-scoped
// store.App.Name.
func (s *Service) queryInstanceSeconds(ctx context.Context, crName, namespace string, start, end time.Time) (int64, bool) {
	return s.queryInstanceSecondsByMatcher(
		ctx, egressquery.PodNameMatcher(namespace, crName), start, end, crName)
}

// queryInstanceSecondsStateful returns instance-seconds for a StatefulSet-style
// workload (CNPG Cluster pods <dbName>-1, <dbName>-2 or Valkey StatefulSet pods
// <kvName>-0). The pod pattern is <name>-[0-9]+ (ordinal suffix), distinct from
// App ReplicaSet pods which use two random-char segments.
//
// Every instance pod counts, so a high-availability Postgres (primary +
// standby, <name>-1 and <name>-2) meters two instances — Render bills the
// standby like the primary ("billed accordingly", w2/m171).
func (s *Service) queryInstanceSecondsStateful(ctx context.Context, name, namespace string, start, end time.Time) (int64, bool) {
	return s.queryInstanceSecondsByMatcher(ctx, statefulInstanceMatchers(namespace, name), start, end, name)
}

func statefulInstanceMatchers(namespace, name string) string {
	return fmt.Sprintf(
		`namespace=%q,pod=~"%s-[0-9]+",container!=""`,
		namespace, egressquery.RegexEscape(name))
}

const bytesPerDecimalGB = 1_000_000_000

// queryStorageGBSeconds returns average used PVC bytes over [start,end),
// converted to decimal GB and multiplied by window seconds. kubelet volume
// stats are already scraped cluster-wide for datastore metrics. CNPG PVCs are
// named <name>-<ordinal>; Valkey's volumeClaimTemplate produces
// data-<name>-<ordinal>. The sum includes every CNPG instance/replica PVC.
//
// The bool distinguishes a successful zero (persist it) from an unavailable
// Prometheus query (leave the row absent so catch-up can retry).
func (s *Service) queryStorageGBSeconds(ctx context.Context, ds datastoreEntry, start, end time.Time) (int64, bool) {
	if s.PromBase == "" {
		return 0, false
	}
	pattern := fmt.Sprintf(`^%s-[0-9]+$`, egressquery.RegexEscape(ds.Name))
	if ds.Kind == store.ResourceKindKeyValue {
		pattern = fmt.Sprintf(`^data-%s-[0-9]+$`, egressquery.RegexEscape(ds.Name))
	}
	windowSecs := int64(end.Sub(start) / time.Second)
	q := fmt.Sprintf(
		`sum(avg_over_time(kubelet_volume_stats_used_bytes{namespace=%q,persistentvolumeclaim=~%q}[%ds]))`,
		ds.Namespace, pattern, windowSecs)
	usedBytes, err := egressquery.Instant(ctx, s.promHTTP, s.PromBase, q, end)
	if err != nil {
		log.Printf("usage: storage_gb_seconds for %s: %v", ds.Name, err)
		return 0, false
	}
	if usedBytes < 0 {
		usedBytes = 0
	}
	return int64(math.Round(usedBytes * float64(windowSecs) / bytesPerDecimalGB)), true
}

// instanceSampleStepSeconds is the resolution instance-seconds are measured
// at: the kubernetes-cadvisor scrape interval (deploy/gitops/base/prometheus.yaml).
// Each pod is credited one step per evaluation point it reported near, so a
// pod's metered time is its lifetime in the window to within three steps.
const instanceSampleStepSeconds = 15

// instanceLivenessSeconds is how recently a pod must have reported for a step
// to count it. cAdvisor samples carry their own timestamps, so no staleness
// marker ends a deleted pod's series (w4/m110): a bare instant selector at each
// step would carry its last sample forward for Prometheus's 5-minute lookback
// and bill every terminated pod ~285 s more than it ran. The samples are also
// stamped at kubelet housekeeping (10 s, jittered up to 2x), so stored samples
// sit up to ~45 s apart even with every scrape landing: production measured a
// 44.3 s maximum over 53,039 live gaps (w5/m111, 2026-10-27), which broke the
// earlier 44 s bound. Four scrape intervals cover it with margin, and one
// second short keeps the bound off the 15 s grid, so Prometheus 2.x's closed
// range and 3.x's left-open range agree. Any bound from 45 to 59 s credits a
// terminated pod the same three steps, so this one costs nothing over 50 s.
// It is deliberately tighter than the Metrics page's 90 s instanceLivenessWindow
// (metrics/source.go): a chart wants continuity across scrape gaps, a meter
// wants a terminated pod billed at most 45 s past its last sample.
const instanceLivenessSeconds = 4*instanceSampleStepSeconds - 1

// instanceSecondsQuery is the running-time measure (w4/m173): per POD — the
// max by (pod) collapses a pod's containers (an App's one, Valkey's server +
// exporter sidecar, CNPG's instance, a restarted container's new series) into
// one presence series — count the 15 s steps of the window at which the pod
// reported within instanceLivenessSeconds, sum across pods, and scale by the
// step. A pod alive 5 minutes reads ~300, a full-hour pod 3600, two replicas
// 7200, and a rollout adds only the seconds old and new pods actually co-ran.
//
// The range is one second short of the window: Prometheus 2.x subqueries
// include an aligned left endpoint, so a full [3600s:15s] holds 241 steps and
// would bill a full-hour pod 3615. [3599s:15s] holds exactly the window's 240
// steps, (start, end], so consecutive hours partition with no shared step.
func instanceSecondsQuery(matchers string, windowSecs int64) string {
	return fmt.Sprintf(
		`sum(count_over_time((max by (pod) (count_over_time(container_memory_working_set_bytes{%s}[%ds])))[%ds:%ds]))`,
		matchers, instanceLivenessSeconds, windowSecs-1, instanceSampleStepSeconds)
}

// queryInstanceSecondsByMatcher is the shared cAdvisor instant-query body:
// instanceSecondsQuery evaluated at the window's end. ok is false when
// Prometheus is unavailable.
func (s *Service) queryInstanceSecondsByMatcher(ctx context.Context, matchers string, start, end time.Time, logName string) (int64, bool) {
	if s.PromBase == "" {
		return 0, false
	}
	windowSecs := int64(end.Sub(start) / time.Second)
	steps, err := egressquery.Instant(ctx, s.promHTTP, s.PromBase, instanceSecondsQuery(matchers, windowSecs), end)
	if err != nil {
		log.Printf("usage: instance_seconds for %s: %v", logName, err)
		return 0, false
	}
	return int64(math.Round(steps * instanceSampleStepSeconds)), true
}

// queryEgressBytes composes the applicable App sources atomically: exact-router
// HTTP responses, downstream WebSocket frames, and App-pod direct public L3
// bytes. Static sites have no tenant pod, so direct is explicit N/A. A failed
// required source or health signal rejects the whole sum.
func (s *Service) queryEgressBytes(ctx context.Context, app store.App, start, end time.Time) (int64, bool) {
	quantity, _, ok := s.queryEgressBytesEvidence(ctx, app, start, end)
	return quantity, ok
}

// resolveAppCR returns the projected App CR for a control-plane row, resolved
// by its unique app-id label across every workspace: per-tenant namespaces
// (ADR043) scatter the CRs across `<ws>` namespaces, so this must list
// cluster-wide, never scoped to a single namespace. kind names the meter for
// the log line. A miss is a source-unavailable signal, never a healthy zero —
// the meter that cannot identify its App has measured nothing, and saying
// otherwise is what let w6/m110's Defect A stay silent.
func (s *Service) resolveAppCR(ctx context.Context, app store.App, kind string) (*appv1alpha1.App, bool) {
	if s.Client == nil {
		return nil, false
	}
	var projected appv1alpha1.AppList
	if err := s.Client.List(ctx, &projected, client.MatchingLabels{store.LabelAppID: app.ID}); err != nil {
		log.Printf("usage: %s resolve App CR for %s: %v", kind, app.ID, err)
		return nil, false
	}
	if len(projected.Items) != 1 {
		log.Printf("usage: %s resolve App CR for %s: found %d projected Apps", kind, app.ID, len(projected.Items))
		return nil, false
	}
	return &projected.Items[0], true
}

// appPodIdentity returns the (object name, namespace) pair that identifies an
// App's pods and build Jobs in the cluster — the App CR's own metadata, which
// is what the operator names every child after. Falls back to the derived
// CRName/AppNamespace when the CR could not be read, so a transient API-server
// failure degrades to the correct-by-construction identity rather than to the
// wrong one; ok is false only when neither is available.
func (s *Service) appPodIdentity(app store.App, cr *appv1alpha1.App) (name, namespace string, ok bool) {
	if cr != nil {
		return cr.Name, cr.Namespace, true
	}
	if app.TenantID == "" || app.Name == "" {
		return "", "", false
	}
	return core.CRName(app.TenantID, app.Name), s.AppNamespace(app.TenantID), true
}

// expectsRunningPods reports whether an App should have at least one pod alive
// for the window starting at windowStart, so a zero pod-count is evidence of a
// broken read rather than of the App's own state. Cron Apps have pods only
// while a run is in flight and suspended/zero-replica Apps have none by
// construction; both are honest zeros. So is a Free service the operator
// auto-hibernated (or suspended) before the window began: its spec still asks
// for replicas, but it ran no pod. Production degraded every hour of every
// hibernated Free service this way, pinning usage coverage to the month start
// (w4/m139 t002). A park that began inside the window is not exempt: the App
// ran before it, so a zero still means the read found nothing.
func expectsRunningPods(cr *appv1alpha1.App, windowStart time.Time) bool {
	if cr == nil || cr.Spec.Suspended || cr.Spec.Type == appv1alpha1.TypeCronJob {
		return false
	}
	if ready := meta.FindStatusCondition(cr.Status.Conditions, appv1alpha1.ConditionReady); ready != nil &&
		ready.Status == metav1.ConditionFalse &&
		(ready.Reason == appv1alpha1.ReasonAutoHibernated || ready.Reason == appv1alpha1.ReasonSuspended) &&
		!ready.LastTransitionTime.Time.After(windowStart) {
		return false
	}
	return cr.Spec.Replicas > 0
}

// degradeSourceHealth downgrades every healthy observation to "degraded",
// leaving unavailable ones alone: the read succeeded, so it is not missing —
// it is just not to be trusted as a measurement. "degraded" already flows into
// UsageCoverage.DegradedSources and clears Complete (store/usage.go), which is
// the signal that would have surfaced Defect A on day one.
func degradeSourceHealth(health []store.UsageSourceObservation) []store.UsageSourceObservation {
	out := make([]store.UsageSourceObservation, len(health))
	copy(out, health)
	for i := range out {
		if out[i].State == store.UsageSourceHealthy {
			out[i].State = store.UsageSourceDegraded
		}
	}
	return out
}

func (s *Service) queryEgressBytesEvidence(ctx context.Context, app store.App, start, end time.Time) (int64, []store.UsageSourceObservation, bool) {
	cr, found := s.resolveAppCR(ctx, app, store.UsageKindEgressBytes)
	if !found {
		return 0, unavailableAppEgressSources(false), false
	}
	direct := cr.Spec.Type != appv1alpha1.TypeStaticSite
	routers, err := s.TraefikRouterNames(ctx, cr)
	if err != nil {
		log.Printf("usage: egress_bytes resolve routers for %s: %v", app.ID, err)
		return 0, unavailableAppEgressSources(false), false
	}
	specs := egressquery.App(app.ID, routers, direct)
	if len(specs) == 0 {
		// A private/no-router static site has explicit healthy zero egress; it is
		// not missing evidence merely because no public counter applies.
		return 0, []store.UsageSourceObservation{{Source: store.UsageSourceHTTP, State: store.UsageSourceHealthy}}, true
	}
	if s.PromBase == "" {
		observations := make([]store.UsageSourceObservation, 0, len(specs))
		for _, spec := range specs {
			observations = append(observations, store.UsageSourceObservation{Source: string(spec.Source), State: store.UsageSourceUnavailable})
		}
		return 0, observations, false
	}
	return s.queryEgressSourcesEvidence(ctx, app.ID, specs, start, end)
}

func unavailableAppEgressSources(direct bool) []store.UsageSourceObservation {
	out := []store.UsageSourceObservation{{Source: store.UsageSourceHTTP, State: store.UsageSourceUnavailable}}
	if direct {
		out = append(out,
			store.UsageSourceObservation{Source: store.UsageSourceWebSocket, State: store.UsageSourceUnavailable},
			store.UsageSourceObservation{Source: store.UsageSourceDirect, State: store.UsageSourceUnavailable})
	}
	return out
}

func (s *Service) queryDatastoreEgressBytes(ctx context.Context, ds datastoreEntry, start, end time.Time) (int64, bool) {
	quantity, _, ok := s.queryDatastoreEgressBytesEvidence(ctx, ds, start, end)
	return quantity, ok
}

func (s *Service) queryDatastoreEgressBytesEvidence(ctx context.Context, ds datastoreEntry, start, end time.Time) (int64, []store.UsageSourceObservation, bool) {
	source := store.UsageSourcePostgres
	if ds.Kind == store.ResourceKindKeyValue {
		source = store.UsageSourceKeyValue
	}
	if !ds.Public {
		return 0, []store.UsageSourceObservation{{Source: source, State: store.UsageSourceHealthy}}, true
	}
	return s.queryEgressSourcesEvidence(ctx, ds.ID, egressquery.Datastore(ds.ID, ds.Kind, true), start, end)
}

// queryEgressSourcesEvidence sums the hour's egress across sources with PER-SOURCE
// health gating (w1/m51, ADR023 § Observability reads vs billing reads): a
// source failing its health product is SKIPPED for this hour (undercount,
// never invent — its increase() could be reset-inflated), while the healthy
// sources still record. Only a transport failure defers the hour: a past
// hour's samples never improve, so deferring on a health term was equivalent
// to never recording (prod evidence: zero egress_bytes rows for all of July
// 2026 under the old any-source-defers rule, w1/034). All sources skipped
// still records a successful zero — the gap-free cursor advances.
func (s *Service) queryEgressSourcesEvidence(ctx context.Context, resourceID string, specs []egressquery.Spec, start, end time.Time) (int64, []store.UsageSourceObservation, bool) {
	if len(specs) == 0 {
		return 0, nil, true
	}
	seconds := int64(end.Sub(start) / time.Second)
	type result struct {
		source  egressquery.Source
		value   float64
		skipped bool
		err     error
	}
	results := make(chan result, len(specs))
	for _, spec := range specs {
		go func() {
			health, err := egressquery.Instant(ctx, s.promHTTP, s.PromBase, egressquery.Health(spec, seconds), end)
			if err != nil {
				results <- result{source: spec.Source, err: err}
				return
			}
			if health < 1 {
				results <- result{source: spec.Source, skipped: true}
				return
			}
			value, err := egressquery.Instant(ctx, s.promHTTP, s.PromBase, egressquery.Increase(spec, seconds), end)
			results <- result{source: spec.Source, value: value, err: err}
		}()
	}
	var total float64
	deferred := false
	observations := make([]store.UsageSourceObservation, 0, len(specs))
	for range specs {
		result := <-results
		state := store.UsageSourceHealthy
		switch {
		case result.err != nil:
			log.Printf("usage: egress_bytes source %s for %s: %v (hour deferred)", result.source, resourceID, result.err)
			deferred = true
			state = store.UsageSourceUnavailable
		case result.skipped:
			log.Printf("usage: egress_bytes source %s for %s unhealthy in [%s, %s): skipped this hour", result.source, resourceID, start.Format(time.RFC3339), end.Format(time.RFC3339))
			state = store.UsageSourceDegraded
		default:
			total += result.value
		}
		observations = append(observations, store.UsageSourceObservation{Source: string(result.source), State: state})
	}
	sort.Slice(observations, func(i, j int) bool { return observations[i].Source < observations[j].Source })
	if deferred {
		return 0, observations, false
	}
	return int64(math.Round(total)), observations, true
}

// --- t004: build-Job duration metering ---

// platformRebuildRevisions is appID's set of platform-opened build revisions
// (w1/m184), read through an optional store capability: a store without it
// (tests, CR-only mode) exempts nothing. A failed read is an unavailable
// source, so the window is retried rather than billed for the platform.
func (s *Service) platformRebuildRevisions(ctx context.Context, appID string) (map[string]bool, bool) {
	src, has := s.Store.(interface {
		PlatformRebuildRevisions(ctx context.Context, appID string) (map[string]bool, error)
	})
	if !has {
		return nil, true
	}
	revisions, err := src.PlatformRebuildRevisions(ctx, appID)
	if err != nil {
		log.Printf("usage: build_seconds platform rebuilds for %s: %v", appID, err)
		return nil, false
	}
	return revisions, true
}

// queryBuildSeconds sums the durations of completed build Jobs whose
// completionTime falls in [window, end). It lists Jobs by the app-name label in
// the namespace the operator actually runs them in — BEX_BUILD_NAMESPACE, or
// the App's own namespace when the two are co-located. The Kubernetes client
// comes from core.Base.
//
// crName is the App CR's name: the operator stamps app.bex.co/build with
// exactly that (build.Options{Name: app.Name} in app_controller.go), so the
// workspace-scoped store name never matches.
//
// Jobs of an exempt build revision (a platform-opened release, w1/m184) are
// the platform's maintenance and meter nothing.
func (s *Service) queryBuildSeconds(ctx context.Context, crName, namespace string, window, end time.Time, exempt map[string]bool) (int64, bool) {
	if s.Client == nil {
		return 0, false
	}
	var jobs batchv1.JobList
	if err := s.Client.List(ctx, &jobs,
		client.InNamespace(namespace),
		client.MatchingLabels{appv1alpha1.LabelBuild: crName},
	); err != nil {
		log.Printf("usage: build_seconds list jobs for %s: %v", crName, err)
		return 0, false
	}
	var total int64
	for _, job := range jobs.Items {
		if exempt[job.Labels[appv1alpha1.LabelBuildRevision]] {
			continue // the platform's rebuild, not the tenant's (w1/m184)
		}
		ct := job.Status.CompletionTime
		if ct == nil {
			continue // still running
		}
		t := ct.UTC()
		if t.Before(window) || !t.Before(end) {
			continue // not in this window
		}
		if job.Status.StartTime == nil {
			continue
		}
		dur := ct.Sub(job.Status.StartTime.Time)
		if dur > 0 {
			total += int64(dur / time.Second)
		}
	}
	return total, true
}

// catchUpDisksThrough meters provisioned disk capacity for every closed hour
// window from the meter's cursor through `through` (docs/ADR082-persistent-disks.md D9).
//
// Unlike the Prometheus meters, this one is computed for every service at once
// rather than service by service: the size periods it integrates already carry
// each disk's whole lifetime, so one query per window covers live disks,
// disks deleted mid-window, and disks grown mid-window alike — including a
// disk whose service has since been suspended, which still owes for the
// volume it is holding.
//
// Because the arithmetic is over committed rows, re-running a window is
// idempotent and a restart backfills losslessly (bounded by catchupLimit, the
// same horizon inside which usage_hourly stays rewritable).
func (s *Service) catchUpDisksThrough(ctx context.Context, through time.Time) {
	if s.Store == nil {
		return
	}
	through = through.UTC().Truncate(time.Hour)
	floor := through.Add(-catchupLimit)
	// With no disk row yet, start at the catch-up floor, not the latest hour:
	// a meter that has never written (0167's missing 'disk' source failed every
	// window) then backfills what the horizon still allows.
	window := floor
	if cursor, ok, err := s.Store.LatestUsageWindowForKind(ctx, store.UsageKindDiskGBSeconds); err != nil {
		log.Printf("usage: disk meter cursor: %v", err)
		return
	} else if ok {
		window = cursor.UTC().Truncate(time.Hour).Add(time.Hour)
	}
	if window.Before(floor) {
		window = floor
	}
	for ; !window.After(through); window = window.Add(time.Hour) {
		if err := s.meterDiskWindow(ctx, window); err != nil {
			// Stop at the first failure so the gap is retried oldest-first on
			// the next tick rather than leaving a hole behind a newer row.
			log.Printf("usage: disk meter window %s: %v", window.Format(time.RFC3339), err)
			return
		}
	}
}

func (s *Service) meterDiskWindow(ctx context.Context, window time.Time) error {
	rows, err := s.Store.DiskUsageForWindow(ctx, window, window.Add(time.Hour))
	if err != nil {
		return err
	}
	for _, row := range rows {
		if row.GBSeconds <= 0 {
			continue
		}
		if err := s.Store.UpsertUsageHourly(ctx, store.HourlyRow{
			WorkspaceID:  row.TenantID,
			ResourceKind: store.ResourceKindService,
			ServiceID:    row.AppID,
			Kind:         store.UsageKindDiskGBSeconds,
			// Disks price at one flat rate per GB regardless of the service's
			// plan, so the tier dimension stays empty rather than carrying a
			// value nothing prices on.
			Tier:        "",
			WindowStart: window,
			Quantity:    row.GBSeconds,
			// The evidence is a committed control-plane row, so this source is
			// healthy by construction — there is no upstream that could be down.
			SourceHealth: []store.UsageSourceObservation{{
				Source: store.UsageSourceDisk,
				State:  store.UsageSourceHealthy,
			}},
		}); err != nil {
			return err
		}
	}
	return nil
}

// freeInstanceHours sums the Free service instance-seconds in rows against the
// allowance, the same measure the freehours sweeper enforces.
func (s *Service) freeInstanceHours(rows []store.UsageSummaryRow) FreeInstanceHours {
	included := s.FreeInstanceHours
	if included <= 0 {
		included = DefaultFreeInstanceHours
	}
	var seconds int64
	for _, r := range rows {
		if r.Kind == store.UsageKindInstanceSeconds && r.Tier == "free" && store.NormalizeResourceKind(r.ResourceKind) == store.ResourceKindService {
			seconds += r.Total
		}
	}
	return FreeInstanceHours{Used: float64(seconds) / 3600, Included: included}
}
