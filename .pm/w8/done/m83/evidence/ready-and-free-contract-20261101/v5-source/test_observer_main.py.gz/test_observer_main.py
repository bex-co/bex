"""Observer main-only workflow consistency, host facts only; no real collection."""
import unittest
import controller as c
import proof_fixtures as f
import test_controller as original


class ObserverMainControls(unittest.TestCase):
    def reject_other_branch(self,target):
        for branch in ('other-branch','',None):
            facts=f.Facts(original.NOW,separate=True)
            entry=facts.document(facts.ready['observer_entry'])
            metadata=facts.document(entry[target]);metadata['head_branch']=branch
            facts.replace(entry[target],metadata)
            facts.replace(facts.ready['observer_entry'],entry)
            # All file hashes/lengths remain qualified; actual metadata branch
            # contradicts the existing observer cluster job's main-only contract.
            with self.subTest(target=target,branch=branch),self.assertRaises(c.Unproved):
                c.gate_readiness(facts.ready,original.NOW,lambda left,right:True,facts.read)

    def test_observer_run_must_be_on_main(self):self.reject_other_branch('run')
    def test_observer_job_must_be_on_main(self):self.reject_other_branch('job')


if __name__=='__main__':unittest.main()
