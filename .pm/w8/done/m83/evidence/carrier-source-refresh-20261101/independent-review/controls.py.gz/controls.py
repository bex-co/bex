"""Existing frozen guard AST only; local Git/source data, no live/auth/modules."""
from pathlib import Path
import ast,copy,datetime,hashlib,json,re,subprocess,types
ROOT=Path('/private/tmp/bex-w8-m83-carrier-source-capsule-20261101-rd6q3ieh');OLD=Path('/private/tmp/bex-w8-m83-live-transport-v3-main-source-20261101-9b2_pe4q');HERE=Path(__file__).resolve().parent;REPO=Path('/Users/tianpan/projects/bex7');checks=[]
def load(p):return json.loads(p.read_text())
def extract(path,names):
 nodes=[n for n in ast.parse(path.read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
 assert {n.name for n in nodes}==set(names);return ast.Module(body=nodes,type_ignores=[])
controller=ROOT/'controller.py';env={'datetime':datetime,'hashlib':hashlib,'re':re,'FIX_SOURCE':'a15472735e63d9217b4db49f873ceaa69324f5d3','proof_binding':types.SimpleNamespace(ProofError=ValueError)}
exec(compile(extract(controller,['Unproved','require','sha','instant','gate_readiness','_gate_readiness']),str(controller),'exec'),env)
c=types.SimpleNamespace(**{n:env[n] for n in ['Unproved','require','sha','instant','gate_readiness']},RESET=datetime.datetime(2026,11,1,tzinfo=datetime.timezone.utc),MAX_METADATA=2*1024*1024)
requirements=load(ROOT/'binding-context/REQUIRED-SOURCE.json');admission=ROOT/'binding-context/admission.py';ns={'gate':c,'subprocess':subprocess,'re':re,'REQUIREMENTS':requirements,'FIX':requirements['required_fix']}
exec(compile(extract(admission,['source_blobs','critical_blobs']),str(admission),'exec'),ns)
def check(name,condition):
 assert condition,name;checks.append({'name':name,'PASS':True})
def reject(name,operation):
 try:operation()
 except c.Unproved as error:checks.append({'name':name,'PASS':True,'refusal':str(error)});return
 raise AssertionError('unexpected acceptance:'+name)
actual=ns['source_blobs'](REPO,'94cf04f950aba179fc1bfbdbc3161c2c144d8a58');check('actual94cf full Git source+mode/blob and a154 ancestry',actual==requirements['runtime_critical_paths'])
critical=load(ROOT/'CRITICAL-SOURCE.json');check('both snapshots describe same full bytes and sizes',critical['files']=={p:{k:x[k] for k in ('bytes','sha256')} for p,x in actual.items()})
for source in ['a15472735e63d9217b4db49f873ceaa69324f5d3','818ed42189624f421e190424529afc031aef72d7']:
 reject('old carrier rejected:'+source,lambda source=source:ns['source_blobs'](REPO,source))
for path in actual:
 for key in ('bytes','sha256','git_mode','git_blob'):
  wrong=copy.deepcopy(actual);wrong[path][key]=wrong[path][key]+1 if key=='bytes' else '100755' if key=='git_mode' else '0'*(64 if key=='sha256' else 40)
  reject('tamper:'+path+':'+key,lambda wrong=wrong:ns['critical_blobs'](wrong))
wrong=copy.deepcopy(actual);wrong.pop(next(iter(wrong)));reject('missing path rejected',lambda:ns['critical_blobs'](wrong))
extra=copy.deepcopy(actual);extra['CONTROL_ONLY_EXTRA']=dict(next(iter(actual.values())));reject('extra path rejected',lambda:ns['critical_blobs'](extra))
# Extract only actual guard/auth methods, never import original source modules.
transport=ROOT/'transport.py';tree=ast.parse(transport.read_text());classnode=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Transport');methodnodes=[n for n in classnode.body if isinstance(n,ast.FunctionDef) and n.name in ('auth','check_ready')];assert len(methodnodes)==2
te={'c':c,'Path':Path,'re':re,'hashlib':hashlib,'json':json,'REPO':REPO,'HERE':ROOT,'now':lambda:datetime.datetime.now(datetime.timezone.utc)}
exec(compile(extract(transport,['digest','read_json','verify_source']),str(transport),'exec'),te);exec(compile(ast.Module(body=methodnodes,type_ignores=[]),str(transport),'exec'),te)
for value in (None,{}):
 path=HERE/('ready-null.json' if value is None else 'ready-empty.json');path.write_text(json.dumps(value)+'\n');calls=[]
 class Dummy:pass
 d=Dummy();d.ready_path=path;d.ready_bytes_sha=te['digest'](path);d.ready=value;d.auth_started=False;d.source=ROOT
 def command(*a,**kw):calls.append((a,kw));raise AssertionError('NO external/auth command')
 d.runner=types.SimpleNamespace(capture=command);d.check_ready=types.MethodType(te['check_ready'],d)
 reject('null/empty Ready refuses before auth:'+str(value),lambda:te['auth'](d));check('auth unstarted and0commands:'+str(value),not d.auth_started and not calls)
oldplan,newplan=load(OLD/'PLAN.json'),load(ROOT/'PLAN.json');oldprotocol,newprotocol=load(OLD/'binding-context/PROTOCOL.json'),load(ROOT/'binding-context/PROTOCOL.json')
check('a154 ancestor constant preserved',requirements['required_fix']==env['FIX_SOURCE'])
om=load(OLD/'MANIFEST.json');nm=load(ROOT/'MANIFEST.json');delta={n for n,x in om.items() if nm.get(n)!=x};check('only five allowed prior changes',delta=={'CRITICAL-SOURCE.json','binding-context/REQUIRED-SOURCE.json','PLAN.json','binding-context/PROTOCOL.json','V3-DERIVATION.json'})
executables={n for n in om if Path(n).suffix in ('.py','.js')};check('all26 executable bytes exact and no additions',len(executables)==26 and all(om[n]==nm[n] for n in executables) and not{n for n in nm if Path(n).suffix in('.py','.js')}-executables)
check('e392 historical host evidence exact',oldprotocol['host_evidence']==newprotocol['host_evidence'])
current=load(ROOT/'CURRENT-CAPSULE.json');receipt=load(ROOT/'RECEIPT.json');check('runtime Ready Free approval allNULL',all(v is None for v in current['actual_runtime'].values()) and current['root_review_approval'] is None and current['live_authority'] is None and all(v is None for v in receipt['new_actual_runtime'].values()))
check('proxyUNKNOWN nonblocking',current['actual_proxy_observation']=={'version':'UNKNOWN','observed':False,'blocking_before_create':False})
check('wire/streams/bounds/externalgates unchanged and currententrypoint',all(oldplan[k]==newplan[k] for k in ('HTTP_contract','bounds','external_gates','clients','source_and_artifacts','fixed_authenticated_reads_after_authorization')) and str(ROOT/'transport.py') in newplan['transport_entrypoint']['command'])
check('public/client inputs exact',all((ROOT/n).read_bytes()==(OLD/n).read_bytes() for n in ('CLIENTS-AND-REUSE.json','PUBLIC-SOURCE.json')))
assert len(checks)==26,len(checks)
# The existing exact outer source guard remains effective on the new capsule.
sha=hashlib.sha256((ROOT/'MANIFEST.json').read_bytes()).hexdigest();accepted=te['verify_source'](sha);assert len(accepted)==129
try:te['verify_source']('0'*64)
except c.Unproved:wrong_outer_rejected=True
else:raise AssertionError('wrong outer SHA accepted')
result={'scope':'Existing source guard functionAST only, no module toplevel/originalhosted/auth body/network/CI/Go/Docker/Kube/runtime action. Actualreadonly Git object reads; fail-on-any-command injected nullReady auth boundary.','checks':checks,'count':len(checks),'all_PASS':True,'outer_manifest_accepted':sha,'wrong_outer_manifest_rejected':wrong_outer_rejected,'actual94cf_source':actual,'new_authority':None}
(HERE/'CONTROL-RESULT.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({'checks':len(checks),'all_PASS':True,'outer_manifest_accepted':True,'wrong_outer_rejected':True}))
