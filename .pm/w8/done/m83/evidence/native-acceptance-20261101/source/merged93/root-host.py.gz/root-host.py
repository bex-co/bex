from pathlib import Path
import sys,tempfile,subprocess,hashlib,json,unittest
from unittest.mock import patch
SOURCE=Path('/private/tmp/bex-w8-m83-log-pages-final-source-20261101-y2xgf8e0')
REVIEW=Path('/private/tmp/bex-w8-m83-log-pages-root-review-20261101-3t3jbjsx')
sys.path.insert(0,str(SOURCE))
import transport,test_transport
critical=json.loads((SOURCE/'CRITICAL-SOURCE.json').read_text())
with tempfile.TemporaryDirectory(prefix='m83-root-fdd-host-',dir='/private/tmp') as tmp:
 root=Path(tmp).resolve()
 for name,row in critical['files'].items():
  p=subprocess.run(['git','-C','/Users/tianpan/projects/bex7','show',critical['approved_source']+':'+name],capture_output=True,timeout=10)
  assert p.returncode==0 and len(p.stdout)==row['bytes'] and hashlib.sha256(p.stdout).hexdigest()==row['sha256']
  dest=root/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.stdout)
 cls=test_transport.TransportControls;original=cls.test_concrete_ready_binding_checks_actual_critical_source_bytes_before_auth
 def qualified(self):
  with patch.object(transport,'REPO',root):return original(self)
 cls.test_concrete_ready_binding_checks_actual_critical_source_bytes_before_auth=qualified
 modules=['test_controller','test_transport','test_transport_v2','test_proof_binding','test_observer_main','test_public_head','test_auth_relay','test_linux_signature','test_empty204','test_canonical_url','test_build_logs']
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(modules))
 record={'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'PASS':result.wasSuccessful(),'context':'Only unchanged fake-Git concrete source test receives full actual fdd critical-file fixtures via test-only REPO patch, matching new approved source data. Other82 controls ordinary; no auth actors or real native/API/crypto calls.'}
 (REVIEW/'HOST-RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
 raise SystemExit(0 if result.wasSuccessful() else 1)
