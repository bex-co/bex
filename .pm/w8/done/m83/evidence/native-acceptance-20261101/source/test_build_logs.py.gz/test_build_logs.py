"""Pure host own-log pagination controls; no API, auth, fixture or shell execution."""
import base64
import copy
import datetime
import gzip
import json
from pathlib import Path
import types
import unittest
from unittest.mock import patch

import controller as c
import host
import transport as t

AT = '2026-11-01T20:47:55.754767+00:00'
END = '2026-11-01T20:50:15.557980+00:00'
SID = 'srv-controlonly123'
MARKER = 'CONTROL_ONLY_BUILD_SOURCE_CONFIRMED'


def completed():
    return {'exit_code':0,'complete':True,'bound':None,'signal':None}


def response(page=None,status=200,body=None):
    raw = json.dumps(page,ensure_ascii=False).encode() if body is None else body
    return {'status':status,'raw':raw,'body':raw,'headers':{'content-type':'application/json'},
            'event':{'at':END,'status':status,'raw_sha256':c.sha(raw),'decoded_sha256':c.sha(raw)},
            'transport':completed()}


def page(messages=(),more=False,start='2026-11-01T20:48:00.000000001Z',end=END):
    return {'logs':[{'message':m} for m in messages], 'hasMore':more,
            'nextStartTime':start,'nextEndTime':end}


class BuildLogControls(unittest.TestCase):
    def actor(self,responses):
        owned=t.Transport.__new__(t.Transport)
        owned.tokens=set(); owned.data={'resources':[{'id':SID,'children':[]}]}
        owned.budget=types.SimpleNamespace(check=lambda:None)
        def own(sid):
            c.require(sid==SID,'CONTROL_ONLY foreign SID refused')
            return owned.data['resources'][0]
        owned.journal=types.SimpleNamespace(own=own)
        owned.saved=[]; owned.paths=[]
        owned.record=lambda name,value,cleanup=False:owned.saved.append((name,copy.deepcopy(value)))
        def api(method,path):
            self.assertTrue(owned.allowed_api(method,path,None,False))
            owned.paths.append(path)
            self.assertLessEqual(len(owned.paths),len(responses),'unexpected extra page')
            return copy.deepcopy(responses[len(owned.paths)-1])
        owned.api=api
        return owned

    def run_logs(self,owned):
        with patch.object(t,'now',return_value=datetime.datetime.fromisoformat(END)):
            return owned.build_logs({'client':'bex'},{'id':SID,'at':AT})

    def test_request_matches_actual_pinned_limit_and_old1000_is_refused(self):
        contract=json.loads((Path(__file__).parent/'PINNED-LOG-CONTRACT.json').read_bytes())['limit']['schema']
        self.assertEqual((contract['minimum'],contract['maximum']),(1,100))
        owned=self.actor([response(page([MARKER]))])
        query={'resource':SID,'type':'build','limit':1000,'startTime':AT,'endTime':END,'direction':'forward'}
        self.assertFalse(owned.allowed_api('GET','/v1/logs?'+t.urlencode(query),None,False))
        self.run_logs(owned)
        self.assertEqual(t.parse_qs(t.urlsplit(owned.paths[0]).query)['limit'],['100'])

    def test_marker_after_first100_is_retrieved_without_changing_fixed_scope(self):
        first=page(['line'+str(i) for i in range(100)],True)
        owned=self.actor([response(first),response(page([MARKER]))])
        self.assertIn(MARKER,self.run_logs(owned));self.assertEqual(len(owned.paths),2)
        before,after=(t.parse_qs(t.urlsplit(p).query) for p in owned.paths)
        for name in ('resource','type','limit','endTime','direction'):self.assertEqual(before[name],after[name])
        self.assertEqual(after['startTime'],[first['nextStartTime']])
        final=owned.saved[-1][1];self.assertFalse(final['hasMore']);self.assertEqual(len(final['logs']),101)

    def test_nanosecond_progress_is_not_truncated_to_python_microseconds(self):
        first=page(['line'],True,start='2026-11-01T20:47:55.754767001Z')
        owned=self.actor([response(first),response(page([MARKER]))])
        self.assertIn(MARKER,self.run_logs(owned))
        self.assertEqual(t.parse_qs(t.urlsplit(owned.paths[1]).query)['startTime'],[first['nextStartTime']])

    def test_non200_body_is_captured_exactly_before_status_refusal(self):
        raw=b'{"error":"bad_request","message":"limit must be between 1 and 100"}'
        owned=self.actor([response(status=400,body=raw)])
        with self.assertRaisesRegex(c.Unproved,'not200'):self.run_logs(owned)
        self.assertEqual(len(owned.saved),1)
        capture=owned.saved[0][1];self.assertEqual(capture['status'],400)
        for field in ('raw_entity_gzip_base64','decoded_entity_gzip_base64'):
            self.assertEqual(gzip.decompress(base64.b64decode(capture[field])),raw)
        self.assertFalse(any(name.endswith('-build-log.json') for name,_ in owned.saved))

    def test_credentials_in_own_log_body_are_not_retained(self):
        owned=self.actor([response(page(['CONTROL_ONLY_PRIVATE_TOKEN']))]);owned.tokens={'CONTROL_ONLY_PRIVATE_TOKEN'}
        with self.assertRaisesRegex(c.Unproved,'credential'):self.run_logs(owned)
        self.assertEqual(owned.saved,[])

    def test_incomplete_transport_and_bad_envelopes_never_emit_complete_log(self):
        cases=[]
        partial=response(page([MARKER]));partial['transport']['complete']=False;cases.append(partial)
        for change in ({'hasMore':1},{'hasMore':None},{'logs':{}},{'logs':[{}]},
                       {'nextStartTime':None},{'nextEndTime':'bad'}):
            changed=page([MARKER]);changed.update(change);cases.append(response(changed))
        missing=page([MARKER]);del missing['hasMore'];cases.append(response(missing))
        cases.append(response(body=b'{truncated'))
        for value in cases:
            with self.subTest(value=value):
                owned=self.actor([value])
                with self.assertRaises((c.Unproved,ValueError,TypeError)):self.run_logs(owned)
                self.assertFalse(any(name.endswith('-build-log.json') for name,_ in owned.saved))

    def test_cursor_repeat_backwards_outside_window_or_changed_end_is_refused(self):
        for start,end in ((AT,END),('2026-11-01T20:47:00Z',END),
                          ('2026-11-01T20:51:00Z',END),('2026-11-01T20:48:00Z','2026-11-01T20:51:00Z')):
            with self.subTest(start=start,end=end):
                owned=self.actor([response(page([MARKER],True,start,end))])
                with self.assertRaisesRegex(c.Unproved,'cursor'):self.run_logs(owned)
                self.assertEqual(len(owned.paths),1)

    def test_ten_incomplete_pages_refuse_even_if_marker_already_present(self):
        pages=[response(page([MARKER],True,'2026-11-01T20:48:'+str(i).zfill(2)+'Z')) for i in range(10)]
        owned=self.actor(pages)
        with self.assertRaisesRegex(host.Stop,'10pages'):self.run_logs(owned)
        self.assertEqual(len(owned.paths),10)
        self.assertFalse(any(name.endswith('-build-log.json') for name,_ in owned.saved))

    def test_cumulative_byte_bound_is_not_reset_per_page(self):
        owned=self.actor([response(page(['x'*600000],True)),response(page(['y'*600000]))])
        with self.assertRaisesRegex(c.Unproved,'1MiB'):self.run_logs(owned)
        self.assertEqual(len(owned.saved),1)

    def test_own_id_and_exact_build_query_remain_required(self):
        owned=self.actor([])
        for change in ({'resource':'srv-foreign'},{'type':'app'},{'direction':'backward'},{'extra':'x'}):
            query={'resource':SID,'type':'build','limit':100,'startTime':AT,'endTime':END,'direction':'forward'}
            query.update(change)
            try:allowed=owned.allowed_api('GET','/v1/logs?'+t.urlencode(query),None,False)
            except c.Unproved:allowed=False
            self.assertFalse(allowed)

if __name__ == '__main__':unittest.main()
