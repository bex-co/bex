"""Audit retained completed m83 own evidence; no live or private-auth actions."""
from pathlib import Path
import base64,copy,datetime,gzip,hashlib,io,json,re,subprocess,sys,types
from urllib.parse import urlsplit,parse_qs
from unittest.mock import patch
R=Path(__file__).parent
RUN=Path('/private/tmp/bex-w8-m83-live-run-92317733e66c75cf')
E=RUN/'evidence'
S=Path('/private/tmp/bex-w8-m83-log-pages-final-source-20261101-y2xgf8e0')
READY=Path('/private/tmp/bex-w8-m83-log-pages-ready-launch-20261101-ppgwwb21/READY.json')
HOST=Path('/private/tmp/bex-w8-m83-log-pages-root-review-20261101-3t3jbjsx')
REPO=Path('/Users/tianpan/projects/bex7')
custody={}
def sha(b):return hashlib.sha256(b).hexdigest()
def raw(p,maximum=2<<20):
 p=Path(p);assert not p.is_relative_to(RUN/'private') and not p.is_symlink() and p.is_file() and p.stat().st_size<=maximum,p
 b=p.read_bytes();custody[str(p)]={'sha256':sha(b),'bytes':len(b)};return b
def load(p):return json.loads(raw(p))
def filehash(p):
 p=Path(p);assert not p.is_symlink() and p.is_file();h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(1<<20):h.update(b);n+=len(b)
 return h.hexdigest(),n
result=load(E/'RESULT.json');manifest=load(E/'MANIFEST.json');inputs=load(E/'inputs.json')
assert result['PASS'] is True and result['failure'] is None and result['cleanup_errors']==[] and result['source_only_run'] is False
assert set(result['results'])=={'bex','render','cleanup'} and sha(raw(E/'MANIFEST.json'))==result['evidence_manifest_sha256']
for name,d in manifest['files'].items():assert filehash(E/name)==(d['sha256'],d['bytes']),name
assert inputs['source_manifest_sha256']==sha(raw(S/'MANIFEST.json'))=='3e5addf88d41525701d21d5374453ca56e05f852bc3b2e2606a7668edc2d4f64'
source_manifest=load(S/'MANIFEST.json')
for name,d in source_manifest.items():assert filehash(S/name)==(d['sha256'],d['bytes']),name
for name in ('fixture.js','stream-observer.js','upgrade-observer.js'):assert raw(RUN/'source'/name)==raw(S/name)
host=load(HOST/'HOST-RESULT.json');assert host['PASS'] is True and host['tests']==93 and host['failures']==host['errors']==host['skips']==0
indep=Path('/private/tmp/bex-w8-m83-log-pages-independent-review-20261101-uPn0KE49')
assert sha(raw(indep/'REVIEW.json'))=='3b7c8261fd113ecb2fb3490942f81d3eabd77f7498539798c007cc1f8ba45aa3'
assert sha(raw(indep/'MANIFEST.json'))=='606d9354f822b58e56104cb8de3de66e9e16d3aaca82a0d8dadfe998b84c90dd'
sys.path.insert(0,str(S))
import controller as c
import transport as t
assert inputs['workspace']==c.WORKSPACE and inputs['no_foreign_auth_reused'] is True
for client,d in inputs['clients'].items():assert filehash(d['resolved_public_binary_path'])==(d['sha256'],d['bytes'])
resources=result['resources'];assert len(resources)==2 and [x['client'] for x in resources]==['bex','render']
before=load(E/'baseline-before.json');after=load(E/'baseline-after.json')
cleanup=c.compare_cleanup(before,after,resources)
assert cleanup==load(E/'cleanup-comparison.json')==result['results']['cleanup'] and cleanup['state']=='PASS' and cleanup['own_used_count_delta']==0
for path,ids in before['metadata'].items():assert set(ids)<=set(after['metadata'][path])
assert before['limits']['services']['used']==after['limits']['services']['used'] and not cleanup['concurrent_additions']
assert all(x['terminating']==0 for x in after['limits'].values())
journal=c.Journal({'workspace':c.WORKSPACE,'baseline_ids':before['ids'],'resources':resources},lambda data:None)
ready=load(READY);assert sha(raw(READY))==inputs['ready_input_sha256']=='8882666f5f74873094ff0670d502915cfb390a24a053934e8e9b6f966ebc1c5a'
def ancestor(old,new):return subprocess.run(['git','merge-base','--is-ancestor',old,new],cwd=REPO,capture_output=True).returncode==0
for path,d in ready['critical_source'].items():
 b=subprocess.run(['git','show',ready['source']+':'+path],cwd=REPO,capture_output=True,check=True).stdout
 assert len(b)==d['bytes'] and sha(b)==d['sha256']
for p in sorted(E.glob('ready-*.json')):
 view=load(p);at=c.instant(resources[-1]['at'])
 checked=c.gate_readiness(ready,at,ancestor,raw)
 assert all(view[k]==v for k,v in checked.items()) and view['actualProxyVersion']=='UNKNOWN'
api_events=[]
for p in sorted((E/'outputs').glob('api-*.json')):
 x=load(p);api_events.append((p,x))
for row in resources:
 assert row['state']=='deleted' and row['HTTP']==201 and row['forwarded_once'] is True and len(row['children'])==1
 journal.own(row['id'])
 client=row['client'];spec=c.specification(client,inputs['nonce'],inputs['public_source'])
 assert row['name']==spec['name']
 assert c.validate_post(row['request'],spec)
 assert 0<=(c.instant(row['at'])-c.instant(ready['at'])).total_seconds()<=3600
 assert c.gate_readiness(ready,c.instant(row['at']),ancestor,raw)['state']=='PASS'
 assert c.public_url(spec,row,'/snapshot').startswith('https://'+row['create_view']['slug']+'.onbex.co/')
posts=[(p,load(p)) for p in sorted(E.glob('native-POST-*.json'))];assert len(posts)==2
entities=[(p,load(p)) for p in sorted((E/'entities').glob('*.json'))]
native=[(p,load(p)) for p in sorted((E/'outputs').glob('native-*.json'))]
heads=[(p,load(p)) for p in sorted(E.glob('public-head-*.json'))];assert len(heads)==2
for p,x in heads:
 c.completed(x);assert x['stdout']==inputs['public_source']['commit']+'\trefs/heads/master\n' and x['stderr']==''
 assert x['argv']==['git','-c','url.https://github.com/.insteadOf=git@github.com:','-c','credential.helper=','-c','core.askPass=','ls-remote','git@github.com:expressjs/serve-static.git','refs/heads/master']
free_inputs=[(p,load(p)) for p in sorted(E.glob('free-gate-inputs-*.json'))];assert len(free_inputs)==2
free_summaries=[]
for p,x in free_inputs:
 at=c.instant(x['at'])
 for kind,event in x['observations'].items():
  c.completed(event['transport']);assert event['status']==200 and 0<=(at-c.instant(event['at'])).total_seconds()<=300
 free_summaries.append({**c.gate_free(x['owner'],x['usage'],x['limits'],at),'coverage_diagnostic':x['usage'].get('coverage'),'input_sha256':sha(raw(p))})
assert all(x['state']=='PASS' and x['free_hours_remaining']>=1 for x in free_summaries)
role_audits={};selected_deployments=[];selected_events=[];selected_commands=[]
for row in resources:
 client=row['client'];spec=c.specification(client,inputs['nonce'],inputs['public_source']);sid=row['id'];snapshot=load(E/(client+'-first-live.json'))
 own_post=[(p,x) for p,x in posts if x['request']['name']==spec['name']];assert len(own_post)==1
 p,post=own_post[0];assert post['status']==201 and c.validate_post(post['request'],spec)
 response=gzip.decompress(base64.b64decode(post['complete_raw_response_gzip_base64'],validate=True));assert len(response)==post['raw_response_bytes'] and sha(response)==post['raw_response_sha256']
 events=[(p,x) for p,x in api_events if x['request']['method']=='POST' and x['request']['path']=='/v1/services' and x['status']==201 and x['raw_sha256']==post['raw_response_sha256']]
 assert len(events)==1;selected_events.append(events[0][0]);event=events[0][1]
 encoding=event['response_headers'].get('content-encoding','identity');assert encoding in ('identity','gzip')
 decoded=c.gunzip_bounded(response) if encoding=='gzip' else response
 assert sha(decoded)==event['decoded_sha256'] and len(decoded)==event['decoded_bytes']
 response=json.loads(decoded);view=response.get('data',response).get('service',response.get('data',response));assert view==row['create_view']
 own_native=[(p,x) for p,x in native if '--name' in x['argv'] and x['argv'][x['argv'].index('--name')+1]==spec['name']];assert len(own_native)==1
 np,n=own_native[0];c.completed(n);assert n['argv']==[client,*spec['args']]
 assert n['group_cleanup']['direct_child_reaped'] is True and n['group_cleanup']['group_absent'] is True
 c.completed(snapshot['capture']);assert json.loads(c.restore_entity(snapshot['capture']))==snapshot['snapshot']
 build=load(E/'outputs'/(client+'-build-log.json'));assert build['hasMore'] is False
 candidates=[];all_children=set()
 for dp in sorted(E.glob('deployments-*.json')):
  d=load(dp)
  if d['id']!=sid:continue
  all_children.update(x['id'] for x in d['rows'])
  try:assessment=c.validate_first_live(spec,d['rows'],snapshot['snapshot'],json.dumps(build,ensure_ascii=False))
  except c.Unproved:continue
  candidates.append((dp,d,assessment))
 assert candidates and all_children==set(row['children']) and all(x[2]==snapshot['assessment'] for x in candidates)
 selected_deployments.append(candidates[0][0])
 pages=[]
 for p in sorted((E/'outputs').glob(client+'-build-log-page-*.json')):
  x=load(p);body=gzip.decompress(base64.b64decode(x['decoded_entity_gzip_base64'],validate=True));entity=gzip.decompress(base64.b64decode(x['raw_entity_gzip_base64'],validate=True));event=x['observation']
  assert sha(body)==event['decoded_sha256'] and len(body)==event['decoded_bytes'] and sha(entity)==event['raw_sha256'] and len(entity)==event['raw_bytes'];c.completed(event['transport']);assert x['status']==event['status']==200
  pages.append((p,x,entity,body))
 assert 1<=len(pages)<=10
 actor=t.Transport.__new__(t.Transport);actor.tokens=set();actor.budget=types.SimpleNamespace(check=lambda:None);saved=[];calls=[]
 actor.record=lambda name,value,cleanup=False:saved.append((name,copy.deepcopy(value)))
 def api(method,path):
  index=len(calls);assert index<len(pages);p,x,entity,body=pages[index];assert method=='GET' and path==x['observation']['request']['path'];calls.append(path)
  return {'raw':entity,'body':body,'status':x['status'],'event':x['observation'],'headers':{'content-encoding':x['content_encoding']},'transport':x['observation']['transport']}
 actor.api=api
 end=parse_qs(urlsplit(pages[0][1]['observation']['request']['path']).query)['endTime'][0]
 with patch.object(t,'now',return_value=c.instant(end)):replayed=json.loads(actor.build_logs(spec,row))
 assert len(calls)==len(pages) and replayed==build
 http=load(E/(client+'-HTTP.json'));assert len(http)==38
 for expected,recorded in zip(c.matrix(spec),http):
  candidates=[(p,x) for p,x in entities if x.get('request',{}).get('row')==expected and x['request']['URL']==c.public_url(spec,row,expected['path'])]
  assert len(candidates)==1
  p,capture=candidates[0];assessment=c.assess_http(spec,expected,capture,snapshot['snapshot']);assert assessment['state']=='PASS' and assessment==recorded['assessment']
  assert recorded['name']==expected['name'] and recorded['protocol']==expected['protocol'];assert capture['group_cleanup']['group_absent'] is True
 streams=load(E/(client+'-streams.json'));assert len(streams)==6
 expected_streams=[(protocol,kind,offer) for protocol in ('1.1','2') for kind,offer in (('sse','identity'),('sse','br, gzip'),('ndjson','gzip'))]
 for saved,(protocol,kind,offer) in zip(streams,expected_streams):
  assert (saved['protocol'],saved['kind'],saved['offer'])==(protocol,kind,offer)
  assessment=c.assess_stream(spec,saved['capture'],protocol,kind);assert assessment['state']=='PASS' and assessment==saved['assessment'];c.completed(saved['transport'])
  expected=['node',str(RUN/'source/stream-observer.js'),c.public_url(spec,row,'/stream' if kind=='sse' else '/ndjson'),spec['marker'],offer,protocol,kind]
  assert saved['transport']['argv']==expected
 upgrade=load(E/(client+'-upgrade.json'));c.completed(upgrade['transport']);u=upgrade['capture'];key=base64.b64encode(b'm83-control-only').decode();accept=base64.b64encode(hashlib.sha1((key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest()).decode()
 assert u['complete'] is True and u['pass'] is True and u['status']==101 and u['actual_protocol']=='1.1' and u['headers']['sec-websocket-accept']==accept and u['headers']['x-qa-marker']==spec['marker'] and not u['headers'].get('content-encoding') and base64.b64decode(u['raw_entity_base64'])==b'\x88\x00'
 assert upgrade['transport']['argv']==['node',str(RUN/'source/upgrade-observer.js'),c.public_url(spec,row,'/upgrade'),spec['marker']]
 settings=load(E/(client+'-settings.json'));assert len(settings)==3 and [x['surface'] for x in settings]==['REST','GraphQL','MCP']
 for setting in settings:assert c.validate_settings(spec,sid,setting['surface'],setting['view'])==setting['assessment']
 for child in row['children']:
  own=[(p,x) for p,x in api_events if x['request']['method']=='GET' and x['request']['path']=='/v1/services/'+sid+'/deploys/'+child and x['status']==404];assert own
  selected_events.append(own[-1][0])
 own=[(p,x) for p,x in api_events if x['request']['method']=='GET' and x['request']['path']=='/v1/services/'+sid and x['status']==404];assert own;selected_events.append(own[-1][0])
 own=[(p,x) for p,x in entities if x['request']['URL']==c.public_url(spec,row,'/snapshot') and x['status']==404];assert len(own)==1;c.completed(own[0][1]);selected_events.append(own[0][0])
 role_audits[client]={'state':'PASS','id':sid,'first_deploy':snapshot['assessment']['first_deploy'],'public_canonical_url':c.public_url(spec,row,'/snapshot').removesuffix('/snapshot'),'native_binary_sha256':inputs['clients'][client]['sha256'],'native_exit':n['exit_code'],'HTTP':38,'streams':6,'upgrade':1,'settings':3,'build_log_pages':len(pages),'program_sha256':spec['program_sha256'],'payload_bytes':spec['payload_bytes'],'payload_sha256':spec['payload_sha256'],'actual_Node':snapshot['snapshot']['node'],'first_only_source_commit':spec['source']['commit'],'all_own_children_deleted':True,'former_canonical_url_status':404}
logout=load(E/'logout.json');assert logout['native_logout_exit']==logout['Kratos_logout_exit']==0 and logout['resources_created_by_run']==2 and logout['own_credential_files_removed'] is True and logout['own_oauth_chain_upstream204'] is True
c.completed(load(E/'logout-command.json'));c.completed(load(E/'auth-command.json'))
revoke=[(p,x) for p,x in api_events if x['request']=={'method':'POST','path':'/v1/oauth/revoke','authorization':'[REDACTED]'} and x['status']==204];assert len(revoke)==1;c.completed(revoke[0][1]['transport']);selected_events.append(revoke[0][0])
assert result['results']['bex']['checks']['required_counts']==result['results']['render']['checks']['required_counts']=={'HTTP':38,'streams':6,'upgrade':1}
ready_projection={'state':'PASS','source':ready['source'],'image':ready['image'],'observed_at':ready['at'],'requiredAncestor':ready['requiredAncestor'],'actualProxyVersion':'UNKNOWN','input_sha256':sha(raw(READY)),'private_input':str(READY),'signature':ready['signature_receipt'],'signature_stdout':ready['signature_stdout'],'inventory':ready['readiness_proof'],'observer':ready['observer_entry'],'scope':'Projection and private hash-bound references only; full production inventory and deployment/pod metadata are excluded. This capsule is not a standalone complete cryptographic or Ready proof.'}
audit={'PASS':True,'at':result['at'],'result_sha256':sha(raw(E/'RESULT.json')),'original_manifest_sha256':sha(raw(E/'MANIFEST.json')),'source_manifest_sha256':inputs['source_manifest_sha256'],'source_payloads_verified':len(source_manifest),'original_evidence_payloads_verified':len(manifest['files']),'roles':role_audits,'ready':ready_projection,'Free':free_summaries,'cleanup':cleanup,'logout':logout,'source_host_controls':host,'actualProxyVersion':'UNKNOWN','signed_differences':['gzip remains enabled despite origin Cache-Control:no-transform','Strong origin ETag retained on transformed gzip entity'],'limitations':['No live Render platform comparison. Original native clients target Bex through supported isolated host/config selection.','Curl captures raw encoded entity after transfer framing removal; it does not capture TLS/TCP or HTTP2 frames.','Image/grpc rows prove content-type exclusion, not complete PNG parsing or gRPC application semantics. Upgrade is finite HTTP1 WebSocket; HTTP2 extended CONNECT is not claimed.','Full private Ready/signature/inventory and baseline metadata remain private; portable evidence only contains explicit projected/hash-bound references.'],'selected_deployment_files':[str(x.relative_to(E)) for x in selected_deployments],'selected_cleanup_events':[str(x.relative_to(E)) for x in selected_events]}
(R/'AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n');(R/'INPUT-CUSTODY.json').write_text(json.dumps(custody,indent=2)+'\n')
print(json.dumps({'PASS':True,'roles':{k:{q:v[q] for q in ('HTTP','streams','upgrade','settings','build_log_pages')} for k,v in role_audits.items()},'source_payloads':len(source_manifest),'original_evidence_payloads':len(manifest['files']),'ready_input_sha256':inputs['ready_input_sha256'],'private_auth_read':False}))
