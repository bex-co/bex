from pathlib import Path
import datetime,hashlib,json,os,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from read import ROOT,command,dump
binary=Path('/private/tmp/bex7-native-acceptance-novb586u/cosign')
h=hashlib.sha256()
with binary.open('rb') as stream:
 for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
assert binary.stat().st_size==99023586 and h.hexdigest()=='9f9b8cd557cf2e5b3df3373a00baa005a86b02391e3e06dd0ce37b3a1533d3a4'
inventory=json.loads((ROOT/'inventory.json').read_text());deps=inventory['platformImages']['deployments']
manager=[d for d in deps if d['namespace']=='bex-system' and d['name']=='bex-controller-manager'];assert len(manager)==1
image=manager[0]['containerImages']['manager']
old=json.loads(Path('/private/tmp/bex-w8-m83-ready-admission-prep-20261031-bo8cxu7u/context/old218-signature-receipt.json').read_text())
assert image==old['image']
source=old['source'];assert source=='d147703d7657f8795593deb2e74c9e7eac426cd2'
# Prior receipt is DISCOVERY ONLY. This fresh command must establish real
# identity/issuer/source/subject/signature/transparency with current trust.
tuf=ROOT/'fresh-tuf';docker=ROOT/'empty-docker-config'
tuf.mkdir(mode=0o700);docker.mkdir(mode=0o700)
argv=[str(binary),'verify','--certificate-identity','https://github.com/bex-co/bex/.github/workflows/deploy.yml@refs/heads/main','--certificate-oidc-issuer','https://token.actions.githubusercontent.com','--certificate-github-workflow-sha',source,image]
row=command('strict-signature',argv,seconds=120,cap=1024*1024,env=dict(os.environ,TUF_ROOT=str(tuf),DOCKER_CONFIG=str(docker),GODEBUG='gctrace=0'))
receipt=dict(row,scope='Fresh actual strict public candidate signature; prior218 receipt used only for exactcandidate/source discovery, not verification evidence.',source=source,image=image,tool_sha256=h.hexdigest(),fresh_private_tuf=str(tuf),empty_docker_config=str(docker))
if row['exit']==0 and row['stop'] is None:
 payload=json.loads((ROOT/'strict-signature.stdout').read_text());assert isinstance(payload,list) and payload
 for proof in payload:
  assert proof['critical']['image']['docker-manifest-digest']==image.split('@')[1]
  assert proof['critical']['identity']['docker-reference']==image
 receipt['proof_count']=len(payload)
 receipt['actual_strict_crypto']='PASS'
else:receipt['actual_strict_crypto']='FAIL_OR_INCOMPLETE'
dump(ROOT/'SIGNATURE-RECEIPT.json',receipt)
print(json.dumps({'actual_signature':receipt['actual_strict_crypto'],'proof_count':receipt.get('proof_count'),'source':source,'stop':row['stop'],'exit':row['exit']}))
