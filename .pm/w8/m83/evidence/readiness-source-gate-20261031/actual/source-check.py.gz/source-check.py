from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from read import ROOT,command,dump
source='d147703d7657f8795593deb2e74c9e7eac426cd2';fix='a15472735e63d9217b4db49f873ceaa69324f5d3'
expected=json.loads(Path('/private/tmp/bex-w8-m83-ready-admission-prep-20261031-bo8cxu7u/REQUIRED-SOURCE.json').read_text())
ancestry=command('source-ancestry',['git','merge-base','--is-ancestor',fix,source],seconds=10,cap=16384)
rows={}
for index,(path,wanted) in enumerate(expected['runtime_critical_paths'].items()):
 body=command('critical-'+str(index),['git','show',source+':'+path],seconds=10,cap=512*1024)
 tree=command('critical-'+str(index)+'-tree',['git','ls-tree',source,'--',path],seconds=10,cap=16384)
 actual=None
 if body['exit']==0 and body['stop'] is None and tree['exit']==0 and tree['stop'] is None:
  parts=(ROOT/('critical-'+str(index)+'-tree.stdout')).read_text().split()
  if parts:actual={'bytes':body['stdout']['bytes'],'sha256':body['stdout']['sha256'],'git_mode':parts[0],'git_blob':parts[2]}
 rows[path]={'expected':wanted,'actual':actual,'equal':actual==wanted}
workflow=command('carrier-deploy-workflow',['git','show',source+':.github/workflows/deploy.yml'],seconds=10,cap=256*1024)
dump(ROOT/'SOURCE-REVIEW.json',{'source':source,'required_fix':fix,'fix_is_ancestor':ancestry['exit']==0 and ancestry['stop'] is None,'ancestry_exit':ancestry['exit'],'critical_files':rows,'all_critical_files_exact':all(row['equal'] for row in rows.values()),'actual_workflow_source':workflow['stdout'],'scope':'Immutable localGitobject bytes/modes/blobs from actualsigned candidate source; nofetch/repoGitmutation. Required source absence/mismatch is a real m83admission blocker, not a proxyversion issue.'})
print(json.dumps({'fix_is_ancestor':ancestry['exit']==0,'critical_files_equal':{p:r['equal'] for p,r in rows.items()}}))
