from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from reader import ROOT,command,dump,now
cases=[('active',41244080467,'ea5a901daf6b78e7da116c4e363b95847dad5110'),('pending',41249441054,'99cdc5c5a5b53629e2a98963d43d373511a91c1f'),('cancelled-a154',41245384647,'a15472735e63d9217b4db49f873ceaa69324f5d3'),('cancelled-c680',41246989227,'c680cd1957db6cc908ad844ccb6f1cb9614f209b')]
projection=[]
for name,run,source in cases:
 row=command(name,['gh','api',f'repos/bex-co/bex/actions/runs/{run}/jobs?per_page=100'],seconds=30,cap=768*1024)
 assert row['exit']==0 and row['stop'] is None,name
 data=json.loads((ROOT/(name+'.stdout')).read_text());assert data['total_count']<=100
 jobs=[]
 for job in data['jobs']:
  assert job['run_id']==run and job['head_sha']==source
  jobs.append({'id':job['id'],'name':job['name'],'status':job['status'],'conclusion':job['conclusion'],'started_at':job.get('started_at'),'completed_at':job.get('completed_at'),'runner_group_name':job.get('runner_group_name'),'labels':job.get('labels'),'steps':[{'number':s['number'],'name':s['name'],'status':s['status'],'conclusion':s['conclusion'],'started_at':s.get('started_at'),'completed_at':s.get('completed_at')} for s in job.get('steps',[])]})
 projection.append({'role':name,'run_id':run,'source':source,'fetched_at':row['ended_at'],'total_jobs':data['total_count'],'jobs':jobs})
dump(ROOT/'JOBS-PROJECTION.json',projection)
print(json.dumps([dict(role=r['role'],run=r['run_id'],total_jobs=r['total_jobs'],jobs=[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'current_steps':[s for s in j['steps'] if s['status']!='completed'],'completed_at':j['completed_at']} for j in r['jobs']]) for r in projection],indent=2))
