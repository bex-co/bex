from pathlib import Path
import datetime,hashlib,json,os,selectors,signal,subprocess,time,shutil
ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/tianpan/projects/bex7')
SMALL_CAP=3*1024*1024

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,value):p.write_text(json.dumps(value,indent=2)+'\n');p.chmod(0o600)
def size():return sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file() and p.name!='job.log')
def command(name,argv,seconds=30,cap=512*1024,env=None):
    start=time.monotonic();at=now();reason=None
    out=ROOT/('job.log' if name=='job-log' else name+'.stdout');err=ROOT/(name+'.stderr')
    p=subprocess.Popen(argv,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,start_new_session=True)
    poll=selectors.DefaultSelector();poll.register(p.stdout,selectors.EVENT_READ,(out,cap));poll.register(p.stderr,selectors.EVENT_READ,(err,65536))
    handles={out:out.open('wb'),err:err.open('wb')};counts={out:0,err:0}
    try:
      while poll.get_map():
        if time.monotonic()-start>seconds:reason='timeout';break
        if size()>SMALL_CAP or shutil.disk_usage('/private/tmp').free<1210056704:reason='resource-guard';break
        for key,_ in poll.select(.1):
          data=os.read(key.fileobj.fileno(),16384)
          path,limit=key.data
          if not data:poll.unregister(key.fileobj);continue
          room=limit-counts[path]
          if len(data)>room:
            handles[path].write(data[:max(0,room)]);counts[path]+=max(0,room);reason='output-cap';break
          handles[path].write(data);counts[path]+=len(data)
        if reason:break
      if reason:
        try:os.killpg(p.pid,signal.SIGTERM)
        except ProcessLookupError:pass
      try:p.wait(timeout=2)
      except subprocess.TimeoutExpired:
        os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=2)
    finally:
      poll.close()
      for f in (p.stdout,p.stderr):f.close()
      for f in handles.values():f.close()
      try:os.killpg(p.pid,signal.SIGKILL)
      except ProcessLookupError:pass
      if p.poll() is None:p.wait(timeout=2)
    row={'argv':argv,'at':at,'ended_at':now(),'seconds':round(time.monotonic()-start,3),'exit':p.returncode,'stop':reason,'stdout':{'path':str(out),'sha256':sha(out),'bytes':out.stat().st_size},'stderr':{'path':str(err),'sha256':sha(err),'bytes':err.stat().st_size}}
    dump(ROOT/(name+'.json'),row)
    return row
