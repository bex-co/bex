"""Six invented host controls for exact per-case family source/custody binding.
No real review, family catalog, source equivalence or runtime approval is created.
"""
import copy,unittest
import core as c
import readiness as r
from qualification_fixtures import Facts


def identity(ref):return {key:ref[key] for key in ('bytes','sha256')}

def observed(f):
    rows=f.doc(f.entry['families']);return rows,rows['rows'][0],f.contract['family_cases'][0]

def save_review(f,rows,row,want,review):
    f.replace(row['source_equivalence'],review)
    want['source_equivalence']['descriptor']=identity(row['source_equivalence'])
    f.replace(f.entry['families'],rows)

def qualify(f):return r.qualification(f.entry,f.contract,f.docs.__getitem__)


class FamilySourceControls(unittest.TestCase):
    def test_mixed_current_and_PM_only_equal_input_rows_keep_both_actual_sources(self):
        f=Facts();dated=f.contract['roles']['family_generator'];target=f.contract['roles']['qualified_source']
        f.family_source(source=target,case_id='current-AMD-control',append=True)
        result=qualify(f)['families']
        self.assertEqual(result['execution_sources'],{'family-amd64':dated,'current-AMD-control':target})
        self.assertEqual(result['source_equivalence']['family-amd64']['kind'],'captured-input-equality')
        self.assertIsNone(result['source_equivalence']['current-AMD-control'])
        self.assertEqual({row['architecture'] for row in f.doc(f.entry['families'])['rows']},{'amd64'})

    def test_older_branch_specific_review_binds_actual_diff_and_unchanged_scope_without_newruntime(self):
        f=Facts();f.family_source(kind='reviewed-branch-nonimpact')
        result=qualify(f)['families'];review=result['source_equivalence']['family-amd64']
        self.assertEqual(review['kind'],'reviewed-branch-nonimpact')
        self.assertNotEqual(review['execution_source'],review['qualified_source'])
        rows,row,want=observed(f)
        self.assertEqual(want['source_equivalence']['unchanged_paths'],[r.COMMON_SLOT])
        self.assertEqual(want['source_equivalence']['changed_paths'],['scripts/CONTROL_ONLY-branch.py'])

    def test_forged_source_swapped_case_or_rehashed_detached_body_result_refuses(self):
        for change in ('row-source','result-case','result-source','result-process','swapped-body'):
            f=Facts();rows,row,want=observed(f)
            if change=='row-source':row['source']='0'*40
            elif change=='swapped-body':
                row['proofs']['body_result']=copy.deepcopy(row['proofs']['input_manifest'])
            else:
                body=f.doc(row['proofs']['body_result'])
                if change=='result-case':body['case_id']='foreign-case'
                elif change=='result-source':body['execution_source']='0'*40
                else:body['result']=dict(body['result'],command=['CONTROL_ONLY','WRONG'])
                f.replace(row['proofs']['body_result'],body)
                want['proofs']['body_result']=identity(row['proofs']['body_result'])
            f.replace(f.entry['families'],rows)
            with self.subTest(change=change),self.assertRaises(c.Unproved):qualify(f)

    def test_missing_exception_unlisted_or_duplicate_case_and_unexpected_current_exception_refuse(self):
        for change in ('missing-exception','missing-policy','extra-ID','duplicate-ID','current-exception'):
            f=Facts();rows,row,want=observed(f)
            if change=='missing-exception':row.pop('source_equivalence')
            elif change=='missing-policy':want.pop('source_equivalence')
            elif change=='extra-ID':
                extra=copy.deepcopy(row);extra['id']='unlisted';rows['rows'].append(extra)
            elif change=='duplicate-ID':rows['rows'].append(copy.deepcopy(row))
            else:
                want['execution_source']=row['source']=f.contract['roles']['qualified_source']
                body=f.doc(row['proofs']['body_result']);body['execution_source']=row['source']
                f.replace(row['proofs']['body_result'],body);want['proofs']['body_result']=identity(row['proofs']['body_result'])
            f.replace(f.entry['families'],rows)
            with self.subTest(change=change),self.assertRaises(c.Unproved):qualify(f)

    def test_full_input_equality_refuses_bytes_mode_and_path_drift_even_when_rehashed_and_listed(self):
        for change in ('bytes','mode','path'):
            f=Facts();rows,row,want=observed(f);review=f.doc(row['source_equivalence'])
            actual=f.doc(review['actual_inputs']);key=next(iter(actual['files']))
            if change=='bytes':actual['files'][key]['sha256']='0'*64
            elif change=='mode':actual['files'][key]['git_mode']='100755'
            else:actual['files']['scripts/other']=actual['files'].pop(key)
            f.replace(review['actual_inputs'],actual)
            want['source_equivalence']['actual_inputs']=identity(review['actual_inputs'])
            target=f.doc(review['qualified_inputs'])['files']
            changed=sorted(path for path in set(actual['files'])|set(target) if actual['files'].get(path)!=target.get(path))
            review['changed_paths']=want['source_equivalence']['changed_paths']=changed
            save_review(f,rows,row,want,review)
            with self.subTest(change=change),self.assertRaises(c.Unproved):qualify(f)

    def test_equivalence_case_target_common_ARCH_review_and_branch_scope_cannot_be_selfclaimed(self):
        for change in ('case','source','target','common','architecture','review-body','target-capture','empty-branch-scope','changed-branch-input'):
            f=Facts();f.family_source(kind='reviewed-branch-nonimpact')
            rows,row,want=observed(f);review=f.doc(row['source_equivalence'])
            if change=='case':review['case_id']='another-case'
            elif change=='source':review['execution_source']='0'*40
            elif change=='target':review['qualified_source']='0'*40
            elif change=='common':review['common_ref']='OTHER_COMMON'
            elif change=='architecture':review['architecture']='arm64'
            elif change=='review-body':
                f.replace(review['review'],{'CONTROL_ONLY':'not the Root-reviewed receipt'})
            elif change=='target-capture':
                target=f.doc(review['qualified_inputs']);target['files'][r.COMMON_SLOT]['sha256']='0'*64
                f.replace(review['qualified_inputs'],target);want['source_equivalence']['qualified_inputs']=identity(review['qualified_inputs'])
            elif change=='empty-branch-scope':review['unchanged_paths']=want['source_equivalence']['unchanged_paths']=[]
            else:
                actual=f.doc(review['actual_inputs']);actual['files'][r.COMMON_SLOT]['sha256']='0'*64
                f.replace(review['actual_inputs'],actual);want['source_equivalence']['actual_inputs']=identity(review['actual_inputs'])
                target=f.doc(review['qualified_inputs'])['files']
                changed=sorted(path for path in set(actual['files'])|set(target) if actual['files'].get(path)!=target.get(path))
                review['changed_paths']=want['source_equivalence']['changed_paths']=changed
            save_review(f,rows,row,want,review)
            with self.subTest(change=change),self.assertRaises(c.Unproved):qualify(f)


if __name__=='__main__':unittest.main()
