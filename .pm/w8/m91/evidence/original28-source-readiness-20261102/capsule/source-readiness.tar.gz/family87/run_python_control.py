"""Journal before ONE of four exact public tiny Python host-control snippets.
No caller-selected general command/module/file, original28 or native program.
"""
import hashlib,json,os,sys
from pathlib import Path
from process_identity import API,same

def main():
    if len(sys.argv)!=4:raise RuntimeError('fixed own Python control arguments required')
    root=Path(sys.argv[1]).resolve(strict=True);origin=json.loads(sys.argv[2]);code=sys.argv[3]
    allowed=json.loads((Path(__file__).parent/'TINY-PYTHON-CONTROLS.json').read_text())
    if allowed.get(hashlib.sha256(code.encode()).hexdigest())!=code:raise RuntimeError('unreviewed Python control source')
    api=API();info=api.bsd(os.getpid());parent=api.bsd(os.getppid())
    if not same(parent,origin) or not info or info['ppid']!=origin['pid'] or info['pgid']!=info['pid'] or info['uid']!=os.getuid():
        raise RuntimeError('exact own child birth/group unavailable')
    ledger=root/'groups.jsonl'
    if ledger.is_symlink() or not ledger.is_file():raise RuntimeError('own group ledger unavailable')
    with ledger.open('a') as stream:
        stream.write(json.dumps({'origin':origin,'group':info},sort_keys=True)+'\n');stream.flush();os.fsync(stream.fileno())
    # Preserve the exact old -c program bytes and ordinary __main__/argv context.
    sys.argv=['-c'];namespace={'__name__':'__main__','__builtins__':__builtins__}
    exec(compile(code,'<string>','exec'),namespace,namespace)

if __name__=='__main__':main()
