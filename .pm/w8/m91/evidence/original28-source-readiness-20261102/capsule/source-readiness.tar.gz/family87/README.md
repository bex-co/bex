# Per-case actual family-source follow-on

Prepared source only; no tests, generated source imports, network, runtime, Go, Docker, auth, repository or PM mutation ran. V6's full81PASS and three expected-red controls, all previous failures and source bytes remain unchanged at the paths/hashes in `PRESERVED-V6-PASS.json`.

`V6-SOURCE-DELTA.diff` adds exact per-case family execution source and reviewed proof/custody binding. Different sources require a case-specific reviewed equivalence record. Full captured-input equality handles PM-only changes; exact reviewed source-diff plus unchanged selected-branch inputs handles accepted dated nonimpact. Neither old executions nor source labels are rewritten as current. `SCHEMA.md` explains the authority boundary; the synthetic example is not a real contract/catalog.

Only readiness.py and its invented qualification fixture change; test_family_sources.py adds six methods. The five existing D3 source overlays otherwise remain exact. Existing utilities, historical V11 five-role/two-platform approval, current AMD64 scope, actual original28 programs/data/commands/HTTP/Free/once/ownership boundaries and null contract stay unchanged.

The proposed full host suite becomes87 unique methods, with the same three counterfactuals and same96MiB own allocation/8GiB physical floor+128MiB margin/512MiB combined-own-RSS caps. `CONTROLLER-DELTA.diff` contains only full count81→87 and necessary own-root bindings; no new program or resource command is introduced. Nothing has executed. Root must review exact source/schema/controls/manifest and serialize any eventual test invocation.

Actual family/catalog authority, inventory-critical/adoption handling, signed deployed Ready, Free/auth and hosted28 remain open. No new ARM/runtime/publisher gate or optional exporter execution is added.
