"""Selected metadata of exact owned Darwin groups; no argv/env or global census.

Layouts/constants are from the retained local Apple SDK proc_info.h/libproc.h
references. No kernel query or CDLL load occurs on module import.
"""
import ctypes,errno,os

class BSD(ctypes.Structure):
    _fields_=[(name,ctypes.c_uint32) for name in ('flags','status','xstatus','pid','ppid','uid','gid','ruid','rgid','svuid','svgid','reserved')]+[
        ('comm',ctypes.c_char*16),('name',ctypes.c_char*32)]+[
        (name,ctypes.c_uint32) for name in ('nfiles','pgid','jobc','tdev','tpgid')]+[
        ('nice',ctypes.c_int32),('start_sec',ctypes.c_uint64),('start_usec',ctypes.c_uint64)]

class Task(ctypes.Structure):
    _fields_=[(name,ctypes.c_uint64) for name in ('virtual','resident','total_user','total_system','threads_user','threads_system')]+[
        (name,ctypes.c_int32) for name in ('policy','faults','pageins','cow_faults','sent','received','mach','unix','csw','threads','running','priority')]

class API:
    def __init__(self):
        if os.uname().sysname!='Darwin':raise RuntimeError('exact Darwin host required')
        if ctypes.sizeof(BSD)!=136 or ctypes.sizeof(Task)!=96:raise RuntimeError('Apple SDK process layout mismatch')
        self.lib=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True)
        self.lib.proc_pidinfo.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_uint64,ctypes.c_void_p,ctypes.c_int]
        self.lib.proc_pidinfo.restype=ctypes.c_int
        self.lib.proc_listpids.argtypes=[ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_int]
        self.lib.proc_listpids.restype=ctypes.c_int
    def bsd(self,pid):
        value=BSD();ctypes.set_errno(0)
        count=self.lib.proc_pidinfo(pid,3,0,ctypes.byref(value),ctypes.sizeof(value))
        if count==0 and ctypes.get_errno() in (0,errno.ESRCH):return None
        if count!=ctypes.sizeof(value):raise RuntimeError('selected process identity unavailable')
        return {'pid':value.pid,'ppid':value.ppid,'pgid':value.pgid,'uid':value.uid,
                'birth':[value.start_sec,value.start_usec],'status':value.status}
    def resident(self,pid):
        value=Task();ctypes.set_errno(0)
        count=self.lib.proc_pidinfo(pid,4,0,ctypes.byref(value),ctypes.sizeof(value))
        if count==ctypes.sizeof(value):return value.resident
        identity=self.bsd(pid)
        if identity is None or identity['status']==5:return 0  # vanished/zombie
        raise RuntimeError('selected owned process RSS unavailable')
    def members(self,pgid):
        # Only this known owned group, never PROC_ALL_PIDS or a process census.
        buffer=(ctypes.c_int*256)();ctypes.set_errno(0)
        count=self.lib.proc_listpids(2,pgid,buffer,ctypes.sizeof(buffer))
        if count<0 or count>=ctypes.sizeof(buffer) or count%ctypes.sizeof(ctypes.c_int):raise RuntimeError('owned group membership bound')
        return [pid for pid in buffer[:count//ctypes.sizeof(ctypes.c_int)] if pid>0]

def same(actual,expected):
    return actual is not None and all(actual.get(key)==expected[key] for key in ('pid','pgid','uid','birth'))
