"""Invented host controls only: no actual supplier/adoption/Ready authority."""
import copy,json,unittest
from unittest.mock import patch
import core as c
import proof_binding as p
import readiness as r
import known_go_slot as slot
from qualification_fixtures import Facts
import test_v2_adoption as v2


def map_line(mapping):
    return ('var nativeRuntimeArtifacts = map[string]string{\n'+''.join(
        '\t'+json.dumps(key)+': '+json.dumps(value)+',\n' for key,value in sorted(mapping.items()))+'}\n').encode()


class D3QualificationControls(unittest.TestCase):
    def test_AMD_current_utilities_and_families_keep_both_historical_children_and_five_roles(self):
        f=Facts();result=r.qualification(f.entry,f.contract,f.docs.__getitem__)
        self.assertEqual({row['architecture'] for row in f.contract['utility_cases']},{'amd64'})
        self.assertEqual({row['architecture'] for row in f.contract['family_cases']},{'amd64'})
        receipt=f.doc(f.entry['v11_receipt'])
        self.assertEqual(set(receipt['platforms']),{'amd64','arm64'})
        self.assertEqual({(row['kind'],row['architecture']) for row in receipt['signed_payloads']},
            {('image-signature',None),('sbom','amd64'),('sbom','arm64'),('vulnerability','amd64'),('vulnerability','arm64')})
        self.assertEqual(result['image_generator_source'],f.contract['roles']['generator'])
        self.assertEqual(result['qualified_baseline_source'],f.contract['roles']['qualified_source'])
        self.assertNotEqual(result['image_generator_source'],result['qualified_baseline_source'])

    def test_current_ARM_rows_cannot_replace_AMD_even_if_catalog_and_results_agree(self):
        for target in ('utilities','families'):
            f=Facts();catalog=f.contract['utility_cases' if target=='utilities' else 'family_cases']
            catalog[0]['architecture']='arm64';rows=f.doc(f.entry[target]);rows['rows'][0]['architecture']='arm64'
            f.replace(f.entry[target],rows)
            with self.subTest(target=target),self.assertRaises(c.Unproved):r.qualification(f.entry,f.contract,f.docs.__getitem__)

    def test_historical_ARM_child_or_either_ARM_signed_role_remains_mandatory(self):
        for missing in ('child','sbom','vulnerability'):
            f=Facts();receipt=f.doc(f.entry['v11_receipt'])
            if missing=='child':receipt['platforms'].pop('arm64')
            else:
                receipt['signed_payloads']=[row for row in receipt['signed_payloads'] if (row['kind'],row['architecture'])!=(missing,'arm64')]
            f.replace(f.entry['v11_receipt'],receipt)
            with self.subTest(missing=missing),self.assertRaises(c.Unproved):r.qualification(f.entry,f.contract,f.docs.__getitem__)

    def test_qualified_source_is_explicit_and_cannot_overwrite_historical_generator(self):
        for change in ('missing-qualified','rewrite-generator'):
            f=Facts()
            if change=='missing-qualified':f.contract['roles'].pop('qualified_source')
            else:f.contract['roles']['generator']=f.contract['roles']['qualified_source']
            with self.subTest(change=change),self.assertRaises(c.Unproved):r.qualification(f.entry,f.contract,f.docs.__getitem__)

    def test_donor_membership_is_separate_from_generated_final_image_refs(self):
        f=Facts();mapping=copy.deepcopy(r.APPROVED_RUNTIME_ARTIFACTS)
        f.contract['runtime_artifacts']=mapping;f.entry['runtime_artifacts']=dict(mapping)
        result=r.qualification(f.entry,f.contract,f.docs.__getitem__)
        self.assertEqual(result['runtime_artifacts'],mapping)
        self.assertTrue(set(mapping.values()).isdisjoint(result['adoptable_refs']))
        for change in ('partial','extra','wrong-value','different-upstream','entry-disagrees'):
            contract=copy.deepcopy(f.contract);entry=copy.deepcopy(f.entry);key=next(iter(mapping))
            if change=='partial':contract['runtime_artifacts'].pop(key)
            elif change=='extra':contract['runtime_artifacts']['node:99@sha256:'+'0'*64]=mapping[key]
            elif change=='wrong-value':contract['runtime_artifacts'][key]='ghcr.io/bex-co/bex-cnb-run@sha256:'+'0'*64
            elif change=='different-upstream':contract['runtime_artifacts'][key.replace('node:','node:0',1)]=contract['runtime_artifacts'].pop(key)
            else:entry['runtime_artifacts']={}
            if change!='entry-disagrees':entry['runtime_artifacts']=dict(contract['runtime_artifacts'])
            with self.subTest(change=change),self.assertRaises(c.Unproved):r.reviewed_runtime_artifacts(entry,contract)


class RuntimeMapScannerControls(unittest.TestCase):
    def test_actual_empty_and_gofmt_aligned_literal_map_use_precise_offsets(self):
        for body,mapping in [(b'var nativeRuntimeArtifacts = map[string]string{}\n',{}),
                             (map_line(r.APPROVED_RUNTIME_ARTIFACTS),r.APPROVED_RUNTIME_ARTIFACTS)]:
            raw=b'package build\n'+body+b'func keep() {}\n';parsed=slot.runtime_artifacts(raw)
            self.assertEqual(parsed['mapping'],mapping);self.assertEqual(raw[parsed['start']:parsed['end']],body)
        aligned=map_line(r.APPROVED_RUNTIME_ARTIFACTS).replace(b': ',b':     ')
        self.assertEqual(slot.runtime_artifacts(aligned)['mapping'],r.APPROVED_RUNTIME_ARTIFACTS)

    def test_comments_literals_and_nested_decoys_are_opaque_not_actual_slots(self):
        body=map_line(r.APPROVED_RUNTIME_ARTIFACTS)
        decoys=[b'// '+body.splitlines()[0]+b'\n',b'/*\n'+body+b'*/\n',
                b'var documentation = `'+body+b'`\n',b'var documentation = '+json.dumps(body.decode()).encode()+b'\n',
                b'func nested() { '+body+b'}\n']
        for decoy in decoys:
            with self.subTest(decoy=decoy[:40]):
                with self.assertRaises(c.Unproved):slot.runtime_artifacts(b'package build\n'+decoy)
                actual=slot.runtime_artifacts(b'package build\n'+decoy+b'var nativeRuntimeArtifacts = map[string]string{}\n')
                self.assertEqual(actual['mapping'],{})

    def test_duplicate_grouped_multiname_calls_comments_and_nonliteral_expressions_refuse(self):
        body=map_line(r.APPROVED_RUNTIME_ARTIFACTS);first=body.splitlines(keepends=True)[1]
        bad=[body+body,b'var (\n nativeRuntimeArtifacts = map[string]string{}\n)\n',
             b'var other, nativeRuntimeArtifacts = makeMaps()\n',
             b'var nativeRuntimeArtifacts = makeMap()\n',body.replace(b'{\n',b'{\n// hidden\n',1),
             body.replace(first,first+first,1),body.replace(first,first.replace(b'"',b'`'),1),
             body.replace(b'}\n',b'}; mutate()\n',1),body.replace(first,first.replace(b': ',b': lookup() + ',1),1)]
        for raw in bad:
            with self.subTest(raw=raw[:70]),self.assertRaises(c.Unproved):slot.runtime_artifacts(b'package build\n'+raw)


class InitialRuntimeMapAdoptionControls(unittest.TestCase):
    def fixture(self):
        contract,qualified,entry,docs,oldgit,before,after=v2.ClosedAdoptionControls().initial()
        empty=b'var nativeRuntimeArtifacts = map[string]string{}\n';full=map_line(r.APPROVED_RUNTIME_ARTIFACTS)
        before+=empty;after+=full;path=r.COMMON_SLOT
        before_ref=contract['pin_only_deltas'][0]['before'];docs[before_ref['path']]=before
        before_ref.update(bytes=len(before),sha256=c.sha(before))
        identity={'bytes':len(before),'sha256':c.sha(before)}
        qualified['qualification_source'][path]=identity;qualified['critical_source'][path]=dict(identity)
        qualified['runtime_artifacts']=dict(r.APPROVED_RUNTIME_ARTIFACTS)
        contract['critical_files'][path].update(bytes=len(after),sha256=c.sha(after))
        contract['pin_only_deltas'][0]['edits'].append({'kind':'native-runtime-artifacts-initializer','before':empty.decode(),'after':full.decode()})
        contract['pins'] += [{'kind':'native-runtime-artifact','path':path,'upstream':key,'qualified_ref':value,'literal':json.dumps(value)}
                            for key,value in r.APPROVED_RUNTIME_ARTIFACTS.items()]
        actual=[after]
        def git(action,left,right):
            if action=='ancestor':return True
            if action=='changes':return [{'status':'M','path':path}]
            return (before,'100644','e'*40) if left==qualified['qualified_baseline_source'] else (actual[0],'100644','f'*40)
        return contract,qualified,entry,docs,git,before,actual

    def test_common_and_only_exact_five_pair_empty_map_initializer_admit_source_only(self):
        contract,qualified,entry,docs,git,before,actual=self.fixture()
        with patch.object(p,'bind_signature',return_value={}):result=r.adoption(contract,entry,qualified,docs.__getitem__,git)
        self.assertEqual(result['changed_critical_paths'],[r.COMMON_SLOT])
        self.assertIn(b'var nativeRuntimeArtifacts = map[string]string{}\n',before)
        self.assertEqual(slot.runtime_artifacts(actual[0])['mapping'],r.APPROVED_RUNTIME_ARTIFACTS)

    def test_wrong_pair_partial_duplicate_pin_or_unrelated_source_edit_never_admits(self):
        for change in ('wrong-value','partial-map','duplicate-pin','missing-pin','extra-code','extra-comment','wrong-path','generic-donor-role'):
            contract,qualified,entry,docs,git,before,actual=self.fixture();edit=contract['pin_only_deltas'][0]['edits'][1]
            key,value=next(iter(r.APPROVED_RUNTIME_ARTIFACTS.items()))
            if change=='wrong-value':edit['after']=edit['after'].replace(value,'ghcr.io/bex-co/bex-cnb-run@sha256:'+'0'*64)
            elif change=='partial-map':edit['after']=map_line({k:v for k,v in r.APPROVED_RUNTIME_ARTIFACTS.items() if k!=key}).decode()
            elif change=='duplicate-pin':contract['pins'][-1]=dict(contract['pins'][-2])
            elif change=='missing-pin':contract['pins'].pop()
            elif change in ('extra-code','extra-comment'):
                actual[0]+=b'func extra() {}\n' if change=='extra-code' else b'// unrelated edit\n'
                contract['critical_files'][r.COMMON_SLOT].update(bytes=len(actual[0]),sha256=c.sha(actual[0]))
            elif change=='wrong-path':contract['pins'][-1]['path']='lego/operator/internal/build/other.go'
            else:contract['pins'][-1].pop('kind')
            with self.subTest(change=change),patch.object(p,'bind_signature',return_value={}),self.assertRaises(c.Unproved):
                r.adoption(contract,entry,qualified,docs.__getitem__,git)

    def test_map_can_never_be_smuggled_through_generic_immutable_ref_edit(self):
        contract,qualified,entry,docs,git,before,actual=self.fixture()
        edit=contract['pin_only_deltas'][0]['edits'][1];edit['kind']='immutable-ref'
        with self.assertRaises(c.Unproved):r.adoption(contract,entry,qualified,docs.__getitem__,git)


if __name__=='__main__':unittest.main()
