# Original28 D3 readiness source proposal

This is an unexecuted private source proposal. No repository or PM files were changed, and no test, checker import, original program, client, network, Go, Docker, cluster or auth action ran. The retained real `ADOPTION-CONTRACT.json` remains `null`.

The patch separates historical image evidence from current production checks. The retained0941 V11 image still requires both architecture children and the same five signed roles. Current utility and family rows accept AMD64 only. The historical image generator stays f071, and the producer/verifier stays1feba; a separately explicit `qualified_source` binds the later closed adoption baseline. Root admitted the actual complete dc08 AMD64 utility content (run41428447253/job125221453132/artifact13133128419); that is content authority, not a filled adoption contract or proof of absent families.

The only new Go transformation populates the actual initially empty, unique top-level `nativeRuntimeArtifacts` literal map. It permits exactly the five retained reviewed same-version Node donor pairs, including exact14.21.2. It preserves every other file byte, rejects comment/literal decoys and nonliteral or duplicate declarations, and keeps donor map pin roles separate from common/generated final-image refs. The fixed list is a membership ceiling for retained supplier subjects. It grants no common integration, family, production or live readiness authority.

`SOURCE.diff` and `SOURCE-MANIFEST.json` cover four changed inherited files and one new synthetic host-control file. `PARENT-SOURCE-MANIFEST.json` binds all241 inherited source/data files without copying their bodies. All original28 programs, data, commands, HTTP assertions, once-only/user/ownership boundaries, Free and Ready guards remain inherited and unchanged. No raw supplier or utility report bodies are duplicated.

`HOST-CONTROLS-PLAN.json` proposes81 expected host tests plus three meaningful counterfactuals using Root's existing qualified venv. Nothing has run. The plan retains an8GiB physical floor,128MiB abort margin,16MiB total added disk and512MiB combined own RSS cap. Fresh capacity, source/interpreter binding and Root review are required before execution. The optional exporter remains unexecuted and is not an acceptance gate.

Actual family catalog proof, inventory-critical delta treatment, supported Node map-miss handling, adoption, signed live Ready, Free/auth and the hosted28 outcome remain open. Original failure histories and historical two-platform image approval are preserved.
