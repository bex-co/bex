#!/usr/bin/env python3
"""Prepared bounded host-control controller. NO action without exact --execute.

No Git/repo writes, network, native program, client, Go, Docker, live adapter,
credential read or real contract. Only fixed fake-host tests and four tiny Python
process-control snippets may execute, under the reviewed Seatbelt profile.
"""
import hashlib,json,os,shutil,signal,stat,subprocess,sys,time
from pathlib import Path
from process_identity import API,same

R=Path(__file__).resolve().parent
E=R/'execution'
PARENT=Path('/private/tmp/bex-w8-original28-free-optional-coverage-source-20261102-gqtfa907/source')
PYTHON='/private/tmp/bex7-native-acceptance-novb586u/venv/bin/python'
CAP=96<<20;DISK_MARGIN=16<<20;FLOOR=8<<30;FREE_MARGIN=128<<20
RSS_CAP=512<<20;RSS_MARGIN=64<<20
WHOLE_SECONDS=300


def require(value,message):
    if not value:raise RuntimeError(message)

def digest(path):
    result=hashlib.sha256()
    with Path(path).open('rb') as stream:
        while body:=stream.read(65536):result.update(body)
    return result.hexdigest()

def regular(path,expected):
    path=Path(path);info=path.lstat()
    require(stat.S_ISREG(info.st_mode) and info.st_size==expected['bytes'] and oct(stat.S_IMODE(info.st_mode))==expected['mode']
            and digest(path)==expected['sha256'],'exact regular source/input differs: '+str(path))

def json_read(path):
    require(Path(path).lstat().st_size<=1<<20 and not Path(path).is_symlink(),'bounded regular metadata required')
    return json.loads(Path(path).read_bytes())

def put(name,value):
    target=E/name;raw=(json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
    require(len(raw)<=1<<20,'own receipt metadata bound')
    with target.open('wb') as stream:stream.write(raw)
    target.chmod(0o600)

def allocation():
    seen=set();total=0
    for path in [R,*R.rglob('*')]:
        try:info=path.lstat()
        except FileNotFoundError:continue  # exact own TemporaryDirectory cleanup
        require(stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode),'own-root symlink/special file refused')
        key=(info.st_dev,info.st_ino)
        if key not in seen:seen.add(key);total+=info.st_blocks*512
    return total

def physical_free():
    info=os.statvfs(R);return info.f_bavail*info.f_frsize


def execute(expected_manifest):
    # Frozen input checks precede any execution directory, child or test action.
    require(len(expected_manifest)==64 and all(x in '0123456789abcdef' for x in expected_manifest),'Root-bound manifest SHA required')
    require(digest(R/'MANIFEST.json')==expected_manifest,'Root-reviewed manifest differs')
    frozen=json_read(R/'MANIFEST.json');parent=json_read(R/'PARENT-SOURCE-MANIFEST.json')
    source=json_read(R/'SOURCE-MANIFEST.json');old=json_read(R/'PRESERVED-PROPOSAL.json')
    interpreter=json_read(R/'INTERPRETER.json')
    def input_check():
        for rel,row in frozen.items():regular(R/rel,row)
        require({str(p.relative_to(PARENT)) for p in PARENT.rglob('*') if p.is_file()}==set(parent),'closed retained parent source set differs')
        for rel,row in parent.items():regular(PARENT/rel,row)
        oldroot=Path(old['path']);require(digest(oldroot/'MANIFEST.json')==old['MANIFEST']['sha256'],'original sealed proposal changed')
        for rel,row in json_read(oldroot/'MANIFEST.json').items():regular(oldroot/rel,row)
        require((PARENT/'ADOPTION-CONTRACT.json').read_bytes().strip()==b'null','retained actual contract must stay null')
        require(interpreter['path']==PYTHON and os.readlink(PYTHON)==interpreter['symlink_target'],'qualified venv entry differs')
        require(str(Path(PYTHON).resolve(strict=True))==interpreter['resolved_binary']['path'],'qualified Python target differs')
        regular(interpreter['resolved_binary']['path'],interpreter['resolved_binary'])
        regular(interpreter['framework_launcher']['path'],interpreter['framework_launcher'])
    input_check()
    require(not E.exists() and not E.is_symlink(),'single fresh own execution only; no replay')
    required=FLOOR+FREE_MARGIN+max(0,CAP-allocation())
    require(physical_free()>=required,'fresh full remaining96MiB plus8GiB+128MiB does not fit')
    E.mkdir(mode=0o700);(E/'tmp').mkdir(mode=0o700);(E/'home').mkdir(mode=0o700)
    (E/'groups.jsonl').write_bytes(b'');(E/'groups.jsonl').chmod(0o600)
    api=API();started=time.monotonic();handlers={};cancel=[];groups={};origins={};processes=[];calls=[]
    peak_alloc=0;peak_rss=0;min_free=1<<63;failure=None;case_results=[];cleanup_errors=[]
    own_identity=api.bsd(os.getpid());require(own_identity and own_identity['uid']==os.getuid(),'own controller identity unavailable')

    def register(info,origin=None):
        require(isinstance(info,dict) and info['pid']==info['pgid'] and info['uid']==os.getuid()
                and type(info['pid']) is int and info['pid']>1 and len(info['birth'])==2,'exact newly owned group required')
        if origin is not None:
            require(same(origin,origins.get(origin['pid'])) and info['ppid']==origin['pid'] and info['birth']>=origin['birth'],
                    'child ledger does not bind exact suite birth')
        if info['pgid'] in groups:require(same(info,groups[info['pgid']]['identity']),'conflicting owned group birth')
        else:
            require(len(groups)<64,'owned Python group catalog bound')
            groups[info['pgid']]={'identity':info,'retired':False,'ever_observed_members':[]}

    def ledger():
        path=E/'groups.jsonl';require(not path.is_symlink() and path.stat().st_size<=128<<10,'own group journal bound')
        raw=path.read_bytes()
        # A single append may be in flight. Only complete lines are admitted.
        for line in raw.split(b'\n')[:-1]:
            row=json.loads(line);require(set(row)=={'origin','group'},'owned group journal shape')
            register(row['group'],row['origin'])

    def members(record):
        identity=record['identity'];pgid=identity['pgid'];current=api.bsd(pgid)
        require(current is None or same(current,identity),'owned group leader PID was reused; refuse signal')
        pids=api.members(pgid)
        if record['retired']:
            require(not pids,'retired group ID reused; refuse adoption/signal');return []
        result=[]
        for pid in pids:
            info=api.bsd(pid)
            if info is None:continue
            require(info['pgid']==pgid and info['uid']==identity['uid'] and info['birth']>=identity['birth'],
                    'foreign/reused member in exact owned session; refuse signal')
            result.append(info)
            if info not in record['ever_observed_members']:record['ever_observed_members'].append(info)
        if not result and current is None:record['retired']=True
        return result

    def observe():
        nonlocal peak_alloc,peak_rss,min_free
        ledger();own=allocation();free=physical_free();rss=api.resident(os.getpid());seen={os.getpid()}
        for record in groups.values():
            for row in members(record):
                if row['pid'] not in seen:seen.add(row['pid']);rss+=api.resident(row['pid'])
        peak_alloc=max(peak_alloc,own);peak_rss=max(peak_rss,rss);min_free=min(min_free,free)
        return own,free,rss

    def guard():
        require(not cancel,'controller cancelled by signal')
        require(time.monotonic()-started<=WHOLE_SECONDS,'whole host-control deadline')
        own,free,rss=observe()
        require(own<CAP-DISK_MARGIN,'own80MiB proactive disk stop before96MiB cap')
        require(free>FLOOR+FREE_MARGIN,'physical8GiB+128MiB proactive stop')
        require(rss<RSS_CAP-RSS_MARGIN,'combined own448MiB proactive RSS stop before512MiB cap')
        require(sum(p.stat().st_size for p in E.glob('*.stdout'))+sum(p.stat().st_size for p in E.glob('*.stderr'))<=2<<20,
                'aggregate own stdout/stderr bound')

    def stop_owned():
        # No process names, broad labels, external group IDs or global kill.
        try:ledger()
        except BaseException as error:cleanup_errors.append('journal:'+type(error).__name__+':'+str(error))
        for sig,seconds in ((signal.SIGTERM,2),(signal.SIGKILL,2)):
            for pgid,record in groups.items():
                try:
                    if members(record):os.killpg(pgid,sig)
                except ProcessLookupError:pass
                except BaseException as error:cleanup_errors.append('exact-group:'+type(error).__name__+':'+str(error))
            deadline=time.monotonic()+seconds
            while time.monotonic()<deadline:
                for process in processes:process.poll()
                if all(not members(record) for record in groups.values()):return
                time.sleep(.05)
        for process in processes:
            try:process.wait(timeout=.1)
            except subprocess.TimeoutExpired:pass
        if any(members(record) for record in groups.values()):cleanup_errors.append('owned groups remain')

    def run_case(mode,expected,timeout):
        guard();out=E/(mode+'.stdout');err=E/(mode+'.stderr')
        env={'PATH':'','HOME':str(E/'home'),'TMPDIR':str(E/'tmp'),'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1',
             'PYTHONHASHSEED':'0','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
        argv=['/usr/bin/sandbox-exec','-f',str(R/'sandbox.sb'),PYTHON,'-B',str(R/'run_host_controls.py'),mode,str(E)]
        before=time.monotonic();bound=None;process=None
        with out.open('xb') as stdout,err.open('xb') as stderr:
            process=subprocess.Popen(argv,cwd=E/'view',env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
            processes.append(process)
            identity=api.bsd(process.pid)
            require(identity is not None and identity['ppid']==os.getpid(),'new suite group birth unavailable')
            register(identity);origins[process.pid]=identity
            try:
                while process.poll() is None:
                    guard();require(time.monotonic()-before<=timeout,'host-control case deadline');time.sleep(.1)
            except BaseException as error:bound=type(error).__name__+':'+str(error)
            finally:stop_owned()
        try:guard()
        except BaseException as error:bound=bound or type(error).__name__+':'+str(error)
        row={'mode':mode,'argv':argv,'exit_code':process.returncode,'expected_exit_code':expected,'bound':bound,
             'seconds':round(time.monotonic()-before,3),'stdout':file_identity(out),'stderr':file_identity(err)}
        calls.append(row);put('CALLS.json',calls)
        require(not bound and process.returncode==expected and not cleanup_errors,'actual host-control case did not meet fixed outcome:'+mode)
        summary=json_read(E/(mode+'.summary.json'))
        if mode=='full':require(summary['testsRun']==81 and summary['successful'] and summary['skipped']==0,'full81 host-control success required')
        else:
            require(summary['testsRun']==1 and not summary['successful'] and summary['skipped']==0,'actual expected counterfactual red required')
            if mode=='old-d3':require(summary['errors']==1 and b'original both utility arches missing' in err.read_bytes(),'old-source refusal cause differs')
            else:require(summary['errors']==0 and summary['failures']>=1 and b'AssertionError' in err.read_bytes(),'targeted counterfactual assertion cause differs')
        case_results.append(summary);put('CASE-RESULTS.json',case_results)

    def file_identity(path):
        path=Path(path);return {'path':str(path.relative_to(E)),'bytes':path.stat().st_size,'sha256':digest(path)}

    try:
        for sig in (signal.SIGINT,signal.SIGTERM):handlers[sig]=signal.getsignal(sig);signal.signal(sig,lambda n,f:cancel.append(n))
        put('PREFLIGHT.json',{'physical_free':physical_free(),'remaining_full_cap_required':required,'own_allocated':allocation(),
                             'fit':True,'volatile_not_reserved':True,'counterfactuals_and_full_suite_unexecuted_at_preflight':True})
        view=E/'view';view.mkdir(mode=0o700)
        for rel,row in parent.items():
            target=view/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(PARENT/rel,target);target.chmod(int(row['mode'],8))
        for rel,row in source.items():
            target=view/rel;shutil.copyfile(R/'source'/rel,target);target.chmod(int(row['after']['mode'],8))
        proposed=(R/'source/readiness.py').read_bytes()
        run_case('full',0,180)
        mutants=[('old-d3',(PARENT/'readiness.py').read_bytes()),
                 ('role-mutant',proposed.replace(b"'qualified_baseline_source':roles['qualified_source']",b"'qualified_baseline_source':roles['generator']")),
                 ('donor-mutant',proposed.replace(b'(not mapping or mapping==APPROVED_RUNTIME_ARTIFACTS)',b'True'))]
        require(proposed.count(b"'qualified_baseline_source':roles['qualified_source']")==1
                and proposed.count(b'(not mapping or mapping==APPROVED_RUNTIME_ARTIFACTS)')==1,'fixed counterfactual source spans differ')
        for mode,mutant in mutants:
            require(mutant!=proposed,'counterfactual must change exact source bytes')
            (E/(mode+'.readiness.py')).write_bytes(mutant);(view/'readiness.py').write_bytes(mutant)
            try:run_case(mode,1,60)
            finally:(view/'readiness.py').write_bytes(proposed)
        require((view/'ADOPTION-CONTRACT.json').read_bytes().strip()==b'null','actual contract populated unexpectedly')
    except BaseException as error:failure=type(error).__name__+':'+str(error)
    finally:
        try:stop_owned()
        except BaseException as error:cleanup_errors.append('stop:'+type(error).__name__+':'+str(error))
        for sig,handler in handlers.items():signal.signal(sig,handler)
        try:input_check()
        except BaseException as error:failure=failure or 'post-input:'+type(error).__name__+':'+str(error)
        # Exact own disposable view only; original source, proposal, logs and
        # mutant copies stay unchanged. No other directory/cache is removed.
        removed=[]
        for name in ('view','tmp','home'):
            path=E/name
            if path.exists() and not path.is_symlink():shutil.rmtree(path);removed.append(name)
        try:observe()
        except BaseException as error:cleanup_errors.append('final-observe:'+type(error).__name__+':'+str(error))
        if cleanup_errors:failure=failure or 'cleanup incomplete'
        if peak_alloc>CAP or peak_rss>RSS_CAP or min_free<FLOOR:failure=failure or 'hard resource bound observed crossed'
        result={'PASS':failure is None and len(case_results)==4,'failure':failure,'cleanup_errors':cleanup_errors,'cases':case_results,
                'calls':calls,'groups':groups,'every_owned_group_absent':all(record['retired'] for record in groups.values()),
                'exact_own_removed_paths':removed,'handlers_restored':all(signal.getsignal(sig)==handler for sig,handler in handlers.items()),
                'peak_own_allocated_bytes':peak_alloc,'peak_combined_own_RSS_bytes':peak_rss,'minimum_physical_free_bytes':min_free,
                'seconds':round(time.monotonic()-started,3),'all_real_authority_still_absent':True,
                'scope':'Synthetic host controls only. No supplier/family/runtime/adoption/Ready/Free/auth/hosted approval.'}
        put('RESULT.json',result);print(json.dumps(result,sort_keys=True),flush=True)
    return 0 if result['PASS'] else 1

if __name__=='__main__':
    if len(sys.argv)==4 and sys.argv[1:3]==['--execute','--manifest-sha']:raise SystemExit(execute(sys.argv[3]))
    if sys.argv[1:]:raise SystemExit('Only --execute --manifest-sha ROOT_REVIEWED_SHA is supported')
    print('UNEXECUTED. Root must review MANIFEST.json, EXECUTION-PLAN.json, sandbox.sb and all controller source first.')
