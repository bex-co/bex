"""Fixed synthetic unittest entry point, plus exact own Python-group registration.

Only fake-I/O adapter journeys and null-contract refusal run. There is no live
adapter/main/native entry point or arbitrary command,
module, test selector, contract, credential, environment or resource input.
"""
import hashlib,json,os,resource,subprocess,sys,tempfile,unittest
from pathlib import Path
from process_identity import API

CASES={
 'full':None,
 'old-d3':'test_d3_readiness.D3QualificationControls.test_AMD_current_utilities_and_families_keep_both_historical_children_and_five_roles',
 'role-mutant':'test_d3_readiness.D3QualificationControls.test_AMD_current_utilities_and_families_keep_both_historical_children_and_five_roles',
 'donor-mutant':'test_d3_readiness.D3QualificationControls.test_donor_membership_is_separate_from_generated_final_image_refs',
}

def main():
    if len(sys.argv)!=3 or sys.argv[1] not in CASES:raise RuntimeError('fixed host-control case required')
    mode=sys.argv[1];root=Path(sys.argv[2]).resolve(strict=True);view=root/'view';ledger=root/'groups.jsonl'
    if view.is_symlink() or not view.is_dir() or not ledger.is_file() or ledger.is_symlink():raise RuntimeError('fixed own host-control view/ledger required')
    api=API();origin=api.bsd(os.getpid())
    if not origin or origin['pgid']!=origin['pid'] or origin['uid']!=os.getuid():raise RuntimeError('own suite session required')
    original=subprocess.Popen;python=Path(sys.executable).resolve(strict=True)
    allowed=json.loads((Path(__file__).parent/'TINY-PYTHON-CONTROLS.json').read_text())
    def tracked(argv,*args,**kwargs):
        if args or not isinstance(argv,list) or len(argv)!=3 or Path(argv[0]).resolve(strict=True)!=python or argv[1]!='-c' or kwargs.get('start_new_session') is not True:
            raise RuntimeError('only exact tiny owned Python groups are allowed')
        digest=hashlib.sha256(argv[2].encode()).hexdigest()
        if allowed.get(digest)!=argv[2]:raise RuntimeError('tiny Python control source not in closed original catalog')
        # The fixed wrapper journals its own birth before executing the exact
        # original four host-test snippets. This avoids a fast-child exit race.
        actual=[sys.executable,'-B',str(Path(__file__).parent/'run_python_control.py'),str(root),json.dumps(origin),argv[2]]
        return original(actual,**kwargs)
    subprocess.Popen=tracked
    original_temporary=tempfile.TemporaryDirectory
    def own_temporary(*args,**kwargs):
        # Preserve exact fixture data/oracles; only place this one existing
        # explicit /private/tmp large synthetic fixture inside measured ownTMP.
        if kwargs.get('prefix')=='bex-w8-original28-v2-fake-evidence-' and kwargs.get('dir')=='/private/tmp':
            kwargs=dict(kwargs,dir=str(root/'tmp'))
        return original_temporary(*args,**kwargs)
    tempfile.TemporaryDirectory=own_temporary
    resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_FSIZE,(32<<20,32<<20))
    resource.setrlimit(resource.RLIMIT_CPU,(60,60))
    sys.path.insert(0,str(view));os.chdir(view)
    loader=unittest.TestLoader();suite=loader.discover(str(view),pattern='test_*.py') if mode=='full' else loader.loadTestsFromName(CASES[mode])
    expected=81 if mode=='full' else 1
    if suite.countTestCases()!=expected:raise RuntimeError('closed expected host-control definition count differs')
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    report={'mode':mode,'testsRun':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),
            'successful':result.wasSuccessful(),'expected_definition_count':expected,'actual_adapter_or_native_program_called':False}
    (root/(mode+'.summary.json')).write_text(json.dumps(report,sort_keys=True)+'\n')
    return 0 if result.wasSuccessful() else 1

if __name__=='__main__':raise SystemExit(main())
