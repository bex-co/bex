"""Finite in-process audit batch over retained bodies. This is not a target/runtime runner."""
from pathlib import Path
import contextlib,hashlib,json,os,runpy,sys,traceback
HERE=Path(__file__).resolve().parent
STEPS=[('node22-node26','node_cases.py','REPORT.json'),('modern-five','modern.py','REVIEW.json'),('legacy37-amd','legacy.py','REVIEW.json'),('donor14213','donor14213.py','AUDIT.json'),('exact14212-primary','exact14212.py','AUDIT.json')]

def identity(path):
 path=Path(path);body=path.read_bytes();return {'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
def dump_new(path,data):
 with Path(path).open('x',encoding='utf-8') as stream:json.dump(data,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())

def main():
 output=Path(sys.argv[1])
 if not output.is_dir() or any(output.iterdir()):raise RuntimeError('fresh empty owned audit output required')
 rows=[]
 for label,script,report in STEPS:
  directory=output/label;directory.mkdir(mode=0o700)
  stdout=output/(label+'.stdout');stderr=output/(label+'.stderr')
  original_argv=list(sys.argv);original_path=list(sys.path);error=None
  try:
   # A fresh argv is required: runpy inherits its caller otherwise.
   sys.argv=[str(HERE/script),str(directory)]
   with stdout.open('x',encoding='utf-8') as out,stderr.open('x',encoding='utf-8') as err,contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
    runpy.run_path(str(HERE/script),run_name='__main__')
   json.loads(stdout.read_bytes())
  except BaseException as caught:
   error=type(caught).__name__+': '+str(caught)
  finally:
   sys.argv=original_argv;sys.path[:]=original_path
   row={'step':label,'kind':'IN_PROCESS_RETAINED_BODY_AUDIT_NOT_AN_OS_PROCESS','source':str(HERE/script),'source_identity':identity(HERE/script),'error':error,'stdout':{'path':str(stdout),**identity(stdout)} if stdout.is_file() else None,'stderr':{'path':str(stderr),**identity(stderr)} if stderr.is_file() else None}
   if (directory/report).is_file():row['report']={'path':str(directory/report),**identity(directory/report)}
   # Persist the exact completed/refused substep before any later posthash.
   dump_new(output/(label+'-STEP.json'),row);rows.append(row)
  if error is not None:raise RuntimeError('retained audit refused: '+label+': '+error)
 if len(rows)!=5:raise RuntimeError('incomplete fixed audit batch')
 observed={'scope':'ONE_OFFLINE_CONTENT_AUDIT_OF_TEN_DATED_AMD_CASES_NO_RUNTIME_OR_CI_REPLAY','pass':True,'cases':10,'steps':rows,'actual_catalog':None,'actual_contract':None,'target_runtime_commands_executed':False}
 dump_new(output/'BATCH-CONTENT-RESULT.json',observed)
 print(json.dumps(observed,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
