"""Inert bounded outer process controller. No execution on import."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,signal,stat,subprocess,sys,time
from reviewed_reaper import stop_group
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
PYTHON='/opt/homebrew/bin/python3.14'
FLOOR,MARGIN,OUTPUT_CAP,WHOLE,CLEANUP_RESERVE=8<<30,128<<20,8<<20,120,15

def sha(path):
 value=hashlib.sha256()
 with Path(path).open('rb') as stream:
  while body:=stream.read(1<<20):value.update(body)
 return value.hexdigest()
def identity(path):
 path=Path(path);info=path.lstat()
 if not stat.S_ISREG(info.st_mode) or path.is_symlink():raise RuntimeError('nonregular input: '+str(path))
 return {'bytes':info.st_size,'sha256':sha(path)}
def json_bytes(data):return (json.dumps(data,indent=2)+'\n').encode('utf-8')
def dump_new(path,data):
 with Path(path).open('xb') as stream:stream.write(json_bytes(data));stream.flush();os.fsync(stream.fileno())
def own_bytes(root):
 total=0
 def missing_only(error):
  if not isinstance(error,FileNotFoundError):raise error
 for base,dirs,files in os.walk(root,onerror=missing_only,followlinks=False):
  for name in files:
   try:info=(Path(base)/name).lstat()
   except FileNotFoundError:continue
   if stat.S_ISREG(info.st_mode):total+=info.st_size
 return total

def main():
 started=time.monotonic();preflight_minimum=shutil.disk_usage(ROOT).free
 if sys.flags.optimize or sys.version_info[:2]!=(3,14):raise RuntimeError('ordinary Python3.14 required')
 def preflight_observe():
  nonlocal preflight_minimum
  free=shutil.disk_usage(ROOT).free;preflight_minimum=min(preflight_minimum,free)
  if free<FLOOR+MARGIN+OUTPUT_CAP:raise RuntimeError('preflight physical floor plus margin and output allowance')
  if time.monotonic()-started>=WHOLE-CLEANUP_RESERVE:raise RuntimeError('preflight whole120s cleanup reserve')
 preflight_observe()
 plan=json.loads((ROOT/'PLAN.json').read_bytes());run=Path(plan['run_root'])
 if str(Path(PYTHON).resolve())!=plan['python']['resolved'] or identity(Path(PYTHON).resolve())!=plan['python']['identity']:raise RuntimeError('Python interpreter changed')
 if run.exists():raise RuntimeError('new outputs refuse overwrite')
 expected=json.loads((ROOT/'SOURCE-MANIFEST.json').read_bytes())
 if {str(p.relative_to(HERE)):identity(p) for p in HERE.iterdir() if p.is_file()}!=expected:raise RuntimeError('frozen source set/bytes differ')
 inputs=json.loads((ROOT/'READONLY-INPUTS.json').read_bytes())
 observed_inputs={}
 for name in inputs:
  observed_inputs[name]=identity(name);preflight_observe()
 if observed_inputs!=inputs:raise RuntimeError('retained input preimage differs')
 if shutil.disk_usage(ROOT).free<FLOOR+MARGIN+OUTPUT_CAP:raise RuntimeError('physical floor plus margin and output allowance')
 run.mkdir(mode=0o700);e=run/'evidence';e.mkdir(mode=0o700);tmp=run/'tmp';tmp.mkdir(mode=0o700)
 profile=run/'offline.sb';profile.write_text('(version 1) (allow default) (deny network*) (deny file-write*) (allow file-write* (subpath '+json.dumps(str(run))+')) (allow file-write* (literal "/dev/null"))\n')
 env={'PATH':'/opt/homebrew/bin:/usr/bin:/bin','HOME':str(tmp),'TMPDIR':str(tmp),'PYTHONPATH':str(HERE),'PYTHONDONTWRITEBYTECODE':'1','PYTHONPYCACHEPREFIX':str(tmp/'pycache'),'GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null','GIT_CONFIG_NOSYSTEM':'1','GIT_OPTIONAL_LOCKS':'0','GIT_TERMINAL_PROMPT':'0'}
 cancelled=[];handlers={};groups={};results=[];failure=None;minimum=min(preflight_minimum,shutil.disk_usage(run).free);peak=own_bytes(run);after=None;late=None
 def observe(reserve=0):
  nonlocal minimum,peak
  free=shutil.disk_usage(run).free;size=own_bytes(run);elapsed=time.monotonic()-started
  minimum=min(minimum,free);peak=max(peak,size)
  if cancelled:return 'cancelled'
  if free<FLOOR+MARGIN:return 'physical floor plus margin'
  if size>OUTPUT_CAP:return 'owned output8MiB'
  if elapsed>=WHOLE-reserve:return 'whole120s cleanup reserve' if reserve else 'whole120s'
  return None
 try:
  for number in (signal.SIGINT,signal.SIGTERM):
   handlers[number]=signal.getsignal(number);signal.signal(number,lambda sig,frame:cancelled.append(sig))
  commands=[('adapter-controls',[PYTHON,'-B','-m','unittest','-v','test_adapter']),('dated10-audit',[PYTHON,'-B',str(HERE/'audit_dated10.py'),str(e/'audit')])]
  for label,argv in commands:
   if groups:raise RuntimeError('prior process-group absence unproved')
   reason=observe(CLEANUP_RESERVE)
   if reason:raise RuntimeError(reason+' before spawn')
   out=e/(label+'.stdout');err=e/(label+'.stderr');process=None;absent=False;bound=None;process_failure=None
   try:
    if label=='dated10-audit':(e/'audit').mkdir(mode=0o700)
    with out.open('xb') as stdout,err.open('xb') as stderr:
     process=subprocess.Popen(['/usr/bin/sandbox-exec','-f',str(profile),*argv],cwd=HERE,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
     groups[process.pid]=process
     dump_new(e/(label+'-PROCESS.json'),{'label':label,'command':process.args,'auditor_command':argv,'pid':process.pid,'pgid':process.pid,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
     while process.poll() is None:
      bound=observe(CLEANUP_RESERVE)
      if bound:break
      time.sleep(.1)
   except BaseException as error:process_failure=type(error).__name__+': '+str(error)
   finally:
    if process is not None:
     try:
      absent=stop_group(process)
      if absent:groups.pop(process.pid,None)
     except BaseException as error:process_failure=process_failure or 'cleanup: '+type(error).__name__+': '+str(error)
    bound=bound or observe()
    row={'label':label,'command':process.args if process else None,'auditor_command':argv,'exit_code':process.returncode if process else None,'complete':process is not None and process.returncode==0 and absent and bound is None and process_failure is None,'bound':bound,'signal':cancelled[-1] if cancelled else None,'direct_child_reaped':process is not None and process.returncode is not None,'process_group_absent':absent,'pid':process.pid if process else None,'pgid':process.pid if process else None,'pending_pgids':sorted(groups),'error':process_failure,'stdout':{'path':str(out),**identity(out)} if out.is_file() else None,'stderr':{'path':str(err),**identity(err)} if err.is_file() else None}
    dump_new(e/(label+'-RESULT.json'),row);results.append(row)
   if not row['complete']:raise RuntimeError('incomplete actual process: '+label)
 except BaseException as error:failure=type(error).__name__+': '+str(error)
 finally:
  for pgid,process in list(groups.items()):
   try:
    if stop_group(process):groups.pop(pgid,None)
   except BaseException as error:failure=failure or 'cleanup: '+type(error).__name__+': '+str(error)
  # Actual process receipts already exist even if posthash refuses or fails.
  try:
   after={name:identity(name) for name in inputs};dump_new(e/'INPUTS-AFTER.json',after)
   if after!=inputs:failure=failure or 'retained input changed'
   private_after={str(p.relative_to(HERE)):identity(p) for p in HERE.iterdir() if p.is_file()}
   dump_new(e/'SOURCE-AFTER.json',private_after)
   if private_after!=expected:failure=failure or 'frozen source changed'
  except BaseException as error:failure=failure or 'posthash: '+type(error).__name__+': '+str(error)
  try:
   for number,handler in handlers.items():signal.signal(number,handler)
  except BaseException as error:failure=failure or 'handler restoration: '+type(error).__name__+': '+str(error)
  if not groups:
   try:shutil.rmtree(tmp)
   except BaseException as error:failure=failure or 'own TMP cleanup: '+type(error).__name__+': '+str(error)
  late=observe()
  complete=len(results)==2 and all(row['complete'] for row in results) and not groups and failure is None and late is None and after==inputs
  result={'complete':complete,'scope':'READONLY_OFFLINE_CONTENT_AUDIT_ONLY_NO_TARGET_REPLAY','results':results,'failure':failure,'late_bound':late,'cancelled':cancelled,'pending_pgids':sorted(groups),'input_bytes_unchanged':after==inputs,'own_TMP_removed':not tmp.exists(),'minimum_free_bytes':minimum,'peak_owned_output_bytes':peak,'elapsed_controller_seconds':time.monotonic()-started,'actual_catalog':None,'actual_contract':None}
  if own_bytes(run)+len(json_bytes(result))>OUTPUT_CAP:result.update(complete=False,late_bound=late or 'final receipt exceeds owned output8MiB')
  dump_new(e/'RESULT.json',result)
 print(json.dumps(result),flush=True)
 return 0 if result['complete'] else 1

if __name__=='__main__':raise SystemExit(main())
