"""Two fixed retained AMD Node outputs; inherited pure Node oracle block, never Node/Docker execution."""
from pathlib import Path
import hashlib,json,os,re,stat,subprocess,sys,types

HERE=Path(__file__).resolve().parent
DATA=json.loads((HERE/'node-inputs.json').read_bytes())
COMMON='ghcr.io/bex-co/bex-cnb-run@sha256:0941c204f87643c2faad308e72acdf584976e67d8fb980a0646c5ab662dcc5d0'
SOURCE='9bc6a5d10b3f479926180698d60a0cfdf238db9b'
FIX=Path('/private/tmp/bex-w8-current-predeploy-e6a-exports-20261102-sjzkvys_/source/lego/operator/internal/build/testdata/native-node-qualification')

def sha(b):return hashlib.sha256(b).hexdigest()
def identity(p):
 p=Path(p);info=p.lstat();assert stat.S_ISREG(info.st_mode) and not p.is_symlink()
 h=hashlib.sha256();n=0
 with p.open('rb') as stream:
  while body:=stream.read(1<<20):h.update(body);n+=len(body)
 return {'bytes':n,'sha256':h.hexdigest()}
def load(p):return json.loads(Path(p).read_bytes())
def write_new(path,data):
 with Path(path).open('x',encoding='utf-8') as stream:json.dump(data,stream,indent=2);stream.write('\n')

def verify_members(root):
 root=Path(root);entries=load(root/'MANIFEST.json')['files'];rows={x['path']:x for x in entries}
 assert len(rows)==len(entries)
 actual={str(p.relative_to(root)) for p in root.rglob('*') if not p.is_dir() or p.is_symlink()}
 assert actual==set(rows)|{'MANIFEST.json'}
 for name,row in rows.items():
  assert not Path(name).is_absolute() and '..' not in Path(name).parts
  assert identity(root/name)=={k:row[k] for k in ('bytes','sha256')},name
 return len(actual)

def validate_roles(inp,sc,receipt,expected,data,canonical,executed):
 assert inp['common_image']==COMMON and inp['producer']==inp['verification']=='1feba939b4697894e800ed0abb4f25a0bf415641'
 assert inp['generator_source']==SOURCE and inp['platform']=='linux/amd64'
 assert inp['selection']['profile']=='node' and inp['selection']['case']==data['case']
 assert inp['selection']['selector']=='^TestCommonNodeGeneratedImages$/^'+re.escape(data['case'])+'$' and inp['selection']['flag']=='BEX_NATIVE_TEST_NODE_PROFILE'
 assert inp['baseline_status']=='current-complete' and inp['utility_baseline_source']=='e6a2386101a78d679f729b7ec0d251373c0aa678'
 assert inp['candidate_receipt_sha256']=='ac17d21d7e5a09c8ea41fece0333b8f613900c7b5f793e8bf2edcdb160e59426'
 assert sc['common']==COMMON and sc['platform']=='linux/amd64' and sc['owner']==sc['builder']==inp['owner']
 assert sc['node_source']==sc['node_runtime_artifact']==data['upstream']
 assert sc['runtime_artifact_mode']=='same-version-source-fallback' and sc['empty_runtime_artifact_map'] is True and sc['runtime_artifact_map'] is None and sc['test_only_network_overlay'] is False
 assert canonical==executed and sha(canonical)==sc['canonical_sha256']==sc['executed_sha256']==data['canonical_sha256']
 assert b'/usr/libexec/bex-native/build-node' not in canonical and b'RUN --network=default ' not in canonical
 assert ('\nFROM '+COMMON+'\n').encode() in canonical
 assert ('COPY --link --from='+data['upstream']+' /usr/local/ /usr/local/\n').encode() in canonical
 assert expected['node']==expected['node_env']==data['version'] and expected['node_donor']==data['upstream'] and expected['yarn']=='1.22.22' and expected['pnpm']=='10.34.7'
 assert receipt['case']==data['case'] and receipt['common_base']==COMMON and receipt['owner']==inp['owner'] and receipt['builder']==inp['owner']
 assert receipt['image_platform']=='linux/amd64' and receipt['network']=='none' and receipt['runtime_command_executed'] is True and receipt['test_prerequisite_overlay'] is False and receipt['static_artifacts_extracted'] is False
 assert re.fullmatch('sha256:[a-f0-9]{64}',receipt['image_config_id'])

def audit(data):
 R=Path(data['root']);A=R/'amd64/extracted/artifact';C=A/data['generated'];Q=C/'qa-output'
 members=verify_members(A);extraction=load(R/'amd64/extracted/extraction.json')
 assert extraction['complete'] is True and extraction['completed_members']==members==data['members']
 assert identity(A/'MANIFEST.json')['sha256']==extraction['manifest_sha256']
 archive=next(x for x in load(R/'artifact-listing.json')['artifacts'] if x['id']==data['artifact_id'])
 assert archive['workflow_run']['id']==data['run_id'] and archive['workflow_run']['head_sha']==SOURCE and archive['size_in_bytes']==extraction['zip_bytes'] and archive['digest']=='sha256:'+extraction['zip_sha256']
 job=next(x for x in load(R/'jobs.json')['jobs'] if x['id']==data['job_id'])
 assert job['head_sha']==SOURCE and job['run_id']==data['run_id'] and job['run_attempt']==1 and job['status']=='completed' and job['conclusion']=='success'
 steps={x['name']:x for x in job['steps']}
 for name in ('measure the selected family case without claiming full-family acceptance',"remove only this job's labeled resources, exact builder and credentials"):
  assert steps[name]['conclusion']=='success'
 inp=load(A/'inputs.json');sc=load(C/'source-custody.json');receipt=load(C/'receipt.json');expected=load(C/'expected-node.json')
 validate_roles(inp,sc,receipt,expected,data,(C/'Dockerfile.canonical').read_bytes(),(C/'Dockerfile').read_bytes())
 captured=load(A/'qualification-source.json');table=load(Path(data['source_table']))
 assert captured['source']==table['source']==SOURCE and len(captured['files'])==len(table['files'])==300
 assert {p:{'bytes':v['bytes'],'sha256':v['sha256'],'git_mode':v['mode']} for p,v in captured['files'].items()}==table['files']
 for name in ('addon.c','check.js','check.py','package.json'):assert identity(FIX/name)['sha256']==sc['fixture_sha256'][name]
 assert sha((data['line']+'\n').encode())==sc['fixture_sha256']['.node-version'] and sha((C/'expected-node.json').read_bytes()+b'\n')==sc['fixture_sha256']['expected-node.json']
 ci=(R/'job.log').read_bytes();plain=b''.join(re.sub(rb'^\xef\xbb\xbf',b'',re.sub(rb'^\d{4}-\d\d-\d\dT\S+Z ',b'',x)) for x in ci.splitlines(keepends=True))
 qualification=(A/'qualification.log').read_bytes();assert qualification in plain
 assert re.findall(rb'--- (PASS|FAIL|SKIP): (\S+) \(',qualification)==[(b'PASS',b'TestCommonNodeGeneratedImages'),(b'PASS',('TestCommonNodeGeneratedImages/'+data['case']).encode())]
 cleanup=load(A/'cleanup.json');assert cleanup['owner']==inp['owner'] and all(type(x['exit_code']) is int and x['exit_code']==0 for x in cleanup['operations'])
 auth=next(x for x in cleanup['operations'] if x['resource']=='docker-auth');assert auth['removed'] is True and auth['logout_exit_code']==0
 expected_cleanup={'owner':cleanup['owner'],'operations':[{k:v for k,v in x.items() if x['resource']!='docker-auth' or k in ('resource','exit_code','logout_exit_code','removed','removal_error')} for x in cleanup['operations']]}
 packets=[json.loads(line.split('BEX_NATIVE_CLEANUP_RESULT ',1)[1]) for line in ci.decode().splitlines() if 'BEX_NATIVE_CLEANUP_RESULT ' in line];assert packets==[expected_cleanup]
 module=types.ModuleType('captured_node_oracle');module.__file__=str(FIX/'check.py');assert identity(FIX/'check.py')['sha256']=='c7e16114b0141ad7f98c13d9425d16f2957e21ffe4c47b254bb27f551f5fa748'
 exec(compile((FIX/'check.py').read_bytes(),str(FIX/'check.py'),'exec'),module.__dict__)
 # The unchanged parent pure-oracle block is inserted here, with only fixed
 # observed version/ABI/npm/projectline/next-major data substitutions.
 versions={};proof_summaries=[];positives={}
 def command(name,success=True):
  x=load(Q/(name+'.json'));assert x['timed_out'] is False and type(x['returncode']) is int and x['returncode']==(0 if success else 1)
  return x
 def parsed(name):return module.proofs(command(name)['stdout'])
 for phase in ('build','runtime'):
  primary=load(Q/('node-'+phase+'.json'));assert primary['pass'] is True and primary['phase']==phase
  module.validate_identity(primary['node'],expected);module.validate_core(primary['node'])
  assert primary['node']['modules']==primary['node']['addon']['module_abi']==data['ABI'] and primary['node']['addon']['headers']==data['version']
  actual={manager:command(manager+'-version-'+phase)['stdout'].strip() for manager in ('npm','yarn','pnpm')}
  tools=parsed('tools-'+phase);assert len(tools)==1;module.validate_tools(tools[0],actual,expected)
  assert actual==primary['tool_versions']=={'npm':data['npm'],'yarn':'1.22.22','pnpm':'10.34.7'}
  assert tools[0]['npm_package_sha256']==primary['npm_package_sha256']
  linked=command('ldd-'+phase);assert 'not found' not in linked['stdout']+linked['stderr']
  if phase=='build':
   command('compile-addon');assert actual==load(Q/'build-tool-versions.json')
   versions=actual
  for manager in ('npm','yarn','pnpm'):
   positive=load(Q/(manager+'-project/package.json'));assert not positive.get('dependencies') and positive['engines']=={'node':data['line']+'.x'}
   positives[manager]=identity(Q/(manager+'-project/package.json'))
   if phase=='build':
    installed=command(manager+'-install');assert '--offline' in installed['command']
    events=module.proofs(installed['stdout'])
    for event in ('preinstall','postinstall'):
     matches=[x for x in events if x['lifecycle']==event];assert len(matches)==1;module.validate_lifecycle(matches[0],expected,manager,event)
    rejected=command(manager+'-wrong-engine',False)
    actual_proof=module.validate_engine_rejection(subprocess.CompletedProcess(rejected['command'],rejected['returncode'],rejected['stdout'],rejected['stderr']),manager,data['engine_range'],actual['npm'],cwd=Path('/opt/render/project/src')/rejected['cwd'],selected_node=expected['node'])
    assert actual_proof==load(Q/(manager+'-engine-proof.json'))
   events=parsed(manager+'-run-'+phase);assert len(events)==1;module.validate_lifecycle(events[0],expected,manager,'probe')
  events=parsed('pnpm-exec-'+phase);assert len(events)==1;module.validate_identity(events[0],expected);module.validate_core(events[0])
  proof_summaries.append({'phase':phase,'Node':primary['node']['node'],'ABI':primary['node']['modules'],'NAPI':primary['node']['napi'],'versions':actual,'Yarn_CLI':tools[0]['yarn_cli'],'pnpm_package':tools[0]['pnpm_package'],'npm_package_sha256':tools[0]['npm_package_sha256'],'identity_addon_core_tools_lifecycle_exec':True})
 addon=(Q/'bex_node.node').read_bytes();assert addon[:6]==b'\x7fELF\x02\x01' and int.from_bytes(addon[18:20],'little')==62
 return {'case_id':'node/'+data['case'],'scope':'READ_ONLY_RETAINED_ACTUAL_CI_AMD_CONTENT_AUDIT_NO_TARGET_REPLAY','pass':True,'source':SOURCE,'common':COMMON,'architecture':'amd64','run_id':data['run_id'],'job_id':data['job_id'],'artifact_id':data['artifact_id'],'original_members':members,'body_manifest':identity(A/'MANIFEST.json'),'canonical_executed_sha256':sc['canonical_sha256'],'input_manifest':identity(C/'source-custody.json'),'image_config':receipt['image_config_id'],'phases':proof_summaries,'positive_projects':positives,'new_target_runtime_execution':False}

def main():
 output=Path(sys.argv[1])
 if not output.is_dir() or any(output.iterdir()):raise RuntimeError('fresh empty owned output required')
 reports=[audit(data) for data in DATA]
 write_new(output/'REPORT.json',{'scope':'TWO_RETAINED_ACTUAL_NODE_AMD_CI_CONTENT_AUDITS_ONLY','pass':True,'cases':reports})
 print(json.dumps({'scope':'TWO_RETAINED_ACTUAL_NODE_AMD_CI_CONTENT_AUDITS_ONLY','pass':True,'cases':reports,'report':identity(output/'REPORT.json')}))

if __name__=='__main__':main()
