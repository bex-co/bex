"""Focused paired refusal controls for the new metadata adapter only. Inert source until approved."""
from pathlib import Path
import copy,hashlib,json,tempfile,unittest
import node_cases as adapter

class AdapterControls(unittest.TestCase):
 def test_actual_roles_pass_and_wrong_source_donor_recipe_version_refuse(self):
  for data in adapter.DATA:
   with self.subTest(case=data['case']):
    A=Path(data['root'])/'amd64/extracted/artifact';C=A/data['generated']
    args=[adapter.load(A/'inputs.json'),adapter.load(C/'source-custody.json'),adapter.load(C/'receipt.json'),adapter.load(C/'expected-node.json'),data,(C/'Dockerfile.canonical').read_bytes(),(C/'Dockerfile').read_bytes()]
    adapter.validate_roles(*args)
    for index,key,value in [(0,'generator_source','0'*40),(1,'runtime_artifact_mode','published-runtime-donors'),(1,'node_source','node:99@sha256:'+'0'*64),(3,'node','0.0.0')]:
     wrong=copy.deepcopy(args);wrong[index][key]=value
     with self.assertRaises(AssertionError):adapter.validate_roles(*wrong)
    wrong=copy.deepcopy(args);wrong[6]+=b'changed'
    with self.assertRaises(AssertionError):adapter.validate_roles(*wrong)
 def test_member_bytes_positive_then_tamper_extra_and_symlink_refuse(self):
  with tempfile.TemporaryDirectory() as name:
   root=Path(name);p=root/'proof.json';p.write_bytes(b'{}\n')
   (root/'MANIFEST.json').write_text(json.dumps({'files':[{'path':p.name,**adapter.identity(p)}]}))
   self.assertEqual(adapter.verify_members(root),2)
   p.write_bytes(b'[]\n')
   with self.assertRaises(AssertionError):adapter.verify_members(root)
   p.write_bytes(b'{}\n');extra=root/'foreign';extra.write_bytes(b'x')
   with self.assertRaises(AssertionError):adapter.verify_members(root)
   extra.unlink();p.unlink();p.symlink_to(root/'MANIFEST.json')
   with self.assertRaises(AssertionError):adapter.verify_members(root)

 def test_controller_hash_accepts_path_and_string(self):
  import run_audit
  with tempfile.TemporaryDirectory() as name:
   p=Path(name)/'data';p.write_bytes(b'exact input\n')
   self.assertEqual(run_audit.sha(p),run_audit.sha(str(p)))
   self.assertEqual(run_audit.sha(p),hashlib.sha256(b'exact input\n').hexdigest())

 def test_final_cap_uses_actual_serialized_bytes_at_the_boundary(self):
  import ast,run_audit
  sample={'complete':True,'results':[{'label':'audit','nested':{'value':'kept'}}],'late_bound':None}
  compact=len(json.dumps(sample).encode())+1
  serialized=run_audit.json_bytes(sample)
  self.assertGreater(len(serialized),compact)
  gate=next(node for node in ast.walk(ast.parse(Path(run_audit.__file__).read_bytes()))
            if isinstance(node,ast.If) and any(isinstance(call,ast.Call) and isinstance(call.func,ast.Name) and call.func.id=='own_bytes' for call in ast.walk(node.test)))
  code=compile(ast.Module(body=[gate],type_ignores=[]),'actual-final-cap-gate','exec')
  # The old compact formula accepted equality here; the real indented write did not fit.
  for existing,accepted in [(run_audit.OUTPUT_CAP-compact,False),(run_audit.OUTPUT_CAP-len(serialized),True)]:
   self.assertLessEqual(existing+compact,run_audit.OUTPUT_CAP)
   values={'own_bytes':lambda root:existing,'run':None,'OUTPUT_CAP':run_audit.OUTPUT_CAP,'result':copy.deepcopy(sample),'json_bytes':run_audit.json_bytes,'late':None}
   exec(code,values)
   self.assertEqual(values['result']['complete'],accepted)
   if accepted:self.assertLessEqual(existing+len(run_audit.json_bytes(values['result'])),run_audit.OUTPUT_CAP)
  # A tiny actual write binds the measured encoder to the bytes dump_new writes.
  with tempfile.TemporaryDirectory() as name:
   output=Path(name)/'result.json';run_audit.dump_new(output,sample)
   self.assertEqual(output.read_bytes(),serialized)

if __name__=='__main__':unittest.main()
