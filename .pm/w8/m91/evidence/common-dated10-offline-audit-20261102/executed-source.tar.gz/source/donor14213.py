"""Read-only original-oracle replay over the retained exact14.21.3 AMD artifact."""
from pathlib import Path
import ast, base64, gzip, hashlib, io, json, os, re, struct, subprocess, tarfile, types


import sys
OUTPUT=Path(sys.argv[1])
if not OUTPUT.is_dir() or any(OUTPUT.iterdir()):raise RuntimeError("fresh empty owned output required")
def write_new(path,text):
 with Path(path).open('x',encoding='utf-8') as stream:stream.write(text)

R=Path('/private/tmp/bex-w8-donor14213-amd-intake-20261102-28wszm9w')
REPO=Path('/Users/tianpan/projects/bex7')
SOURCE='77307722e157e148ef04b1f77b675a72e0bd9d35'
COMMON='ghcr.io/bex-co/bex-cnb-run@sha256:0941c204f87643c2faad308e72acdf584976e67d8fb980a0646c5ab662dcc5d0'
DONOR='ghcr.io/bex-co/bex-cnb-run@sha256:4fec31cbb186e340cd7ce25ac1d0705f78735631f793b75629d653c6601f83fc'
UPSTREAM='node:14-bullseye@sha256:c0bff0d29a742f40650d5f0305dd581351c10954e6cb6676fc96f47590b9666e'

def need(ok,why):
    if not ok:raise AssertionError(why)
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def identity(p):b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b)}
def git(p):return subprocess.check_output(['git','show',SOURCE+':'+p],cwd=REPO)

A=R/'amd64/extracted/artifact';E=load(R/'amd64/extracted/extraction.json')
rows=load(A/'MANIFEST.json')['files'];members={x['path']:x for x in rows}
actual={str(p.relative_to(A)) for p in A.rglob('*') if p.is_file()}
need(len(members)==len(rows) and actual==set(members)|{'MANIFEST.json'},'original manifest/file bijection')
need(E['complete'] is True and E['completed_members']==len(actual) and identity(A/'MANIFEST.json')['sha256']==E['manifest_sha256'],'V2 actual extraction binding')
for name,row in members.items():need(identity(A/name)=={k:row[k] for k in ('bytes','sha256')},'original member changed:'+name)
artifact=next(x for x in load(R/'artifact-listing-fresh.json')['artifacts'] if x['id']==13116130059)
need(artifact['workflow_run']['id']==41376352475 and artifact['workflow_run']['head_sha']==SOURCE and artifact['size_in_bytes']==E['zip_bytes']==86424 and artifact['digest']=='sha256:'+E['zip_sha256'],'fresh exact ZIP metadata')
job=next(x for x in load(R/'jobs.json')['jobs'] if x['id']==125069817230)
need(job['head_sha']==SOURCE and job['run_id']==41376352475 and job['run_attempt']==1 and job['conclusion']=='success','whole job/source identity')
steps={s['name']:s for s in job['steps']}
for name in ['measure the selected family case without claiming full-family acceptance',"remove only this job's labeled resources, exact builder and credentials",'hash retained successes and failures']:
    need(steps[name]['conclusion']=='success','whole job required step:'+name)
need(next(s for s in job['steps'] if s['name'].startswith('Run actions/upload-artifact@'))['conclusion']=='success','complete upload')
inputs=load(A/'inputs.json');captured=load(A/'qualification-source.json')
need(inputs['common_image']==COMMON and inputs['producer']==inputs['verification']=='1feba939b4697894e800ed0abb4f25a0bf415641' and inputs['generator_source']==SOURCE and inputs['platform']=='linux/amd64','image/source/platform roles')
need(inputs['selection']['profile']=='node-donors' and inputs['selection']['case']=='node-exact14213' and inputs['selection']['selector']=='^TestCommonNodeGeneratedImages$/^node\\-exact14213$' and inputs['selection']['flag']=='BEX_NATIVE_TEST_NODE_DONORS','exact selected donor profile')
baseline=load(REPO/'.pm/w8/m91/evidence/common-current-e6-20261102/utilities/amd64/artifact/qualification-source.json')
need(captured['source']==SOURCE and len(captured['files'])==300 and captured['files']==baseline['files'],'actual dated functional300 capture')
need(inputs['baseline_status']=='current-complete' and inputs['utility_baseline_source']==baseline['source'] and inputs['candidate_receipt_sha256']=='ac17d21d7e5a09c8ea41fece0333b8f613900c7b5f793e8bf2edcdb160e59426','dated baseline provenance')
tree=subprocess.check_output(['git','ls-tree','-r','-z',SOURCE,'--',*captured['files']],cwd=REPO)
tree_rows={}
for raw in tree.split(b'\0'):
    if raw:
        header,name=raw.split(b'\t');mode,kind,oid=header.decode().split();tree_rows[name.decode()]=(mode,kind,oid)
objects=subprocess.check_output(['git','cat-file','--batch'],input=''.join(tree_rows[n][2]+'\n' for n in sorted(captured['files'])).encode(),cwd=REPO)
need(len(objects)<16<<20,'source read bounded')
cursor=0
for name in sorted(captured['files']):
    end=objects.index(b'\n',cursor);oid,kind,size=objects[cursor:end].decode().split();size=int(size);b=objects[end+1:end+1+size];cursor=end+1+size
    need(objects[cursor:cursor+1]==b'\n' and tree_rows[name][1]=='blob' and kind=='blob' and oid==tree_rows[name][2],'Git framing');cursor+=1
    row=captured['files'][name];need(len(b)==row['bytes'] and sha(b)==row['sha256'] and tree_rows[name][0]==row['mode'],'exact source bytes/mode:'+name)
need(cursor==len(objects),'no extra Git bytes')

ci=(R/'job.log').read_bytes();plain=b''.join(re.sub(rb'^\xef\xbb\xbf',b'',re.sub(rb'^\d{4}-\d\d-\d\dT\S+Z ',b'',x)) for x in ci.splitlines(keepends=True))
need((A/'qualification.log').read_bytes() in plain,'actual whole CI qualification log')
passed=re.findall(rb'--- (PASS|FAIL|SKIP): (\S+) \(', (A/'qualification.log').read_bytes())
need(passed==[(b'PASS',b'TestCommonNodeGeneratedImages'),(b'PASS',b'TestCommonNodeGeneratedImages/node-exact14213')],'exact actual Go case result')
cleanup=load(A/'cleanup.json');need(cleanup['owner']==inputs['owner'] and all(x['exit_code']==0 for x in cleanup['operations']),'declared cleanup')
auth=next(x for x in cleanup['operations'] if x['resource']=='docker-auth');need(auth['removed'] is True and auth['logout_exit_code']==0,'auth cleanup')
expected_cleanup={'owner':cleanup['owner'],'operations':[{k:v for k,v in x.items() if x['resource']!='docker-auth' or k in ('resource','exit_code','logout_exit_code','removed','removal_error')} for x in cleanup['operations']]}
packets={marker:[json.loads(s.split(marker,1)[1]) for s in ci.decode().splitlines() if marker in s] for marker in ['BEX_NATIVE_CLEANUP_RESULT ','BEX_BUILDKIT_PULL_ATTEMPT ']}
need(packets['BEX_NATIVE_CLEANUP_RESULT ']==[expected_cleanup],'cleanup/actual CI stdout binding')
bootstrap=load(A/'bootstrap.json');need(len(packets['BEX_BUILDKIT_PULL_ATTEMPT '])==len(bootstrap['attempts']) and bootstrap['image_output_emitted'] is True,'complete bootstrap attempt history')
for packet,attempt in zip(packets['BEX_BUILDKIT_PULL_ATTEMPT '],bootstrap['attempts']):
    need(packet['attempt']==attempt and packet['owner']==inputs['owner'],'bootstrap attempt binding')
    for stream in ['stdout','stderr']:
        b=(A/attempt[stream]['path']).read_bytes();need(base64.b64decode(packet[stream+'_base64'],validate=True)==b and identity(A/attempt[stream]['path'])=={k:attempt[stream][k] for k in ['bytes','sha256']},'bootstrap full raw custody')

G=next((A/'generated').iterdir())/'node-exact14213';Q=G/'qa-output'
sc=load(G/'source-custody.json');expected=load(G/'expected-node.json');receipt=load(G/'receipt.json')
canonical=(G/'Dockerfile.canonical').read_bytes();executed=(G/'Dockerfile').read_bytes()
need(canonical==executed and sha(canonical)==sc['canonical_sha256']==sc['executed_sha256'],'exact canonical/executed recipe')
need(sc['runtime_artifact_mode']=='published-runtime-donors' and sc['empty_runtime_artifact_map'] is False and sc['test_only_network_overlay'] is False and sc['node_runtime_artifact']==DONOR and sc['runtime_artifact_map'][UPSTREAM]==DONOR,'actual pinned runtime donor')
need(sc['common']==COMMON and sc['node_source']==UPSTREAM and sc['owner']==sc['builder']==inputs['owner'] and sc['platform']=='linux/amd64','source-custody roles')
need(b'\nFROM '+COMMON.encode()+b'\n' in canonical and ('COPY --link --from='+DONOR+' /usr/local/ /usr/local/\n').encode() in canonical and ('COPY --link --from='+DONOR+' /usr/share/bex-node-brotli /usr/share/bex-node-brotli\n').encode() in canonical,'common foundation/runtime tree/provenance')
need(b'/usr/libexec/bex-native/build-node' not in canonical and b'RUN --network=default ' not in canonical,'no source patch compiler/network overlay')
need(expected['node']=='14.21.3' and expected['node_env']=='14.21.3' and expected['node_donor']==UPSTREAM and expected['yarn']=='1.22.22' and expected['pnpm']=='10.34.7','exact primary/tool expectations')
for name in ['addon.c','check.js','check.py','package.json']:
    need(sha(git('lego/operator/internal/build/testdata/native-node-qualification/'+name))==sc['fixture_sha256'][name],'unchanged original fixture:'+name)
need(sha(b'14.21.3\n')==sc['fixture_sha256']['.node-version'] and sha((G/'expected-node.json').read_bytes()+b'\n')==sc['fixture_sha256']['expected-node.json'],'exact emitted version/context expectation bytes')
need(receipt['common_base']==COMMON and receipt['image_platform']=='linux/amd64' and receipt['network']=='none' and receipt['test_prerequisite_overlay'] is False and receipt['runtime_command_executed'] is True and receipt['owner']==inputs['owner'] and re.fullmatch('sha256:[a-f0-9]{64}',receipt['image_config_id']),'actual config/platform/offline runtime')

source=git('lego/operator/internal/build/testdata/native-node-qualification/check.py');parsed=ast.parse(source)
names=['validate_identity','validate_core','validate_tools','validate_lifecycle','proofs','validate_engine_rejection']
nodes=[n for n in parsed.body if isinstance(n,ast.FunctionDef) and n.name in names];need(len(nodes)==len(names),'all unchanged pure original oracles')
ns={'hashlib':hashlib,'os':os,'json':json,'Path':Path,'PAYLOAD':'bex Node café λ 雪'.encode(),'ENGINE_SENTINEL':'bex-node-engine-sentinel'}
exec(compile(ast.Module(body=nodes,type_ignores=[]),'pure-original-node-oracles','exec'),ns)
root=Path('/opt/render/project/src')
def record(name):
    d=load(Q/(name+'.json'));need(d['timed_out'] is False,'actual command timeout:'+name);return d
def proof(name):
    d=record(name);need(d['returncode']==0,'actual command failure:'+name);p=ns['proofs'](d['stdout']);need(len(p)==1,'one actual proof:'+name);return p[0]
phases=[]
for phase in ['build','runtime']:
    result=load(Q/('node-'+phase+'.json'));need(result['pass'] is True and result['phase']==phase,'actual phase success')
    primary=result['node'];ns['validate_identity'](primary,expected);ns['validate_core'](primary)
    linked=record('ldd-'+phase);need(linked['returncode']==0 and 'not found' not in linked['stdout']+linked['stderr'],'resolved actual Node libraries')
    tools=proof('tools-'+phase);versions={m:record(m+'-version-'+phase)['stdout'].strip() for m in ['npm','yarn','pnpm']}
    ns['validate_tools'](tools,versions,expected);need(versions==result['tool_versions']==load(Q/'build-tool-versions.json'),'same actual build/runtime tool versions')
    for manager in ['npm','yarn','pnpm']:
        manifest=load(Q/(manager+'-project')/'package.json');need('dependencies' not in manifest and manifest['engines']['node']=='14.x','original positive project dependency-free app engines')
        if phase=='build':
            install=record(manager+'-install');need(install['returncode']==0 and '--offline' in install['command'],'offline real install')
            for event in ['preinstall','postinstall']:
                rows=[p for p in ns['proofs'](install['stdout']) if p['lifecycle']==event];need(len(rows)==1,'actual lifecycle:'+manager+'/'+event);ns['validate_lifecycle'](rows[0],expected,manager,event)
        run=proof(manager+'-run-'+phase);ns['validate_lifecycle'](run,expected,manager,'probe')
    p=proof('pnpm-exec-'+phase);ns['validate_identity'](p,expected);ns['validate_core'](p)
    phases.append({'phase':phase,'Node':primary['node'],'ABI':primary['modules'],'NAPI':primary['napi'],'versions':versions,'tool_pnpm_standalone':tools['pnpm_package'].get('standalone'),'actual_selected_header_C_addon':primary['addon'],'ldd_sha256':sha(linked['stdout'].encode()),'all_three_actual_offline_lifecycle_and_exec_oracles':True})
binary=(Q/'bex_node.node').read_bytes();need(binary[:6]==b'\x7fELF\x02\x01' and struct.unpack_from('<H',binary,18)[0]==62,'actual AMD64 ELF C addon')
compile_record=record('compile-addon');need(compile_record['returncode']==0 and '-I/usr/local/include/node' in compile_record['command'],'selected-header compile command')
engines=[]
for manager in ['npm','yarn','pnpm']:
    d=record(manager+'-wrong-engine');need(d['returncode']==1,'precise engine exit')
    proof_input=load(Q/(manager+'-engine-input.json'))
    if manager=='pnpm':
        need(proof_input['negative_kind']=='project-engine-strict' and proof_input['project_cwd']==str(root/'qa-output/pnpm-wrong-engine') and proof_input['selected_node']=='14.21.3' and proof_input['dependency_tarball'] is None,'actual PNPM root negative identity')
        need(identity(Q/'pnpm-wrong-engine/package.json')['sha256']==proof_input['project_manifest_sha256'] and identity(Q/'pnpm-wrong-engine/pnpm-workspace.yaml')['sha256']==proof_input['workspace_sha256'],'PNPM actual project/workspace bytes')
    else:
        archive=Q/(manager+'-wrong-engine')/'bex-node-engine-sentinel.tgz';need(identity(archive)=={'bytes':proof_input['bytes'],'sha256':proof_input['sha256']},'actual offline negative archive')
        with tarfile.open(fileobj=io.BytesIO(archive.read_bytes()),mode='r:gz') as tar:
            members=tar.getmembers();need(len(members)==1 and members[0].name=='package/package.json' and members[0].isfile(),'negative archive members');pkg=json.load(tar.extractfile(members[0]));need(pkg==proof_input['package'] and pkg['name']=='bex-node-engine-sentinel' and pkg['engines']['node']=='>=15','actual sentinel engines')
    checked=ns['validate_engine_rejection'](types.SimpleNamespace(**d),manager,'>=15',phases[0]['versions']['npm'],cwd=root/'qa-output/pnpm-wrong-engine',selected_node='14.21.3')
    need(checked==load(Q/(manager+'-engine-proof.json')),'original strict rejection oracle vs retained proof');engines.append(checked)

report={'assessment':'DATED_EXACT14213_AMD_CONTENT_AUDIT_PASS_ONLY','source':SOURCE,'functional300_equal_dated9bc_and_e6':True,'run_id':41376352475,'job_id':125069817230,'artifact_id':13116130059,'ZIP':identity(R/'amd64/original.zip'),'original_manifest':identity(A/'MANIFEST.json'),'members':len(actual),'payload_bytes':E['actual_file_bytes'],'common':COMMON,'actual_runtime_donor':DONOR,'actual_upstream':UPSTREAM,'canonical_equals_executed':sha(canonical),'image_config_id':receipt['image_config_id'],'phases':phases,'precise_engine_negatives':engines,'ELF_machine':62,'original_oracle_source':{'path':'lego/operator/internal/build/testdata/native-node-qualification/check.py','sha256':sha(source),'functions':names,'AST_sha256':sha(ast.dump(ast.Module(body=nodes,type_ignores=[]),include_attributes=False).encode())},'bootstrap_attempt_exit_codes':[x['exit_code'] for x in bootstrap['attempts']],'full_cleanup_log_bound':True,'scope':'Actual AMD donor primary14.21.3 only. No source-fallback/exact14.21.2/Rubycompanion/implicitnode-gyp/native-init/phase/hosted/fullfamily/current301baseline/adoption proof. Original code/fixtures/oracles unchanged; no network or target execution in this read-only audit.'}
write_new(OUTPUT/'AUDIT.json',json.dumps(report,indent=2)+'\n')
print(json.dumps({'assessment':report['assessment'],'members':len(actual),'audit':identity(OUTPUT/'AUDIT.json')},indent=2))
