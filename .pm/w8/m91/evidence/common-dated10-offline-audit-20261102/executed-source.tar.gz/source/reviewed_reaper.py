"""Unchanged stop_group definition extracted from reviewed e158 pilot; no pilot code imported."""
import os,signal,subprocess,time

def stop_group(process):
    """Reap the leader AND prove the whole owned group gone."""
    def alive():
        process.poll() # Reap an exited leader before probing its Darwin group.
        try:os.killpg(process.pid,0);return True
        except ProcessLookupError:return False
        except PermissionError:return True # Unproved, never absence.
    process.poll()
    try:os.killpg(process.pid,signal.SIGTERM)
    except (ProcessLookupError,PermissionError):pass
    until=time.monotonic()+3
    while alive() and time.monotonic()<until:
        process.poll();time.sleep(.05)
    if alive():
        try:os.killpg(process.pid,signal.SIGKILL)
        except (ProcessLookupError,PermissionError):pass
    try:process.wait(timeout=5)
    except subprocess.TimeoutExpired:return False
    until=time.monotonic()+5
    while alive() and time.monotonic()<until:time.sleep(.05)
    return process.returncode is not None and not alive()
