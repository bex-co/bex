import importlib.util,json,pathlib,sys,types,unittest
from unittest.mock import patch
HERE=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/Users/tianpan/projects/bex7')
FIXTURE=REPO/'lego/operator/internal/build/testdata/native-utilities'
NEWTEST=HERE/'original-cases_test.py'
mode=sys.argv[1]
assert mode in ('new-all','old-negative')
selected_driver=HERE/'original-cases.py' if mode=='new-all' else FIXTURE/'original-cases.py'
real_spec=importlib.util.spec_from_file_location

def routed(name,path,*args,**kwargs):
    if pathlib.Path(path)==FIXTURE/'original-cases.py':path=selected_driver
    return real_spec(name,path,*args,**kwargs)
module=types.ModuleType('independent_replay_'+mode.replace('-','_'))
module.__file__=str(FIXTURE/'original-cases_test.py')
sys.modules[module.__name__]=module
with patch.object(importlib.util,'spec_from_file_location',routed):
    exec(compile(NEWTEST.read_bytes(),str(FIXTURE/'original-cases_test.py'),'exec'),module.__dict__)
module.replay.ROOT=FIXTURE
suite=unittest.defaultTestLoader.loadTestsFromModule(module) if mode=='new-all' else unittest.defaultTestLoader.loadTestsFromTestCase(module.OriginalBuildFailureOutputControls)
result=unittest.TextTestRunner(verbosity=2).run(suite)
record={'mode':mode,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'was_successful':result.wasSuccessful(),'fixture_root':str(FIXTURE),'driver':str(selected_driver),'scope':'New full9 includes unchanged retained-body localhost HTTP oracles plus own synthetic bash printf/exit23. Old-negative runs only new failing-shell test against original driver; no actual authored native program, image or remote network.'}
(HERE/(mode+'-RESULT.json')).write_text(json.dumps(record,indent=2)+'\n')
if mode=='new-all':
    sys.exit(0 if record==dict(record,tests=9,failures=0,errors=0,skipped=0,was_successful=True) else 1)
else:
    sys.exit(0 if record['tests']==1 and record['failures']==1 and record['errors']==0 and not record['was_successful'] else 1)
