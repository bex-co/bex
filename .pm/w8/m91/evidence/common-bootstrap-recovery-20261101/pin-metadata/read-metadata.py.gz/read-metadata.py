#!/usr/bin/env python3
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import types
import urllib.error
import urllib.parse
import urllib.request

OUT=Path(__file__).resolve().parent
SOURCE=Path('/tmp/loopx-w8-verify-native-artifact.py')
FRESHNESS=Path('/Users/tianpan/projects/bex7/scripts/lib/toolchain-freshness.py')
PIN='sha256:0168606be2315b7c807a03b3d8aa79beefdb31c98740cebdffdfeebf31190c9f'
namespace={'urllib':urllib,'hashlib':hashlib,'json':json,'MAX_DOCUMENT':512<<10}
module=ast.parse(SOURCE.read_text())
names={'require','small_get','public_registry','manifest_document'}
nodes=[n for n in module.body if isinstance(n,ast.FunctionDef) and n.name in names]
assert {n.name for n in nodes}==names
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(SOURCE),'exec'),namespace)
constants={}
for n in ast.parse(FRESHNESS.read_text()).body:
    if isinstance(n,ast.Assign):
        for t in n.targets:
            if isinstance(t,ast.Name) and t.id in {'REGISTRY_API','REGISTRY_AUTH','MANIFEST_ACCEPT'}:
                constants[t.id]=ast.literal_eval(n.value)
assert len(constants)==3
freshness=types.SimpleNamespace(**constants)
result={'at':datetime.now(timezone.utc).isoformat(),'reference':'moby/buildkit:v0.30.0@'+PIN,'mode':'anonymous immutable index plus two child manifests only','helper':{'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'unchanged_ast_functions':sorted(names),'manifest_read_limit_bytes':512<<10,'token_read_limit_bytes':128<<10,'socket_timeout_seconds':60},'bodies_requested':False,'retried':False}
try:
    url,headers=namespace['public_registry'](freshness,'docker.io','moby/buildkit')
    doc,raw,digest=namespace['manifest_document'](url,headers,PIN)
    assert doc.get('schemaVersion')==2
    assert doc.get('mediaType') in {'application/vnd.oci.image.index.v1+json','application/vnd.docker.distribution.manifest.list.v2+json'}
    (OUT/'index.raw.json').write_bytes(raw)
    result['index']={'digest':digest,'bytes':len(raw),'media_type':doc['mediaType'],'descriptor_count':len(doc['manifests'])}
    result['platforms']=[]
    for arch in ['amd64','arm64']:
        rows=[m for m in doc['manifests'] if m.get('platform',{}).get('os')=='linux' and m.get('platform',{}).get('architecture')==arch]
        assert len(rows)==1,'ambiguous or missing exact platform'
        row=rows[0]
        assert re.fullmatch(r'sha256:[a-f0-9]{64}',row['digest']) and type(row['size']) is int and 0<row['size']<=512<<10
        child,body,child_digest=namespace['manifest_document'](url,headers,row['digest'])
        assert len(body)==row['size']
        assert child.get('schemaVersion')==2 and child.get('mediaType')==row['mediaType']
        assert child['mediaType'] in {'application/vnd.oci.image.manifest.v1+json','application/vnd.docker.distribution.manifest.v2+json'}
        layers=child.get('layers');assert isinstance(layers,list) and layers
        for desc in layers+[child['config']]:
            assert re.fullmatch(r'sha256:[a-f0-9]{64}',desc['digest']) and type(desc['size']) is int and desc['size']>=0
        (OUT/(arch+'-manifest.raw.json')).write_bytes(body)
        result['platforms'].append({'platform':row['platform'],'child_digest':child_digest,'manifest_bytes':len(body),'index_descriptor_bytes':row['size'],'media_type':child['mediaType'],'config_descriptor':child['config'],'layer_count':len(layers),'sum_compressed_layer_bytes':sum(d['size'] for d in layers),'largest_compressed_layer_bytes':max(d['size'] for d in layers),'layer_descriptors':layers})
    result['outcome']='PASS_METADATA_AVAILABILITY_AND_IMMUTABLE_DESCRIPTOR_BINDING'
except Exception as exc:
    result['outcome']='REFUSED_OR_FAILED_METADATA_READ'
    result['failure']={'class':type(exc).__name__,'http_status':exc.code if isinstance(exc,urllib.error.HTTPError) else None}
finally:
    result['completed_at']=datetime.now(timezone.utc).isoformat()
    result['limits']=['No config, layer, attestation or executable blob body requested. Anonymous token kept only in memory and no request/auth/redirect headers retained.','Manifest descriptor sizes do not measure transfer throughput, decompressed size, allocated storage, actual pull success, BuildKit daemon health or the current CI setup-hang cause.','The existing image/version/policy was not changed or approved anew.']
    (OUT/'METADATA-RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['helper','limits','platforms']},indent=2))
for row in result.get('platforms',[]):
    print(json.dumps({k:v for k,v in row.items() if k not in ['layer_descriptors','config_descriptor']},indent=2))
raise SystemExit(0 if result['outcome'].startswith('PASS_') else 1)
