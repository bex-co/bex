"""Owned Python-only helper SIGTERM probe; exact frozen pull function, no Docker."""
from pathlib import Path
import json,os,signal,subprocess,sys,time
HERE=Path(__file__).resolve().parent;helper=Path('/private/tmp/bex-w8-common-bootstrap-source-20261101-1nfn6dtu/source/.github/scripts/native-common-qualify.py');journal=HERE/'signal-owned-child.json'
wrapper="""import importlib.util,json,os,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('exact_bootstrap_signal',sys.argv[1]);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
script='import json,os,pathlib,sys,time;pathlib.Path(sys.argv[1]).write_text(json.dumps({\"pid\":os.getpid(),\"pgid\":os.getpgrp()}));time.sleep(60)'
m.pull_buildkit([sys.executable,'-B','-c',script,sys.argv[2]],dict(os.environ))
"""
parent=None;pgid=None;result={'scope':'Owned synthetic Python subprocess only; actual frozen pull_buildkit imported, no bootstrap policy/Docker/network/auth/resources.'}
try:
 with (HERE/'signal-parent.log').open('wb') as log:
  parent=subprocess.Popen([sys.executable,'-B','-c',wrapper,str(helper),str(journal)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  deadline=time.monotonic()+4
  while not journal.exists():
   assert parent.poll() is None,'parent ended before fixture spawn';assert time.monotonic()<deadline;time.sleep(0.01)
  child=json.loads(journal.read_text());pgid=child['pgid'];assert child['pid']==pgid and pgid!=parent.pid
  os.kill(parent.pid,signal.SIGTERM);code=parent.wait(timeout=2)
  try:os.killpg(pgid,0);alive=True
  except ProcessLookupError:alive=False
  result.update(parent_pid=parent.pid,parent_exit=code,owned_child=child,owned_group_alive_after_parent_SIGTERM=alive)
finally:
 if pgid is not None:
  try:os.killpg(pgid,signal.SIGKILL)
  except ProcessLookupError:pass
  deadline=time.monotonic()+5
  while True:
   try:os.killpg(pgid,0)
   except ProcessLookupError:result['final_owned_group_absent']=True;break
   if time.monotonic()>=deadline:result['final_owned_group_absent']=False;break
   time.sleep(0.01)
 if parent is not None and parent.poll() is None:
  os.kill(parent.pid,signal.SIGKILL);parent.wait(timeout=2)
 result['parent_reaped']=parent is not None and parent.poll() is not None
(HERE/'SIGNAL-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));assert result['final_owned_group_absent'] and result['parent_reaped']
