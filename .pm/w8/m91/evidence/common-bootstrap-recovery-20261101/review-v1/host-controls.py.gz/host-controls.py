import importlib.util,sys,types,unittest
from pathlib import Path
from unittest.mock import patch
repo=Path('/Users/tianpan/projects/bex7');root=Path('/private/tmp/bex-w8-common-bootstrap-source-20261101-1nfn6dtu');source=root/'source'
helper=repo/'.github/scripts/native-common-qualify.py';test=repo/'.github/scripts/test_native_oci_common_qualification.py';workflow=repo/'.github/workflows/native-common-image.yml'
original_spec=importlib.util.spec_from_file_location;original_read=Path.read_text
candidate=(source/'.github/workflows/native-common-image.yml').read_text()
def route_spec(name,path,*args,**kwargs):
 if Path(path)==helper:path=source/'.github/scripts/native-common-qualify.py'
 return original_spec(name,path,*args,**kwargs)
def route_read(path,*args,**kwargs):
 if path==workflow:return candidate
 return original_read(path,*args,**kwargs)
module=types.ModuleType('candidate_common_controls');module.__file__=str(test);sys.modules[module.__name__]=module
with patch.object(importlib.util,'spec_from_file_location',route_spec),patch.object(Path,'read_text',route_read):
 exec(compile((source/'.github/scripts/test_native_oci_common_qualification.py').read_bytes(),str(test),'exec'),module.__dict__)
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
 sys.exit(not result.wasSuccessful())
