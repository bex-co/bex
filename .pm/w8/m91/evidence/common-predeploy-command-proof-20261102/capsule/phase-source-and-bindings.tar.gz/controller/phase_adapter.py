"""Pure data adapters for the reviewed dev8 source driver; no transport/action on import."""
import base64,copy,hashlib,json,re
from pathlib import Path
MANIFEST='sha256:cd8542c966bfa204dad5bb96857046aec6cf07c4d38e5bcd60e00a87bb618a2e'
CONFIG='sha256:85152c4e3f9d5947f048b4558bb347b6bcfdfd7ca3510feca90ead00bb483f2a'
REVISION='1feba939b4697894e800ed0abb4f25a0bf415641'
HEREDOC='62e612225534dd76166dacc73d217cc49e9bb5e7e78aa09202e33ea7195d81d6'
KINDS={'Job':'/apis/batch/v1/namespaces/dev-8/jobs/','Secret':'/api/v1/namespaces/dev-8/secrets/','NetworkPolicy':'/apis/networking.k8s.io/v1/namespaces/dev-8/networkpolicies/','ConfigMap':'/api/v1/namespaces/dev-8/configmaps/'}
def digest(b):return hashlib.sha256(b).hexdigest()
def names(name,owner):
 assert re.fullmatch(r'qa-common-predeploy-[a-f0-9]{12}',name)
 assert re.fullmatch(r'bex-nq-[a-f0-9]{24}',owner)
 return {'app':name,'owner':owner,'anchor':name+'-anchor','env':name+'-env','files':name+'-files','pull':name+'-pull','wrong':name+'-wrong-pull'}
def anchor_request(name,owner,expires_at):
 n=names(name,owner)
 return {'apiVersion':'v1','kind':'ConfigMap','metadata':{'name':n['anchor'],'namespace':'dev-8','labels':{'bex.co/qa-owner':owner}},'data':{'purpose':'one canonical common-child predeploy; not an AppCR','expires_at':expires_at}}
def secret_and_policy_requests(anchor,name,owner,host,good_config,bad_config):
 n=names(name,owner);m=anchor['metadata'];assert m['name']==n['anchor'] and m['namespace']=='dev-8' and m['labels']['bex.co/qa-owner']==owner
 assert re.fullmatch(r'[a-f0-9-]{36}',m['uid']) and re.fullmatch(r'localhost:[0-9]+',host)
 assert set(good_config)==set(bad_config)=={'auths'} and set(good_config['auths'])==set(bad_config['auths'])=={host}
 assert good_config['auths'][host]['auth']!=bad_config['auths'][host]['auth']
 def metadata(key):return {'name':n[key],'namespace':'dev-8','labels':{'bex.co/qa-owner':owner},'ownerReferences':[{'apiVersion':'v1','kind':'ConfigMap','name':n['anchor'],'uid':m['uid'],'controller':True}]}
 def secret(key,kind,data):return {'apiVersion':'v1','kind':'Secret','metadata':metadata(key),'type':kind,'data':{k:base64.b64encode(v).decode() for k,v in data.items()}}
 result=[secret('env','Opaque',{'QA_SECRET_MARKER':b'own-synthetic-only','QA_ENVFROM':'envFrom-text-雪\n'.encode(),'QA_OVERRIDE':b'secret-loses','PORT':b'30000'}),secret('files','Opaque',{'proof.txt':b'own-dev8-file\x00\xff\n'}),secret('pull','kubernetes.io/dockerconfigjson',{'.dockerconfigjson':json.dumps(good_config).encode()}),secret('wrong','kubernetes.io/dockerconfigjson',{'.dockerconfigjson':json.dumps(bad_config).encode()})]
 result.append({'apiVersion':'networking.k8s.io/v1','kind':'NetworkPolicy','metadata':{**metadata('anchor'),'name':name+'-deny-egress'},'spec':{'podSelector':{'matchLabels':{'app.bex.co/app-uid':m['uid']}},'policyTypes':['Egress'],'egress':[]}})
 return result
def input_from_anchor(anchor,name,owner,transport,command_file,generation=1,wrong=False):
 n=names(name,owner);m=anchor['metadata']
 assert anchor['kind']=='ConfigMap' and m['name']==n['anchor'] and m['namespace']=='dev-8'
 assert m['labels']['bex.co/qa-owner']==owner and re.fullmatch(r'[a-f0-9-]{36}',m['uid'])
 assert m.get('creationTimestamp') and not m.get('deletionTimestamp')
 assert re.fullmatch(r'localhost:[0-9]+/[a-z0-9][a-z0-9/-]*@'+re.escape(MANIFEST),transport)
 assert str(Path(command_file))==command_file and Path(command_file).is_absolute()
 assert (generation,wrong) in ((1,False),(2,True))
 return {'name':name,'namespace':'dev-8','anchor_name':n['anchor'],'anchor_uid':m['uid'],'image':transport,'image_revision':REVISION,'registry':transport.split('/')[0],'pull_secret':n['wrong'] if wrong else n['pull'],'env_secret':n['env'],'file_secret':n['files'],'command_file':command_file,'generation':generation}
def validate_export(canonical,anchored,source,input,command):
 c=canonical['spec']['template']['spec']['containers'][0];pod=canonical['spec']['template']
 assert canonical['metadata']['namespace']=='dev-8' and canonical['metadata']['name'].startswith('predeploy-'+input['name']+'-')
 assert c['image']==input['image'] and c['imagePullPolicy']=='Always'
 assert pod['metadata']['labels']['app.bex.co/egress-app-id']==input['name']
 assert pod['metadata']['labels']['app.bex.co/app-uid']==input['anchor_uid']
 assert pod['spec']['hostUsers'] is False and pod['spec']['automountServiceAccountToken'] is False and pod['spec']['nodeSelector']=={'bex.co/pool':'tenant'}
 assert canonical['spec']['activeDeadlineSeconds']==600 and canonical['spec']['backoffLimit']==0 and canonical['spec']['ttlSecondsAfterFinished']==3600
 assert c['resources']['requests']==c['resources']['limits']=={'cpu':'500m','memory':'512Mi','ephemeral-storage':'2Gi'}
 assert pod['spec']['imagePullSecrets']==[{'name':input['pull_secret']}]
 assert c['envFrom']==[{'secretRef':{'name':input['env_secret']}}]
 assert c['command'][:2]==['/bin/sh','-c'] and c['command'][2].replace('$$','$').encode()==command
 assert digest(command)==HEREDOC and source['command_sha256']==HEREDOC and source['input']==input
 assert source['podtemplate_unchanged'] and source['only_outer_job_ownerReferences_changed']
 assert canonical['spec']['template']==anchored['spec']['template']
 restored=copy.deepcopy(anchored);restored['metadata']['ownerReferences']=canonical['metadata']['ownerReferences'];assert restored==canonical
 assert anchored['metadata']['ownerReferences']==[{'apiVersion':'v1','kind':'ConfigMap','name':input['anchor_name'],'uid':input['anchor_uid'],'controller':True}]
 return True

def delete_request(entry,name,owner):
 names(name,owner);assert entry['namespace']=='dev-8' and entry['kind'] in KINDS
 assert entry['owner']==owner and re.fullmatch(r'[a-f0-9-]{36}',entry['uid'])
 assert entry['name'].startswith(name+'-') or (entry['kind']=='Job' and entry['name'].startswith('predeploy-'+name+'-'))
 return KINDS[entry['kind']]+entry['name'],{'apiVersion':'v1','kind':'DeleteOptions','preconditions':{'uid':entry['uid']},'propagationPolicy':'Foreground'}

def pod_binding(job,pod,transport):
 assert pod['metadata']['ownerReferences'][0]['uid']==job['metadata']['uid']
 assert len(pod['spec']['containers'])==1 and pod['spec']['containers'][0]['image']==transport and pod['spec']['containers'][0]['imagePullPolicy']=='Always'
 assert transport.endswith('@'+MANIFEST)
 status=pod.get('status',{}).get('containerStatuses',[]);assert len(status)==1
 return status[0]

def command_diagnostics(commands,rows):
 versions=rows['BEX_COMMON_PREDEPLOY_VERSIONS'];programs=('node','npm','yarn','pnpm','/usr/bin/python3','python','python3','python3-config')
 assert isinstance(versions,dict) and set(versions)==set(programs)
 assert versions['node']['present'] is True and versions['/usr/bin/python3']['present'] is True
 # Other version probes are diagnostic; only node/systemPython and the final three commands require completion.
 expected=[]
 for program in programs:
  version=versions[program];assert type(version['present']) is bool
  if not version['present']:
   assert version=={'present':False};continue
  assert set(version)=={'present','resolved','realpath','command','stdout'} and isinstance(version['command'],dict) and isinstance(version['stdout'],str)
  assert isinstance(version['resolved'],str) and version['resolved'] and isinstance(version['realpath'],str)
  argv=[version['resolved'],'--includes' if program=='python3-config' else '--version']
  expected.append((argv,version['command'],program in ('node','/usr/bin/python3')))
 empty=['/usr/bin/python3','-c','import json,os;assert os.environ["PATH"]=="";print(json.dumps({"PATH":os.environ["PATH"],"cwd":os.getcwd()}))']
 expected.extend((argv,None,True) for argv in (empty,['/usr/bin/python3','utility-check.py','predeploy'],['/usr/bin/python3','original-cases.py','predeploy','node']))
 assert len(commands)==len(expected)
 output=[]
 for record,(argv,version_record,required) in zip(commands,expected):
  core={'argv','exit_code','bound','stdout_bytes','stdout_sha256','stderr_bytes','stderr_sha256'}
  assert isinstance(record,dict) and record['argv']==argv and type(record['exit_code']) is int
  assert record['bound'] in (None,'timeout','remaining-process-group','incomplete-output-after-stop','capture-size')
  for stream in ('stdout','stderr'):
   assert type(record[stream+'_bytes']) is int and record[stream+'_bytes']>=0 and re.fullmatch(r'[a-f0-9]{64}',record[stream+'_sha256'])
  if max(record['stdout_bytes'],record['stderr_bytes'])<=1<<20:
   assert set(record)==core|{'stdout_base64','stderr_base64'}
   decoded={}
   for stream in ('stdout','stderr'):
    raw=base64.b64decode(record[stream+'_base64'],validate=True)
    assert len(raw)==record[stream+'_bytes'] and digest(raw)==record[stream+'_sha256'];decoded[stream]=raw
  else:
   assert set(record)==core|{'full_output_not_retained'} and record['full_output_not_retained'] is True and record['bound']=='capture-size';decoded=None
  if version_record is not None:assert record==version_record
  if required:assert record['exit_code']==0 and record['bound'] is None and decoded is not None
  output.append(decoded)
 present=[versions[p] for p in programs if versions[p]['present']]
 for i,version in enumerate(present):
  if output[i] is not None:assert output[i]['stdout'].decode(errors='replace')==version['stdout']
 assert json.loads(output[-3]['stdout'])==rows['BEX_COMMON_PREDEPLOY_EMPTY_PATH_CHILD_ONLY']['observation']
 assert rows['BEX_COMMON_PREDEPLOY_EMPTY_PATH_CHILD_ONLY']['observation']=={'PATH':'','cwd':'/opt/render/project/src'}
 assert rows['BEX_COMMON_PREDEPLOY_EMPTY_PATH_CHILD_ONLY']['utilities_run_with_empty_PATH'] is False
 assert [json.loads(x['stdout']) for x in output[-2:]]==rows['BEX_COMMON_PREDEPLOY_MAINTAINED_PROGRAMS']
 return commands

def positive(job,pod,transport,log,expected42):
 s=pod_binding(job,pod,transport);assert job.get('status',{}).get('succeeded')==1 and pod['status']['phase']=='Succeeded'
 assert s['state']['terminated']['exitCode']==0 and s['restartCount']==0
 # Exact manifest reference only. A config-ID runtime needs separately retained actual runtime mapping, never a guessed alias.
 assert s['imageID'] in (transport,'docker-pullable://'+transport)
 rows={};commands=[]
 for line in log.splitlines():
  if not line.startswith('BEX_COMMON_PREDEPLOY_'):continue
  key,sep,value=line.partition(' ');assert sep
  if key=='BEX_COMMON_PREDEPLOY_COMMAND':commands.append(json.loads(value));continue
  assert key not in rows;rows[key]=json.loads(value)
 assert 'BEX_COMMON_PREDEPLOY_FAILURE' not in rows
 keys={'IDENTITY','SOURCE_BYTES','ENV_FILE','VERSIONS','EMPTY_PATH_CHILD_ONLY','MAINTAINED_PROGRAMS','HTTP_PROOFS','RETAINED_BUILD_ARTIFACTS','PASS'}
 assert set(rows)=={'BEX_COMMON_PREDEPLOY_'+x for x in keys}
 assert rows['BEX_COMMON_PREDEPLOY_SOURCE_BYTES']==expected42 and rows['BEX_COMMON_PREDEPLOY_ENV_FILE']['pass'] is True
 identity=rows['BEX_COMMON_PREDEPLOY_IDENTITY'];assert identity['cwd']=='/opt/render/project/src'
 maintained=rows['BEX_COMMON_PREDEPLOY_MAINTAINED_PROGRAMS'];assert len(maintained)==2 and all(x['pass'] is True and x['phase']=='predeploy' for x in maintained)
 mids={91,93,98,99,101,103,107};assert maintained[1]['mode']=='node' and {x['mid'] for x in maintained[1]['original_cases']}==mids
 proof=rows['BEX_COMMON_PREDEPLOY_HTTP_PROOFS'];assert set(proof)=={'runtime-'+str(x)+'-predeploy.json' for x in mids}
 assert all(isinstance(v,list) and len(v)==3 and all(x['pass'] is True for x in v) for v in proof.values())
 assert rows['BEX_COMMON_PREDEPLOY_PASS']['pass'] is True
 rows['BEX_COMMON_PREDEPLOY_COMMAND']=command_diagnostics(commands,rows)
 return rows

def auth_negative(job,pod,transport,wrong_secret,proxy_http_status):
 s=pod_binding(job,pod,transport)
 assert pod['spec']['imagePullSecrets']==[{'name':wrong_secret}]
 assert s.get('started') is False and s['restartCount']==0 and not s['imageID']
 waiting=s['state']['waiting'];assert waiting['reason'] in ('ErrImagePull','ImagePullBackOff')
 assert proxy_http_status==401 and ('401' in waiting['message'] or 'unauthorized' in waiting['message'].lower())
 return {'pass':True,'scope':'bounded actual wrong-auth denial after same image cached; not terminal Job/deadline proof','container_never_started':True,'observed_reason':waiting['reason']}

if __name__=='__main__':
 print(json.dumps(json.loads((Path(__file__).parent/'PLAN.json').read_bytes()),indent=2))
