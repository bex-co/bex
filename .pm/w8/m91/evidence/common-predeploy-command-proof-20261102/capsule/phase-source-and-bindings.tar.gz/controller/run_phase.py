"""One fixed dev8 predeploy phase. --plan/import are inert; execution needs Root's actual CI inputs."""
from pathlib import Path
import base64,copy,datetime,hashlib,importlib.util,io,json,os,re,secrets,shutil,signal,stat,subprocess,sys,tarfile,time
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('phase_data',HERE/'phase_adapter.py');a=importlib.util.module_from_spec(s);s.loader.exec_module(a)
s=importlib.util.spec_from_file_location('reviewed_v4',HERE/'retained-v4.py');v4=importlib.util.module_from_spec(s);s.loader.exec_module(v4)
NS='dev-8';KINDS=a.KINDS

def hashfile(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def read_descriptor(d):
 assert set(d)=={'path','bytes','sha256'}
 p=Path(d['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink() and s.st_size==d['bytes']<=2<<20 and hashfile(p)==d['sha256']
 return json.loads(p.read_bytes())
def ci_gate(cfg,plan):
 run=read_descriptor(cfg['ci']['run']);assert run['id']==plan['gates']['current_utility_run_reference_only'] and run['head_sha']==plan['gates']['required_source'] and run['head_branch']=='main' and run['event']=='workflow_dispatch'
 assert run['path']=='.github/workflows/native-common-image.yml'
 ids=[]
 for arch in ('amd64','arm64'):
  job=read_descriptor(cfg['ci'][arch]);assert job['run_id']==run['id'] and job['status']=='completed' and job['conclusion']=='success'
  if 'head_sha' in job:assert job['head_sha']==run['head_sha']
  if 'head_branch' in job:assert job['head_branch']=='main'
  assert arch in job['name'];ids.append(job['id'])
  steps=[x for x in job['steps'] if x['name']=='actual generated offline builds, original replays and exact-default SPDX']
  assert len(steps)==1 and steps[0]['conclusion']=='success'
 assert len(set(ids))==2
 return {'run_id':run['id'],'source':run['head_sha'],'job_ids':ids,'scope':'Actual whole-job success binding only; Root separately reviews complete current utility artifacts before invoking this fixed phase.'}

def verify_source(plan):
 eq=json.loads((HERE/'SOURCE-EQUIVALENCE.json').read_bytes())
 assert eq['built_source']=='6883953e58e750fb41763d1d5e4bd4103bdb74c5' and eq['current_source']==plan['gates']['required_source']
 assert not eq['source848_missing'] and not eq['functional300_additions'] and not eq['functional300_deletions']
 assert eq['functional300_changed']==['lego/operator/internal/build/dockerhub.go','lego/operator/internal/build/dockerhub_test.go','lego/operator/internal/build/nativequalification_init_test.go','lego/operator/internal/build/nativeutility_integration_test.go']
 source=Path(eq['current_snapshot_root']);manifest=read_descriptor(eq['current_functional300_manifest'])
 assert manifest['source']==plan['gates']['required_source'] and len(manifest['files'])==300
 for name,w in manifest['files'].items():
  q=source/name;observed=q.lstat();assert stat.S_ISREG(observed.st_mode) and not q.is_symlink() and observed.st_size==w['bytes'] and hashfile(q)==w['sha256'] and stat.S_IMODE(observed.st_mode)==w['permissions']
 for name,w in eq['canonical_A_sources13_current'].items():
  q=source/name;assert q.stat().st_size==w['bytes'] and hashfile(q)==w['sha256']
 for name,w in eq['fixtures42_unchanged'].items():
  q=source/w['source_path'];assert q.stat().st_size==w['bytes'] and hashfile(q)==w['sha256']
 proof=read_descriptor(eq['current_offline_output_equivalence'])
 assert proof['PASS'] and not proof['rebuild_required_for_deterministic_output_change'] and all(proof['B_recipe_env_choices_receipt_byte_exact'].values())
 assert len(proof['B_all46_context_bytes_and_modes_exact'])==46 and all(x['bytes_equal'] and x['mode_equal'] for x in proof['B_all46_context_bytes_and_modes_exact'].values())
 assert all(proof['A_positive_canonical_raw_byte_equal'][name] for name in ('canonical-job.json','canonical-podtemplate.json','anchored-job.json','synthetic-secrets.json'))
 assert proof['A_negative_generation2_wrongpull_actual_export'] and proof['A_generation1_wrongpull_actual_rejected']
 for d in (plan['canonical_A']['exporter_binary'],plan['canonical_A']['observer'],plan['canonical_A']['heredoc'],plan['source_only_tool_checks']['ORAS_binary']):assert Path(d['path']).stat().st_size==d['bytes'] and hashfile(d['path'])==d['sha256']
 archive=plan['child']['oci_tar'];assert Path(archive['path']).stat().st_size==archive['bytes'] and hashfile(archive['path'])==archive['sha256']
 return eq

def admission_preserved(request,actual,pod,node_name):
 """Same old phase defaults, recorded and value-checked; never modify original objects."""
 want=request['spec']['template'];got=copy.deepcopy(actual['spec']['template']);changes=[]
 labels=got['metadata']['labels']
 for key,value in [('batch.kubernetes.io/controller-uid',actual['metadata']['uid']),('controller-uid',actual['metadata']['uid']),('batch.kubernetes.io/job-name',actual['metadata']['name']),('job-name',actual['metadata']['name'])]:
  if key not in want['metadata'].get('labels',{}) and key in labels:
   assert labels.pop(key)==value;changes.append({'path':'metadata.labels.'+key,'actual':value})
 def normalize(spec,expected,prefix):
  for key,value in [('dnsPolicy','ClusterFirst'),('schedulerName','default-scheduler'),('terminationGracePeriodSeconds',30)]:
   if key not in expected and key in spec:
    assert spec.pop(key)==value;changes.append({'path':prefix+'.'+key,'actual':value})
  for i,container in enumerate(spec['containers']):
   for key,value in [('terminationMessagePath','/dev/termination-log'),('terminationMessagePolicy','File')]:
    if key not in expected['containers'][i] and key in container:
     assert container.pop(key)==value;changes.append({'path':prefix+'.containers.'+str(i)+'.'+key,'actual':value})
  for i,volume in enumerate(spec.get('volumes',[])):
   if 'projected' in volume and 'defaultMode' not in expected['volumes'][i].get('projected',{}) and 'defaultMode' in volume['projected']:
    assert volume['projected'].pop('defaultMode')==420;changes.append({'path':prefix+'.volumes.'+str(i)+'.projected.defaultMode','actual':420})
 normalize(got['spec'],want['spec'],'Job.template.spec');assert got==want
 actualspec=copy.deepcopy(pod['spec']);expected=want['spec']
 for key,value in [('nodeName',node_name),('serviceAccount','default'),('serviceAccountName','default'),('priority',0),('preemptionPolicy','PreemptLowerPriority'),('tolerations',[{'effect':'NoExecute','key':'node.kubernetes.io/not-ready','operator':'Exists','tolerationSeconds':300},{'effect':'NoExecute','key':'node.kubernetes.io/unreachable','operator':'Exists','tolerationSeconds':300}])]:
  if key not in expected and key in actualspec:
   assert actualspec.pop(key)==value;changes.append({'path':'Pod.spec.'+key,'actual':value})
 normalize(actualspec,expected,'Pod.spec');assert actualspec==expected
 assert all(pod['metadata']['labels'].get(k)==v for k,v in want['metadata'].get('labels',{}).items())
 return changes

def job_creation_request(anchored):
 request=copy.deepcopy(anchored);assert not request['metadata'].get('uid')
 removed={k:request['metadata'].pop(k) for k in ('resourceVersion','creationTimestamp') if k in request['metadata']}
 assert request['spec']['template']==anchored['spec']['template']
 restored=copy.deepcopy(request);restored['metadata'].update(removed);assert restored==anchored
 return request,removed

class Phase:
 def __init__(self,plan,cfg):
  self.p,self.cfg=plan,cfg;self.root=Path(plan['runtime_root_proposal']);self.e=self.root/'evidence';self.private=self.root/'private'
  self.owner,self.name=plan['local_resource_owner'],plan['app_name'];self.n=a.names(self.name,self.owner)
  self.k=['/opt/homebrew/bin/kubectl','--kubeconfig','/Users/tianpan/projects/bex7/.pm/w8/dev-8/.kubeconfig','--cache-dir',str(self.private/'kube-cache'),'--request-timeout=10s']
  self.env={'PATH':os.environ['PATH'],'DOCKER_HOST':'unix:///Users/tianpan/.orbstack/run/docker.sock','DOCKER_CONFIG':str(self.private/'docker-config'),'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(self.private/'tmp')}
  self.started=time.monotonic();self.cancel=None;self.groups={};self.pending_unproved=set();self.calls=[];self.entries=[];self.bodies={};self.docker={};self.volumes={};self.errors=[];self.pending=[];self.baseline=None;self.cleaning=False;self.cleanup_deadline=None
  self.origin_port=self.proxy_port=self.node_cid=self.transport=None;self.anchor=None;self.peak_bytes=0;self.free0=shutil.disk_usage(HERE).free;self.minfree=self.free0;self.last_observe=0
 def save(self,n,x):
  p=self.e/n;p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n');p.chmod(0o600)
 def usage(self):return sum(p.stat().st_size for p in self.root.rglob('*') if p.is_file() and not p.is_symlink()) if self.root.exists() else 0
 def resource_reason(self):
  used=self.usage();free=shutil.disk_usage(self.root if self.root.exists() else HERE).free;self.peak_bytes=max(self.peak_bytes,used);self.minfree=min(self.minfree,free)
  if self.cancel:return 'cancelled'
  elapsed=time.monotonic()-self.started
  if elapsed>2400:return 'whole2400s'
  if not self.cleaning and elapsed>2100:return 'creation2100s cleanup300s reserved'
  temporary=sum(p.stat().st_size for p in (self.private/'tmp').rglob('*') if p.is_file()) if (self.private/'tmp').exists() else 0
  if temporary>128<<20:return 'own tooltemporary128MiB'
  if used-temporary>64<<20:return 'own metadata64MiB'
  if free<8<<30 or self.free0-free>2<<30:return 'physical8GiB/globaldrop2GiB'
  return None
 def command(self,label,argv,data=None,seconds=20,retain=True,cleanup=False,observe=False):
  if self.pending_unproved:raise RuntimeError('prior client process-group absence unproved; refusing new command')
  if self.cleaning and self.groups:raise RuntimeError('cleanup client process-group absence unproved; refusing new command')
  if not cleanup:
   why=self.resource_reason()
   if why:raise RuntimeError(why)
  elif self.cleanup_deadline is not None:
   seconds=min(seconds,max(0,self.cleanup_deadline-time.monotonic()))
   if seconds<=0:raise RuntimeError('finally300s exhausted')
  p=None;out=err=b'';bound=None;began=time.monotonic();caught=None
  try:
   p=subprocess.Popen(argv,env=self.env,stdin=subprocess.PIPE if data is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);self.groups[p.pid]=p
   first=True
   while True:
    try:out,err=p.communicate(input=data if first else None,timeout=.2);break
    except subprocess.TimeoutExpired as ex:
     first=False
     if len(ex.output or b'')>2<<20 or len(ex.stderr or b'')>2<<20:bound='response2MiB';break
     if time.monotonic()-began>seconds:bound='command deadline';break
     if not cleanup:
      why=self.resource_reason()
      if why:bound=why;break
      if observe:self.observe()
  except BaseException as error:
   caught=error;bound=bound or ('client/observer:'+type(error).__name__)
  finally:
   if p is not None:
    absent=v4.stop_group(p)
    if absent:self.groups.pop(p.pid,None);self.pending_unproved.discard(p.pid)
    else:self.pending_unproved.add(p.pid)
    try:out,err=p.communicate(timeout=2)
    except subprocess.TimeoutExpired:bound=bound or 'capture incomplete'
   else:absent=False
  if len(out)>2<<20 or len(err)>2<<20:bound=bound or 'final response2MiB'
  number=len(self.calls);stem=f'{number:04d}-'+label
  row={'label':label,'argv':argv,'exit_code':p.returncode if p else None,'bound':bound,'group_absent':absent,'seconds':round(time.monotonic()-began,3),'stdout_bytes':len(out),'stderr_bytes':len(err),'stdout_sha256':hashlib.sha256(out).hexdigest(),'stderr_sha256':hashlib.sha256(err).hexdigest(),'stdin_bytes':len(data) if data else 0,'stdin_sha256':hashlib.sha256(data).hexdigest() if data else None,'raw_retained':retain}
  if retain:
   (self.e/(stem+'.stdout')).write_bytes(out[:2<<20]);(self.e/(stem+'.stderr')).write_bytes(err[:2<<20]);row.update(stdout=stem+'.stdout',stderr=stem+'.stderr',raw_complete=len(out)<=2<<20 and len(err)<=2<<20)
  self.calls.append(row);self.save('calls.json',self.calls)
  if bound or not absent:raise RuntimeError(label+': '+str(bound or 'process group unproved')) from caught
  return p.returncode,out,err
 def checked(self,label,argv,**kw):
  code,out,err=self.command(label,argv,**kw)
  if code:raise RuntimeError(label+': nonzero '+str(code))
  return out
 @staticmethod
 def cached_child_state(raw,reference):
  lines=raw.decode('utf-8').splitlines();assert len(lines)==2 and lines[0].split()==['REF','TYPE','DIGEST','STATUS','SIZE','UNPACKED']
  match=re.fullmatch(re.escape(reference)+r'\s+application/vnd\.oci\.image\.manifest\.v1\+json\s+'+re.escape(a.MANIFEST)+r'\s+(complete|incomplete) \((\d+)/(\d+)\)\s+\d+(?:\.\d+)? [KMGT]?i?B/\d+(?:\.\d+)? [KMGT]?i?B\s+(true|false)\s*',lines[1]);assert match
  available,total=int(match[2]),int(match[3]);complete=match[1]=='complete'
  assert 0<=available<=total and total>0 and complete==(available==total)
  return {'compressed_complete':complete,'available_content_objects':available,'expected_content_objects':total,'unpacked':match[4]=='true'}
 def require_cached_child(self,label):
  expected=self.p['fresh_baseline_reference_only']['tenant_node'];cached=self.cached_child;reference=self.p['cached_child_operating_input']['owned_reference']
  assert cached['tenant']['name']==expected['name'] and cached['tenant']['NodeUID']==expected['uid'] and cached['tenant']['DockerCID']==self.node_cid
  assert cached['unpacked'] is True and type(cached['compressed_complete']) is bool and cached['owned_reference']==reference and cached['config']['digest']==a.CONFIG and cached['platform_manifest']['digest']==a.MANIFEST
  raw=self.checked('cached-child-'+label,['docker','exec',self.node_cid,'crictl','inspecti','--quiet','--output','json',a.CONFIG],seconds=20)
  status=json.loads(raw)['status'];assert status['id']==a.CONFIG and reference in status['repoDigests']
  manifest=self.checked('cached-child-manifest-'+label,['docker','exec',self.node_cid,'ctr','--namespace','k8s.io','content','get',a.MANIFEST],seconds=20)
  assert 'sha256:'+hashlib.sha256(manifest).hexdigest()==a.MANIFEST and json.loads(manifest)['config']['digest']==a.CONFIG
  check=self.checked('cached-child-unpacked-'+label,['docker','exec',self.node_cid,'ctr','--namespace','k8s.io','images','check','name=="'+reference+'"'],seconds=20)
  state=Phase.cached_child_state(check,reference);assert state['unpacked'] is True
  self.save('cached-child-'+label+'.json',{'node':expected['name'],'node_uid':expected['uid'],'docker_cid':self.node_cid,'reference':reference,'manifest':a.MANIFEST,'config':a.CONFIG,**state,'status_sha256':hashlib.sha256(raw).hexdigest(),'manifest_sha256':hashlib.sha256(manifest).hexdigest(),'ctr_check_sha256':hashlib.sha256(check).hexdigest(),'scope':'Fresh exact-node unpacked snapshot precondition only. Incomplete compressed content is recorded and allowed; repull may exceed operating limits and leave phase UNPROVED. No reservation or completion guarantee.'})
 def observe(self):
  now=time.monotonic()
  if now-self.last_observe<1:return
  self.last_observe=now;rows=[]
  for role,record in self.docker.items():
   if role not in ('origin','proxy') or not record.get('id') or record.get('removed'):continue
   code,out,_=self.command('du-'+role,['docker','exec',record['id'],'du','-sk','/var/lib/registry'],seconds=10,cleanup=True)
   if code or not re.fullmatch(rb'\d+\s+/var/lib/registry\n?',out):raise RuntimeError('ownregistry measurement unavailable')
   size=int(out.split()[0])*1024;cap={'origin':1280<<20,'proxy':128<<20}[role];rows.append({'role':role,'allocated_bytes':size,'operating_limit_bytes':cap})
   if size>cap:raise RuntimeError('ownregistry '+role+' cache cap')
  self.save('resource-observation.json',{'rows':rows,'physical_free_bytes':shutil.disk_usage(self.root).free,'root_bytes':self.usage()})
 def kube_command(self,label,args,**kw):
  verb=args[2] if len(args)>2 and args[:2]==['-n',NS] else args[0] if args else ''
  for attempt in range(3):
   result=self.command(label if attempt==0 else label+'-read-retry-'+str(attempt+1),self.k+args,**kw)
   code,out,err=result
   transient=re.fullmatch(rb'Unable to connect to the server: (?:context deadline exceeded(?: \(Client.Timeout exceeded while awaiting headers\))?|[^\n]*: (?:connection reset by peer|i/o timeout))\n?',err)
   if verb!='get' or kw.get('data') is not None or code!=1 or out or not transient:return result
  return result
 def kube(self,label,args,**kw):
  code,out,_=self.kube_command(label,args,**kw)
  if code:raise RuntimeError(label+': nonzero '+str(code))
  return out
 @staticmethod
 def notfound(err):return re.fullmatch(rb'Error from server \(NotFound\): [^\n]+ not found\n?',err) is not None
 def get(self,kind,name,cleanup=False,secret=False):
  code,out,err=self.kube_command('get-'+kind+'-'+name,['-n',NS,'get',kind,name,'-o','json'],retain=not secret,cleanup=cleanup)
  if code==1 and self.notfound(err):return None
  if code:raise RuntimeError('get identity unproved')
  return json.loads(out)
 def identities(self,cleanup=False):
  jp='{range .items[*]}{.kind}{"\\t"}{.metadata.name}{"\\t"}{.metadata.uid}{"\\n"}{end}'
  raw=self.kube('baseline',['-n',NS,'get','apps.app.bex.co,jobs,pods,secrets,configmaps,networkpolicies,resourcequotas,limitranges','-o','jsonpath='+jp],cleanup=cleanup)
  return sorted([line.split('\t') for line in raw.decode().splitlines()])
 def guard(self,cleanup=False):
  if not cleanup:
   why=self.resource_reason()
   if why:raise RuntimeError(why)
  p=self.p['fresh_baseline_reference_only']
  ns=self.kube('namespace',['get','namespace',NS,'-o','jsonpath={.metadata.uid}'],cleanup=cleanup).decode();sa=self.kube('default-sa',['-n',NS,'get','sa','default','-o','jsonpath={.metadata.uid}'],cleanup=cleanup).decode()
  ca=self.kube('root-ca',['-n',NS,'get','configmap','kube-root-ca.crt','-o','jsonpath={.metadata.uid}{"\\n"}{.data.ca\\.crt}'],cleanup=cleanup,retain=False);uid,sep,body=ca.partition(b'\n');assert sep
  observed={'namespace_uid':ns,'default_sa_uid':sa,'ca_uid':uid.decode(),'ca_sha256':hashlib.sha256(body).hexdigest()}
  assert ns==p['namespace']['uid'] and sa==p['default_serviceaccount']['uid'] and uid.decode()==p['root_ca_hash_only']['uid'] and observed['ca_sha256']==p['root_ca_hash_only']['sha256']
  self.save('guard-latest.json',observed)
 def metadata_only(self,kind,name,cleanup=False):
  code,out,err=self.kube_command('metadata-'+kind+'-'+name,['-n',NS,'get',kind,name,'-o','jsonpath={.metadata}'],cleanup=cleanup)
  if code==1 and self.notfound(err):return None
  if code:raise RuntimeError('metadata identity unproved')
  return json.loads(out)
 def create(self,obj):
  self.guard();kind=obj['kind'];name=obj['metadata']['name'];assert kind in KINDS and obj['metadata']['namespace']==NS
  assert name.startswith(self.name+'-') or (kind=='Job' and name.startswith('predeploy-'+self.name+'-'))
  assert not any(x['kind']==kind and x['name']==name for x in self.entries),'never repeat create'
  assert self.metadata_only(kind,name) is None,'own proposed name preexists; no adoption or write'
  body=json.dumps(obj,separators=(',',':')).encode();entry={'kind':kind,'name':name,'namespace':NS,'owner':self.owner,'uid':None,'unknown':True,'request_sha256':hashlib.sha256(body).hexdigest()};self.entries.append(entry);self.bodies[(kind,name)]=copy.deepcopy(obj);self.save('ledger.json',self.entries)
  try:
   raw=self.kube('create-'+kind,['create','-f','-','-o','json'],data=body,seconds=30,retain=kind!='Secret');row=json.loads(raw)
   assert self.acknowledged_object_matches(row,obj) and re.fullmatch(r'[a-f0-9-]{36}',row['metadata']['uid'])
   entry.update(uid=row['metadata']['uid'],unknown=False,creation_timestamp=row['metadata']['creationTimestamp']);self.save('ledger.json',self.entries)
   self.save('created-'+name+'.json',{'apiVersion':row['apiVersion'],'kind':kind,'metadata':row['metadata'],'type':row.get('type'),'data_keys':sorted(row.get('data',{}))} if kind=='Secret' else row)
   return row
  except BaseException:
   self.save('ledger.json',self.entries);raise
 @staticmethod
 def acknowledged_object_matches(actual,requested):
  if isinstance(actual,dict) and isinstance(requested,dict) and actual.get('kind')==requested.get('kind')=='NetworkPolicy':
   want,got=requested.get('spec'),actual.get('spec')
   if isinstance(want,dict) and want.get('egress')==[] and isinstance(got,dict) and 'egress' not in got:
    actual=copy.deepcopy(actual);actual['spec']['egress']=[]
  return Phase.matches(actual,requested)
 @staticmethod
 def matches(actual,requested):
  if isinstance(requested,dict):return isinstance(actual,dict) and all(k in actual and Phase.matches(actual[k],v) for k,v in requested.items())
  if isinstance(requested,list):return isinstance(actual,list) and len(actual)==len(requested) and all(Phase.matches(x,y) for x,y in zip(actual,requested))
  return actual==requested
 def resolve_unknown(self,entry):
  meta=self.metadata_only(entry['kind'],entry['name'],cleanup=True)
  if meta is None:return None #404 cannot clear a submitted POST.
  requested=self.bodies[(entry['kind'],entry['name'])]
  if entry['kind']=='Job':assert meta.get('ownerReferences')==requested['metadata']['ownerReferences']
  else:assert meta.get('labels',{}).get('bex.co/qa-owner')==self.owner
  row=self.get(entry['kind'],entry['name'],cleanup=True,secret=entry['kind']=='Secret')
  if row is None:return None # Crucially,404 does NOT clear an uncertain POST.
  assert self.acknowledged_object_matches(row,self.bodies[(entry['kind'],entry['name'])])
  assert re.fullmatch(r'[a-f0-9-]{36}',row['metadata']['uid'])
  entry.update(uid=row['metadata']['uid'],unknown=False,resolved_by='exact-owned-read');self.save('ledger.json',self.entries)
  return row
 def inspect(self,kind,name,role=None):
  code,out,err=self.command('inspect-'+kind+'-'+name,['docker',kind,'inspect',name],cleanup=True)
  if code==0:
   rows=json.loads(out);assert len(rows)==1;return rows[0]
  messages={'container':('Error response from daemon: No such container: '+name,'Error: No such container: '+name,'Error: No such object: '+name),'volume':('Error response from daemon: get '+name+': no such volume','Error response from daemon: No such volume: '+name)}
  if code==1 and out.strip() in (b'',b'[]') and err.decode().strip() in messages[kind]:return None
  raise RuntimeError('docker absence unproved')
 def volume(self,role):
  name=self.owner+'-'+role+'-data';assert self.inspect('volume',name) is None
  self.volumes[role]={'name':name,'unknown':True};self.save('docker-ledger.json',{'containers':self.docker,'volumes':self.volumes})
  raw=self.checked('volume-'+role,['docker','volume','create','--label','bex.qa.owner='+self.owner,name]);assert raw.decode().strip()==name
  row=self.inspect('volume',name);assert row['Name']==name and row['Labels']['bex.qa.owner']==self.owner
  self.volumes[role]['unknown']=False;return name
 def container(self,role,args,image):
  name=self.owner+'-'+role;assert self.inspect('container',name) is None
  self.docker[role]={'name':name,'image':image,'id':None,'unknown':True};self.save('docker-ledger.json',{'containers':self.docker,'volumes':self.volumes})
  raw=self.checked('create-'+role,['docker','create','--name',name,'--label','bex.qa.owner='+self.owner,*args,image],seconds=30)
  assert re.fullmatch(rb'[a-f0-9]{64}\n?',raw);cid=raw.decode().strip();self.docker[role].update(id=cid,unknown=False);self.save('docker-ledger.json',{'containers':self.docker,'volumes':self.volumes})
  row=self.inspect('container',name);self.bind_container(role,row)
  return cid
 def transport_setup(self):
  registry=self.p['steps'][2]['argv_template'][-1] # Cached historical Registry config, freshly inspected before use.
  assert registry=='sha256:0c922d46158ce6e7d062337afbef4367aa80e2601de34522171ad8de06fd5b87'
  raw=self.checked('registry-image',['docker','image','inspect','--format','{{.Id}} {{.Os}}/{{.Architecture}}',registry]);assert raw.decode().strip()==registry+' linux/arm64'
  expected=self.p['fresh_baseline_reference_only']['tenant_node'];name=expected['name']
  node=self.kube('tenant-node',['get','node',name,'-o','jsonpath={.metadata.uid}{"\\t"}{.status.nodeInfo.architecture}{"\\t"}{.status.conditions[?(@.type=="Ready")].status}']).decode();assert node==expected['uid']+'\tarm64\tTrue'
  raw=self.checked('tenant-docker',['docker','container','inspect','--format','{{json .Id}} {{json .Name}}',name]);m=re.fullmatch(rb'"([a-f0-9]{64})" "([^"\n]+)"\n?',raw);assert m and m[2].decode()=='/'+name;self.node_cid=m[1].decode()
  self.require_cached_child('before-registries')
  originvol=self.volume('origin');cid=self.container('origin',['--pull=never','--platform','linux/arm64','--memory','512m','--cpus','1','--pids-limit','128','--cap-drop','ALL','--security-opt','no-new-privileges','--publish','127.0.0.1::5000','--mount','type=volume,src='+originvol+',dst=/var/lib/registry'],registry)
  self.checked('start-origin',['docker','start',cid]);row=self.inspect('container',self.owner+'-origin');ports=row['NetworkSettings']['Ports']['5000/tcp'];assert len(ports)==1 and ports[0]['HostIp']=='127.0.0.1';self.origin_port=int(ports[0]['HostPort']);assert 0<self.origin_port<65536
  target='127.0.0.1:'+str(self.origin_port)+'/'+self.name
  ready_until=time.monotonic()+20
  while True:
   code,out,_=self.command('origin-ready',['/usr/bin/curl','--disable','--silent','--show-error','--max-time','5','--output','/dev/null','--write-out','%{http_code}','http://127.0.0.1:'+str(self.origin_port)+'/v2/'],seconds=10)
   if code==0 and out==b'200':break
   if time.monotonic()>ready_until:raise RuntimeError('own origin readiness20s')
   time.sleep(.5)
  config=str(self.private/'empty-auth.json');(self.private/'empty-auth.json').write_text('{"auths":{}}\n')
  oras='/opt/homebrew/bin/oras';archive=self.p['child']['oci_tar'];assert hashfile(archive['path'])==archive['sha256'] and Path(archive['path']).stat().st_size==archive['bytes']
  self.checked('oras-copy',[oras,'cp','--from-oci-layout','--from-registry-config',config,'--to-registry-config',config,'--to-plain-http','--concurrency','1',archive['path']+'@'+a.MANIFEST,target+':source688'],seconds=600,observe=True)
  raw=self.checked('origin-manifest',['/usr/bin/curl','--disable','--fail','--silent','--show-error','--max-time','10','--header','Accept: application/vnd.oci.image.manifest.v1+json','http://127.0.0.1:'+str(self.origin_port)+'/v2/'+self.name+'/manifests/'+a.MANIFEST],seconds=20);assert 'sha256:'+hashlib.sha256(raw).hexdigest()==a.MANIFEST
  manifest=json.loads(raw);assert manifest['config']['digest']==a.CONFIG and len(manifest['layers'])==35
  actual=json.loads(Path('/private/tmp/bex-w8-common-predeploy-build-20261101-4bff55bed15b1d32/evidence/OCI-IDENTITY.json').read_bytes());assert manifest['layers']==actual['layers']
  # Raw owned-loopback HTTP bytes, never CLI pretty-print/newline normalization.
  rawcfg=self.checked('origin-config',['/usr/bin/curl','--disable','--fail','--silent','--show-error','--max-time','10','http://127.0.0.1:'+str(self.origin_port)+'/v2/'+self.name+'/blobs/'+a.CONFIG],seconds=20);assert 'sha256:'+hashlib.sha256(rawcfg).hexdigest()==a.CONFIG
  image=json.loads(rawcfg);assert image['config']['Labels']['org.opencontainers.image.revision']==a.REVISION and 'NODE_VERSION=24.22.1' in image['config']['Env']
  raw=self.checked('node-listeners',['docker','exec',self.node_cid,'ss','-H','-ltn']);self.proxy_port=next(p for p in range(43829,43929) if not re.search(rb':'+str(p).encode()+rb'\s',raw))
  password=secrets.token_urlsafe(32);wrong=secrets.token_urlsafe(32);user='dev8-qa'
  h=self.checked('htpasswd',['/usr/sbin/htpasswd','-niB',user],data=(password+'\n').encode(),retain=False);(self.private/'htpasswd').write_bytes(h)
  proxyvol=self.volume('proxy');cid=self.container('proxy',['--pull=never','--platform','linux/arm64','--network','container:'+self.node_cid,'--memory','512m','--cpus','1','--pids-limit','128','--cap-drop','ALL','--security-opt','no-new-privileges','--mount','type=volume,src='+proxyvol+',dst=/var/lib/registry','--env','REGISTRY_HTTP_ADDR=127.0.0.1:'+str(self.proxy_port),'--env','REGISTRY_PROXY_REMOTEURL=http://host.docker.internal:'+str(self.origin_port),'--env','REGISTRY_AUTH=htpasswd','--env','REGISTRY_AUTH_HTPASSWD_REALM='+self.owner,'--env','REGISTRY_AUTH_HTPASSWD_PATH=/tmp/qa-htpasswd'],registry)
  stream=io.BytesIO()
  with tarfile.open(fileobj=stream,mode='w') as tar:
   entry=tarfile.TarInfo('qa-htpasswd');entry.mode=0o644;entry.uid=entry.gid=0;entry.size=len(h);tar.addfile(entry,io.BytesIO(h))
  self.checked('copy-hash',['docker','cp','-',cid+':/tmp'],data=stream.getvalue());self.checked('start-proxy',['docker','start',cid])
  host='localhost:'+str(self.proxy_port);url='http://'+host+'/v2/'+self.name+'/manifests/'+a.MANIFEST
  def curl(passwd,status=False):
   conf='url = "'+url+'"\nheader = "Accept: application/vnd.oci.image.manifest.v1+json"\n'
   if passwd is not None:conf+='user = "'+user+':'+passwd+'"\n'
   args=['docker','exec','-i',self.node_cid,'curl','--disable','--silent','--show-error','--max-time','5']
   args+=['--output','/dev/null','--write-out','%{http_code}'] if status else ['--fail']
   return self.checked('proxy-probe',args+['--config','-'],data=conf.encode(),seconds=10)
  deadline=time.monotonic()+20
  while True:
   try:good=curl(password);break
   except RuntimeError:
    if time.monotonic()>deadline:raise
    time.sleep(.5)
  assert 'sha256:'+hashlib.sha256(good).hexdigest()==a.MANIFEST and curl(None,True)==b'401' and curl(wrong,True)==b'401'
  self.transport=host+'/'+self.name+'@'+a.MANIFEST
  def config(p):return {'auths':{host:{'auth':base64.b64encode((user+':'+p).encode()).decode()}}}
  goodcfg,badcfg=config(password),config(wrong)
  self.save('transport.json',{'origin_manifest':a.MANIFEST,'config':a.CONFIG,'transport':self.transport,'origin_port':self.origin_port,'proxy_port':self.proxy_port,'tenant_container':self.node_cid,'good_manifest200':True,'noauth401':True,'wrong401':True})
  return goodcfg,badcfg
 def canonical_job(self,route):
  wrong=route=='negative';generation=2 if wrong else 1;out=self.root/('exports-'+route);(out/'controller-export').mkdir(parents=True,mode=0o700);inputs=self.private/('inputs-'+route);inputs.mkdir(mode=0o700)
  command=Path(self.p['canonical_A']['heredoc']['path']);inp=a.input_from_anchor(self.anchor,self.name,self.owner,self.transport,'/templates/A/command.txt',generation,wrong);(inputs/'controller-input.json').write_text(json.dumps(inp)+'\n')
  exported=Path(self.p['canonical_A']['source_root']);templates=command.parents[1];image='sha256:ab3fe4defd29ba6231229a4d41440ac8bde8218e85870e53876277faa24b35c4'
  args=['--pull=never','--platform','linux/arm64','--read-only','--network','none','--memory','512m','--cpus','1','--pids-limit','128','--tmpfs','/tmp:rw,nosuid,nodev,size=64m','--workdir','/source/lego/operator/internal/controller']
  for src,dst in [(exported,'/source'),(Path(self.p['canonical_A']['exporter_binary']['path']),'/exporter'),(templates,'/templates'),(inputs,'/inputs')]:args+=['--mount','type=bind,src='+str(src)+',dst='+dst+',readonly']
  args+=['--mount','type=bind,src='+str(out)+',dst=/private/tmp','--env','BEX_COMMON_PREDEPLOY_INPUT=/inputs/controller-input.json','--env','BEX_COMMON_PREDEPLOY_OUTPUT=/private/tmp/controller-export','--entrypoint','/exporter']
  # container() appends its image; test arguments belong after it.
  role='export-'+route;name=self.owner+'-'+role;assert self.inspect('container',name) is None
  self.docker[role]={'name':name,'image':image,'id':None,'unknown':True};self.save('docker-ledger.json',{'containers':self.docker,'volumes':self.volumes})
  raw=self.checked('create-'+role,['docker','create','--name',name,'--label','bex.qa.owner='+self.owner,*args,image,'-test.run','^TestScratchCommonPredeployExport$','-test.v','-test.count=1','-test.timeout=2m'],seconds=30);assert re.fullmatch(rb'[a-f0-9]{64}\n?',raw)
  cid=raw.decode().strip();self.docker[role].update(id=cid,unknown=False);self.bind_container(role,self.inspect('container',name));self.checked('run-'+role,['docker','start','--attach',cid],seconds=150,observe=True)
  j=json.loads((out/'controller-export/canonical-job.json').read_bytes());anchored=json.loads((out/'controller-export/anchored-job.json').read_bytes());source=json.loads((out/'controller-export/export-source.json').read_bytes())
  a.validate_export(j,anchored,source,inp,command.read_bytes());expected=json.loads((HERE/'SOURCE-EQUIVALENCE.json').read_bytes())['canonical_A_sources13_current'];assert source['source_hashes']=={p:{'bytes':w['bytes'],'sha256':w['sha256']} for p,w in expected.items()}
  self.remove_container(role)
  # Same server-bookkeeping cleanup as retained run.py.generate; PodTemplate untouched.
  request,removed=job_creation_request(anchored)
  self.save(route+'-Job-creation-bookkeeping.json',{'removed_outer_server_metadata':removed,'PodTemplate_unchanged':True})
  self.save(route+'-Job-request.json',request);return request
 def observe_job(self,job,negative=False):
  until=time.monotonic()+(90 if negative else 620);last=None
  while time.monotonic()<until:
   self.guard();actual=self.get('Job',job['metadata']['name']);assert actual and actual['metadata']['uid']==job['metadata']['uid']
   raw=self.kube('own-pods',['-n',NS,'get','pods','-l','job-name='+job['metadata']['name'],'-o','json']);pods=json.loads(raw)['items']
   assert len(pods)<=1
   if pods:
    pod=pods[0];assert pod['metadata']['ownerReferences'][0]['uid']==job['metadata']['uid'];last=(actual,pod)
    differences=admission_preserved(self.bodies[('Job',job['metadata']['name'])],actual,pod,self.p['fresh_baseline_reference_only']['tenant_node']['name']);self.save(('negative' if negative else 'positive')+'-admission-defaults.json',differences)
    if negative:
     try:result=a.auth_negative(actual,pod,self.transport,self.n['wrong'],401)
     except (KeyError,AssertionError):result=None
     if result:return actual,pod,result
     statuses=pod.get('status',{}).get('containerStatuses',[])
     if statuses and (statuses[0].get('started') or statuses[0].get('imageID') or statuses[0].get('state',{}).get('terminated')):raise RuntimeError('wrongsecret container started/unexpected terminal')
    elif actual.get('status',{}).get('succeeded')==1:
     log=self.kube('positive-log',['-n',NS,'logs',pod['metadata']['name']],seconds=20)
     expected={p:{'bytes':w['bytes'],'sha256':w['sha256']} for p,w in json.loads((HERE/'SOURCE-EQUIVALENCE.json').read_bytes())['fixtures42_unchanged'].items()}
     boundpod=pod
     status=pod.get('status',{}).get('containerStatuses',[{}])[0]
     if status.get('imageID')==a.CONFIG:
      # Only an actual CRI mapping can justify config-ID normalization; original Pod is retained unchanged.
      rawmap=self.checked('actual-CRI-mapping',['docker','exec',self.node_cid,'crictl','inspecti','--output','json',a.CONFIG],seconds=20)
      mapping=json.loads(rawmap);assert mapping['status']['id']==a.CONFIG and self.transport in mapping['status']['repoDigests']
      self.save('actual-CRI-imageID-binding.json',{'original_Pod_imageID':a.CONFIG,'exact_repoDigest':self.transport,'actual_CRI_mapping_sha256':hashlib.sha256(rawmap).hexdigest(),'scope':'actualruntime config-to-manifest mapping, never guessed alias'})
      boundpod=copy.deepcopy(pod);boundpod['status']['containerStatuses'][0]['imageID']=self.transport
     result=a.positive(actual,boundpod,self.transport,log.decode(),expected);return actual,pod,result
    elif actual.get('status',{}).get('failed') or pod.get('status',{}).get('phase')=='Failed':
     self.command('failed-positive-log',self.k+['-n',NS,'logs',pod['metadata']['name']],seconds=20);raise RuntimeError('actual positive Job failed')
   self.observe();time.sleep(1)
  raise RuntimeError('negative90s unproved' if negative else 'positive Job620s unproved')
 def bind_container(self,role,row):
  rec=self.docker[role]
  assert row['Name']=='/'+rec['name'] and row['Image']==rec['image'] and row['Config']['Labels']['bex.qa.owner']==self.owner
  if rec.get('id'):assert row['Id']==rec['id']
  assert row['HostConfig']['Memory']==512<<20 and row['HostConfig']['NanoCpus']==1000000000 and row['HostConfig']['PidsLimit']==128
  if role in ('origin','proxy'):
   assert len(row['Mounts'])==1 and row['Mounts'][0]['Type']=='volume' and row['Mounts'][0]['Name']==self.volumes[role]['name'] and row['Mounts'][0]['Destination']=='/var/lib/registry'
   if role=='proxy':assert row['HostConfig']['NetworkMode']=='container:'+self.node_cid
  else:assert role in ('export-positive','export-negative') and row['HostConfig']['ReadonlyRootfs'] and row['HostConfig']['NetworkMode']=='none'
  return True
 def remove_container(self,role):
  rec=self.docker[role];row=self.inspect('container',rec['name'])
  if row:
   self.bind_container(role,row)
   rec['id']=row['Id']
   self.checked('remove-'+role,['docker','rm','--force','--volumes',row['Id']],seconds=20,cleanup=True)
  assert self.inspect('container',rec['name']) is None
  rec['removed']=True
  if rec['unknown']:self.errors.append('unknown Docker create retained:'+role)
 def cleanup(self):
  self.cleaning=True;self.cleanup_deadline=min(time.monotonic()+300,self.started+2400)
  for pid,p in list(self.groups.items()):
   if v4.stop_group(p):self.groups.pop(pid,None);self.pending_unproved.discard(pid)
   else:self.pending_unproved.add(pid)
  if self.groups or self.pending_unproved:self.errors.append('client groups remain; no daemon/private cleanup');return
  for entry in self.entries:
   if entry['unknown']:
    try:self.resolve_unknown(entry)
    except BaseException as e:self.errors.append('unknown create reconcile:'+type(e).__name__)
  ordered=sorted(self.entries,key=lambda x:0 if x['kind']=='Job' else 2 if x['kind']=='ConfigMap' else 1)
  for entry in ordered:
   if not entry['uid']:
    self.pending.append({'kind':entry['kind'],'name':entry['name'],'reason':'uncertain POST unresolved;404doesnotclear'});continue
   try:
    self.guard(cleanup=True);uri,body=a.delete_request(entry,self.name,self.owner)
    code,out,err=self.command('delete-'+entry['name'],self.k+['delete','--raw',uri,'-f','-'],data=json.dumps(body).encode(),seconds=20,cleanup=True)
    if code and not self.notfound(err):raise RuntimeError('UID delete nonzero/unproved')
    self.checked('wait-delete-'+entry['name'],self.k+['-n',NS,'wait','--for=delete',entry['kind'].lower()+'/'+entry['name'],'--timeout=30s'],seconds=35,cleanup=True)
    assert self.get(entry['kind'],entry['name'],cleanup=True,secret=entry['kind']=='Secret') is None
    if entry['kind']=='Job':
     raw=self.kube('deleted-job-pods',['-n',NS,'get','pods','-l','job-name='+entry['name'],'-o','json'],cleanup=True);assert not json.loads(raw)['items']
    entry['absent_after_uid_delete']=True;self.save('ledger.json',self.entries)
   except BaseException as e:self.errors.append('UID cleanup '+entry['kind']+':'+type(e).__name__)
  for role in reversed(list(self.docker)):
   if role in ('origin','proxy') and self.docker[role].get('id'):
    try:self.command('terminal-'+role+'-log-tail',['docker','logs','--timestamps','--tail','200',self.docker[role]['id']],seconds=20,cleanup=True)
    except BaseException as e:self.errors.append('owned registry logs:'+type(e).__name__)
   try:self.remove_container(role)
   except BaseException as e:self.errors.append('own container cleanup '+role+':'+type(e).__name__)
  for role,entry in self.volumes.items():
   try:
    row=self.inspect('volume',entry['name'])
    if row:
     assert row['Name']==entry['name'] and row['Labels']['bex.qa.owner']==self.owner
     self.checked('remove-volume-'+role,['docker','volume','rm',entry['name']],seconds=20,cleanup=True)
    assert self.inspect('volume',entry['name']) is None;entry['removed']=True
    if entry['unknown']:self.errors.append('unknown volume create retained:'+role)
   except BaseException as e:self.errors.append('own volume cleanup:'+type(e).__name__)
  try:
   self.guard(cleanup=True);after=self.identities(cleanup=True);self.save('baseline-after.json',after)
   node=self.p['fresh_baseline_reference_only']['tenant_node']
   observed=self.kube('tenant-node-after',['get','node',node['name'],'-o','jsonpath={.metadata.uid}{"\\t"}{.status.nodeInfo.architecture}'],cleanup=True).decode()
   assert observed==node['uid']+'\tarm64';self.save('node-baseline-after.json',{'uid':node['uid'],'architecture':'arm64'})
   if hasattr(self,'policy_baseline'):
    for kind,before in self.policy_baseline.items():
     raw=self.kube(kind+'-after',['-n',NS,'get',kind,'-o','json'],cleanup=True);rows=json.loads(raw)['items']
     projected=sorted([{'name':x['metadata']['name'],'uid':x['metadata']['uid'],'spec':x['spec']} for x in rows],key=lambda x:x['name']);assert projected==before
   if self.baseline is not None:assert after==self.baseline
  except BaseException as e:self.errors.append('baseline preservation:'+type(e).__name__)
  for pid,p in list(self.groups.items()):
   if v4.stop_group(p):self.groups.pop(pid,None);self.pending_unproved.discard(pid)
   else:self.pending_unproved.add(pid)
  if not self.groups and not self.pending_unproved:
   if self.private.exists():
    assert self.private.is_dir() and not self.private.is_symlink() and self.private.stat().st_uid==os.getuid() and not self.private.stat().st_mode&0o077
    shutil.rmtree(self.private)
  else:self.errors.append('late client groups;private cleanup refused')
 def execute(self):
  # No resources/privatefiles before actualwhole-job CI and immutable source guards.
  gate=ci_gate(self.cfg,self.p);verify_source(self.p);self.cached_child=read_descriptor(self.cfg['cached_child']);assert not self.root.exists()
  assert shutil.disk_usage(HERE).free>(8<<30)+(2<<30)+(32<<20)
  handlers={};failure=None;proofs={};old_umask=os.umask(0o077)
  try:
   for sig in (signal.SIGTERM,signal.SIGINT):handlers[sig]=signal.getsignal(sig);signal.signal(sig,lambda n,f:setattr(self,'cancel',n))
   self.root.mkdir(mode=0o700);self.e.mkdir(mode=0o700);self.private.mkdir(mode=0o700);(self.private/'tmp').mkdir(mode=0o700);(self.private/'docker-config').mkdir(mode=0o700);(self.private/'docker-config/config.json').write_text('{"auths":{}}\n')
   self.save('CI-GATE.json',gate);self.save('PLAN.json',self.p)
   self.guard();self.baseline=self.identities();self.save('baseline-before.json',self.baseline)
   self.policy_baseline={}
   for kind in ('resourcequotas','limitranges'):
    rows=json.loads(self.kube(kind,['-n',NS,'get',kind,'-o','json']))['items']
    self.policy_baseline[kind]=sorted([{'name':x['metadata']['name'],'uid':x['metadata']['uid'],'spec':x['spec']} for x in rows],key=lambda x:x['name'])
   good,bad=self.transport_setup()
   expires=(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(seconds=2400)).isoformat();self.anchor=self.create(a.anchor_request(self.name,self.owner,expires))
   host=self.transport.split('/')[0]
   for obj in a.secret_and_policy_requests(self.anchor,self.name,self.owner,host,good,bad):self.create(obj)
   for route in ('positive','negative'):
    self.require_cached_child('before-'+route)
    job=self.create(self.canonical_job(route));actual,pod,proof=self.observe_job(job,route=='negative');self.save(route+'-job.json',actual);self.save(route+'-pod.json',pod);self.save(route+'-proof.json',proof)
    self.kube(route+'-events',['-n',NS,'get','events','--field-selector','involvedObject.uid='+pod['metadata']['uid'],'-o','json']);proofs[route]=True
  except BaseException as e:failure=type(e).__name__+': '+str(e)
  finally:
   try:
    if self.root.exists():self.cleanup()
   except BaseException as e:self.errors.append('finally:'+type(e).__name__)
   try:verify_source(self.p)
   except BaseException as e:self.errors.append('immutable source:'+type(e).__name__)
   reason=self.resource_reason()
   if reason:failure=failure or reason
   restoration_errors=[]
   for sig,h in reversed(list(handlers.items())):
    try:signal.signal(sig,h)
    except BaseException as error:restoration_errors.append(type(error).__name__)
   os.umask(old_umask)
   if restoration_errors:self.errors.append('signal handler restoration:'+','.join(restoration_errors))
   if self.cancel:failure=failure or 'cancelled'
   result={'PASS':failure is None and not self.errors and not self.pending and proofs=={'positive':True,'negative':True},'scope':'One actualsamecommonNodearm64 dev8predeploy only, nohosted/adoption/fullfamilies/native-init claim','failure':failure,'errors':self.errors,'pending_uncertainty':self.pending,'proofs':proofs,'cancel_signal':self.cancel,'pending_pgids':sorted(self.groups),'pending_unproved_pgids':sorted(self.pending_unproved),'private_absent':not self.private.exists(),'elapsed_seconds':round(time.monotonic()-self.started,3),'source_unchanged':not any(x.startswith('immutable source') for x in self.errors),'peak_owned_metadata_bytes':self.peak_bytes,'minimum_physical_free_bytes':self.minfree,'anchor_uid':self.anchor['metadata']['uid'] if self.anchor else None,'transport':self.transport,'Docker':self.docker,'volumes':self.volumes,'handlers_restored':all(signal.getsignal(n)==h for n,h in handlers.items())}
   if self.e.exists():self.save('RESULT.json',result)
   self.bodies.clear();print(json.dumps(result),flush=True)
  return result['PASS']

def main():
 plan=json.loads((HERE/'PLAN.json').read_bytes())
 if len(sys.argv)==1 or sys.argv[1:] in (['--plan'],['--help']):print(json.dumps(plan,indent=2));return 0
 assert len(sys.argv)==3 and sys.argv[1]=='--execute'
 cfg=json.loads(Path(sys.argv[2]).read_bytes());os.umask(0o077);return 0 if Phase(plan,cfg).execute() else 1
if __name__=='__main__':raise SystemExit(main())
