"""Independent actual-slot/source-span checks, no Go/crypto/native actions."""
from pathlib import Path
import sys,json
from unittest.mock import patch
ROOT=Path('/private/tmp/bex-w8-original28-adapter-v3-source-20261101-avnm1yg_');HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
import core as c,readiness as r,proof_binding as p,known_go_slot as scanner
from test_adoption import AdoptionControls
out={};base=AdoptionControls().fixture();old=base[0]['pin_only_deltas'][0]['edits'][0]['before'];new=base[1]['common_ref'];body=b'func choose(workspace string) string { return nativeCommonBase }\n'
def check(raw):
 contract,q,entry,docs,_,_=AdoptionControls().fixture();path=r.COMMON_SLOT;identity={'bytes':len(raw),'sha256':c.sha(raw)}
 q['qualification_source'][path]=identity;q['critical_source'][path]=dict(identity);contract['critical_files'][path].update(**identity,git_blob='f'*40);contract['pin_only_deltas']=[]
 scope=contract['scope_code'][0];scope.update(first_byte=raw.index(body),last_byte=raw.index(body)+len(body))
 def git(action,left,right):return True if action=='ancestor' else [] if action=='changes' else (raw,'100644','f'*40)
 with patch.object(p,'bind_signature',return_value={'CONTROL_ONLY':True}) as signatures:
  try:r.adoption(contract,entry,q,docs.__getitem__,git)
  except c.Unproved as error:return {'accepted':False,'reason':str(error),'signature_calls':signatures.call_count}
  return {'accepted':True,'signature_calls':signatures.call_count}
fixed=r.common_initializer(new,'inferred');oldline=r.common_initializer(old,'inferred')
decoys={'line-comment':b'// '+fixed,'block-comment':b'/*\n'+fixed+b'*/\n','raw':b'var documentation = `\n'+fixed+b'`\n','quoted':b'var documentation = '+json.dumps(fixed.decode()).encode()+b'\n','rune':b"var brace = '}'\n// "+fixed,'nested':b'func nested() {\n'+fixed+b'}\n'}
for label,decoy in decoys.items():
 result=check(b'package build\n'+oldline+decoy+body);assert result['accepted'] is False and result['signature_calls']==0,(label,result);out['OLD_plus_qualified_'+label]=result
correct=b'package build\n'+fixed+b''.join(decoys.values())+body
out['actual_correct_with_all_decoys']=check(correct);assert out['actual_correct_with_all_decoys']['accepted']
out['duplicate_actual']=check(b'package build\n'+fixed+oldline+body);assert not out['duplicate_actual']['accepted']
onlyfake=b'package build\n'+b''.join(x for k,x in decoys.items() if k!='nested')+body
out['fake_only_missing_actual']=check(onlyfake);assert not out['fake_only_missing_actual']['accepted']
# Scan actual tracked source, then bind an initializer-only edit with fake zero
# text BEFORE and AFTER the genuine declaration; exact byte offsets preserve it.
actual=(Path('/Users/tianpan/projects/bex7')/r.COMMON_SLOT).read_bytes();zero=scanner.declaration(actual);assert zero['form']=='zero'
assert actual[zero['start']:zero['end']]==b'var nativeCommonBase string\n'
out['actual_current_zero']={'form':zero['form'],'start':zero['start'],'end':zero['end'],'source_sha256':c.sha(actual)}
for syntax in ('inferred','typed'):
 header=b'// var nativeCommonBase string\n/*\nvar nativeCommonBase string\n*/\n'
 trailer=b'\nvar documentation = `var nativeCommonBase string\n`\n'
 before=header+actual+trailer;span=scanner.declaration(before);after=before[:span['start']]+r.common_initializer(new,syntax)+before[span['end']:]
 assert after.startswith(header) and after.endswith(trailer)
 contract,q,entry,docs,_,_=AdoptionControls().fixture();path=r.COMMON_SLOT;ref=contract['pin_only_deltas'][0]['before'];docs[ref['path']]=before;ref.update(bytes=len(before),sha256=c.sha(before))
 identity={'bytes':len(before),'sha256':c.sha(before)};q['qualification_source'][path]=identity;q['critical_source'][path]=dict(identity);contract['critical_files'][path].update(bytes=len(after),sha256=c.sha(after))
 contract['common_initializer_syntax']=syntax;contract['pin_only_deltas'][0]['edits']=[{'kind':'native-common-base-initializer','before':'var nativeCommonBase string\n','after':r.common_initializer(new,syntax).decode()}]
 scope=contract['scope_code'][0];docs[scope['source']['path']]=after;scope['source'].update(bytes=len(after),sha256=c.sha(after));scope.update(first_byte=0,last_byte=len(after),sha256=c.sha(after))
 def git(action,left,right):
  if action=='ancestor':return True
  if action=='changes':return [{'status':'M','path':path}]
  return (before,'100644','e'*40) if left==q['qualified_baseline_source'] else (after,'100644','f'*40)
 with patch.object(p,'bind_signature',return_value={'CONTROL_ONLY':True}) as signatures:
  result=r.adoption(contract,entry,q,docs.__getitem__,git);assert signatures.call_count==2
 assert scanner.declaration(after)['value']==new
 out['actual_initializer_'+syntax]={'accepted':True,'only_actual_decl_span_changed':True,'fake_zero_text_preserved':True,'signature_calls_mocked':2,'changed':result['changed_critical_paths']}
(HERE/'PROBE-RESULTS.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,sort_keys=True,indent=2))
