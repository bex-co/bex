"""Narrow real exported metadata/file interface checks; no admission authority."""
from pathlib import Path
import ast,hashlib,importlib.util,json,sys,types,subprocess,socket,urllib.request
from unittest import mock
R=Path(__file__).resolve().parent;SRC=R/'source';REPO=Path('/Users/tianpan/projects/bex7');EXPORT=REPO/'.pm/w8/m91/evidence/common-artifact-review-20261101'
receipt=json.loads((R/'actual-metadata/receipt.json').read_bytes());custody=json.loads((R/'actual-metadata/CUSTODY.json').read_bytes())
def hfile(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(1<<20):h.update(b);n+=len(b)
 return h.hexdigest(),n
def pub(d):
 p=REPO/d['path'];assert p.resolve().is_relative_to(EXPORT.resolve()) and not p.is_symlink();return p
def denied(*args,**kwargs):raise AssertionError('No signature/network/auth command allowed in compatibility audit')
sys.path.insert(0,str(SRC))
with mock.patch.object(subprocess,'run',denied),mock.patch.object(subprocess,'Popen',denied),mock.patch.object(urllib.request,'urlopen',denied),mock.patch.object(socket,'create_connection',denied):
 import evidence
 tree=ast.parse((SRC/'proof_binding.py').read_bytes());constants={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('COSIGN','COSIGN_SHA','ISSUER')}
 rt=ast.parse((SRC/'readiness.py').read_bytes());fn=next(n for n in rt.body if isinstance(n,ast.FunctionDef) and n.name=='native_command');ident=next(ast.literal_eval(n.value) for n in rt.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='NATIVE_IDENTITY' for x in n.targets))
 namespace={'p':types.SimpleNamespace(**constants),'NATIVE_IDENTITY':ident};exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'EXTRACTED_NATIVE_COMMAND_ONLY','exec'),namespace)
 assert receipt['ref']=='ghcr.io/bex-co/bex-cnb-run@sha256:56c58abb41abd6becfa1810834c6cba46b742703e2beffdb3a88387772b3b986'
 original=Path(receipt['signed_payloads'][0]['path']).parent.parent/'receipt.json';assert hfile(original)==hfile(EXPORT/'actual/receipt.json')
 crypto_key=str(original.parent/'bundles/crypto-results.json');crypto=json.loads(pub(custody['files'][crypto_key]).read_bytes())
 tools=[]
 for key,digest in receipt['evidence_tool_sha256'].items():
  d=custody['files'][key];assert hfile(pub(d))==(digest,d['bytes']);tools.append({'basename':Path(key).name,'actual_original_key':key,'sha256':digest,'bytes':d['bytes']})
 assert next(x['sha256'] for x in tools if x['basename']=='common-v11-adapter.py')=='4746a5022ab6df57ed95b6354d56b92eff15976d1737c2aa5a5ca15aa0080a4b'
 for row in receipt['signed_payloads']:
  actual=next(x for x in crypto['results'] if x['bundle_digest']==row['bundle_digest']);assert namespace['native_command'](row['path'],row['predicate_type'],receipt['ref'].split('@')[1],receipt['verification_workflow_sha'])==actual['command']
 assert constants['COSIGN_SHA']=='9f9b8cd557cf2e5b3df3373a00baa005a86b02391e3e06dd0ce37b3a1533d3a4'
 access=evidence.Access(denied);files=[]
 for row in receipt['signed_payloads']:
  assert 0<row['bundle_bytes']<=evidence.MAX_ATTESTATIONS and 0<row['decoded_predicate_sorted_json_bytes']<=evidence.MAX_ATTESTATIONS
  for kind in ('full_bundle_gzip','full_predicate_gzip'):
   d=custody['files'][row[kind]];assert d['sha256']==row[kind+'_sha256'];repo_hash=hfile(pub(d));assert repo_hash==(d['sha256'],d['bytes'])
   private={'path':row[kind],'bytes':d['bytes'],'sha256':d['sha256']}
   assert evidence.descriptor(private)==(d['bytes'],d['sha256'])
   actual=evidence.verify_full(private,access);assert actual=={'bytes':d['bytes'],'sha256':d['sha256']}
   relative_rejected=False;repo_absolute_rejected=False
   try:evidence.descriptor(d)
   except ValueError:relative_rejected=True
   absolute=dict(d,path=str(pub(d)))
   try:
    with evidence.private_open(absolute):pass
   except ValueError:repo_absolute_rejected=True
   assert relative_rejected and repo_absolute_rejected
   files.append({'kind':row['kind'],'arch':row['architecture'],'form':kind,'compressed_bytes':d['bytes'],'sha256':d['sha256'],'original_private_counterpart_exists_and_hashes':True,'absolute_private_descriptor_accepted':True,'portable_relative_descriptor_requires_translation':True,'absolute_repo_path_not_allowed_by_private_reader':True})
 def functions(path):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_bytes()).body if isinstance(n,ast.FunctionDef)}
 derived=functions(SRC/'retained_v11_predicates.py');support_name=custody['support_inputs']['loopx-w8-verify-native-artifact.py'];support=functions(pub(custody['files'][support_name]));same={name:derived[name]==support[name] for name in ['spdx_binding','trivy_binding','package_arches']};assert all(same.values())
 result={'actual_receipt_sha256':hfile(EXPORT/'actual/receipt.json')[0],'actual_ref':receipt['ref'],'actual_roles':receipt['producer_verification_provenance'],'actual_tool_table':tools,'common_native_command_matches_all5_actual_strict_commands':True,'COSIGN_SHA_matches_real_approved_binary_identity':True,'full_external_size_ceiling':evidence.MAX_ATTESTATIONS,'largest_raw_bundle_bytes':max(x['bundle_bytes'] for x in receipt['signed_payloads']),'largest_canonical_predicate_bytes':max(x['decoded_predicate_sorted_json_bytes'] for x in receipt['signed_payloads']),'largest_gzip_bytes':max(x['compressed_bytes'] for x in files),'real_gzip_path_size_hash_interface_checks':files,'inherited_report_predicate_AST_matches_original_support':same,'metadata_sizes':{name:(EXPORT/name).stat().st_size for name in ['actual/receipt.json','CUSTODY.json','EXPORT.json']},'metadata_all_under2MiB':True,'representation_requirement':'CUSTODY is portable storage metadata, not a runtime admission capsule: preserve its original receipt path keys, resolve those keys to existing hash-matching absolute private proof descriptors. Relative repo paths, and absolute repo paths, intentionally do not satisfy this private reader. No authority or new qualified/adoption contract was created.','scope':'Read/hash existing gzip files in place and execute only typed file predicates plus extracted argv builder. No original app/validator/hosted input import, no full qualification/adoption/readiness/auth/signature/network call, no large copies.'}
 (R/'COMPATIBILITY.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'artifact_component_schema_tools_and_sizes_compatible':True,'all10private_gzip_typed_hash_predicates_pass':True,'portable_path_translation_required':True,'no_authority_synthesized_or_admitted':True}))
