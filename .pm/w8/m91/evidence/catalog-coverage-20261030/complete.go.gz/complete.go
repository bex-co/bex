/*
Copyright 2026.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package build

import (
	"cmp"
	"context"
	"fmt"
	"regexp"
	"strings"
)

// nativeSuppliedBases maps reviewed official bases to their reviewed,
// immutable supplied derivatives. Publication alone never changes this map.
// Keep official toolchain pins separate: exact selection and companions must
// continue to resolve the upstream primary rather than a derivative tag.
var nativeSuppliedBases = map[string]string{
	"node:14-bullseye@sha256:c0bff0d29a742f40650d5f0305dd581351c10954e6cb6676fc96f47590b9666e":     "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"node:16-bookworm@sha256:73e677f85fbc56d22c817b4e5d7f72086c5343c0859f3bf8aaadab22aab29ce6":     "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"node:18-bookworm@sha256:c6ae79e38498325db67193d391e6ec1d224d96c693a8a4d943498556716d3783":     "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"node:20-bookworm@sha256:8f693eaa7e0a8e71560c9a82b55fd54c2ae920a2ba5d2cde28bac7d1c01c9ba5":     "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"python:3.7-bullseye@sha256:f36f6fe9ddb2622aab9803944cbe7e2bc50be75d624a081f7895e60e7c6b7f0a":  "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"python:3.8-bookworm@sha256:d411270700143fa2683cc8264d9fa5d3279fd3b6afff62ae81ea2f9d070e390c":  "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"python:3.9-bookworm@sha256:ff12c273af1e1814efcd8dfdefe16a70a4d901afe94dce721ffed8a34176f285":  "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"python:3.10-bookworm@sha256:f72a86806f92fe13a49f49aeca1db0b19ea5cf4a0470b842a01b0e14314945b8": "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"ruby:3.0-bullseye@sha256:dcb8a8a6ee981f949da505cb9f4f15cde696e7bcb088955bc1f92f23a4cd7a72":    "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"ruby:3.1-bookworm@sha256:91627f55e8969006aab67d15c92fb930500ff73948803da1330b8a853fecebb5":    "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"ruby:3.2-bookworm@sha256:bf13a46a498fb4055d0e52495c351a2648c8bc8d41b473ee3f734041a74c7f56":    "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"elixir:1.17@sha256:0ff6cbfc498e86d21d1f8939672f32acaffe9e5be8924da7942ce69fd34e2c68":          "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"elixir:1.18@sha256:17e900a5657265d248499a1525b00c64c33e7f93f9a71c766614c8e910656351":          "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"elixir:1.19@sha256:8f40275227054af01252a5a84c725ad2a34e971f8a5343cb132509fc37b61842":          "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"elixir:1.20@sha256:c904ce753c35768c76a3be6f16428a83f8237ca0c402355b49bac99d74da2beb":          "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"golang:1.27-bookworm@sha256:d9b6a1beb9474adc2a1ce842573639b44b2a0dd49b6669f51d3821baf9ec37c9": "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"node:22-bookworm@sha256:18a6d90fd60542269850c80ca03b29b1d9b14d6b221ac7ee8e35b0d33ef904bd":     "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"node:24-bookworm@sha256:d862bb5d082c5ae0210ac07e8c0344cb8cf7bef6d78e9b8c50c179da923108ea":     "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"node:26-bookworm@sha256:3b764117159bda01d2396391e7789b6a9106af9729cfd001ef55e98557868310":     "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"python:3.11-bookworm@sha256:84fa927127b46670e768371d1ad1be271d57ba93a6fbb3479045c7c6c452432f": "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"python:3.12-bookworm@sha256:a5bab0ff300f91231c2e68bf73a8a8d60762ac39ce1c50eaf6803e4c38a9062b": "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"python:3.13-bookworm@sha256:3856e3e7bf4d0ba061501a84ed2eb0d429663307c0f54f191dc4de03c7081c3e": "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"python:3.14-bookworm@sha256:a8cf203c684b61fd2676ec5a17159cf68ed38ad471481e1f4ebc4679825250bd": "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"ruby:3.3-bookworm@sha256:0e4ba04b135a870aedf21340f33ce376c7fe0ed2d9a02886420c820acb3e9c50":    "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"ruby:3.4-bookworm@sha256:8853c6f24866429483fce3a869e61a6a13916beb2720468c6d95c78f41c0f564":    "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"ruby:4.0-bookworm@sha256:470eb587e87c42ad9b0062ba9bc362d90d94fb67b09fecd6052b381d897d0777":    "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	"rust:1-bookworm@sha256:9181b56c2a21ab1d5e73cffe04fc762426d30aa7fac3c91141dd033f49a7fc8b":      "ghcr.io/bex-co/bex-cnb-run@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
}

var nativeImageEnvName = regexp.MustCompile(`^[A-Za-z_][A-Za-z0-9_]*$`)

var nativeDebianHistory = regexp.MustCompile(`^# debian\.sh --arch '(?:amd64|arm64)' out/ '(bullseye|bookworm|trixie)' '@[0-9]+'$`)
var nativeLegacyDebianHistory = regexp.MustCompile(`^(?:/bin/sh -c #\(nop\) )?ADD file:[a-f0-9]{64} in /$`)

// nativeDebianSuite accepts only Debian's own root-image provenance format.
// The legacy ADD format names no suite; callers must not infer one from dates.
func nativeDebianSuite(history []string) (string, error) {
	if len(history) == 0 || len(history) > 1024 {
		return "", fmt.Errorf("native image history has an invalid entry count")
	}
	total := 0
	for _, entry := range history {
		total += len(entry)
		if len(entry) > 64<<10 || total > maxVersionFileBytes {
			return "", fmt.Errorf("native image history exceeds the provenance limit")
		}
	}
	root := strings.TrimSpace(history[0])
	for _, entry := range history[1:] {
		if strings.HasPrefix(strings.TrimSpace(entry), "# debian.sh ") {
			return "", fmt.Errorf("native image history has ambiguous Debian roots")
		}
	}
	if m := nativeDebianHistory.FindStringSubmatch(root); m != nil {
		return m[1], nil
	}
	if nativeLegacyDebianHistory.MatchString(root) {
		return "", nil
	}
	return "", fmt.Errorf("native image history does not identify a reviewed Debian root")
}

// suppliedNativeImage keeps exact OTP on the same Debian suite as its source.
// Older Elixir/OTP images used Debian's legacy ADD history: the reviewed line
// carrying that actual OTP major is the compatible candidate, and the generated
// filesystem check still verifies its suite before any primary is replaced.
func suppliedNativeImage(reviewedImage string, choice NativeChoice, supplied map[string]string) (string, error) {
	reviewedSource := cmp.Or(choice.upstream, reviewedImage)
	selected := reviewedSource
	if choice.Image != reviewedImage && strings.HasPrefix(reviewedSource, "elixir:") {
		wantedOTP := ""
		if choice.imageSuite == "" {
			for _, entry := range choice.imageEnv {
				if value, found := strings.CutPrefix(entry, "OTP_VERSION="); found {
					if !otpRelease.MatchString(value) {
						return "", fmt.Errorf("legacy native image has an invalid OTP version")
					}
					wantedOTP, _, _ = strings.Cut(value, ".")
				}
			}
			if wantedOTP == "" {
				return "", fmt.Errorf("legacy native image has no verified OTP version")
			}
		}
		matched := false
		for _, line := range nativeToolchains[nativeElixirRuntime].lines {
			if (choice.imageSuite != "" && line.debian == choice.imageSuite) || (wantedOTP != "" && line.otp == wantedOTP) {
				if !matched {
					selected, matched = cmp.Or(line.upstream, line.image), true
				}
				if line.image == reviewedImage {
					selected = reviewedSource
					break
				}
			}
		}
		if !matched {
			return "", fmt.Errorf("no reviewed supplied Elixir base matches the exact image's Debian/OTP provenance")
		}
	}
	image, ok := supplied[selected]
	if !ok {
		return "", fmt.Errorf("no reviewed supplied base for %s", selected)
	}
	return image, nil
}

// pinNativePrimary keeps exact-version fallback behavior while collecting the
// verified metadata needed to transplant that primary onto a supplied base.
func pinNativePrimary(ctx context.Context, exact ExactImageResolver, runtime string, reviewed NativeChoice) (NativeChoice, error) {
	choice := reviewed
	var err error
	if choice.erlang != "" {
		choice, err = pinErlangVersion(ctx, exact, choice)
		if err != nil {
			return NativeChoice{}, err
		}
	} else {
		choice = pinExactVersion(ctx, exact, choice)
	}
	if len(nativeSuppliedBases) == 0 || choice.Image == reviewed.Image {
		return choice, nil
	}
	requestedImage := choice.Image
	var history []string
	choice.imageEnv, history, err = exact.ImageMetadata(ctx, choice.Image)
	if err == nil && runtime == nativeElixirRuntime {
		choice.imageSuite, err = nativeDebianSuite(history)
	}
	if err == nil {
		return choice, nil
	}
	if choice.erlang != "" {
		return NativeChoice{}, fmt.Errorf("read exact Erlang image environment: %w", err)
	}
	reviewed.note = fmt.Sprintf("==> Could not read the exact image %s environment (%v); using the reviewed %s %s image", requestedImage, err, reviewed.Label, reviewed.Line)
	return reviewed, nil
}

// applyNativeSuppliedBase runs after all language and companion selection.
// Its primary replacement is prepended ahead of companions so an exact
// primary cannot erase Node, Ruby, Bun, Poetry, or their links.
func applyNativeSuppliedBase(dockerfile, reviewedImage string, choice NativeChoice, supplied map[string]string) (string, error) {
	if len(supplied) == 0 {
		return dockerfile, nil
	}
	image, err := suppliedNativeImage(reviewedImage, choice, supplied)
	if err != nil {
		return "", err
	}
	ref, digest, pinned := strings.Cut(image, "@")
	if !pinned || ref == "" || strings.ContainsAny(ref, " \t\r\n") || !digestPattern.MatchString(digest) {
		return "", fmt.Errorf("supplied native base is not pinned: %s", image)
	}
	out, err := rewriteNativeBase(dockerfile, choice.Image, image)
	if err != nil || choice.Image == reviewedImage {
		return out, err
	}
	if len(choice.imageEnv) == 0 {
		return "", fmt.Errorf("exact primary %s has no verified environment", choice.Image)
	}
	// COPY merges directories. Remove the reviewed primary first so a newer
	// patch's modules or extension files cannot survive beside the requested
	// interpreter. Debian packages and supplied tools live outside /usr/local.
	var lines strings.Builder
	lines.WriteString("COPY --link --from=" + choice.Image + " /usr/lib/os-release /opt/bex-primary-os-release\n" +
		"RUN . /opt/bex-primary-os-release && [ -n \"$VERSION_CODENAME\" ] && primary_os=\"$VERSION_CODENAME\" && . /etc/os-release && [ -n \"$VERSION_CODENAME\" ] && " +
		"{ [ \"$primary_os\" = \"$VERSION_CODENAME\" ] || { echo 'exact native primary and supplied base have different Debian distributions' >&2; exit 1; }; } && " +
		"rm -f /opt/bex-primary-os-release && rm -rf /usr/local && mkdir -p /usr/local\n" +
		"COPY --link --from=" + choice.Image + " /usr/local/ /usr/local/\n" +
		"RUN --network=none /sbin/ldconfig\n")
	escaper := strings.NewReplacer(`\`, `\\`, `"`, `\"`, `$`, `\$`)
	for _, item := range choice.imageEnv {
		key, value, valid := strings.Cut(item, "=")
		if !valid || !nativeImageEnvName.MatchString(key) || strings.ContainsAny(value, "\x00\r\n") {
			return "", fmt.Errorf("exact primary %s has an invalid environment entry", choice.Image)
		}
		escaped := escaper.Replace(value)
		fmt.Fprintf(&lines, "ENV %s=\"%s\"\n", key, escaped)
	}
	if strings.HasPrefix(cmp.Or(choice.upstream, reviewedImage), "python:") {
		lines.WriteString("RUN --network=none /usr/bin/bex-native-python-tools\n")
	}
	return afterNativeBase(out, image, lines.String())
}
