"""Root-only export after complete current validation and unchanged rejected-attempt custody."""
from pathlib import Path
import datetime,gzip,hashlib,json,re,shutil,subprocess
REPO=Path('/Users/tianpan/projects/bex7');ROOT=Path('/tmp/loopx-w8-native-review-ruby31-v11-fd358');SHA='fd358d2010f8b5e2715250d7148a505ba12c1cb6';CASE=ROOT/('native-ruby-3.1-bookworm-'+SHA);CONTROLS=Path('/tmp/loopx-w8-native-controls-ruby31-v11-fd358');DEST=REPO/'.pm/w8/m91/evidence/published-ruby31-20261030'
def hfile(p,z=False):
 h=hashlib.sha256();n=0
 with (gzip.open(p,'rb') if z else Path(p).open('rb')) as f:
  while b:=f.read(1<<20):h.update(b);n+=len(b)
 return h.hexdigest(),n
def read(p):return json.loads(Path(p).read_text())
def dump(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def require(x,m):
 if not x:raise RuntimeError(m)
def main():
 require(not DEST.exists(),'Never overwrite a capsule');r=read(CASE/'receipt.json');process=read(ROOT/'process-exit-case-attempt4.json');frozen=read(CONTROLS/'FROZEN-MANIFEST.json');chain=read(CONTROLS/'frozen-complete-attempt-chain.json')
 require(hfile(CONTROLS/'FROZEN-MANIFEST.json')[0]=='2eae27339974962a2c586b214f9efda03d1c6363e0f4610b28c7ed31d570b816','Frozen manifest differs')
 require(hfile(CASE/'receipt.json')[0]=='9c60f86f70f7ffef89d7f08207ab946abbd5e56f0c12d4c82a50f486e172320b','Actual receipt differs')
 for label,row in frozen['files'].items():require(hfile(row['path'])==(row['sha256'],row['bytes']),'Frozen payload differs: '+label)
 require(len(frozen['files'])==175,'Unexpected frozen payload set')
 require(process['actual_returncode']==0 and process['stopped_reason'] is None and process['minimum_observed_free_bytes']>=2<<30 and process['maximum_observed_owned_bytes']<=2<<30,'Actual success/resource gates failed')
 require(r['approved_supplier_candidate'] is True and r['producer_workflow_sha']==r['verification_workflow_sha']==SHA and r['ci_runtime_scan_signing_evidence']['job_id']==124090808291,'Wrong candidate/source/job')
 require(r['ref']=='ghcr.io/bex-co/bex-cnb-run@sha256:5f4dc113a6b3e98217f98b98f99824e8245c74b45dff760aaace3983cecd9bfe','Wrong index')
 for key in ['anonymous_manifest_bytes_sha_verified','strict_keyless_signature_and_sbom_and_vulnerability_attestations_verified','strict_actual_Rekor_v2_and_RFC3161_TSA_verified','wrong_source_and_subject_negative_checks_rejected']:require(r[key] is True,'Strict gate failed: '+key)
 require(r['new_manual_layer_reads']==0 and r['spdx_additional_verified_root_bindings']==[] and not r['unaccepted_attachment_results'],'Unexpected manual/attachment lineage')
 rows=r['anonymous_pull']['blob_receipts'];require(len(rows)==len({x['digest'] for x in rows})==33 and sum(x['bytes_hashed'] for x in rows)==1353900387,'Incomplete actual byte set')
 prior=[x for x in rows if x['reused_prior_full_read']];new=[x for x in rows if not x['reused_prior_full_read']];require(len(prior)==21 and sum(x['bytes_hashed'] for x in prior)==579627684 and len(new)==12 and sum(x['bytes_hashed'] for x in new)==774272703,'Wrong reused/new byte custody')
 seed=read(CONTROLS/'seeded21-full-read-receipts.json')['blobs'];require(set(seed)=={x['digest'] for x in prior},'Prior receipt set differs')
 for x in prior:require(x['current_anonymous_head_at'] and seed[x['digest']]['bytes_hashed']==x['bytes_hashed'],'Prior HEAD/size evidence missing')
 for x in new:
  d=read(CASE/('ranged-body-'+x['digest'][7:]+'.json'));require(d['logical_bytes_delivered']==x['bytes_hashed'] and len(d['attempts'])==1 and d['attempts'][0]['requested_offset']==0 and d['attempts'][0]['http_status']==200 and d['attempts'][0]['outcome']=='complete','Unexpected actual range/retry lineage')
 context=read(CONTROLS/'fresh-source-recipe-context.json');require(context['producer_sha']==context['verification_sha']==SHA and len(context['files'])==22,'Wrong recipe context')
 for x in context['files']:
  b=subprocess.check_output(['git','-C',str(REPO),'show',SHA+':'+x['path']]);require(len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['content_sha256'],'Recipe source changed')
 require(len(r['signed_payloads'])==5 and {(x['kind'],x['architecture']) for x in r['signed_payloads']}=={('image-signature',None),('sbom','amd64'),('sbom','arm64'),('vulnerability','amd64'),('vulnerability','arm64')},'Incomplete architecture signature set')
 entries=[]
 for x in r['signed_payloads']:
  raw=Path(x['path']);z=Path(x['full_bundle_gzip']);pred=Path(x['full_predicate_gzip']);rh,rn=hfile(raw);zh,zn=hfile(z);ph,pn=hfile(pred);uh,un=hfile(z,True);puh,pun=hfile(pred,True)
  require('sha256:'+rh==x['bundle_digest'] and rn==x['bundle_bytes'] and (uh,un)==(rh,rn),'Full signed bundle custody failed')
  require((zh,zn)==(x['full_bundle_gzip_sha256'],x['full_bundle_gzip_bytes']) and ph==x['full_predicate_gzip_sha256'] and (puh,pun)==(x['decoded_predicate_sorted_json_sha256'],x['decoded_predicate_sorted_json_bytes']),'Full gzip/predicate custody failed')
  row={k:x[k] for k in ['kind','architecture','manifest_digest','bundle_digest','bundle_bytes','signed_statement_sha256','predicate_type','decoded_predicate_sorted_json_sha256','decoded_predicate_sorted_json_bytes','tlog_kind_versions','tsa_timestamp_count']};row.update(bundle_manifest_url='https://ghcr.io/v2/bex-co/bex-cnb-run/manifests/'+x['manifest_digest'],bundle_blob_url='https://ghcr.io/v2/bex-co/bex-cnb-run/blobs/'+x['bundle_digest'],full_private_bundle_gzip={'path':str(z),'sha256':zh,'bytes':zn,'uncompressed_sha256':uh,'uncompressed_bytes':un},extracted_full_predicate_gzip_sha256=ph,extracted_full_predicate_json_sha256=puh,extracted_full_predicate_json_bytes=pun,extracted_full_predicate_private_path=str(pred));entries.append(row)
 DEST.mkdir();custody=[]
 def cp(f,rel):
  f=Path(f);b=f.read_bytes();require(len(b)<2<<20 and not f.is_symlink(),'Unsafe/large compact input')
  require(not re.search(rb'authorization["\s:]+bearer\s+[A-Za-z0-9_.-]{20,}|[?&](?:sig|access_token|token|skoid|sktid)=[A-Za-z0-9%+/_=-]{12,}',b,re.I),'Secret-like transport material')
  dest=DEST/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);custody.append({'source':str(f),'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 cp(CASE/'receipt.json','receipt.json')
 for f in sorted(CASE.rglob('*')):
  if not f.is_file() or f==CASE/'receipt.json' or f.name.endswith(('.bundle.json','.gz')) or f.stat().st_size>=2<<20:continue
  rel=str(f.relative_to(CASE));cp(f,('actual/'+rel[:-4]+'.txt') if f.suffix=='.log' else 'actual/'+rel)
 for f in sorted(CONTROLS.iterdir()):
  if f.is_file():cp(f,'controls/'+f.name)
 for f,rel in [(ROOT/'process-exit-case-attempt4.json','engineering/process-exit.json'),(ROOT/'v11-case-attempt4.log','engineering/actual-execution.txt'),(Path('/private/tmp/loopx-w8-run-ruby31-v11-case4.py'),'engineering/resource-supervisor.py')]:cp(f,rel)
 for name in ['retrieve-and-verify.py','test-image-bundle-retrieval.py']:cp(REPO/'.pm/w8/m91/evidence/published-python39-20261030/tools'/name,'tools/'+name)
 policy={'schema':'bex.native-published-supplier-evidence/v1','reviewed_at':r['reviewed_at'],'ref':r['ref'],'official_base':r['official_base'],'producer_sha':SHA,'verification_sha':SHA,'workflow_run':41063733348,'job_id':124090808291,'cosign_version':'3.1.4','verified_darwin_arm64_binary_sha256':'9f9b8cd557cf2e5b3df3373a00baa005a86b02391e3e06dd0ce37b3a1533d3a4','certificate_identity':'https://github.com/bex-co/bex/.github/workflows/native-base-image.yml@refs/heads/main','certificate_oidc_issuer':'https://token.actions.githubusercontent.com','subject_digest_algorithm':'sha256','subject_digest':r['ref'].split('@sha256:')[1],'source_policy':'Exact fresh-build same producer/verifier;22 immutable recipe inputs; no recovery equality claim.','crypto_policy':'Five full strict bundles, actual wrong-source/subject rejection, production TUF/Rekor-v2/RFC3161 timestamps; no weakened flags.','report_policy':'Independent exact registry architecture/config/child and DiffID bindings; every finding retained.','production_catalog_changed':False}
 dump(DEST/'source-policy.json',policy);dump(DEST/'full-predicate-retrieval.json',{'schema':'bex.native-full-predicate-retrieval/v1','repository':'bex-co/bex-cnb-run','policy':policy,'canonicalization':'Full decoded predicate sorted-JSON hash is a semantic-document hash; original bundle and signed-statement hashes bind signed bytes.','entries':entries});dump(DEST/'LOG-CUSTODY.json',{'scope':'Small metadata/source/log copies only; every original full signed bundle and gzip remains private and unchanged.','files':custody})
 disposition={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root_supplier_approval':True,'scope':'Current immutable Ruby3.1 supplier evidence only; no catalog/hosted approval','actual_attempt':4,'actual_exit':0,'current_receipt_sha256':hfile(CASE/'receipt.json')[0],'frozen_manifest_sha256':hfile(CONTROLS/'FROZEN-MANIFEST.json')[0],'all175_frozen_payload_hashes_rechecked':True,'all5_bundle_and_predicate_gzip_roundtrips_rechecked':True,'new_complete_blobs':12,'new_complete_bytes':774272703,'prior_genuine_complete_blobs':21,'prior_genuine_complete_bytes':579627684,'all33_complete_bytes':1353900387,'rejected_attempts':'Attempts1–3 remain rejected: unclassified integrity failure, TUF/report-pair failure, two confirmed short bodies. Later correct bytes do not classify an old response or waive it.','current_acceptance_basis':'The new complete validation independently proves every current immutable config/layer descriptor and every strict signature/report/source gate. Prior complete receipts retain exact custody and fresh anonymous HEAD checks; no failed response was reused. Both failed blob IDs were read from zero and fully matched their SHA and size.','live_range_resumes':0,'custody_limit':'Three earlier derived gzip representations were overwritten; all original signed bundles remain authoritative. This loss is recorded and not concealed.','no_raw_unlink_or_old_helper_execution':True,'tool_review':'Exact V11/policy reviewed and11+4+6+43 controls pass; committed native-review-ranged-streams-20261030 capsule retains source/tests/reviews.'};dump(DEST/'ROOT-REVIEW.json',disposition)
 print(json.dumps({'archive':str(DEST),'root_supplier_approved':True,'all33_bytes':1353900387,'full_raw_bundles_retained':True,'files_before_reader_test_and_manifest':sum(x.is_file() for x in DEST.rglob('*'))}))
if __name__=='__main__':main()
