import pathlib,subprocess,os,time,signal,json,hashlib,shutil,datetime
ROOT=pathlib.Path(__file__).parent;REPO=pathlib.Path('/Users/tianpan/projects/bex7');TMP=ROOT/'tmp';TMP.mkdir();os.chown(TMP,-1,os.getgid())
FLOOR=1024**3;MARGIN=128*1024**2;CAP=896*1024**2;MAXTMP=768*1024**2
paths=['lego/.dockerignore','lego/operator/internal/build/nativecommon.go','lego/operator/internal/build/nativeresolve.go','lego/operator/internal/build/nativenodepython.go','lego/operator/internal/build/nativenodepython.py','deploy/native-common/prepare-node14-tools.py','deploy/native-common/node14_tools_test.py','deploy/native-common/testdata/node16-find-python.js','lego/operator/internal/build/nativecommon_node14_test.go','lego/operator/internal/build/nativenodepython_test.go','lego/operator/internal/build/testdata/native-node-qualification/check.py','lego/operator/internal/build/testdata/native-node-qualification/check_test.py','lego/go.work.sum']
def hashes():return {p:hashlib.sha256((REPO/p).read_bytes()).hexdigest() for p in paths}
def dump(n,d):(ROOT/n).write_text(json.dumps(d,indent=2)+'\n')
def size(p):return sum(q.stat().st_size for q in p.rglob('*') if q.is_file() and not q.is_symlink())
startfree=shutil.disk_usage(ROOT).free
assert startfree>=FLOOR+CAP+MARGIN,(startfree,'insufficient bounded own compile headroom')
before=hashes();dump('SCOPE.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':before,'reserve':FLOOR,'own_free_drop_cap':CAP,'temporary_stop':MAXTMP,'margin':MARGIN,'start_free':startfree,'mode':'observed physical free and ownedTMP, no kernelquota; own processgroups only; no package/tool/image downloads','commands':[['make','test'],['./bin/golangci-lint','run','--concurrency','2','./internal/build/...']]})
env=os.environ.copy();env.update({'TMPDIR':str(TMP),'GOWORK':'off','GOTOOLCHAIN':'local','GOPROXY':'off','GOSUMDB':'off','GOMAXPROCS':'2','GOMEMLIMIT':'512MiB','GOFLAGS':'-p=1'});env.pop('KUBECONFIG',None)
results=[];minimum=startfree;peak=0
for label,args in [('disk-mode-focused',['go','test','-p','1','./internal/disksnapshot','-run','^TestRestoreReappliesArchivedOwnerAndMode$','-count=1','-v']),('operator-full',['make','test']),('build-lint',['./bin/golangci-lint','run','--concurrency','2','./internal/build/...'])]:
 t=time.monotonic();stop=None
 with (ROOT/(label+'.log')).open('wb') as log:
  p=subprocess.Popen(args,cwd=REPO/'lego/operator',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  dump(label+'-PROCESS.json',{'pid':p.pid,'pgid':p.pid,'command':args})
  while p.poll() is None:
   free=shutil.disk_usage(ROOT).free;owned=size(TMP);minimum=min(minimum,free);peak=max(peak,owned)
   if free<FLOOR+MARGIN or startfree-free>CAP-MARGIN or owned>MAXTMP-MARGIN or time.monotonic()-t>1500:
    stop={'free':free,'observed_free_drop':startfree-free,'owned_tmp':owned,'seconds':round(time.monotonic()-t,3)};break
   time.sleep(1)
  # Always remove this exact process group, including descendants after leader exit.
  for sig,grace in [(signal.SIGTERM,2),(signal.SIGKILL,2)]:
   try:os.killpg(p.pid,sig)
   except ProcessLookupError:break
   deadline=time.monotonic()+grace
   while time.monotonic()<deadline:
    p.poll()
    try:os.killpg(p.pid,0)
    except ProcessLookupError:break
    time.sleep(.1)
  rc=p.wait(timeout=5)
 result={'command':args,'exit':rc,'stop':stop,'seconds':round(time.monotonic()-t,3),'log_sha256':hashlib.sha256((ROOT/(label+'.log')).read_bytes()).hexdigest()};results.append(result);dump(label+'-RESULT.json',result)
 if rc or stop:break
shutil.rmtree(TMP)
after=hashes();dump('RESULT.json',{'results':results,'sources_unchanged':before==after,'source_after':after,'minimum_free':minimum,'peak_owned_tmp':peak,'tmp_removed':not TMP.exists(),'scope':'Actual full make test and scoped build lint; opt-in runtime/image/hosted gates remain separate'})
print(json.dumps({'root':str(ROOT),'results':results,'sources_unchanged':before==after,'minimum_free':minimum,'peak_owned_tmp':peak}))
raise SystemExit(0 if len(results)==3 and all(x['exit']==0 and x['stop'] is None for x in results) and before==after else 1)
