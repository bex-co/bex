import subprocess,json,pathlib,time,datetime
sha='846a56038319f1b5c212d1fcda8291d20e49c2b0'
p=pathlib.Path('/private/tmp/bex-w8-trivy-corrected-elixir-dispatch-20261030');p.mkdir(exist_ok=False)
s={'source':sha,'scope':'one corrected dispatch per exact Elixir118/119 runtime; no ambiguous POST replay','requests':[]}
def save():(p/'receipt.json').write_text(json.dumps(s,indent=2)+'\n')
def api(endpoint,label,method='GET',body=None):
 cmd=['gh','api','-H','Cache-Control: no-cache','--method',method,endpoint+('' if method!='GET' else ('&' if '?' in endpoint else '?')+'w8_fresh='+str(time.time_ns()))]
 if body:cmd+=['--input',str(body)]
 r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60);(p/(label+'.json')).write_bytes(r.stdout);(p/(label+'.stderr')).write_bytes(r.stderr);s['requests'].append({'label':label,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':method,'exit':r.returncode,'bytes':len(r.stdout)});save();assert r.returncode==0,(label,r.stderr.decode()[-500:]);return json.loads(r.stdout) if r.stdout else None
branch=api('repos/bex-co/bex/branches/main','main');assert branch['commit']['sha']==sha,'main changed; review before dispatch'
endpoint='repos/bex-co/bex/actions/workflows/native-base-image.yml/runs?event=workflow_dispatch&per_page=100'
pre=api(endpoint,'preflight');recent=[x for x in pre['workflow_runs'] if x['head_sha']==sha];assert not recent,'new-source manual run exists; inspect before avoiding duplicates'
for name in ['elixir-1.18','elixir-1.19']:
 before=api(endpoint,name+'-before');ids={x['id'] for x in before['workflow_runs']};body=p/(name+'-request.json');body.write_text(json.dumps({'ref':'main','inputs':{'runtime':name}})+'\n');api('repos/bex-co/bex/actions/workflows/native-base-image.yml/dispatches',name+'-post','POST',body)
 found=None
 for i in range(20):
  after=api(endpoint,name+'-after-'+str(i));new=[x for x in after['workflow_runs'] if x['id'] not in ids and x['head_sha']==sha]
  if new:assert len(new)==1,'ambiguous new runs, do not retry';found=new[0];break
  time.sleep(2)
 assert found is not None,'POST accepted but unique run unproved; do not retry'
 s.setdefault('runs',{})[name]={'run_id':found['id'],'source':found['head_sha'],'created_at':found['created_at'],'url':found['html_url'],'actual_job_identity':'pending matrix'};save();print(name,found['id'],found['head_sha'],flush=True)
print('receipt',p/'receipt.json',flush=True)
