import pathlib,subprocess,json,sys,time,datetime,hashlib
sha=sys.argv[1];assert len(sha)==40 and all(c in '0123456789abcdef' for c in sha)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==sha
p=pathlib.Path('/private/tmp/bex-w8-trivy-ssh-push-'+sha[:12]);p.mkdir(exist_ok=False)
s={'source':sha,'scope':'push reviewed CI fix; cancel only its own all-matrix push request after two fresh complete inventories prove no assigned or started build','observations':[]}
def save(): (p/'receipt.json').write_text(json.dumps(s,indent=2)+'\n')
def api(endpoint,method='GET'):
 if method=='GET':endpoint+=('&' if '?' in endpoint else '?')+'w8_fresh='+str(time.time_ns())
 r=subprocess.run(['gh','api','-H','Cache-Control: no-cache','--method',method,endpoint],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
 row={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'endpoint':endpoint,'method':method,'exit':r.returncode,'bytes':len(r.stdout),'sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr':r.stderr.decode()[-500:]};s['observations'].append(row);(p/(str(len(s['observations']))+'.json')).write_bytes(r.stdout);save()
 return json.loads(r.stdout) if r.returncode==0 and r.stdout else None
r=subprocess.run(['git','push','origin','HEAD:main'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180);(p/'push.txt').write_bytes(r.stdout);s['push_exit']=r.returncode;save();print('push exit',r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
run=None
for i in range(20):
 v=api('repos/bex-co/bex/actions/workflows/native-base-image.yml/runs?event=push&head_sha='+sha+'&per_page=20')
 if v:
  rows=[x for x in v['workflow_runs'] if x['head_sha']==sha and x['event']=='push' and x['head_branch']=='main']
  if rows:assert len(rows)==1;run=rows[0];break
 time.sleep(2)
if run is None:s['retirement']='no unique matching run observed; untouched';save();raise SystemExit(0)
s['run_id']=run['id'];save()
if run['status']=='completed':s['retirement']='already terminal; untouched';save();raise SystemExit(0)
for i in range(2):
 v=api('repos/bex-co/bex/actions/runs/'+str(run['id'])+'/jobs?per_page=100')
 if v is None or v['total_count']!=len(v['jobs']):s['retirement']='complete inventory unproved; untouched';save();raise SystemExit(0)
 jobs=v['jobs'];assert all(j['head_sha']==sha for j in jobs)
 builds=[j for j in jobs if j['name'].startswith('build (')]
 clean=all(j['status']=='queued' and j.get('runner_id',0)==0 and not j.get('runner_name') and all(x.get('status')=='queued' and not x.get('started_at') for x in j.get('steps',[])) for j in builds)
 if not clean:s['retirement']='assigned/started build observed; entire run untouched';save();print(s['retirement'],flush=True);raise SystemExit(0)
 s.setdefault('zero_active_predicates',[]).append({'observation':i+1,'represented_builds':len(builds),'all_builds_queued_unassigned_unstarted':True});save();time.sleep(0.5)
api('repos/bex-co/bex/actions/runs/'+str(run['id'])+'/cancel','POST');assert s['observations'][-1]['exit']==0;s['retirement']='cancel requested only after two fresh zero-active build predicates';save();print('own full run',run['id'],s['retirement'],flush=True)
for i in range(12):
 v=api('repos/bex-co/bex/actions/runs/'+str(run['id']))
 if v and v['status']=='completed':s['terminal_conclusion']=v['conclusion'];save();break
 time.sleep(2)
print('receipt',p/'receipt.json',flush=True)
