import contextlib
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import stat
import struct
import tempfile
import threading
import time
import unittest
from unittest import mock
import warnings
import zipfile

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("utility_zip", HERE / "extract_utility_zip.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class Intake(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="utility-zip-synthetic-", dir=HERE)
        self.root = Path(self.temp.name)
        self.free = mock.patch.object(m, "free_bytes", return_value=8 << 30)
        self.free.start()
        self.handlers = {s: signal.getsignal(s) for s in (signal.SIGINT, signal.SIGTERM)}

    def tearDown(self):
        self.free.stop()
        self.assertEqual({s: signal.getsignal(s) for s in self.handlers}, self.handlers)
        self.assertFalse(any(t.name == "owned-utility-zip-observer" for t in threading.enumerate()))
        self.temp.cleanup()

    def make(self, files=None, manifest=None, extra=None, method=zipfile.ZIP_DEFLATED, name="input.zip"):
        files = files if files is not None else {"data.bin": b"actual synthetic\0\xff data\n"}
        rows = [{"path": p, "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()} for p, b in files.items()]
        body = manifest if manifest is not None else json.dumps({"files": rows, "scope": "synthetic only"}, indent=2).encode() + b"\r\n"
        archive = self.root / name
        with warnings.catch_warnings(), zipfile.ZipFile(archive, "w", compression=method) as z:
            warnings.simplefilter("ignore", UserWarning)
            for path, data in files.items():
                z.writestr(path, data)
            for info, data in extra or []:
                z.writestr(info, data)
            z.writestr("MANIFEST.json", body)
        return archive, files, body

    def run_zip(self, archive, output="owned", **kwargs):
        return m.extract(archive, kwargs.get("size", archive.stat().st_size), kwargs.get("sha", hashlib.sha256(archive.read_bytes()).hexdigest()), self.root / output)

    def refuses(self, archive, text=None, **kwargs):
        with self.assertRaises(Exception) as caught:
            self.run_zip(archive, **kwargs)
        if text:
            self.assertIn(text, str(caught.exception))
        receipt = self.root / kwargs.get("output", "owned") / "extraction.json"
        if receipt.exists():
            self.assertFalse(json.loads(receipt.read_text())["complete"])
        return caught.exception

    def test_real_extraction_preserves_raw_gzip_hidden_unicode_manifest_and_private_modes(self):
        raw = b'{"packages":[{"name":"synthetic"}]}\n'
        files = {"reports/raw.json": raw, "reports/raw.json.gz": gzip.compress(raw, mtime=0), ".hidden": b"", "na\u00efve/file.bin": b"\0\xff\n"}
        directory = zipfile.ZipInfo("empty/")
        directory.external_attr = (stat.S_IFDIR | 0o777) << 16
        archive, files, body = self.make(files, extra=[(directory, b"")])
        state = self.run_zip(archive)
        self.assertTrue(state["complete"])
        artifact = self.root / "owned/artifact"
        self.assertEqual((artifact / "MANIFEST.json").read_bytes(), body)
        for path, data in files.items():
            self.assertEqual((artifact / path).read_bytes(), data)
            self.assertEqual(stat.S_IMODE((artifact / path).stat().st_mode), 0o600)
        self.assertTrue((artifact / "empty").is_dir())
        self.assertEqual(gzip.decompress((artifact / "reports/raw.json.gz").read_bytes()), raw)
        self.assertEqual(state["completed_members"], len(files) + 1)

    def test_stored_member_and_empty_file(self):
        z, _, _ = self.make({"empty": b"", "value": b"unchanged"}, method=zipfile.ZIP_STORED)
        self.assertTrue(self.run_zip(z)["complete"])

    def test_small_stream_chunks_use_real_zip_open(self):
        z, _, _ = self.make({"multi": bytes(range(128)) * 4})
        original, reads = zipfile.ZipExtFile.read, []
        def read(stream, size=-1):
            reads.append(size)
            return original(stream, size)
        with mock.patch.object(m, "CHUNK", 17), mock.patch.object(zipfile.ZipExtFile, "read", read):
            self.assertTrue(self.run_zip(z)["complete"])
        self.assertGreater(len(reads), 40)
        self.assertTrue(all(0 < n <= 17 for n in reads))

    def test_path_and_credential_scopes_refuse_before_opening_any_member(self):
        for index, bad in enumerate(["../escape", "/absolute", "C:/drive", "a//b", "./dot", "a\\b", "x/MANIFEST.json", ".docker/config.json", "x/.env", "x/render-env", "x/token.json", "x/private.kubeconfig"]):
            with self.subTest(bad=bad):
                z, _, _ = self.make({bad: b"not credentials; synthetic"}, name=f"bad-{index}.zip")
                with mock.patch.object(zipfile.ZipFile, "open", side_effect=AssertionError("member opened")) as opened:
                    self.refuses(z, output=f"bad-{index}")
                    opened.assert_not_called()

    def test_casefold_nfc_and_file_directory_collisions(self):
        for index, files in enumerate([{"A/x": b"a", "a/y": b"b"}, {"caf\u00e9": b"a", "cafe\u0301": b"b"}, {"parent": b"a", "parent/child": b"b"}]):
            z, _, _ = self.make(files, name=f"collision-{index}.zip")
            self.refuses(z, "path-collision", output=f"collision-{index}")

    def test_duplicate_member_and_symlink_fifo_unknown_extra(self):
        for index, kind in enumerate([stat.S_IFLNK, stat.S_IFIFO, stat.S_IFSOCK]):
            info = zipfile.ZipInfo("special")
            info.external_attr = (kind | 0o777) << 16
            z, _, _ = self.make({}, extra=[(info, b"synthetic")], name=f"special-{index}.zip")
            self.refuses(z, "special-member", output=f"special-{index}")
        info = zipfile.ZipInfo("link-metadata")
        info.extra = struct.pack("<HH", 0x000D, 0)
        z, _, _ = self.make({}, extra=[(info, b"")], name="extra.zip")
        self.refuses(z, "unknown-extra-metadata", output="extra")
        z, _, _ = self.make({"same": b"a"}, extra=[("same", b"b")], name="duplicate.zip")
        self.refuses(z, "duplicate-member", output="duplicate")

    def test_recognized_timestamp_and_unix_id_metadata_do_not_change_bytes_or_modes(self):
        info = zipfile.ZipInfo("metadata")
        info.extra = struct.pack("<HHBI", 0x5455, 5, 1, 42) + struct.pack("<HHBBBBB", 0x7875, 5, 1, 1, 0, 1, 0)
        data = b"ordinary payload"
        body = json.dumps({"files": [{"path": "metadata", "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}]}).encode()
        z, _, _ = self.make({}, manifest=body, extra=[(info, data)])
        self.assertTrue(self.run_zip(z)["complete"])
        self.assertEqual((self.root / "owned/artifact/metadata").read_bytes(), data)

    def test_sha_size_member_count_path_and_output_bounds(self):
        z, _, _ = self.make()
        self.refuses(z, "zip-sha-mismatch", sha="0" * 64)
        self.refuses(z, "zip-size-bound", size=True, output="bool")
        self.refuses(z, "zip-not-regular-or-size", size=z.stat().st_size + 1, output="size")
        with mock.patch.object(m, "MAX_MEMBERS", 1):
            self.refuses(z, "member-count", output="members")
        with mock.patch.object(m, "MAX_OUTPUT", 1):
            self.refuses(z, "declared-output-fit", output="total")
        with mock.patch.object(m, "MAX_MEMBER", 1):
            self.refuses(z, "member-size", output="member")
        with mock.patch.object(m, "MAX_PATH", 2):
            self.refuses(z, "member-path-bound", output="path")
        with mock.patch.object(m, "MAX_PARTS", 1):
            other, _, _ = self.make({"a/b": b"x"}, name="parts.zip")
            self.refuses(other, "member-path", output="parts")

    def test_manifest_bijection_typed_rows_duplicate_keys_and_tamper(self):
        sha = hashlib.sha256(b"x").hexdigest()
        cases = [b'{"files":[],"files":[]}', b'{"files":false}', json.dumps({"files": []}).encode(), json.dumps({"files": [{"path": "data", "bytes": True, "sha256": sha}]}).encode(), json.dumps({"files": [{"path": "data", "bytes": 1, "sha256": "0" * 64}]}).encode(), json.dumps({"files": [{"path": "data", "bytes": 2, "sha256": sha}]}).encode()]
        for i, body in enumerate(cases):
            z, _, _ = self.make({"data": b"x"}, manifest=body, name=f"manifest-{i}.zip")
            self.refuses(z, output=f"manifest-{i}")
        z, _, _ = self.make()
        with mock.patch.object(m, "MAX_MANIFEST", 1):
            self.refuses(z, "root-manifest", output="manifest-size")

    def test_crc_nul_encryption_and_unsupported_compression_are_real_archive_failures(self):
        z, _, _ = self.make({"payload": b"unique-stored-payload"}, method=zipfile.ZIP_STORED)
        raw = z.read_bytes().replace(b"unique-stored-payload", b"Unique-stored-payload", 1)
        z.write_bytes(raw)
        self.refuses(z, output="crc")
        z, _, _ = self.make({"nul.txt": b"x"}, name="nul.zip")
        z.write_bytes(z.read_bytes().replace(b"nul.txt", b"n\0l.txt"))
        self.refuses(z, "original-name-differs", output="nul")
        z, _, _ = self.make(name="encrypted.zip")
        raw = bytearray(z.read_bytes())
        for signature, offset in [(b"PK\x03\x04", 6), (b"PK\x01\x02", 8)]:
            at = raw.find(signature)
            struct.pack_into("<H", raw, at + offset, struct.unpack_from("<H", raw, at + offset)[0] | 1)
        z.write_bytes(raw)
        self.refuses(z, "zip-method-or-flags", output="encrypted")
        z, _, _ = self.make(method=zipfile.ZIP_BZIP2, name="method.zip")
        self.refuses(z, "zip-method-or-flags", output="method")

    def test_no_wrapper_strip_or_overwrite_or_symlink_input_output_parent(self):
        z, _, _ = self.make({"wrapper/file": b"x"}, manifest=b'{"files":[{"path":"file","bytes":1,"sha256":"' + hashlib.sha256(b"x").hexdigest().encode() + b'"}]}')
        self.refuses(z, "manifest-bijection")
        existing = self.root / "existing"
        existing.mkdir()
        (existing / "sentinel").write_bytes(b"foreign")
        self.refuses(z, output="existing")
        self.assertEqual((existing / "sentinel").read_bytes(), b"foreign")
        alias = self.root / "alias"
        alias.symlink_to(z)
        self.refuses(alias, "zip-not-regular-or-size", output="symlink")
        parent = self.root / "linked-parent"
        parent.symlink_to(self.root)
        self.refuses(z, "parent-not-directory", output="linked-parent/new")

    def test_space_entry_and_real_after_write_stop_preserve_partial(self):
        z, _, _ = self.make({"payload": b"x" * 100})
        with mock.patch.object(m, "free_bytes", return_value=m.FLOOR):
            self.refuses(z, "free-space-bound", output="entry")
        def available(path):
            f = self.root / "partial/artifact/payload"
            return 0 if f.exists() and f.stat().st_size else 8 << 30
        with mock.patch.object(m, "free_bytes", side_effect=available):
            self.refuses(z, "free-space-bound", output="partial")
        self.assertEqual((self.root / "partial/artifact/payload").read_bytes(), b"x" * 100)
        receipt = json.loads((self.root / "partial/extraction.json").read_text())
        self.assertFalse(receipt["complete"])
        self.assertEqual(receipt["observed_output_bytes"], 100)

    def test_observer_real_failure_and_start_then_raise_are_joined(self):
        z, _, _ = self.make({"slow.bin": b"small"})
        original_read = zipfile.ZipExtFile.read
        def delayed(stream, size=-1):
            if stream.name == "slow.bin":
                time.sleep(1.1)
            return original_read(stream, size)
        def available(path):
            return 0 if threading.current_thread().name == "owned-utility-zip-observer" else 8 << 30
        with mock.patch.object(m, "free_bytes", side_effect=available), mock.patch.object(zipfile.ZipExtFile, "read", delayed):
            self.refuses(z, "cancel-or-observer-failure")
        original_start = threading.Thread.start
        def started(thread):
            original_start(thread)
            raise OSError("synthetic-start-after")
        with mock.patch.object(threading.Thread, "start", started):
            self.refuses(z, output="started")

    def test_partial_signal_install_and_cancellation_restore_handlers(self):
        z, _, _ = self.make()
        original_signal, calls = signal.signal, []
        def installing(signum, handler):
            calls.append(signum)
            if len(calls) == 2:
                raise OSError("synthetic-install")
            return original_signal(signum, handler)
        with mock.patch.object(signal, "signal", installing):
            self.refuses(z)
        original_check = m.Budget.check
        def cancelled(budget, *args, **kwargs):
            signal.getsignal(signal.SIGTERM)(signal.SIGTERM, None)
            return original_check(budget, *args, **kwargs)
        with mock.patch.object(m.Budget, "check", cancelled):
            self.refuses(z, output="cancel")


    def test_exact_projected_free_fit_and_zero_payload_budget_boundary(self):
        z, _, _ = self.make({"deep/a/b/payload": b"small"})
        with zipfile.ZipFile(z) as archive:
            declared = sum(i.file_size for i in archive.infolist())
        def available(path):
            artifact = self.root / "owned/artifact"
            written = sum(p.stat().st_size for p in artifact.rglob("*") if p.is_file())
            return m.FLOOR + m.MARGIN + declared - written
        with mock.patch.object(m, "free_bytes", side_effect=available), mock.patch.object(m, "MAX_OUTPUT", declared):
            self.assertTrue(self.run_zip(z)["complete"])
        for path in (self.root / "owned/artifact/deep", self.root / "owned/artifact/deep/a", self.root / "owned/artifact/deep/a/b"):
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o700)

    def test_final_observation_and_restore_failure_cannot_keep_complete_receipt(self):
        z, _, _ = self.make()
        original_check, seen = m.Budget.check, [0]
        def final(budget, *args, **kwargs):
            if kwargs.get("inventory"):
                seen[0] += 1
                if seen[0] == 2:
                    raise OSError("synthetic-final-observation")
            return original_check(budget, *args, **kwargs)
        with mock.patch.object(m.Budget, "check", final):
            self.refuses(z)
        real_signal, installed = signal.signal, [False]
        def restoring(signum, handler):
            if handler is self.handlers[signal.SIGTERM] and signum == signal.SIGTERM and not installed[0]:
                installed[0] = True
                real_signal(signum, handler)
                raise OSError("synthetic-restore-after")
            return real_signal(signum, handler)
        with mock.patch.object(signal, "signal", restoring):
            self.refuses(z, "signal-restore-failure", output="restore")
        self.assertTrue(installed[0])

    def test_truncated_archive_and_unknown_system_refuse_without_repair(self):
        z, _, _ = self.make(name="truncated.zip")
        z.write_bytes(z.read_bytes()[:-10])
        self.refuses(z, output="truncated")
        info = zipfile.ZipInfo("unknown-platform")
        info.create_system = 7
        z, _, _ = self.make({}, extra=[(info, b"x")], name="unknown-system.zip")
        self.refuses(z, "unknown-member-system", output="unknown-system")

    def test_injected_parent_symlink_never_creates_foreign_descendant(self):
        z, _, _ = self.make({"nested/new/file": b"small"})
        foreign = self.root / "foreign"
        foreign.mkdir()
        (foreign / "sentinel").write_bytes(b"unchanged")
        original = zipfile.ZipFile.open
        injected = [False]
        def opening(archive, member, *args, **kwargs):
            if not injected[0]:
                injected[0] = True
                (self.root / "owned/artifact/nested").symlink_to(foreign)
            return original(archive, member, *args, **kwargs)
        with mock.patch.object(zipfile.ZipFile, "open", opening):
            self.refuses(z, "owned-nonregular")
        receipt = json.loads((self.root / "owned/extraction.json").read_text())
        self.assertEqual(receipt["failure"], "parent-not-directory")
        self.assertEqual(receipt["final_failure"], "owned-nonregular")
        self.assertEqual(list(foreign.iterdir()), [foreign / "sentinel"])
        self.assertEqual((foreign / "sentinel").read_bytes(), b"unchanged")

    def test_cancellation_during_handler_restoration_is_persisted_and_refused(self):
        z, files, _ = self.make()
        original, events = signal.signal, []
        def restoring(signum, handler):
            if signum == signal.SIGTERM and handler is self.handlers[signum] and not events:
                events.append("existing SIGINT callback during SIGTERM restore")
                signal.getsignal(signal.SIGINT)(signal.SIGINT, None)
            return original(signum, handler)
        with mock.patch.object(signal, "signal", restoring):
            self.refuses(z, "late-observer-failure")
        receipt = json.loads((self.root / "owned/extraction.json").read_text())
        self.assertEqual(len(events), 1)
        self.assertFalse(receipt["complete"])
        self.assertTrue(receipt["cancelled"])
        self.assertIsNone(receipt["observer_error"])
        for name, body in files.items():
            self.assertEqual((self.root / "owned/artifact" / name).read_bytes(), body)

if __name__ == "__main__":
    unittest.main(verbosity=2)
