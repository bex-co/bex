import hashlib, importlib.util, json, pathlib, signal, tempfile, threading, zipfile
from unittest import mock
R=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('extractor_reviewed',R/'extract_utility_zip.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
initial={s:signal.getsignal(s) for s in (signal.SIGINT,signal.SIGTERM)}
with tempfile.TemporaryDirectory(prefix='owned-probe-',dir=R) as d:
 root=pathlib.Path(d);p=root/'input.zip'; payload=b'synthetic only\n'; body=json.dumps({'files':[{'path':'data.bin','bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}]}).encode()
 with zipfile.ZipFile(p,'w',compression=zipfile.ZIP_DEFLATED) as z:z.writestr('data.bin',payload);z.writestr('MANIFEST.json',body)
 original=signal.signal;events=[]
 def restoring(signum,handler):
  if signum==signal.SIGTERM and handler is initial[signum] and not events:
   events.append('cancellation callback invoked while restoring SIGTERM, after final receipt write')
   signal.getsignal(signal.SIGINT)(signal.SIGINT,None)
  return original(signum,handler)
 result=None;error=None
 try:
  with mock.patch.object(m,'free_bytes',return_value=8<<30),mock.patch.object(signal,'signal',side_effect=restoring):
   result=m.extract(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest(),root/'output')
 except BaseException as e:error={'type':type(e).__name__,'args':e.args}
 receipt=json.loads((root/'output/extraction.json').read_text())
 observed={'source_sha256':hashlib.sha256((R/'extract_utility_zip.py').read_bytes()).hexdigest(),'injection':'Exact existing flag-only SIGINT callback during SIGTERM restoration; no real signal sent','events':events,'returned':result,'error':error,'receipt':receipt,'handlers_restored':{s:signal.getsignal(s) for s in initial}==initial,'observer_absent':not any(t.name=='owned-utility-zip-observer' for t in threading.enumerate()),'partial_payload_unchanged':(root/'output/artifact/data.bin').read_bytes()==payload}
 (R/'late-cancel-result.json').write_text(json.dumps(observed,indent=2)+'\n')
 print(json.dumps({'injected':bool(events),'returned_complete':result and result['complete'],'receipt_complete':receipt['complete'],'error':error,'handlers_restored':observed['handlers_restored'],'observer_absent':observed['observer_absent']}))
