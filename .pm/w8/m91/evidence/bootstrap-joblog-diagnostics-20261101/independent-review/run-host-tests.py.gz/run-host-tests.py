from pathlib import Path
import importlib.util,sys,types,unittest
P=Path('/private/tmp/bex-w8-bootstrap-joblog-diagnostics-source-20261101-1q0qcafg');R=Path('/Users/tianpan/projects/bex7')
q=types.ModuleType('independent_new_qualification');q.__file__=str(P/'source/.github/scripts/native-common-qualify.py');exec(compile(Path(q.__file__).read_bytes(),q.__file__,'exec'),q.__dict__)
testpath=R/'.github/scripts/test_native_oci_common_qualification.py'
s=(P/'source/.github/scripts/test_native_oci_common_qualification.py').read_text()
old='qualification = load("native_common_qualification", HERE / "native-common-qualify.py")'
assert s.count(old)==1
s=s.replace(old,'qualification = __review_qualification')
m=types.ModuleType('independent_diagnostics_tests');m.__file__=str(testpath);m.__dict__['__review_qualification']=q;sys.modules[m.__name__]=m
exec(compile(s,str(testpath),'exec'),m.__dict__)
suite=unittest.defaultTestLoader.loadTestsFromModule(m);assert suite.countTestCases()==83
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
