"""Proposed three serial CI source checks. No invocation before Root approval."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,shutil,signal,stat,subprocess,time
R=Path(__file__).resolve().parent;V=R/'view';T=R/'tmp';REPO=Path('/Users/tianpan/projects/bex7')
FLOOR=(8<<30)+(128<<20);CAP=128<<20;WHOLE=600
P=Path('/opt/homebrew/bin/python3.14')
GO=Path('/opt/homebrew/Cellar/go/1.26.4/libexec/bin/go')
LINT=REPO/'lego/operator/bin/golangci-lint'
INPUTS=json.loads((R/'SOURCE-MANIFEST.json').read_text())
DEP=Path('/private/tmp/bex-w8-node14-local-pilot-v4-source-20261101-bop3sbht/run_pilot.py')
def sha(p):
 digest=hashlib.sha256()
 with Path(p).open('rb') as stream:
  while chunk:=stream.read(1<<20):digest.update(chunk)
 return digest.hexdigest()
def identity(path):
 path=Path(path);info=path.lstat()
 assert stat.S_ISREG(info.st_mode)
 return {'bytes':info.st_size,'sha256':sha(path),'mode':oct(stat.S_IMODE(info.st_mode))}

def dump(name,value):(R/name).write_text(json.dumps(value,indent=2)+'\n')
def size(path):
 total=0
 def missing(error):
  if not isinstance(error,FileNotFoundError):raise error
 for base,dirs,files in os.walk(path,onerror=missing,followlinks=False):
  for name in files:
   try:s=(Path(base)/name).lstat()
   except FileNotFoundError:continue
   if stat.S_ISREG(s.st_mode):total+=s.st_size
 return total
assert sha(DEP)=='e158acde2c44aac290d09f109ddf4f3bf2ca93dc660161dd326fb3ad7cc72c03'
spec=importlib.util.spec_from_file_location('reviewed_group_cleanup',DEP);cleanup=importlib.util.module_from_spec(spec);spec.loader.exec_module(cleanup)
expected=json.loads((R/'VIEW-MANIFEST.json').read_text())
def view_matches():
 entries=list(V.rglob('*'))
 if any(not(stat.S_ISDIR(p.lstat().st_mode) or stat.S_ISREG(p.lstat().st_mode)) for p in entries):return False
 actual={str(p.relative_to(V)) for p in entries if p.is_file()}
 return actual==set(expected) and all(identity(V/rel)==row for rel,row in expected.items())
assert view_matches();assert shutil.disk_usage(R).free>=FLOOR+CAP+(32<<20)
assert identity(R/'VIEW-MANIFEST.json')==INPUTS['view_manifest']
for rel,want in INPUTS['repo301'].items():assert identity(REPO/rel)==want
for rel,want in INPUTS['private_sources'].items():assert identity(R/'source'/rel)==want
assert identity(REPO/'lego/go.work.sum')==INPUTS['foreign_go_work_sum']
for rel,want in INPUTS['supplemental_repo_inputs'].items():assert identity(REPO/rel)==want
for tool in INPUTS['tools'].values():assert identity(tool['path'])=={k:tool[k] for k in ('bytes','sha256','mode')}
for path in INPUTS['cache_directories'].values():assert Path(path).is_dir() and not Path(path).is_symlink()
T.mkdir(mode=0o700);(R/'home').mkdir(mode=0o700)
env=os.environ.copy()
for key in list(env):
 if key.startswith(('BEX_','GITHUB_','RUNNER_','GIT_')) or key in ('CI','KUBECONFIG','DOCKER_CONTEXT','DOCKER_HOST','PYTHONPATH','PYTHONOPTIMIZE','WORKFLOWS_DIR','PRODUCTION_SECRETS_FILE'):env.pop(key,None)
env.update(TMPDIR=str(T),HOME=str(R/'home'),PYTHONDONTWRITEBYTECODE='1',PYTHONPYCACHEPREFIX=str(T/'unused-pyc'),PATH='/Users/tianpan/.nvm/versions/node/v24.16.0/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')
env.update(INPUTS['cache_directories'])
env.update(GOWORK='off',GOTOOLCHAIN='local',GOENV='off',GOFLAGS='-mod=readonly',GOMAXPROCS='2',GOPROXY='off',GOSUMDB='off',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null')
policy='(version 1) (allow default) (deny network-outbound) (allow network-outbound (remote ip "localhost:*"))'
commands=[
 ('python153',[str(P),'-B','-m','unittest','discover','-s','.github/scripts','-p','test_native_oci_*.py'],120,str(V)),
 ('go-policy',[str(GO),'test','-p','1','-count=1','-timeout','150s','./internal/build','-run','^TestCommonNodeRuntimeArtifactPolicy$','-v'],180,str(REPO/'lego/operator')),
 ('build-lint',[str(LINT),'run','--concurrency','2','./internal/build'],240,str(REPO/'lego/operator')),
]
def bound_sources():
 return {'actual_repository_HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,env=env,timeout=10).decode().strip(),
  'foreign_go_work_sum':identity(REPO/'lego/go.work.sum'),
  'repo301':{rel:identity(REPO/rel) for rel in INPUTS['repo301']},
  'supplemental_repo_inputs':{rel:identity(REPO/rel) for rel in INPUTS['supplemental_repo_inputs']},
  'private_sources':{rel:identity(R/'source'/rel) for rel in INPUTS['private_sources']},
  'view_manifest':identity(R/'VIEW-MANIFEST.json'),
  'tools':{name:identity(row['path']) for name,row in INPUTS['tools'].items()}}
before=bound_sources()
assert before['actual_repository_HEAD']==INPUTS['actual_repository_HEAD']
dump('CHECK-SOURCE-BEFORE.json',before)
dump('SCOPE.json',{'commands':commands,'network':'Same qbed sandbox: denies nonloopback outbound; existing loopback source-control fixture only. No target opt-ins, native, Docker, registry, auth or integration actions.',
 'sandbox_policy':policy,'physical_floor_plus_margin':FLOOR,'owned_TMP_cap':CAP,'whole_seconds':WHOLE,'source':before,
 'Go_environment':{key:env[key] for key in ('GOPATH','GOMODCACHE','GOCACHE','GOLANGCI_LINT_CACHE','GOWORK','GOTOOLCHAIN','GOENV','GOFLAGS','GOMAXPROCS','GOPROXY','GOSUMDB')},
 'shared_caches':'Ordinary existing Go module/build/lint caches read/write; no clone/prune/delete. Missing local dependencies fail under no-outbound scope; no automatic repair.',
 'resources':'Operating disk/deadline bounds, no capacity reservation. Private view remains frozen; Go/lint read current repository operator.'})
start=time.monotonic();minimum=shutil.disk_usage(R).free;peak=0;groups={};handlers={};signals=[];results=[];failure=None
try:
 for sig in (signal.SIGINT,signal.SIGTERM):handlers[sig]=signal.getsignal(sig);signal.signal(sig,lambda n,f:signals.append(n))
 for label,argv,seconds,cwd in commands:
  if signals or groups or not view_matches():raise RuntimeError('cancelled, pending group or changed source')
  if time.monotonic()-start>WHOLE or shutil.disk_usage(R).free<FLOOR or size(T)>CAP:raise RuntimeError('pre-spawn operating guard')
  began=time.monotonic();bound=None;process=None;absent=False
  actual=['/usr/bin/sandbox-exec','-p',policy,*argv]
  with (R/(label+'.stdout')).open('wb') as out,(R/(label+'.stderr')).open('wb') as err:
   try:
    process=subprocess.Popen(actual,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True);groups[process.pid]=process
    dump(label+'-PROCESS.json',{'pid':process.pid,'pgid':process.pid,'argv':actual,'cwd':cwd})
    while process.poll() is None:
     free=shutil.disk_usage(R).free;owned=size(T);minimum=min(minimum,free);peak=max(peak,owned)
     if signals or free<FLOOR or owned>CAP or time.monotonic()-began>seconds or time.monotonic()-start>WHOLE:
      bound={'free':free,'owned_TMP':owned,'seconds':time.monotonic()-began,'signals':signals};break
     time.sleep(.15)
   except BaseException as error:bound={'observer_error':type(error).__name__,'message':str(error)}
   finally:
    if process is not None:
     absent=cleanup.stop_group(process)
     if absent:groups.pop(process.pid,None)
  free=shutil.disk_usage(R).free;owned=size(T);minimum=min(minimum,free);peak=max(peak,owned)
  if signals or free<FLOOR or owned>CAP or time.monotonic()-start>WHOLE:bound=bound or {'late_guard':True,'signals':signals,'free':free,'owned_TMP':owned}
  result={'label':label,'argv':actual,'exit':process.returncode if process else None,'bound':bound,'seconds':time.monotonic()-began,'group_absent':absent,'stdout_sha256':sha(R/(label+'.stdout')),'stderr_sha256':sha(R/(label+'.stderr'))};results.append(result);dump(label+'-RESULT.json',result);print(json.dumps(result),flush=True)
  if process is None or process.returncode or bound or not absent:break
except BaseException as error:failure=type(error).__name__+': '+str(error)
finally:
 for pgid,process in list(groups.items()):
  if cleanup.stop_group(process):groups.pop(pgid,None)
 for sig,handler in handlers.items():signal.signal(sig,handler)
 after=bound_sources()
 dump('CHECK-SOURCE-AFTER.json',after)
 if not groups:shutil.rmtree(T);shutil.rmtree(R/'home')
 report={'PASS':len(results)==len(commands) and all(r['exit']==0 and r['bound'] is None and r['group_absent'] for r in results) and before==after and view_matches() and not groups and not signals and failure is None,'results':results,'failure':failure,'source_unchanged':before==after,'view_unchanged':view_matches(),'minimum_free_bytes':minimum,'peak_TMP_bytes':peak,'own_TMP_gone':not T.exists(),'pending_pgids':sorted(groups),'signals':signals,'elapsed_seconds':time.monotonic()-start,'actual_runtime_or_adoption_claim':False}
 dump('RESULT.json',report)
print(json.dumps(report),flush=True)
raise SystemExit(0 if report['PASS'] else 1)
