import pathlib,json,subprocess,datetime,time
p=pathlib.Path(__file__).parent

def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def gh(args):
 r=subprocess.run(['gh',*args],capture_output=True,timeout=60);assert r.returncode==0,r.stderr.decode()[:500];return r.stdout
run=json.loads(gh(['api','repos/bex-co/bex/actions/runs/41043547006']));jobs=json.loads(gh(['api','repos/bex-co/bex/actions/runs/41043547006/jobs?per_page=100']))
(p/'pre-cancel-run.json').write_text(json.dumps(run,indent=2)+'\n');(p/'pre-cancel-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
assert run['status']=='queued' and jobs['total_count']==len(jobs['jobs']) and all(j['status'] in ('queued','completed') for j in jobs['jobs'])
assert {j['name'].split('build (',1)[1].split(',',1)[0] for j in jobs['jobs'] if j['status']=='queued'}=={'python-3.7-bullseye','python-3.8-bookworm'}
started=utc();out=gh(['run','cancel','41043547006']);(p/'cancel-output.txt').write_bytes(out);(p/'cancel-receipt.json').write_text(json.dumps({'runId':41043547006,'requestedAt':started,'exitCode':0,'reason':'Entire run queued, zero running jobs; current queued jobs duplicate approved suppliers. Replace latent pre-HTTP1/pre-complete-retry matrix with exactly16 current missing supplier targets. Running independent Node18/20 jobs untouched.'},indent=2)+'\n');print('cancel queued obsolete run',out.decode().strip(),flush=True)
targets=json.loads((p/'targets.json').read_text());current=gh(['api','repos/bex-co/bex/commits/main']);assert json.loads(current)['sha']==targets['source'],'main moved: review source before dispatch'
for name in targets['names']:
 stamp=utc();out=gh(['workflow','run','native-base-image.yml','--ref','main','-f','runtime='+name]);r={'name':name,'source':targets['source'],'requestedAt':stamp,'exitCode':0};(p/('dispatch-'+name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print('dispatched',name,stamp,flush=True)
(p/'after.json').write_bytes(gh(['run','list','--workflow','native-base-image.yml','--limit','100','--json','databaseId,createdAt,headSha,status,conclusion,event']));print('all16 submitted',flush=True)
