"""Local wrapper controls with fake executables; no registry, DB, scanner or candidate proof."""
import errno
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
REF = 'ghcr.io/bex-co/bex-cnb-run@sha256:' + '1' * 64
FAKE = r'''#!/usr/bin/env python3
import json,os,pathlib,resource,subprocess,sys
root=pathlib.Path(os.environ['CONTROL_ROOT']);name=pathlib.Path(sys.argv[0]).name
log=root/'calls.jsonl'
def event(x):
 with log.open('a') as f:f.write(json.dumps(x)+'\n')
if name=='df':
 count=root/'df-count';n=int(count.read_text())+1 if count.exists() else 1;count.write_text(str(n))
 available=1 if os.environ['CONTROL_MODE']=='low-space' or (os.environ['CONTROL_MODE']=='space-after-db' and n>1) else 40*1024*1024
 print('Filesystem 1024-blocks Used Available Capacity Mounted on')
 for path in sys.argv[-2:]: print('local 999999999 1',available,'1%',path)
 sys.exit(0)
if name=='sleep':sys.exit(0)
if name=='timeout':
 event({'tool':'timeout','argv':sys.argv[1:]})
 if os.environ['CONTROL_MODE']=='timeout' and '--download-db-only' not in sys.argv and '--download-java-db-only' not in sys.argv:
  try: subprocess.run(sys.argv[3:],timeout=.15,check=False)
  except subprocess.TimeoutExpired: sys.exit(124)
 sys.exit(subprocess.call(sys.argv[3:]))
args=sys.argv[1:];database=any(a.startswith('--download-') for a in args)
rows=[json.loads(x) for x in log.read_text().splitlines()] if log.exists() else []
scans=sum(x.get('tool')=='trivy' and not x.get('database') for x in rows)
tmp=pathlib.Path(os.environ['TMPDIR']);(tmp/'own-partial').write_text('controlled local temporary bytes')
output=os.environ.get('TRIVY_OUTPUT')
event({'tool':'trivy','argv':args,'database':database,'platform':os.environ.get('TRIVY_PLATFORM'),'cache':os.environ.get('TRIVY_CACHE_DIR'),'tmp':str(tmp),'limit':resource.getrlimit(resource.RLIMIT_FSIZE),'stale_report':bool(output and pathlib.Path(output).exists()),'scan_timeout':os.environ.get('TRIVY_TIMEOUT'),'scanners':os.environ.get('TRIVY_SCANNERS'),'output':output})
if database:
 (pathlib.Path(os.environ['TRIVY_CACHE_DIR'])/'kept-cache').write_text('valid existing cache control')
 sys.exit(3 if os.environ['CONTROL_MODE']=='db-fail' else 0)
pathlib.Path(output).write_text('partial report')
mode=os.environ['CONTROL_MODE']
if mode=='timeout':
 import time;time.sleep(30)
if mode=='fail' or (mode=='retry' and scans<2):sys.exit(2)
pathlib.Path(output).write_text(json.dumps({'CONTROL_ONLY':True,'argv':args}))
'''

class Controls(unittest.TestCase):
 def run_control(self, mode, arch='linux/amd64', posix=False):
  td=tempfile.TemporaryDirectory(prefix='trivy-staging-control-');self.addCleanup(td.cleanup)
  root=Path(td.name);bin=root/'bin';bin.mkdir();runner=root/'runner';runner.mkdir();cache=root/'cache';cache.mkdir()
  foreign=runner/'foreign-sentinel';foreign.write_text('untouched');(cache/'foreign-cache').write_text('untouched')
  report=root/'report.json';report.write_text('stale report')
  for n in ['df','sleep','timeout','trivy']:
   f=bin/n;f.write_text(FAKE);f.chmod(0o755)
  env=os.environ.copy();env.update(PATH=str(bin)+os.pathsep+env['PATH'],RUNNER_TEMP=str(runner),TRIVY_OUTPUT=str(report),TRIVY_CACHE_DIR=str(cache),TRIVY_PLATFORM=arch,TRIVY_TIMEOUT='20m',CONTROL_ROOT=str(root),CONTROL_MODE=mode)
  env.pop('TRIVY_SCANNERS',None)
  if posix:env['POSIXLY_CORRECT']='1'
  proc=subprocess.run(['/bin/bash',str(ROOT/'native-trivy'),'image',REF],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
  calls=[json.loads(x) for x in (root/'calls.jsonl').read_text().splitlines()] if (root/'calls.jsonl').exists() else []
  self.assertEqual(foreign.read_text(),'untouched');self.assertEqual((cache/'foreign-cache').read_text(),'untouched')
  self.assertEqual(list(runner.iterdir()),[foreign])
  return proc,calls,report,cache
 def test_complete_arguments_db_order_and_limits_on_both_architectures(self):
  for arch in ['linux/amd64','linux/arm64']:
   with self.subTest(arch=arch):
    p,c,r,cache=self.run_control('success',arch,posix=True);self.assertEqual(p.returncode,0,p.stderr)
    trivy=[x for x in c if x['tool']=='trivy'];self.assertEqual([x['argv'] for x in trivy[:2]],[['image','--download-db-only'],['image','--download-java-db-only']])
    scan=trivy[2];self.assertEqual(scan['argv'],['image',REF,'--image-src','remote','--parallel','1','--max-image-size','8589934592B'])
    self.assertEqual(scan['platform'],arch);self.assertEqual(scan['cache'],str(cache));self.assertEqual(scan['scan_timeout'],'20m');self.assertIsNone(scan['scanners'])
    self.assertEqual(scan['limit'],[8*1024**3,8*1024**3]);self.assertFalse(scan['stale_report'])
    self.assertTrue(all(x['output'] is None for x in trivy[:2]));self.assertTrue(r.exists());self.assertTrue((cache/'kept-cache').exists())
    self.assertTrue(all(x['argv'][:2]==['--kill-after=10s','21m'] for x in c if x['tool']=='timeout'))
 def test_three_complete_attempts_preserve_ref_and_remove_partial_reports(self):
  p,c,r,_=self.run_control('retry');self.assertEqual(p.returncode,0,p.stderr)
  scans=[x for x in c if x['tool']=='trivy' and not x['database']];self.assertEqual(len(scans),3)
  self.assertTrue(all(x['argv'][1]==REF and not x['stale_report'] for x in scans));self.assertTrue(r.exists())
  self.assertEqual(len([x for x in c if x['tool']=='trivy' and x['database']]),2)
 def test_exhausted_full_scans_fail_closed_and_clean_only_owned_temp(self):
  p,c,r,cache=self.run_control('fail');self.assertNotEqual(p.returncode,0);self.assertFalse(r.exists())
  self.assertEqual(len([x for x in c if x['tool']=='trivy' and not x['database']]),3);self.assertTrue((cache/'kept-cache').exists())
 def test_database_failure_never_yields_scan_approval(self):
  p,c,r,_=self.run_control('db-fail');self.assertNotEqual(p.returncode,0);self.assertFalse(r.exists())
  self.assertTrue(all(x.get('database',True) for x in c))
 def test_capacity_refusal_before_db_or_image_bytes(self):
  p,c,r,_=self.run_control('low-space');self.assertNotEqual(p.returncode,0);self.assertEqual(c,[]);self.assertFalse(r.exists())
 def test_capacity_rechecked_after_db_before_each_full_scan(self):
  p,c,r,cache=self.run_control('space-after-db');self.assertNotEqual(p.returncode,0);self.assertFalse(r.exists());self.assertTrue((cache/'kept-cache').exists())
  self.assertEqual(len([x for x in c if x['tool']=='trivy']),2)
 def test_timeout_reaps_own_child_and_cleans_dirty_temporary_files(self):
  p,c,r,_=self.run_control('timeout');self.assertNotEqual(p.returncode,0);self.assertFalse(r.exists())
  self.assertEqual(len([x for x in c if x['tool']=='trivy' and not x['database']]),3)
 def test_small_real_kernel_file_limit_is_a_hard_failure(self):
  with tempfile.TemporaryDirectory(prefix='trivy-limit-control-') as td:
   code='import resource,sys;resource.setrlimit(resource.RLIMIT_FSIZE,(4096,4096));open(sys.argv[1],"wb",buffering=0).write(b"x"*8192);open(sys.argv[1],"ab",buffering=0).write(b"x")'
   p=subprocess.run([sys.executable,'-c',code,str(Path(td)/'owned-file')],text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   self.assertNotEqual(p.returncode,0);self.assertLessEqual((Path(td)/'owned-file').stat().st_size,4096)

if __name__=='__main__':unittest.main(verbosity=2)
