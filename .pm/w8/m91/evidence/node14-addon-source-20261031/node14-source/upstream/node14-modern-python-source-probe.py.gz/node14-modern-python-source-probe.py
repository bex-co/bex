"""Exercise the exact vendored function's file-open path, not an addon/image."""
import ast,hashlib,json,os,sys,tempfile
from pathlib import Path
root=Path(__file__).resolve().parent
source=root/'node14-vendored-gyp-input.py'
raw=source.read_bytes();tree=ast.parse(raw)
function=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='LoadOneBuildFile')
module=ast.Module(body=[function],type_ignores=[])
namespace={'os':os,'sys':sys}
exec(compile(module,str(source),'exec'),namespace)
with tempfile.TemporaryDirectory(prefix='source-gyp-control-',dir=root) as temporary:
 build=Path(temporary)/'binding.gyp';build.write_text("{'targets': []}\n")
 try:namespace['LoadOneBuildFile'](str(build),{},{},None,False,False)
 except ValueError as error:
  assert "invalid mode" in str(error) and 'rU' in str(error)
  result={'source_version':'Node14.21.3/npm bundled node-gyp5.1.1','function':'LoadOneBuildFile','upstream_source_sha256':hashlib.sha256(raw).hexdigest(),'executed_host_python':sys.version.split()[0],'actual_result':'ValueError','actual_error':str(error),'control_exit':0,'scope':'Exact source-extracted function file-open path with real host builtins; no npm/addon/compiler/common-image execution. Python3.11 removal established separately by official docs.'}
 else:raise RuntimeError('source control did not reproduce the removed-mode error')
(root/'node14-modern-python-source-probe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
