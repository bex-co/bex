import datetime,hashlib,json,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent; repo=pathlib.Path('/Users/tianpan/projects/bex7')
rows=json.loads((root/'SOURCE.json').read_text())['owned_paths']
def immutable():
 for row in rows:
  data=(repo/row['path']).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
immutable()
checks=[('common-python',['python3','-B','-m','unittest','discover','-s','deploy/native-common','-p','*_test.py','-v']),('workflow-python',['python3','-B','-m','unittest','discover','-s','.github/scripts','-p','test_native_oci_*.py']),('actionlint',['/opt/homebrew/bin/actionlint','-config-file',str(root/'actionlint.yaml'),'.github/workflows/native-base-image.yml','.github/workflows/native-common-image.yml']),('actions-guard',['bash','scripts/github-actions-validate.sh']),('diff-check',['git','diff','--check'])]
results=[]
for name,command in checks:
 before=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (root/'checks'/(name+'.log')).open('wb') as output:
  result=subprocess.run(command,cwd=repo,stdout=output,stderr=subprocess.STDOUT,timeout=90)
 row={'name':name,'command':command,'exit_code':result.returncode,'started_at':before,'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()};results.append(row);print(json.dumps(row),flush=True)
immutable();(root/'source-checks.json').write_text(json.dumps({'checks':results,'owned_source_unchanged':True},indent=2)+'\n')
sys.exit(any(row['exit_code'] for row in results))
