import datetime, hashlib, importlib.util, json, pathlib, subprocess, urllib.request
root=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('prepare_node14','/Users/tianpan/projects/bex7/deploy/native-common/prepare-node14-tools.py'); tools=importlib.util.module_from_spec(spec); spec.loader.exec_module(tools)
source_dir=root/'upstream';source_dir.mkdir()
rows=[]
for tag in ('v14.0.0','v14.21.3'):
 url='https://raw.githubusercontent.com/nodejs/node/'+tag+'/deps/npm/node_modules/node-gyp/lib/find-python.js'
 if tag=='v14.21.3':
  data=pathlib.Path('/private/tmp/bex-w8-common-runtime-audit-20261031-jps55hb5/node14-find-python.js').read_bytes();custody='exact original cached tagged upstream bytes; no refetch'
 else:
  with urllib.request.urlopen(url,timeout=30) as response: data=response.read(64<<10)
  custody='fresh public HTTPS tagged upstream read'
 text=data.decode();patched=tools.patch_finder(text)
 assert patched.count(tools.PRIVATE_CHECK)==1
 assert tools.patch_finder(patched)==patched
 (source_dir/(tag+'-find-python.js')).write_bytes(data)
 start=text.index('  findPython: function findPython () {');end=text.index('\n  // Check if command',start)
 actual=text[start:end].rstrip().removesuffix(',')
 fixture=pathlib.Path('/Users/tianpan/projects/bex7/deploy/native-common/testdata/node14-find-python.js').read_text()
 assert actual in fixture, tag+' finder method differs from retained fixture'
 rows.append({'tag':tag,'url':url,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'custody':custody,'exact_finder_method_matches_executed_fixture':True,'actual_complete_source_patch_and_idempotence':True})
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':rows,'scope':'tagged finder source transformation and same method custody only; no image/npm/addon execution'}
(root/'tagged-upstream-finder-control.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
