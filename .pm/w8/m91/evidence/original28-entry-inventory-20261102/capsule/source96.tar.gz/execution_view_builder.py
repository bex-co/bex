"""Build a clean source-only runner view from exact reviewed inputs; never execute it.
No auth/contract filling, native program, network, repo mutation or test on import.
"""
import hashlib,json,os,stat,sys
from pathlib import Path,PurePosixPath


def require(value,message):
    if not value:raise ValueError(message)

def sha(raw):return hashlib.sha256(raw).hexdigest()

def relative(name):
    require(isinstance(name,str) and name and not PurePosixPath(name).is_absolute()
            and '..' not in PurePosixPath(name).parts and str(PurePosixPath(name))==name,'canonical relative source name required')
    return name

def input_bytes(row):
    path=Path(row['source']);info=path.lstat()
    require(path.is_absolute() and stat.S_ISREG(info.st_mode) and not path.is_symlink()
            and str(path.resolve(strict=True))==str(path),'exact regular source input required')
    raw=path.read_bytes()
    require(len(raw)==row['bytes'] and sha(raw)==row['sha256'] and oct(stat.S_IMODE(info.st_mode))==row['mode'],
            'source input bytes/hash/mode drift')
    return raw

def runtime_manifest(files):
    require(isinstance(files,dict) and files and 'MANIFEST.json' not in files,'new source manifest must exclude itself')
    return {relative(name):{'bytes':row['bytes'],'sha256':row['sha256']} for name,row in sorted(files.items())}

def verify_view(target,files,manifest):
    target=Path(target);expected=set(files)|{'MANIFEST.json'}
    actual=set()
    for path in target.rglob('*'):
        info=path.lstat();require(stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode),'source view symlink/special path')
        if stat.S_ISREG(info.st_mode):actual.add(str(path.relative_to(target)))
    require(actual==expected,'closed execution view has missing/extra source file')
    for name,row in files.items():
        path=target/relative(name);info=path.lstat();raw=path.read_bytes()
        require(len(raw)==row['bytes'] and sha(raw)==row['sha256'] and oct(stat.S_IMODE(info.st_mode))==row['mode'],
                'execution view differs from reviewed bytes/mode')
    require((target/'MANIFEST.json').read_bytes()==manifest,'refreshed source manifest bytes differ')


def materialize(plan,target):
    """Used only with Root-reviewed plan, or tiny invented host-control input."""
    require(isinstance(plan,dict) and plan.get('schema')=='bex.original28.execution-view/v1'
            and plan.get('actual_authority') is None and isinstance(plan.get('files'),dict),'source-only execution-view plan required')
    files=plan['files'];manifest=(json.dumps(runtime_manifest(files),indent=2,sort_keys=True)+'\n').encode()
    require(sha(manifest)==plan.get('manifest_sha256') and len(manifest)==plan.get('manifest_bytes'),
            'Root-reviewed refreshed manifest differs')
    require(sum(row['bytes'] for row in files.values())+len(manifest)<3*1024*1024,'source view exceeds original3MiB component')
    roots=[Path(x) for x in plan['input_roots']]
    require(roots and all(p.is_absolute() and not p.is_symlink() for p in roots),'exact source roots required')
    for name,row in files.items():
        relative(name);source=Path(row['source'])
        require(any(source.is_relative_to(root) for root in roots),'source outside reviewed roots')
        input_bytes(row)
    require('ADOPTION-CONTRACT.json' in files and input_bytes(files['ADOPTION-CONTRACT.json']).strip()==b'null',
            'original actual contract must stay null')
    target=Path(target);require(not target.exists() and not target.is_symlink(),'new empty own source view required')
    target.mkdir(mode=0o700)
    for name,row in files.items():
        path=target/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(input_bytes(row));path.chmod(int(row['mode'],8))
    (target/'MANIFEST.json').write_bytes(manifest);(target/'MANIFEST.json').chmod(0o644)
    verify_view(target,files,manifest)
    return {'files':len(files),'manifest_bytes':len(manifest),'manifest_sha256':sha(manifest),'source_only':True,'actual_authority':None}


def main():
    root=Path(__file__).resolve().parent;path=root/'EXECUTION-VIEW-PLAN.json'
    if len(sys.argv)!=3 or sys.argv[1]!='--build-source-only':
        raise SystemExit('UNEXECUTED: only --build-source-only ROOT_REVIEWED_PLAN_SHA is supported; this never runs the adapter')
    raw=path.read_bytes();require(sha(raw)==sys.argv[2],'Root-reviewed source-view plan SHA differs')
    plan=json.loads(raw);target=Path(plan['output'])
    require(target.parent==Path('/private/tmp') and target.name=='bex-w8-original28-runner-view-'+root.name.rsplit('-',1)[1],
            'fixed unique own source-view output required')
    result=materialize(plan,target);print(json.dumps({'output':str(target),**result},sort_keys=True))

if __name__=='__main__':main()
