"""Five invented controls for the one seven-row inventory append; no real grant."""
import copy,json,unittest
from unittest.mock import patch
import core as c
import proof_binding as p
import readiness as r
import freshness_append as fresh
from qualification_fixtures import inventory_fixture
import test_d3_readiness as d3


class InventoryAppendControls(unittest.TestCase):
    def test_exact_seven_rows_keep_old_bytes_and_admit_only_the_bound_critical_delta(self):
        docs={};policy,before=inventory_fixture(docs);rows=fresh.reviewed_rows(policy,docs.__getitem__)
        after=fresh.render_append(before,rows);suffix=b'\n  ]\n}\n'
        self.assertTrue(after.startswith(before[:-len(suffix)]+b',\n'))
        self.assertEqual(json.loads(after)['images'],json.loads(before)['images']+rows)
        self.assertEqual(len(rows),7);self.assertEqual({row['kind'] for row in rows},{'native-base'})
        self.assertTrue(all(row['resolved_at']=='2026-01-02T03:04:05Z' for row in rows))
        contract,qualified,entry,docs,git,before,actual=d3.InitialRuntimeMapAdoptionControls().fixture()
        with patch.object(p,'bind_signature',return_value={}):result=r.adoption(contract,entry,qualified,docs.__getitem__,git)
        self.assertEqual(result['changed_critical_paths'],[r.COMMON_SLOT,fresh.PATH])

    def test_missing_extra_reordered_or_any_unreviewed_row_field_refuses(self):
        for change in ('missing','extra','reorder','id','kind','upstream','committed','files','source','date','extra-field'):
            docs={};policy,before=inventory_fixture(docs)
            if change=='missing':policy['rows'].pop()
            elif change=='extra':policy['rows'].append(copy.deepcopy(policy['rows'][0]))
            elif change=='reorder':policy['rows'].reverse()
            elif change=='extra-field':policy['rows'][0]['extra']='not reviewed'
            else:
                key={'date':'resolved_at'}.get(change,change)
                policy['rows'][0][key]=['another/path'] if key=='files' else 'not-the-exact-reviewed-value'
            with self.subTest(change=change),self.assertRaises(c.Unproved):fresh.reviewed_rows(policy,docs.__getitem__)

    def test_rehashed_receipt_date_tag_digest_or_header_drift_never_invents_resolution(self):
        for change in ('checked_at','tag','digest','header_digest'):
            docs={};policy,before=inventory_fixture(docs);ref=policy['receipts']['native-node14-runtime-tree']
            value=json.loads(docs[ref['path']]);value[change]='2026-01-03T03:04:05+00:00' if change=='checked_at' else 'changed'
            raw=json.dumps(value,sort_keys=True,separators=(',',':')).encode();docs[ref['path']]=raw;ref.update(bytes=len(raw),sha256=c.sha(raw))
            with self.subTest(change=change),self.assertRaises(c.Unproved):fresh.reviewed_rows(policy,docs.__getitem__)

    def test_rehashed_actual_old_row_schema_order_or_unrelated_bytes_cannot_hide_in_append(self):
        for change in ('old-row','old-order','schema','unrelated-field','whitespace'):
            contract,qualified,entry,docs,git,before,actual=d3.InitialRuntimeMapAdoptionControls().fixture()
            raw,mode,blob=git('blob',contract['source'],fresh.PATH);value=json.loads(raw)
            if change=='old-row':value['images'][0]['unrelated']['keep']='CHANGED'
            elif change=='old-order':value['images'][:2]=reversed(value['images'][:2])
            elif change=='schema':value['schema']='another-schema'
            elif change=='unrelated-field':value['unreviewed']=True
            changed=b'\n'+raw if change=='whitespace' else (json.dumps(value,indent=2)+'\n').encode()
            contract['critical_files'][fresh.PATH].update(bytes=len(changed),sha256=c.sha(changed))
            def observed(action,left,right):
                if action=='blob' and left==contract['source'] and right==fresh.PATH:return changed,mode,blob
                return git(action,left,right)
            with self.subTest(change=change),patch.object(p,'bind_signature',return_value={}),self.assertRaises(c.Unproved):
                r.adoption(contract,entry,qualified,docs.__getitem__,observed)

    def test_inventory_cannot_be_omitted_or_modified_by_generic_or_wrong_path_grammar(self):
        for change in ('missing-policy','missing-delta','missing-critical','extra-edit','wrong-path'):
            contract,qualified,entry,docs,git,before,actual=d3.InitialRuntimeMapAdoptionControls().fixture()
            delta=contract['pin_only_deltas'][1]
            if change=='missing-policy':contract.pop('freshness_append')
            elif change=='missing-delta':contract['pin_only_deltas'].pop()
            elif change=='missing-critical':
                qualified['critical_source'].pop(fresh.PATH);contract['critical_files'].pop(fresh.PATH)
            elif change=='extra-edit':delta['edits'].append({'kind':'immutable-ref','before':fresh.COMMON,'after':fresh.COMMON})
            else:contract['pin_only_deltas'][0]['edits'][0]={'kind':'native-common-freshness-append'}
            with self.subTest(change=change),patch.object(p,'bind_signature',return_value={}),self.assertRaises(c.Unproved):
                r.adoption(contract,entry,qualified,docs.__getitem__,git)


if __name__=='__main__':unittest.main()
