"""Tiny invented signed-looking DATA for field-binding controls, never real crypto."""
import base64,copy,gzip,json
import core as c
import readiness as r
import retained_v11_predicates as v11
import freshness_append as fresh

def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
class Facts:
    def __init__(self):
        self.docs={};self.i=0
        roles={'producer':'a'*40,'verifier':'b'*40,'generator':'c'*40,'utility_source':'d'*40,'family_generator':'e'*40,'qualified_source':'f'*40}
        layers={arch:(arch+'-CONTROL_ONLY-layer').encode() for arch in ('amd64','arm64')};manifests={};configs={};children=[];platforms={};blobs=[]
        for arch in ('amd64','arm64'):
            config=encoded({'os':'linux','architecture':arch,'rootfs':{'diff_ids':['sha256:'+c.sha(layers[arch])]}});configref=self.put('config-'+arch,config);configs[arch]=configref
            desc={'digest':'sha256:'+c.sha(config),'size':len(config)};layer={'digest':'sha256:'+c.sha(layers[arch]),'size':len(layers[arch])}
            manifest=encoded({'schemaVersion':2,'config':desc,'layers':[layer]});ref=self.put('manifest-'+arch,manifest);manifests[arch]=ref
            children.append({'digest':'sha256:'+c.sha(manifest),'size':len(manifest),'platform':{'os':'linux','architecture':arch}})
            platforms[arch]={'manifest_digest':'sha256:'+c.sha(manifest),'config_digest':desc['digest']}
            for d in (desc,layer):blobs.append({'digest':d['digest'],'bytes_hashed':d['size'],'registry_repository':'ghcr.io/bex-co/native',
                'anonymous_full_get_at':'2026-11-01T00:00:00Z','reused_prior_full_read':False})
        index=encoded({'schemaVersion':2,'manifests':children});common='ghcr.io/bex-co/native@sha256:'+c.sha(index)
        signed=[];results=[];reports={}
        for kind,arch,ptype in [('image-signature',None,'https://sigstore.dev/cosign/sign/v1'),('sbom','amd64','https://spdx.dev/Document'),('sbom','arm64','https://spdx.dev/Document'),('vulnerability','amd64','https://aquasecurity.github.io/trivy/attestation/vuln/v1'),('vulnerability','arm64','https://aquasecurity.github.io/trivy/attestation/vuln/v1')]:
            predicate={'CONTROL_ONLY':kind,'architecture':arch}
            if kind=='sbom':
                predicate={'spdxVersion':'SPDX-2.3','SPDXID':'SPDXRef-DOCUMENT','documentDescribes':['SPDXRef-Root'],
                    'packages':[{'SPDXID':'SPDXRef-Root','name':'CONTROL_ONLY_root','checksums':[{'algorithm':'SHA256','checksumValue':platforms[arch]['config_digest'].split(':')[1]}]}]+[
                        {'SPDXID':'SPDXRef-'+name,'name':name,'versionInfo':'CONTROL_ONLY','externalRefs':[{'referenceLocator':'pkg:deb/debian/'+name+'@1?arch='+arch}]} for name in sorted(v11.REQUIRED|{'libvips42'})]}
            elif kind=='vulnerability':
                config=json.loads(self.docs[configs[arch]['path']]);predicate={'ArtifactType':'container_image','SchemaVersion':2,'ArtifactName':common,
                    'Metadata':{'ImageID':platforms[arch]['config_digest'],'ImageConfig':config},'Results':[{'Class':'os-pkgs','Type':'debian','Vulnerabilities':[]}]}
            raw_pred=encoded(predicate)
            statement=encoded({'subject':[{'digest':{'sha256':common.split('@sha256:')[1]}}],'predicateType':ptype,'predicate':predicate})
            bundle=encoded({'dsseEnvelope':{'payload':base64.b64encode(statement).decode()},'verificationMaterial':{'tlogEntries':[{'kindVersion':{'kind':'hashedrekord','version':'0.0.2'}}],'timestampVerificationData':{'rfc3161Timestamps':[{'CONTROL_ONLY':'NOT_REAL_SIGNATURE'}]}}})
            bd='sha256:'+c.sha(bundle);path='/private/tmp/CONTROL_ONLY_V11/'+bd[7:]+'.bundle.json';bgz=path+'.gz';pgz=path+'.predicate.gz'
            reports[bgz]=self.put('bundle-'+str(len(signed)),gzip.compress(bundle,mtime=0));reports[pgz]=self.put('predicate-'+str(len(signed)),gzip.compress(raw_pred,mtime=0))
            signed.append({'kind':kind,'architecture':arch,'bundle_digest':bd,'bundle_bytes':len(bundle),'path':path,'predicate_type':ptype,
                'signed_statement_sha256':c.sha(statement),'full_bundle_gzip':bgz,'full_predicate_gzip':pgz,
                'decoded_predicate_sorted_json_sha256':c.sha(raw_pred),'decoded_predicate_sorted_json_bytes':len(raw_pred),
                'full_bundle_gzip_sha256':reports[bgz]['sha256'],'full_predicate_gzip_sha256':reports[pgz]['sha256']})
            results.append({'bundle_digest':bd,'exit_code':0,'command':r.native_command(path,ptype,common.split('@')[1],roles['verifier'])})
        negative_source={'exit_code':1,'command':r.native_command(signed[0]['path'],signed[0]['predicate_type'],common.split('@')[1],'0'*40)}
        negative_subject={'exit_code':1,'command':r.native_command(signed[0]['path'],signed[0]['predicate_type'],'sha256:'+'0'*64,roles['verifier'])}
        crypto={'results':results,'accepted_bundles':[s['bundle_digest'] for s in signed],'wrong_source':negative_source,'wrong_subject':negative_subject}
        tools={'/private/tmp/CONTROL_ONLY_V11/driver.py':'f'*64}
        receipt={'ref':common,'approved_supplier_candidate':True,'producer_workflow_sha':roles['producer'],'verification_workflow_sha':roles['verifier'],
            'producer_verification_provenance':{'producer_sha':roles['producer'],'verification_sha':roles['verifier'],'generator_sha':roles['generator']},
            'evidence_tool_sha256':tools,'platforms':platforms,'anonymous_pull':{'unique_blob_count':len(blobs),'blob_receipts':blobs},'signed_payloads':signed}
        baseline=b'package build\nconst root="CONTROL_ONLY_PREPIN"\n';baseline_ref=self.put('baseline',baseline)
        utility_cases=[];utility_rows=[]
        for arch in ('amd64',):
            want={'id':'utility-'+arch,'architecture':arch,'command':['CONTROL_ONLY','utility',arch],'observations':{'pg_restore':'18.2','pg15_archive':'restored','pg18_archive':'bounded'},'inputs':{}}
            result=self.result(want['command'],want['observations']);utility_cases.append(want)
            utility_rows.append({'id':want['id'],'architecture':arch,'common_ref':common,'source':roles['utility_source'],'result':result,'inputs':{}})
        family_cases=[];family_rows=[]
        for arch in ('amd64',):
            want={'id':'family-'+arch,'architecture':arch,'command':['CONTROL_ONLY','family',arch],'observations':{'runtime':'node','phase':'app-node','version':'24.14.0'},'inputs':{}}
            family_cases.append(want);family_rows.append({'id':want['id'],'architecture':arch,'common_ref':common,'source':roles['family_generator'],'result':self.result(want['command'],want['observations']),'inputs':{}})
        image='ghcr.io/bex-co/generated-python@sha256:'+'9'*64
        root={'SPDXID':'SPDXRef-Root','name':'CONTROL_ONLY_generated_python','versionInfo':image.split('@')[1]}
        sbom={'spdxVersion':'SPDX-2.3','packages':[root,{'SPDXID':'SPDXRef-brotli','name':'libbrotli1','versionInfo':'1.0.9-2+deb12u1'}],
              'relationships':[{'spdxElementId':'SPDXRef-DOCUMENT','relationshipType':'DESCRIBES','relatedSpdxElement':'SPDXRef-Root'}]}
        spdx=self.put('generated-SPDX',encoded(sbom));command=['CONTROL_ONLY','generated-python-no-signal']
        generated={'result':self.result(command,{'python':'3.14.8','version_signals':[],'base':common,'image':image,'spdx_sha256':spdx['sha256'],'spdx_image':image}),'spdx':spdx}
        self.contract={'common_ref':common,'roles':roles,'qualifier_tools':tools,'qualification_source':{r.COMMON_SLOT:{'bytes':len(baseline),'sha256':c.sha(baseline)}},
            'adoption_critical_paths':[r.COMMON_SLOT],'adoption_critical_scope':[{'directory':'lego/operator/internal/build','suffix':'.go','exclude_suffixes':['_test.go']}],
            'utility_cases':utility_cases,'family_cases':family_cases,'generated_default_python_command':command,
            'fixed_brotli_versions':['1.0.9-2+deb12u1'],'generated_spdx_root':{'image':image,'SPDXID':root['SPDXID'],'package':root}}
        self.entry={'common_ref':common,'roles':roles,'v11_receipt':self.put('V11',encoded(receipt)),'v11_crypto':self.put('crypto',encoded(crypto)),
            'qualification_source':{r.COMMON_SLOT:baseline_ref},'index':self.put('index',index),'platform_manifests':manifests,'platform_configs':configs,
            'retained_reports':reports,'wrong_source_stderr':self.put('wrong-source',b'expected GithubWorkflowSHA '+roles['verifier'].encode()),
            'wrong_subject_stderr':self.put('wrong-subject',b'provided artifact digest does not match any digest in statement'),
            'utilities':self.put('utilities',encoded({'rows':utility_rows})),'families':self.put('families',encoded({'rows':family_rows})),
            'generated_default_python':self.put('generated',encoded(generated))}
        self.family_source()

    def family_source(self,source=None,kind='captured-input-equality',case_id=None,append=False):
        """Invented case-specific custody; never real source/review authority."""
        rows=self.doc(self.entry['families'])['rows'];index=len(rows) if append else 0
        want=copy.deepcopy(self.contract['family_cases'][0]);row=copy.deepcopy(rows[0])
        if case_id is not None:want['id']=row['id']=case_id
        source=source or self.contract['roles']['family_generator'];target=self.contract['roles']['qualified_source']
        want['execution_source']=row['source']=source
        refs={name:self.put('family-'+name,encoded({'CONTROL_ONLY':name,'case':want['id']}))
              for name in ('body_manifest','input_manifest','oracle_manifest')}
        refs['canonical_recipe']=self.put('family-recipe',('FROM '+self.contract['common_ref']+'\n# CONTROL_ONLY '+want['id']+'\n').encode())
        identities={name:{key:ref[key] for key in ('bytes','sha256')} for name,ref in refs.items()}
        result={'schema':'bex.original28.family-body-result/v1','case_id':want['id'],'execution_source':source,
                'common_ref':self.contract['common_ref'],'architecture':want['architecture'],'result':row['result'],
                'inputs':row.get('inputs',{}),'proofs':dict(identities)}
        refs['body_result']=self.put('family-body-result',encoded(result))
        identities['body_result']={key:refs['body_result'][key] for key in ('bytes','sha256')}
        want['proofs']=identities;row['proofs']=refs
        want.pop('source_equivalence',None);row.pop('source_equivalence',None)
        if source!=target:
            branch='scripts/CONTROL_ONLY-branch.py'
            if kind=='reviewed-branch-nonimpact' and branch not in self.contract['qualification_source']:
                ref=self.put('qualified-branch',b'CONTROL_ONLY_current')
                self.entry['qualification_source'][branch]=ref
                self.contract['qualification_source'][branch]={key:ref[key] for key in ('bytes','sha256')}
            qualified={path:dict(identity,git_mode='100644') for path,identity in self.contract['qualification_source'].items()}
            actual=copy.deepcopy(qualified);changed=[];unchanged=[]
            if kind=='reviewed-branch-nonimpact':
                raw=b'CONTROL_ONLY_older_unselected_branch';actual[branch]={'bytes':len(raw),'sha256':c.sha(raw),'git_mode':'100644'}
                changed=[branch];unchanged=[r.COMMON_SLOT]
            actual_ref=self.put('actual-inputs',encoded({'schema':'bex.original28.source-inputs/v1','source':source,'files':actual}))
            qualified_ref=self.put('qualified-inputs',encoded({'schema':'bex.original28.source-inputs/v1','source':target,'files':qualified}))
            review_ref=self.put('case-nonimpact-review',encoded({'CONTROL_ONLY_NOT_APPROVAL':True,'case_id':want['id'],
                'execution_source':source,'qualified_source':target,'kind':kind}))
            review={'schema':'bex.original28.family-source-equivalence/v1','kind':kind,'case_id':want['id'],
                    'execution_source':source,'qualified_source':target,'common_ref':self.contract['common_ref'],'architecture':'amd64',
                    'proofs':identities,'actual_inputs':actual_ref,'qualified_inputs':qualified_ref,'review':review_ref,
                    'changed_paths':changed,'unchanged_paths':unchanged}
            descriptor=self.put('case-source-equivalence',encoded(review));row['source_equivalence']=descriptor
            want['source_equivalence']={'kind':kind,'descriptor':{key:descriptor[key] for key in ('bytes','sha256')},
                **{name:{key:ref[key] for key in ('bytes','sha256')} for name,ref in [('actual_inputs',actual_ref),('qualified_inputs',qualified_ref),('review',review_ref)]},
                'changed_paths':changed,'unchanged_paths':unchanged}
        if append:self.contract['family_cases'].append(want);rows.append(row)
        else:self.contract['family_cases'][index]=want;rows[index]=row
        self.replace(self.entry['families'],{'rows':rows})

    def put(self,name,raw):
        self.i+=1;path='/private/tmp/CONTROL_ONLY_QUALIFICATION/'+str(self.i)+'-'+name+'.json';self.docs[path]=raw
        return {'path':path,'bytes':len(raw),'sha256':c.sha(raw)}
    def doc(self,ref):return json.loads(self.docs[ref['path']])
    def replace(self,ref,value):
        raw=encoded(value);self.docs[ref['path']]=raw;ref.update(bytes=len(raw),sha256=c.sha(raw))
    def result(self,command,observation):return {'exit_code':0,'complete':True,'bound':None,'signal':None,'command':command,'stdout':self.put('stdout',encoded(observation))}


def inventory_fixture(docs):
    """Invented dated receipt metadata; never a real inventory/adoption grant."""
    receipts={};rows=[];at='2026-01-02T03:04:05.678901+00:00'
    for ident,upstream,committed,date_key,value_key in fresh.SPECS:
        data={date_key:at,value_key:committed.split('@')[1] if value_key=='digest' else committed,'tag':upstream}
        if value_key=='digest':data['header_digest']=data[value_key]
        path='/private/tmp/CONTROL_ONLY_FRESHNESS/'+ident+'.json';raw=encoded(data);docs[path]=raw
        ref={'path':path,'bytes':len(raw),'sha256':c.sha(raw)};receipts[ident]=ref
        source='Retained '+date_key+' '+at+'; receipt SHA256 '+ref['sha256']+'; no new tag resolution or runtime approval claimed'
        rows.append({'id':ident,'kind':'native-base','upstream':upstream,'committed':committed,
                     'resolved_at':'2026-01-02T03:04:05Z','source':source,'files':[fresh.PIN_PATH]})
    policy={'rows':rows,'receipts':receipts}
    before=(json.dumps({'schema':fresh.SCHEMA,'images':[{'id':'old-a','unrelated':{'keep':'EXACT'}},{'id':'old-b','array':[2,1]}]},indent=2)+'\n').encode()
    return policy,before


def inventory_adoption_fixture(contract,qualified,docs,git,actual):
    # Model the now-required inventory alongside the same fake signed adoption.
    old=qualified['common_ref'];qualified['common_ref']=fresh.COMMON;actual[0]=actual[0].replace(old.encode(),fresh.COMMON.encode())
    qualified['adoptable_refs']=[fresh.COMMON if ref==old else ref for ref in qualified['adoptable_refs']]
    contract['pins'][0].update(qualified_ref=fresh.COMMON,literal=json.dumps(fresh.COMMON))
    contract['pin_only_deltas'][0]['edits'][0]['after']=r.common_initializer(fresh.COMMON,contract['common_initializer_syntax']).decode()
    contract['critical_files'][r.COMMON_SLOT].update(bytes=len(actual[0]),sha256=c.sha(actual[0]))
    for scope in contract['scope_code']:
        body=docs[scope['source']['path']];scope.update(first_byte=actual[0].index(body),last_byte=actual[0].index(body)+len(body))
    policy,before=inventory_fixture(docs);after=fresh.render_append(before,policy['rows']);contract['freshness_append']=policy
    identity={'bytes':len(before),'sha256':c.sha(before)}
    qualified['qualification_source'][fresh.PATH]=identity;qualified['critical_source'][fresh.PATH]=dict(identity)
    qualified['critical_scope'].append({'path':fresh.PATH})
    contract['critical_files'][fresh.PATH]={'bytes':len(after),'sha256':c.sha(after),'git_mode':'100644','git_blob':'a'*40}
    path='/private/tmp/CONTROL_ONLY_FRESHNESS/before.json';docs[path]=before
    contract['pin_only_deltas'].append({'qualification_source':qualified['qualified_baseline_source'],'path':fresh.PATH,
        'before':{'path':path,**identity},'edits':[{'kind':'native-common-freshness-append'}]})
    def observed(action,left,right):
        if action=='changes':return git(action,left,right)+[{'status':'M','path':fresh.PATH}]
        if action=='blob' and right==fresh.PATH:return (before,'100644','b'*40) if left==qualified['qualified_baseline_source'] else (after,'100644','a'*40)
        return git(action,left,right)
    return observed
