"""Four source controls for manifest refresh; no original program runs."""
import json,sys,tempfile,unittest
from unittest.mock import patch
import adapter as a
import core as c
from pathlib import Path
import execution_view_builder as view


def fixture(directory):
    root=Path(directory);inputs=root/'inputs';inputs.mkdir()
    values={'adapter.py':b'CONTROL_ONLY_NEVER_EXECUTED','original-inputs/command.sh':b'EXACT_ORIGINAL_COMMAND\n','ADOPTION-CONTRACT.json':b'null\n'}
    rows={}
    for name,raw in values.items():
        p=inputs/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);p.chmod(0o600)
        rows[name]={'source':str(p),'bytes':len(raw),'sha256':view.sha(raw),'mode':'0o600'}
    manifest=(json.dumps(view.runtime_manifest(rows),indent=2,sort_keys=True)+'\n').encode()
    return {'schema':'bex.original28.execution-view/v1','actual_authority':None,'files':rows,'input_roots':[str(inputs)],
            'manifest_bytes':len(manifest),'manifest_sha256':view.sha(manifest)},root/'view',manifest


class ExecutionViewControls(unittest.TestCase):
    def test_refreshed_manifest_binds_every_preserved_fake_data_command_and_mode_without_execution(self):
        with tempfile.TemporaryDirectory() as directory:
            plan,target,manifest=fixture(directory);result=view.materialize(plan,target)
            self.assertEqual(result['files'],3);self.assertEqual(result['manifest_sha256'],view.sha(manifest))
            self.assertEqual((target/'original-inputs/command.sh').read_bytes(),b'EXACT_ORIGINAL_COMMAND\n')
            self.assertEqual((target/'ADOPTION-CONTRACT.json').read_bytes(),b'null\n')
            self.assertNotIn('MANIFEST.json',json.loads((target/'MANIFEST.json').read_bytes()))
            view.verify_view(target,plan['files'],manifest)

    def test_input_hash_mode_path_root_or_manifest_tamper_refuses_before_new_view(self):
        for change in ('hash','mode','path','outside-root','manifest','authority'):
            with self.subTest(change=change),tempfile.TemporaryDirectory() as directory:
                plan,target,manifest=fixture(directory)
                if change=='hash':Path(plan['files']['adapter.py']['source']).write_bytes(b'changed')
                elif change=='mode':Path(plan['files']['adapter.py']['source']).chmod(0o644)
                elif change=='path':plan['files']['../escape']=plan['files'].pop('adapter.py')
                elif change=='outside-root':plan['input_roots']=[str(Path(directory)/'unrelated')]
                elif change=='manifest':plan['manifest_sha256']='0'*64
                else:plan['actual_authority']={'do_not_fill':True}
                with self.assertRaises(ValueError):view.materialize(plan,target)
                self.assertFalse(target.exists())

    def test_real_refreshed_view_main_checks_full_source_then_refuses_null_before_setup_or_auth(self):
        here=Path(__file__).resolve().parent;manifest=here/'MANIFEST.json';contract=here/'ADOPTION-CONTRACT.json'
        with tempfile.TemporaryDirectory() as directory:
            capsule=Path(directory)/'capsule.json';capsule.write_bytes(b'{}')
            argv=['adapter.py','execute','--capsule',str(capsule),'--contract',str(contract),
                  '--capsule-sha',view.sha(capsule.read_bytes()),'--contract-sha',view.sha(contract.read_bytes()),
                  '--source-manifest-sha',view.sha(manifest.read_bytes())]
            with patch.object(sys,'argv',argv),patch.object(a,'Adapter',side_effect=AssertionError('no actual Adapter before null refusal')) as adapter, \
                 patch.object(a,'free_bytes',side_effect=AssertionError('no runtime budget before null refusal')) as free:
                with self.assertRaisesRegex(c.Unproved,'actual adoption absent; refuse before auth'):a.main()
                adapter.assert_not_called();free.assert_not_called()
            fresh=manifest.read_bytes();stale=Path(view.__file__).with_name('INHERITED-STALE-MANIFEST.json').read_bytes()
            argv[-1]=view.sha(stale)
            try:
                manifest.write_bytes(stale)
                with patch.object(sys,'argv',argv),patch.object(a,'Adapter',side_effect=AssertionError('no Adapter for stale source')) as adapter:
                    with self.assertRaisesRegex(c.Unproved,'reviewed source payload differs'):a.main()
                    adapter.assert_not_called()
            finally:manifest.write_bytes(fresh)

    def test_extra_output_file_or_changed_manifest_cannot_be_admitted(self):
        for change in ('extra','manifest'):
            with self.subTest(change=change),tempfile.TemporaryDirectory() as directory:
                plan,target,manifest=fixture(directory);view.materialize(plan,target)
                if change=='extra':(target/'extra').write_bytes(b'unreviewed')
                else:(target/'MANIFEST.json').write_bytes(b'{}')
                with self.assertRaises(ValueError):view.verify_view(target,plan['files'],manifest)


if __name__=='__main__':unittest.main()
