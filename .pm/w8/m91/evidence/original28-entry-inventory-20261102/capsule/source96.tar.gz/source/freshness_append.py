"""One reviewed seven-row freshness append, never a general JSON patch.

These exact subjects are a membership ceiling, not runtime/adoption approval.
Real receipt descriptors and the final contract still need independent Root review.
"""
import json
import core as c
import proof_binding as p

PATH='lego/operator/internal/build/toolchain-freshness.json'
SCHEMA='bex.build-toolchain-freshness/v1'
PIN_PATH='lego/operator/internal/build/nativebases.go'
REPO='ghcr.io/bex-co/bex-cnb-run'
COMMON=REPO+'@sha256:0941c204f87643c2faad308e72acdf584976e67d8fb980a0646c5ab662dcc5d0'
# id, upstream tag, committed identity, retained date field, identity field.
SPECS=(
 ('native-common-bookworm',REPO+':native-common-bookworm-1feba939b4697894e800ed0abb4f25a0bf415641',COMMON,'reviewed_at','ref'),
 ('native-node14-runtime-tree',REPO+':native-node-14-bullseye',REPO+'@sha256:4fec31cbb186e340cd7ce25ac1d0705f78735631f793b75629d653c6601f83fc','checked_at','digest'),
 ('native-node16-runtime-tree',REPO+':native-node-16-bookworm',REPO+'@sha256:2802078e18496838c15159ec99c01c9b260128cef8e1d1ba29cd0a1836165113','checked_at','digest'),
 ('native-node18-runtime-tree',REPO+':native-node-18-bookworm',REPO+'@sha256:6c40aaf4af55979e9b923e5949704f562d8e334e7370022f0c3584341742ddd1','checked_at','digest'),
 ('native-node20-runtime-tree',REPO+':native-node-20-bookworm',REPO+'@sha256:2c69d3e2913703a634016cc24338f9532f24a750ddb831351e1374d274846a4d','checked_at','digest'),
 ('native-node14212-runtime-tree',REPO+':native-node-14.21.2-bullseye-6883953e58e750fb41763d1d5e4bd4103bdb74c5',REPO+'@sha256:332869e644cdd45bf1f9e7c42ed3df91fedb95c4d0cee6bf2abf771c9eb760c7','reviewed_at','ref'),
 ('native-node14212-upstream','node:14.21.2-bullseye','node:14.21.2-bullseye@sha256:cc748803fe49871926c433ae6aafbfd59b765eed6005dc0843b916eb74f67b12','reviewed_at','official_base'),
)


def unique(items):
    value={}
    for key,item in items:
        c.require(key not in value,'duplicate freshness JSON key');value[key]=item
    return value


def parsed(raw):
    value=json.loads(raw,object_pairs_hook=unique)
    c.require(isinstance(value,dict) and set(value)=={'schema','images'} and value['schema']==SCHEMA
              and isinstance(value['images'],list) and value['images'],'exact initial freshness schema missing')
    ids=[row.get('id') for row in value['images'] if isinstance(row,dict)]
    c.require(len(ids)==len(value['images']) and all(isinstance(x,str) for x in ids) and len(ids)==len(set(ids)),
              'freshness old rows/IDs malformed')
    return value


def reviewed_rows(policy,reader):
    ids=[spec[0] for spec in SPECS]
    c.require(isinstance(policy,dict) and set(policy)=={'rows','receipts'} and isinstance(policy['receipts'],dict)
              and set(policy['receipts'])==set(ids),'exact seven reviewed freshness receipt bindings required')
    result=[]
    for ident,upstream,committed,date_key,value_key in SPECS:
        ref=policy['receipts'][ident];raw=p.read_ref(ref,reader);receipt=json.loads(raw,object_pairs_hook=unique)
        want=committed.split('@')[1] if value_key=='digest' else committed
        c.require(isinstance(receipt,dict) and receipt.get(value_key)==want,'freshness receipt binds another approved identity')
        if value_key!='official_base':c.require(receipt.get('tag')==upstream,'freshness receipt tag differs')
        if value_key=='digest':c.require(receipt.get('header_digest')==want,'retained tag/header digest differs')
        at=c.instant(receipt.get(date_key,''));stamp=at.strftime('%Y-%m-%dT%H:%M:%SZ')
        # resolved_at records the retained observation's date, not an invented
        # current lookup. Full precision remains in the original receipt.
        source='Retained '+date_key+' '+receipt[date_key]+'; receipt SHA256 '+ref['sha256']+'; no new tag resolution or runtime approval claimed'
        result.append({'id':ident,'kind':'native-base','upstream':upstream,'committed':committed,
                       'resolved_at':stamp,'source':source,'files':[PIN_PATH]})
    c.require(policy.get('rows')==result,'freshness row fields/order/date/source are not the exact reviewed seven')
    return result


def render_append(before,rows):
    old=parsed(before);new_ids={spec[0] for spec in SPECS}
    c.require(len(rows)==7 and [row.get('id') for row in rows]==[spec[0] for spec in SPECS]
              and not ({row['id'] for row in old['images']} & new_ids),'freshness append is missing/extra/reordered or already present')
    suffix=b'\n  ]\n}\n'
    c.require(before.endswith(suffix),'only the existing canonical final images-array append is supported')
    lines=json.dumps(rows,indent=2,ensure_ascii=True).encode().splitlines()[1:-1]
    after=before[:-len(suffix)]+b',\n'+b'\n'.join(b'  '+line for line in lines)+suffix
    c.require(parsed(after)=={'schema':SCHEMA,'images':old['images']+rows},'freshness append changed old rows/schema')
    return after


def verify_tail(raw,rows):
    actual=parsed(raw)['images'];c.require(len(actual)>7 and actual[-7:]==rows,'actual inventory lacks exact final seven reviewed rows')
