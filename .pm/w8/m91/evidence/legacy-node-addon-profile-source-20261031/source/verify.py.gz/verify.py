from pathlib import Path
import ast,datetime,gzip,hashlib,importlib.util,json,os,subprocess,tempfile,time
root=Path(__file__).resolve().parent;source=root/'source';repo=Path('/Users/tianpan/projects/bex7')
f='lego/operator/internal/build/testdata/native-node-addon-qualification/'
(root/'actionlint.yaml').write_text('self-hosted-runner:\n  labels: [bex-ci, bex-production]\n')
checks=[('addon-host-final',[os.sys.executable,'-B',f+'check_test.py','-v']),('routing-host-final',[os.sys.executable,'-B','.github/scripts/test_native_oci_common_qualification.py','-v']),('node-syntax-final',['node','--check',f+'check.js']),('actionlint-final',['/opt/homebrew/bin/actionlint','-config-file',str(root/'actionlint.yaml'),'-shellcheck=','-pyflakes=','.github/workflows/native-common-image.yml'])]
results=[]
for name,argv in checks:
 start=time.monotonic();p=subprocess.run(argv,cwd=source,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True,text=True,timeout=45)
 (root/(name+'.log')).write_text(p.stdout+p.stderr)
 row={'name':name,'argv':argv,'exit':p.returncode,'seconds':round(time.monotonic()-start,3)};results.append(row);print(json.dumps(dict(row,tail=(p.stdout+p.stderr)[-800:])))
(root/'FINAL-CHECKS.json').write_text(json.dumps(results,indent=2)+'\n')
if any(row['exit'] for row in results):raise SystemExit('host/source check failed; logs retained')
# Regenerate only the existing positive data fixtures using the unchanged host
# source. Do not execute package managers or target programs.
spec=importlib.util.spec_from_file_location('unchanged_node_manifest_generator',source/'lego/operator/internal/build/testdata/native-node-qualification/check.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
old=repo/'.pm/w8/m91/evidence/pnpm-project-engine-20261031/fixture-source/prior-positive-project-byte-equality.json.gz'
known=json.loads(gzip.decompress(old.read_bytes()))['expected'];equal={}
for key,expected in known.items():
 version,manager=key.split('/')
 out=root/'positive-projects'/version;out.mkdir(parents=True,exist_ok=True);module.OUT=out
 work=module.project(manager,{'node':version,'node_env':version,'pnpm':'10.34.7'})
 raw=(work/'package.json').read_bytes();digest=hashlib.sha256(raw).hexdigest()
 assert digest==expected['sha256'] and len(raw)==expected['bytes'],key
 equal[key]={'sha256':digest,'bytes':len(raw),'public_frozen_sha256':expected['sha256'],'byte_identical':True}
assert len(equal)==9
(root/'POSITIVE9-GUARD.json').write_text(json.dumps({'all9_byte_identical_to_public_frozen_evidence':True,'public_receipt_path':str(old),'public_receipt_gzip_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'files':equal},indent=2)+'\n')
# Recheck all copied original13/tool fixture files and the parent-supplied28
# custody sources; never import hosted.py or read its ledger/auth inputs.
baseline=json.loads((root/'BASELINE.json').read_text());verified={}
for name,row in baseline.items():
 live=repo/name;assert hashlib.sha256(live.read_bytes()).hexdigest()==row['sha256'],name
 assert oct(live.stat().st_mode&0o777)==row['mode'],name
 if not row['owned']:
  assert hashlib.sha256((source/name).read_bytes()).hexdigest()==row['sha256'],name
  assert oct((source/name).stat().st_mode&0o777)==row['mode'],name
 if '/testdata/' in name:verified[name]=row
original=json.loads((root/'ORIGINAL28-READONLY-HASHES.json').read_text())
for name,row in original.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==row['sha256'],name
(root/'FROZEN-FIXTURE-GUARD.json').write_text(json.dumps({'all_original13_and_existing_node_fixture_bytes_modes_unchanged':True,'fixture_files':verified,'all28_original_custody_hashes_unchanged':original,'prepared_fixture_count':28,'scope':'Read/hash only28source files; no hosted.py import, ledger/auth read or source writes.'},indent=2)+'\n')
print(json.dumps({'positive9':True,'fixture_files_unchanged':len(verified),'original28':True}))
