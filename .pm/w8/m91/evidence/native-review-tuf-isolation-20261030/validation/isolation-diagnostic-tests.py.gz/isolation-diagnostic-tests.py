"""Private local subprocess/synthetic-byte tests only; no real Cosign verification or public read."""
import concurrent.futures,contextlib,hashlib,importlib.util,io,json,os,stat,tempfile,threading,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
ROOT=Path(__file__).resolve().parent

def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
g=load('private_v10','/tmp/loopx-w8-native-review-v10.py');old=load('private_v9','/tmp/loopx-w8-native-review-v9.py')
def review(path,module=g):
 r=module.Review.__new__(module.Review);r.v=load('private_policy_'+path.name,'/tmp/loopx-w8-verify-native-artifact.py');r.out=path;r.bundle_dir=path/'bundles';r.bundle_dir.mkdir(exist_ok=True);r.a=SimpleNamespace(sha='4'*40,name='UNIT-ONLY',layer_workers=1);r.digest='sha256:'+'5'*64;r.lock=threading.Lock();r.v2=r.v.BlobReceipts(path/'unit-only-cache');r.public=lambda:('https://unit.invalid/v2/UNIT-ONLY',{'Authorization':'Bearer UNIT-ONLY-DO-NOT-LOG'});return r

def row(n=6):return {'bundle_digest':'sha256:'+str(n)*64,'path':'UNIT-ONLY-NOT-AN-ATTESTATION','predicate_type':g.SIGN}

class Tests(unittest.TestCase):
 def test_real_local_cli_subprocesses_receive_distinct_owned_cache_directories(self):
  with tempfile.TemporaryDirectory(prefix='v10-cli-',dir=ROOT) as td:
   r=review(Path(td));cli=Path(td)/'unit-cli.py';cli.write_text('''#!/usr/bin/env python3
import json,os,stat,sys
from pathlib import Path
p=Path(os.environ['TUF_ROOT']);assert p.is_dir() and stat.S_IMODE(p.stat().st_mode)==0o700
assert not list(p.iterdir());(p/'UNIT-ONLY-CACHE-MARKER').write_text('local fixture, no trust claim')
print(json.dumps({'argv':sys.argv[1:],'cache':str(p)}))
''');cli.chmod(0o700);r.v.COSIGN=cli
   with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(lambda n:r.verify_command(row(n),'positive'),[6,7,8]))
   roots=[Path(x['tuf_cache']) for x in results];self.assertEqual(len(set(roots)),3)
   for result,root in zip(results,roots):
    self.assertEqual(root.parent,r.bundle_dir/'cosign-tuf-cache');self.assertTrue((root/'UNIT-ONLY-CACHE-MARKER').exists());self.assertEqual(result['exit_code'],0)
    observation=json.loads(Path(result['stderr'].replace('.stderr.log','.stdout.log')).read_text());self.assertEqual(observation['cache'],str(root));self.assertEqual(observation['argv'],result['command'][1:]);self.assertIn('--use-signed-timestamps',observation['argv']);self.assertNotIn('--offline',observation['argv'])
   again=r.verify_command(row(6),'positive');self.assertNotIn(Path(again['tuf_cache']),roots)
 def test_strict_arguments_and_all_other_environment_values_match_v9(self):
  with tempfile.TemporaryDirectory(prefix='v10-env-',dir=ROOT) as td:
   base=Path(td);calls=[]
   def execute(args,**kw):calls.append((args,kw['env'].copy()));return SimpleNamespace(returncode=0)
   for module,name in [(old,'old'),(g,'new')]:
    p=base/name;p.mkdir();r=review(p,module)
    with patch.object(module.subprocess,'run',side_effect=execute):r.verify_command(row(),'positive')
   self.assertEqual(calls[0][0],calls[1][0]);before,after=calls[0][1],calls[1][1];self.assertEqual({k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)},{'TUF_ROOT'})
   self.assertTrue(Path(after['TUF_ROOT']).is_dir());self.assertNotIn('--trusted-root',calls[1][0]);self.assertFalse(any('ignore' in flag for flag in calls[1][0]))
 def test_existing_tuf_network_retry_gets_new_cache_each_invocation_but_persistence_is_not_retried(self):
  with tempfile.TemporaryDirectory(prefix='v10-retry-',dir=ROOT) as td:
   r=review(Path(td));calls=[]
   def execute(args,**kw):
    calls.append((args,kw['env']['TUF_ROOT']));kw['stderr'].write(b'error getting trusted root from TUF: TLS handshake timeout' if len(calls)==1 else b'');return SimpleNamespace(returncode=1 if len(calls)==1 else 0)
   with patch.object(g.subprocess,'run',side_effect=execute),patch.object(g.time,'sleep'):result=r.verify_command(row(),'positive')
   self.assertEqual(len(calls),2);self.assertNotEqual(calls[0][1],calls[1][1]);self.assertEqual(calls[0][0],calls[1][0]);self.assertEqual(result['exit_code'],0)
   calls.clear()
   def persist_error(args,**kw):calls.append(args);kw['stderr'].write(b'getting trusted root from TUF: tuf refresh failed: failed to persist metadata');return SimpleNamespace(returncode=1)
   with patch.object(g.subprocess,'run',side_effect=persist_error):result=r.verify_command(row(7),'positive')
   self.assertEqual(len(calls),1);self.assertEqual(result['exit_code'],1)
 def test_symlink_cache_parent_fails_before_any_cli_write(self):
  with tempfile.TemporaryDirectory(prefix='v10-symlink-',dir=ROOT) as td:
   p=Path(td);r=review(p);elsewhere=p/'elsewhere';elsewhere.mkdir();(r.bundle_dir/'cosign-tuf-cache').symlink_to(elsewhere,target_is_directory=True)
   with patch.object(g.subprocess,'run',side_effect=AssertionError('CLI must not run')):
    with self.assertRaisesRegex(RuntimeError,'symlink'):r.verify_command(row(),'positive')
   self.assertEqual(list(elsewhere.iterdir()),[])
 def test_canonical_bad_bodies_record_actual_whitelist_only_and_never_accept_or_retry(self):
  for mode in ['short','overlong','wrong-sha']:
   with self.subTest(mode=mode),tempfile.TemporaryDirectory(prefix='v10-blob-',dir=ROOT) as td:
    p=Path(td);r=review(p);expected=b'expected-unit-only-body';digest='sha256:'+hashlib.sha256(expected).hexdigest();body=expected[:-1] if mode=='short' else expected+b'X' if mode=='overlong' else b'X'*len(expected);r.blobs={digest:{'digest':digest,'size':len(expected)}};calls=[]
    class Response(io.BytesIO):
     headers={'Authorization':'SECRET-SENTINEL','Location':'https://unit.invalid/?token=TOKEN-SENTINEL'}
    def opening(request,timeout):calls.append(1);return Response(body)
    with patch.object(g.urllib.request,'urlopen',side_effect=opening),contextlib.redirect_stdout(io.StringIO()):
     with self.assertRaises(RuntimeError):r.pull_blobs()
    paths=list(p.glob('anonymous-blob-failure-*.json'));self.assertEqual(len(paths),1);raw=paths[0].read_text();d=json.loads(raw);self.assertEqual(d['error_type'],'RuntimeError');self.assertEqual(d['classification'],{'short':'short-body','overlong':'overlong-body','wrong-sha':'full-size-sha-mismatch'}[mode]);self.assertEqual(set(d['canonical_pull_state']),{'digest','expected_size','total','observed_sha256'})
    self.assertEqual(d['canonical_pull_state']['digest'],digest);self.assertEqual(d['canonical_pull_state']['expected_size'],len(expected));self.assertEqual(d['canonical_pull_state']['total'],len(body));self.assertEqual(d['canonical_pull_state']['observed_sha256'],'sha256:'+hashlib.sha256(b'' if mode=='overlong' else body).hexdigest());self.assertEqual(len(calls),1);self.assertNotIn(digest,r.v2.read());self.assertFalse((p/'receipt.json').exists());self.assertFalse(d['candidate_approved'])
    for forbidden in ['UNIT-ONLY-DO-NOT-LOG','SECRET-SENTINEL','TOKEN-SENTINEL','Authorization','Location','unit.invalid']:self.assertNotIn(forbidden,raw)
 def test_partial_network_error_stays_unclassified_and_unrelated_traceback_locals_are_excluded(self):
  with tempfile.TemporaryDirectory(prefix='v10-private-',dir=ROOT) as td:
   p=Path(td);r=review(p);body=b'expected-body';digest='sha256:'+hashlib.sha256(body).hexdigest();r.blobs={digest:{'digest':digest,'size':len(body)}}
   class Interrupted(io.BytesIO):
    def read(self,size=-1):
     if self.tell():raise TimeoutError('SECRET-ERROR-URL?token=DO-NOT-LOG')
     return super().read(3)
   with patch.object(g.urllib.request,'urlopen',return_value=Interrupted(body)),contextlib.redirect_stdout(io.StringIO()):
    with self.assertRaises(TimeoutError):r.pull_blobs()
   first=json.loads(next(p.glob('anonymous-blob-failure-*.json')).read_text());self.assertEqual(first['classification'],'unclassified');self.assertEqual(first['canonical_pull_state']['total'],3)
   class Foreign:
    def pull(self,*args):
     digest='sha256:'+'9'*64;size=999;total=998;headers={'Authorization':'DO-NOT-LOG'};raise ValueError('SECRET-DO-NOT-LOG')
   r.v2=Foreign()
   with contextlib.redirect_stdout(io.StringIO()):
    with self.assertRaises(ValueError):r.pull_blobs()
   records=[json.loads(x.read_text()) for x in p.glob('anonymous-blob-failure-*.json')];foreign=next(x for x in records if x['error_type']=='ValueError');self.assertEqual(foreign['canonical_pull_state'],{});self.assertEqual(foreign['classification'],'unclassified')
   for x in p.glob('anonymous-blob-failure-*.json'):self.assertNotIn('DO-NOT-LOG',x.read_text());self.assertNotIn('SECRET',x.read_text())

if __name__=='__main__':unittest.main(verbosity=2)
