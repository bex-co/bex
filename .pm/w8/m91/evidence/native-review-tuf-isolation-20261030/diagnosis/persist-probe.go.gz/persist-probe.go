// Isolated mechanism probe using exact go-tuf/v2 v2.4.2 persistMetadata body.
// Apache-2.0 source: https://github.com/theupdateframework/go-tuf/blob/v2.4.2/metadata/updater/updater.go
package main
import("encoding/json";"errors";"fmt";"log/slog";"net/url";realos "os";"path/filepath";"sync";"sync/atomic")
type cfg struct{LocalMetadataDir string;DisableLocalCache bool};type Updater struct{cfg *cfg}
var metadata=struct{GetLogger func()*slog.Logger}{slog.Default}
type ops struct{renames atomic.Int32;firstRenamed chan struct{};overwriteDone chan struct{};mu sync.Mutex;osErrors []string}
var os *ops
func(o *ops) record(e error)error{if e!=nil{o.mu.Lock();o.osErrors=append(o.osErrors,e.Error());o.mu.Unlock()};return e}
func(o *ops)CreateTemp(d,p string)(*realos.File,error){f,e:=realos.CreateTemp(d,p);o.record(e);return f,e}
func(o *ops)Remove(p string)error{return o.record(realos.Remove(p))}
func(o *ops)ReadFile(p string)([]byte,error){b,e:=realos.ReadFile(p);o.record(e);return b,e}
func(o *ops)Rename(a,b string)error{e:=o.record(realos.Rename(a,b));if e==nil&&o.renames.Add(1)==1{close(o.firstRenamed);<-o.overwriteDone};return e}
func (update *Updater) persistMetadata(roleName string, data []byte) error {
	log := metadata.GetLogger()
	// do not persist the metadata if we have disabled local caching
	if update.cfg.DisableLocalCache {
		return nil
	}
	// caching enabled, proceed with persisting the metadata locally
	fileName := filepath.Join(update.cfg.LocalMetadataDir, fmt.Sprintf("%s.json", url.PathEscape(roleName)))
	// create a temporary file
	file, err := os.CreateTemp(update.cfg.LocalMetadataDir, "tuf_tmp")
	if err != nil {
		return err
	}
	// change the file permissions to our desired permissions
	err = file.Chmod(0644)
	if err != nil {
		// close and delete the temporary file if there was an error while writing
		file.Close()
		errRemove := os.Remove(file.Name())
		if errRemove != nil {
			log.Info("Failed to delete temporary file", "name", file.Name())
		}
		return errors.Join(err, errRemove)
	}
	// write the data content to the temporary file
	_, err = file.Write(data)
	if err != nil {
		// close and delete the temporary file if there was an error while writing
		file.Close()
		errRemove := os.Remove(file.Name())
		if errRemove != nil {
			log.Info("Failed to delete temporary file", "name", file.Name())
		}
		return errors.Join(err, errRemove)
	}

	// can't move/rename an open file on windows, so close it first
	err = file.Close()
	if err != nil {
		return err
	}
	// if all okay, rename the temporary file to the desired one
	err = os.Rename(file.Name(), fileName)
	if err != nil {
		return err
	}
	read, err := os.ReadFile(fileName)
	if err != nil {
		return err
	}
	if string(read) != string(data) {
		return fmt.Errorf("failed to persist metadata")
	}
	return nil
}

func run(base string,isolated bool)map[string]any{
 os=&ops{firstRenamed:make(chan struct{}),overwriteDone:make(chan struct{})};d1:=filepath.Join(base,"shared");d2:=d1;if isolated{d2=filepath.Join(base,"isolated")};if e:=realos.MkdirAll(d1,0700);e!=nil{panic(e)};if e:=realos.MkdirAll(d2,0700);e!=nil{panic(e)}
 a,b:=&Updater{&cfg{LocalMetadataDir:d1}},&Updater{&cfg{LocalMetadataDir:d2}};done:=make(chan error,1);go func(){done<-a.persistMetadata("root",[]byte("synthetic metadata A; no trust claim"))}();<-os.firstRenamed;eb:=b.persistMetadata("root",[]byte("synthetic metadata B; no trust claim"));close(os.overwriteDone);ea:=<-done
 text:=func(e error)string{if e==nil{return ""};return e.Error()};r:=map[string]any{"isolated_directories":isolated,"first_error":text(ea),"second_error":text(eb),"underlying_os_errors":os.osErrors};if isolated{if ea!=nil||eb!=nil{panic("isolated case failed")}}else{if ea==nil||ea.Error()!="failed to persist metadata"||eb!=nil{panic("shared case did not reproduce exact readback error")}};return r
}
func main(){base,e:=realos.MkdirTemp("/tmp/loopx-w8-native-controls-ruby31-fd358/tuf-diagnosis","owned-persist-probe-");if e!=nil{panic(e)};out:=map[string]any{"scope":"Controlled private filesystem mechanism probe only. Uses exact persistence body with OS-call scheduling hooks; no real TUF verification, global cache writes or claim of historical causality.","directory":base,"shared":run(filepath.Join(base,"shared-case"),false),"isolated":run(filepath.Join(base,"isolated-case"),true)};b,e:=json.MarshalIndent(out,"","  ");if e!=nil{panic(e)};fmt.Println(string(b))}
