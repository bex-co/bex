import ast, copy, hashlib, json, pathlib, stat
R=pathlib.Path('/private/tmp/bex-w8-common-predeploy-independent-review-20261101-86r5yg2u')
A=pathlib.Path('/private/tmp/bex-w8-common-predeploy-source-20261101-6i5po0e2')
B=pathlib.Path('/private/tmp/bex-w8-common-predeploy-export-source-20261101-6273khmb')
REPO=pathlib.Path('/Users/tianpan/projects/bex7')
checks=[]; custody={}
def ident(p):
 s=p.lstat(); assert stat.S_ISREG(s.st_mode),str(p)
 h=hashlib.sha256(); n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b); n+=len(b)
 return {'bytes':n,'sha256':h.hexdigest()}
def yes(name,value=True):
 assert value,name; checks.append({'name':name,'pass':True})
def refuses(name,fn):
 try:fn()
 except (AssertionError,KeyError,TypeError):yes(name)
 else:raise AssertionError('accepted '+name)
for root,hm,receipt,hr in [(A,'9b12c8f70463e412c83b8db73b2dee8a79788b547b610b7c7272f7a0220f8043','RECEIPT.json','549da3787f425d85ed9c205fa65e883acd36c9cf1be4de1732980adb421f85b5'),(B,'7d4334354ee4edb0b79c25ab5247bd7438aa40480759fc9e4c2e57e593308fea','REVIEW.json','70d6178135a8e1dc1cf897b71ca4127fc4a174a7d56748249310098c1e67d682')]:
 yes(root.name+' manifest hash',ident(root/'MANIFEST.json')['sha256']==hm)
 yes(root.name+' receipt hash',ident(root/receipt)['sha256']==hr)
 m=json.loads((root/'MANIFEST.json').read_text()); names=set()
 for row in m['files']:
  p=pathlib.PurePosixPath(row['path']);assert not p.is_absolute() and '..' not in p.parts
  assert row['path'] not in names;names.add(row['path'])
  got=ident(root/row['path']);assert got=={k:row[k] for k in ('bytes','sha256')},row['path']
  custody[str(root/row['path'])]=got
 yes(root.name+' all listed regular payloads exact')
 allowed=names|{'MANIFEST.json',receipt}
 yes(root.name+' exact regular fileset',set(p.name for p in root.iterdir())==allowed)
for root,name in [(A,'INPUT-CUSTODY.json'),(B,'SOURCE-CUSTODY.json')]:
 d=json.loads((root/name).read_text()); n=0
 for raw,want in d['files'].items():
  p=pathlib.Path(raw) if raw.startswith('/') else REPO/raw
  got=ident(p); assert got=={k:want[k] for k in ('bytes','sha256')},str(p)
  if 'mode' in want: assert oct(p.stat().st_mode&0o777)==want['mode'],str(p)
  if 'git_mode' in want: assert ('100755' if p.stat().st_mode&0o111 else '100644')==want['git_mode'],str(p)
  custody[str(p)]=got;n+=1
 yes(name+' all '+str(n)+' allowlisted source identities current')
source=(A/'predeploy-observer.py').read_bytes();tree=ast.parse(source)
allowed={'NODE_MIDS','LITERAL','FILE_BYTES','PHASE_COMMANDS','EXPECTED','MAX_CAPTURE','ROOT'}
safe=[]
for node in tree.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in allowed for t in node.targets):
  if any(isinstance(t,ast.Name) and t.id=='ROOT' for t in node.targets):continue
  safe.append(node)
 if isinstance(node,ast.FunctionDef) and node.name in {'environment_contract','completed','proofs_complete'}:safe.append(node)
ns={'hashlib':hashlib};exec(compile(ast.Module(body=safe,type_ignores=[]),'reviewed-pure-observer','exec'),ns)
yes('only selected literal assignments and three pure functions executed')
cmd=(A/'command.txt').read_bytes();first=b"/usr/bin/python3 - <<'BEX_COMMON_PREDEPLOY_OBSERVER'\n";last=b'BEX_COMMON_PREDEPLOY_OBSERVER\n'
yes('exact quoted-heredoc byte derivation without shell execution',cmd==first+source+last)
yes('exact maintained phase argv',ns['PHASE_COMMANDS']==(('/usr/bin/python3','utility-check.py','predeploy'),('/usr/bin/python3','original-cases.py','predeploy','node')))
expected=json.loads((A/'EXPECTED-FIXTURE-BYTES.json').read_text())
# Metadata is a direct map, compare with literal from reviewed observer.
yes('observer expected map equals retained fixed metadata',expected==ns['EXPECTED'])
fixture=REPO/'lego/operator/internal/build/testdata/native-utilities'
for name,want in ns['EXPECTED'].items():
 p={'pg18.dump.b64':REPO/'deploy/native-base/testdata/archive.dump.b64','pg18-rows.txt':REPO/'deploy/native-base/testdata/rows.txt'}.get(name,fixture/name)
 assert ident(p)==want,name
yes('all '+str(len(ns['EXPECTED']))+' observer file/data hashes match current maintained bytes')
specs=json.loads((fixture/'original-cases.json').read_text())
yes('exact seven maintained Node case IDs',tuple(sorted(x['mid'] for x in specs if x['runtime']=='node'))==ns['NODE_MIDS'])
yes('all thirteen current replay records retained',len(specs)==13)
env={'QA_LITERAL':ns['LITERAL'],'QA_EMPTY':'','QA_SECRET_MARKER':'own-synthetic-only','QA_ENVFROM':'envFrom-text-雪\n','QA_OVERRIDE':'literal-wins','PORT':'10000'}
fn=ns['environment_contract']; args=(env,ns['FILE_BYTES'],False,False,False)
yes('exact environment and binary file accepted',fn(*args)['pass'] is True)
for k in env:
 e=dict(env);e[k]+='changed';refuses('reject wrong '+k,lambda e=e:fn(e,*args[1:]))
for label,idx,value in [('binary',1,b'changed'),('serviceaccount token',2,True),('projected pull file',3,True),('writable file',4,True)]:
 a=list(args);a[idx]=value;refuses('reject '+label,lambda a=a:fn(*a))
for k in ('DOCKER_CONFIG','REGISTRY_AUTH_FILE','KUBERNETES_DOCKERCONFIGJSON'):
 e=dict(env);e[k]='synthetic';refuses('reject projected '+k,lambda e=e:fn(e,*args[1:]))
proofs={'runtime-'+str(mid)+'-predeploy.json':[{'pass':True,'path':str(i)} for i in range(3)] for mid in ns['NODE_MIDS']}
yes('seven case twenty-one HTTP result shape accepted',ns['proofs_complete'](proofs)['independent_HTTP_responses']==21)
for label,change in [('missing case',lambda p:p.pop(next(iter(p)))),('wrong phase',lambda p:p.__setitem__('runtime-91-runtime.json',p.pop('runtime-91-predeploy.json'))),('short HTTP',lambda p:p['runtime-91-predeploy.json'].pop()),('false HTTP',lambda p:p['runtime-91-predeploy.json'][0].__setitem__('pass',False)),('truthy non-bool HTTP',lambda p:p['runtime-91-predeploy.json'][0].__setitem__('pass',1))]:
 p=copy.deepcopy(proofs);change(p);refuses('reject '+label,lambda p=p:ns['proofs_complete'](p))
ns['completed']({'exit_code':0,'bound':None});yes('canonical exit accepted')
for code,bound in [(False,None),(1,None),(-15,None),(0,'timeout'),(0,'remaining-process-group'),(0,'capture-size')]:refuses('reject noncanonical completion '+repr((code,bound)),lambda code=code,bound=bound:ns['completed']({'exit_code':code,'bound':bound}))
prefix=json.loads((B/'PREFIX-CUSTODY.json').read_text());original=(REPO/'lego/operator/internal/build/nativeutility_integration_test.go').read_bytes();over=(B/'nativeutility_integration_test.overlay.go').read_bytes();append=(B/'APPENDED.go.txt').read_bytes()
yes('B exact current original prefix plus only appended test',over==original+append and len(original)==prefix['original_bytes'])
yes('B no new imports',over.split(b')\n',1)[0]==original.split(b')\n',1)[0])
aover=(A/'predeploy_pull_secret_test.overlay.go').read_bytes();orig=(REPO/'lego/operator/internal/controller/predeploy_pull_secret_test.go').read_bytes();before=aover.split(b'\n\n// Scratch-only common-child exporter.',1)[0]
for line in (b'\t"bytes"\n',b'\t"crypto/sha256"\n',b'\t"encoding/json"\n',b'\t"fmt"\n',b'\t"io"\n',b'\t"os"\n',b'\t"path/filepath"\n',b'\t"regexp"\n',b'\t"k8s.io/apimachinery/pkg/types"\n'):
 before=before.replace(line,b'',1)
yes('A original canonical test body exact after only extra imports',before.rstrip(b'\n')==orig.rstrip(b'\n'))
result={'verdict':'CLEAN_SOURCE_ONLY','checks':checks,'count':len(checks),'input_custody':custody,'scope':'Exact frozen bytes/current allowlisted source reads, AST/literal comparison and pure observer controls only; no main, original program, shell, Go/compiler, resolver, registry, build, container, cluster, credential, CI or network execution.'}
(R/'CHECKS.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'checks':len(checks),'verdict':result['verdict'],'custody_paths':len(custody)}))
