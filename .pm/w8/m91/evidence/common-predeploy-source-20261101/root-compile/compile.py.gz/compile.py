"""Offline compile-only validation; never starts an exporter or a test binary."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/tianpan/projects/bex7')
TMP = ROOT / 'tmp'
FLOOR = (1 << 30) + (128 << 20)
OWN_CAP = 768 << 20
LOG_CAP = 8 << 20
STAGES = [
    ('build', 'internal/build', Path('/private/tmp/bex-w8-common-predeploy-export-source-20261101-6273khmb')),
    ('controller', 'internal/controller', Path('/private/tmp/bex-w8-common-predeploy-source-20261101-6i5po0e2')),
]

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()

def dump(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')

def identities():
    result = {}
    for _, _, capsule in STAGES:
        m = json.loads((capsule / 'MANIFEST.json').read_bytes())
        for row in m['files']:
            f = capsule / row['path']
            assert not f.is_symlink() and f.is_file()
            assert f.stat().st_size == row['bytes'] and digest(f) == row['sha256']
        result[str(capsule)] = digest(capsule / 'MANIFEST.json')
    result['foreign_go_work_sum'] = digest(REPO / 'lego/go.work.sum')
    return result

def interrupted(signum, frame):
    raise RuntimeError('observer signal ' + str(signum))

signal.signal(signal.SIGTERM, interrupted)
before = identities()
assert before['foreign_go_work_sum'] == 'efb45a8fffa3eaa979709e70e7e8c6660b207181450ac5f17febc6d0365f4ff6'
env = {k: v for k, v in os.environ.items() if not k.startswith('BEX_')}
env.update(GOWORK='off', GOTOOLCHAIN='local', GOENV='off', GOPROXY='off',
           GOSUMDB='off', GOFLAGS='-mod=readonly -buildvcs=false',
           GOMAXPROCS='2', GOMEMLIMIT='512MiB', TMPDIR=str(TMP),
           PYTHONDONTWRITEBYTECODE='1')
scope = {'scope': 'Compile test binaries only with go test -c; no test binary/exporter/resolver/program/image/cluster execution.',
         'source_before': before, 'free_floor': FLOOR, 'own_cap': OWN_CAP,
         'log_cap': LOG_CAP, 'timeout_each_seconds': 600,
         'controlled_environment': {k: env[k] for k in ('GOWORK','GOTOOLCHAIN','GOENV','GOPROXY','GOSUMDB','GOFLAGS','GOMAXPROCS','GOMEMLIMIT','TMPDIR')},
         'source_plan_delta': 'Actual exporter execution remains after both baseline architectures. Compile-only source validation runs now to catch type/import errors, with no fake reconcile or registry lookup.'}
dump('SCOPE.json', scope)
rows = []
failure = None
try:
    for name, package, capsule in STAGES:
        free = shutil.disk_usage(ROOT).free
        assert free > FLOOR + OWN_CAP + (32 << 20), free
        binary = TMP / (name + '.test')
        command = ['go','test','-c','-p','1','-overlay',str(capsule / 'overlay.json'),'-o',str(binary),'./' + package]
        row = {'name': name, 'argv': command, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'initial_free': free, 'minimum_free': free, 'peak_own_bytes': 0, 'bound': None}
        rows.append(row)
        process = None
        started = time.monotonic()
        logpath = ROOT / (name + '.log')
        try:
            with logpath.open('xb') as log:
                process = subprocess.Popen(command, cwd=REPO / 'lego/operator', env=env,
                                           stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                row['pid'] = process.pid
                while True:
                    free = shutil.disk_usage(ROOT).free
                    own = sum(f.stat().st_size for f in ROOT.rglob('*') if f.is_file())
                    row['minimum_free'] = min(free, row['minimum_free'])
                    row['peak_own_bytes'] = max(own, row['peak_own_bytes'])
                    if free <= FLOOR or own >= OWN_CAP - (32 << 20) or logpath.stat().st_size > LOG_CAP:
                        row['bound'] = 'capacity-or-log'
                        break
                    if time.monotonic() - started > 600:
                        row['bound'] = 'timeout'
                        break
                    if process.poll() is not None:
                        break
                    time.sleep(1)
        finally:
            if process is not None:
                try:
                    os.killpg(process.pid, 0)
                    if process.poll() is None:
                        row['bound'] = row['bound'] or 'aborted'
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait(timeout=10)
                row['exit_code'] = process.returncode
                try:
                    os.killpg(process.pid, 0)
                except ProcessLookupError:
                    row['group_absent'] = True
                else:
                    row['group_absent'] = False
        row['elapsed_seconds'] = time.monotonic() - started
        row['log'] = {'bytes': logpath.stat().st_size, 'sha256': digest(logpath)}
        if binary.is_file():
            row['compiled_binary'] = {'bytes': binary.stat().st_size, 'sha256': digest(binary), 'executed': False}
            binary.unlink()
        dump('PROGRESS.json', rows)
        assert row['exit_code'] == 0 and row['bound'] is None and row['group_absent'], row
except BaseException as error:
    failure = type(error).__name__ + ': ' + str(error)
finally:
    after = identities()
    assert before == after, 'source capsule or foreign sum changed'
    shutil.rmtree(TMP)
    dump('RESULT.json', {'scope': scope['scope'], 'stages': rows, 'failure': failure,
                         'source_unchanged': before == after, 'source_after': after,
                         'own_temporary_directory_removed': not TMP.exists(), 'actual_predeploy': None})
print(json.dumps({'root': str(ROOT), 'failure': failure, 'stages': [{k: r.get(k) for k in ('name','exit_code','bound','elapsed_seconds')} for r in rows]}))
if failure:
    raise SystemExit(1)
