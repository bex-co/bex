"""One current common-child predeploy observation; no action on import.

The two maintained programs run unchanged. This observer is not a controller,
image builder, production release or all-runtime/all-architecture acceptance.
"""
import base64
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path('/opt/render/project/src')
NODE_MIDS = (91, 93, 98, 99, 101, 103, 107)
LITERAL = 'literal $(QA_SECRET_MARKER) $HOME; "雪"\ntrailing\n'
FILE_BYTES = b'own-dev8-file\x00\xff\n'
PHASE_COMMANDS = (('/usr/bin/python3', 'utility-check.py', 'predeploy'),
                  ('/usr/bin/python3', 'original-cases.py', 'predeploy', 'node'))
MAX_CAPTURE = 1024 * 1024
EXPECTED = {'cases/m100/http.py': {'bytes': 1301, 'sha256': '81bb386b11c2aad0896d45d1b48597bc03373c8af977d9af4e2cebdcb5d88b69'}, 'cases/m100/validators.py': {'bytes': 784, 'sha256': '986ccddf422b19d220a5e4c2108a2858814d8df4445a7cde4f45ac07482651a0'}, 'cases/m101/http.py': {'bytes': 1224, 'sha256': '2d0fb551b23822b2301a71db30605ba910d816af13657836d773cb0bdd4c4634'}, 'cases/m101/validators.py': {'bytes': 794, 'sha256': '63ae3cae9e37db7f9e60a233b6fe214747af47656ad17dd7a41db317ccea4ed3'}, 'cases/m102/http.py': {'bytes': 1782, 'sha256': '63b6e563fbf9e9cccbbaa58af87ce73eab5dd8910b64e769ecf0ec54d80504fe'}, 'cases/m102/validators.py': {'bytes': 846, 'sha256': '899060770d761dbe8255cc51d18ba6bbdde923f5b26dee8057ac9adb3702648e'}, 'cases/m103/http.py': {'bytes': 1346, 'sha256': '21649c018aa68b1e9bd027d165a0498dae3e4d8cfbe18228b7246a465c223189'}, 'cases/m103/validators.py': {'bytes': 1007, 'sha256': '6679f39358f9ecdba3aba7747ccea4b028372bcee427fa77db142c1fe454b208'}, 'cases/m107/http.py': {'bytes': 2704, 'sha256': 'f659f8a44cd73db33da8902ab4e3dbad4f5713ca91677a67a48a5696b34db06d'}, 'cases/m107/validators.py': {'bytes': 444, 'sha256': 'e3c01915a1d5fa7b81890bd553be3654d416685ee1295d8ff5b0da272272b634'}, 'cases/m91/http.py': {'bytes': 760, 'sha256': '9476c0fb42d65a8a6fd7a32f64307003a5746aefe062b85304be29e8d6763803'}, 'cases/m91/qa402.dump.b64': {'bytes': 2297, 'sha256': '8697ff567103ca61423fc1a0b4f364d191ffa22086e547c64f89c1f2fa41d0bd'}, 'cases/m91/validators.py': {'bytes': 868, 'sha256': 'bcea54ec9a58a9f8c97676680f6d5cee9876feb16d16cc809cda26056856ace1'}, 'cases/m93/http.py': {'bytes': 1490, 'sha256': '1c6dd3da3d568ba52fdd9728ce7c0f9f38c6e928060358eb55c5814a9b2cdfc0'}, 'cases/m93/sweep407-html.py': {'bytes': 918, 'sha256': '43314330690433d298e850a047460b848f286a3824bbb8e2509831e1de8be597'}, 'cases/m93/validators.py': {'bytes': 903, 'sha256': '14a6714bfddf409acfc8eee1f75666eeeac7be18b4b2d9674b239417e5fa03d7'}, 'cases/m94/validators.py': {'bytes': 823, 'sha256': 'dc67c77b617c59cb5d66bae199ad315d5c4344f42ba0cb82040216ba8dbb9e8b'}, 'cases/m95/http.py': {'bytes': 1513, 'sha256': '27d85a80e1e0ac250ee526593ff694918af83e1d378c464e1f68b9825553d878'}, 'cases/m95/sweep406-png.py': {'bytes': 950, 'sha256': '7d4f86261baee458fdacc5e5f347def3ddf5b154a6416ef8bfde2a95a554f505'}, 'cases/m95/validators.py': {'bytes': 729, 'sha256': '8a9f007446916ac3f60a16476527517fe22b4c4475fe6cc343d6370e3e8735aa'}, 'cases/m96/http.py': {'bytes': 1769, 'sha256': '7d361863070b3d7bc794a1dd182b4f95f854770ee15de5893c38caab8207627a'}, 'cases/m96/validators.py': {'bytes': 951, 'sha256': '998088b1aa2fa9162ff1ec0ae304072b92e4dd0b6cda0b62605db0ae97a1690b'}, 'cases/m97/http.py': {'bytes': 1901, 'sha256': 'd38910713883276aec60ffc9ad4cf7ef84fb7fe7fbf4b7a4c58d2a74a0cd38c9'}, 'cases/m97/sweep406-png.py': {'bytes': 950, 'sha256': '7d4f86261baee458fdacc5e5f347def3ddf5b154a6416ef8bfde2a95a554f505'}, 'cases/m97/validators.py': {'bytes': 537, 'sha256': 'ef78852f2d8a39da81d40b9da023ab97de2221ee6d30d9a268589bdeca826eb9'}, 'cases/m98/http.py': {'bytes': 1179, 'sha256': '69d6823694a2ec9d55b925213688c5d0e6b297cb7fb795fab3567d6fca726438'}, 'cases/m98/validators.py': {'bytes': 1132, 'sha256': 'a8abc8d50988275aa2c2936cc895bc7a7b0358ed7f06edf30a788bfaa0118a08'}, 'cases/m99/http.py': {'bytes': 1188, 'sha256': '4631fc56dcf3498a080af4cce09bb50ed127404b0e3d9068963cf1fb8f6a447b'}, 'cases/m99/validators.py': {'bytes': 708, 'sha256': '2dec2aca1c6eb8b1d2a1cca35bbc2c9e47849d65148ec417b8854e022ad04008'}, 'gettext-reference.json': {'bytes': 777, 'sha256': 'cf8dc598500148d80e44606c138449154847cd7d639ade59886d9cf9f10b9edb'}, 'messages.po': {'bytes': 508, 'sha256': 'cf68cfd752aa80d6a0334fb0b907e5f186962298860ba3ea0b43de953356000a'}, 'original-cases.json': {'bytes': 83949, 'sha256': 'c8387719f59d574e71732faca7c1c06e6e421fec1bf7766f2b3c0d7bf7063ce5'}, 'original-cases.py': {'bytes': 6239, 'sha256': 'c0490ebecc5a4c940aa5d64b6c5c8d70f87527ace424bf5c21a2c45159e608b0'}, 'original-cases_test.py': {'bytes': 6613, 'sha256': 'bf7128b692b6d062402665c478bb604a9439e31b7252eb13c5611fef66201159'}, 'png-decoder.py': {'bytes': 1933, 'sha256': '723d510abad384f74069b445c31f80c79e3930281ed5d6542e12453455c2150e'}, 'provenance.json': {'bytes': 21602, 'sha256': '48a9fb0691b00879f07b200ffb560dc338b8bb4e2f9a8cd3e875df5fbb9d782d'}, 'recorded-node-http.json.gz': {'bytes': 12008, 'sha256': '5510f0dfe1fa2838cdc7213dc94a631c93056bb08c10b48481e6617f62b3564e'}, 'source-carrier/CHANGELOG': {'bytes': 18, 'sha256': '9c65e366055edd9a0f6ab9c7b8a37fc92803cfe1d30ffa727ceed0c63939c2e5'}, 'source-carrier/LICENSE': {'bytes': 1072, 'sha256': '20b064910b32bce1bc04595a5b20477a28c503995ef8528929a311d6cb7a3b09'}, 'utility-check.py': {'bytes': 11577, 'sha256': '3e895819b0b650ac9f9def487d0f396d5fbf00fc3ae3c2ff7f9df7f5fc9d41fb'}, 'pg18.dump.b64': {'bytes': 2679, 'sha256': '5f2c6098b9b6b79681ac78792955d2104916298d6cc5010c1e98a6508ff53dc0'}, 'pg18-rows.txt': {'bytes': 33, 'sha256': '504f196d8a6cbc57cbf1e3b125cbc6419f08efb4e4995e9d06392d8c992b839b'}}


def identity(path):
    digest = hashlib.sha256()
    size = 0
    with Path(path).open('rb') as source:
        for body in iter(lambda: source.read(65536), b''):
            size += len(body)
            digest.update(body)
    return {'bytes': size, 'sha256': digest.hexdigest()}


def environment_contract(environment, payload, token_exists, pull_file_exists, writable):
    assert environment['QA_LITERAL'] == LITERAL
    assert environment['QA_EMPTY'] == ''
    assert environment['QA_SECRET_MARKER'] == 'own-synthetic-only'
    assert environment['QA_ENVFROM'] == 'envFrom-text-雪\n'
    assert environment['QA_OVERRIDE'] == 'literal-wins'
    assert environment['PORT'] == '10000'
    assert payload == FILE_BYTES
    assert not token_exists and not pull_file_exists and not writable
    assert all('dockerconfigjson' not in key.lower() for key in environment)
    assert 'DOCKER_CONFIG' not in environment and 'REGISTRY_AUTH_FILE' not in environment
    return {'pass': True, 'literal_sha256': hashlib.sha256(LITERAL.encode()).hexdigest(),
            'file_sha256': hashlib.sha256(payload).hexdigest(), 'empty_preserved': True,
            'text_envFrom': True, 'literal_precedence': True, 'port_precedence': True,
            'binary_file_read_only': True, 'serviceaccount_token_absent': True,
            'pull_credentials_not_projected': True}


def emit(label, value):
    print('BEX_COMMON_PREDEPLOY_' + label + ' ' + json.dumps(value, ensure_ascii=False, sort_keys=True), flush=True)


def capture(argv, timeout, environment=None):
    """Only a fixed observation command, bounded inside the600s canonical Job."""
    process = subprocess.Popen(list(argv), cwd=ROOT, env=environment,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    bound = None
    stdout, stderr = b'', b''
    try:
        try:
            stdout, stderr = process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired as error:
            bound = 'timeout'
            stdout, stderr = error.output or b'', error.stderr or b''
            # Let the unchanged Python program unwind its own server finally.
            try: os.killpg(process.pid, signal.SIGINT)
            except ProcessLookupError: pass
            try: stdout, stderr = process.communicate(timeout=3)
            except subprocess.TimeoutExpired: pass
    finally:
        try:
            os.killpg(process.pid, 0)
            bound = bound or 'remaining-process-group'
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        try: stdout, stderr = process.communicate(timeout=3)
        except subprocess.TimeoutExpired:
            bound = 'incomplete-output-after-stop'
            process.stdout.close()
            process.stderr.close()
        process.wait(timeout=1)
    record = {'argv': list(argv), 'exit_code': process.returncode, 'bound': bound,
              'stdout_bytes': len(stdout), 'stdout_sha256': hashlib.sha256(stdout).hexdigest(),
              'stderr_bytes': len(stderr), 'stderr_sha256': hashlib.sha256(stderr).hexdigest()}
    if len(stdout) <= MAX_CAPTURE and len(stderr) <= MAX_CAPTURE:
        record.update(stdout_base64=base64.b64encode(stdout).decode(), stderr_base64=base64.b64encode(stderr).decode())
    else:
        record['bound'] = 'capture-size'
        record['full_output_not_retained'] = True
    emit('COMMAND', record)
    return record, stdout


def completed(record):
    assert type(record['exit_code']) is int and record['exit_code'] == 0 and record['bound'] is None, record


def proofs_complete(proofs):
    assert set(proofs) == {'runtime-' + str(mid) + '-predeploy.json' for mid in NODE_MIDS}
    assert all(isinstance(rows, list) and len(rows) == 3
               and all(isinstance(row, dict) and row.get('pass') is True for row in rows)
               for rows in proofs.values())
    return {'original_node_cases': 7, 'independent_HTTP_responses': 21, 'pass': True}


def main():
    assert not sys.flags.optimize
    deadline = time.monotonic() + 540
    assert Path.cwd().resolve() == ROOT, ('actual cwd differs', str(Path.cwd()))
    emit('IDENTITY', {'cwd': str(Path.cwd()), 'PATH': os.environ.get('PATH'),
                     'python_executable': sys.executable, 'python_version': sys.version,
                     'scope': 'one same-common Node compute child, actual current local architecture only'})
    observed = {name: identity(ROOT / name) for name in EXPECTED}
    assert observed == EXPECTED, 'maintained source/program/data bytes differ'
    emit('SOURCE_BYTES', observed)
    payload = Path('/etc/secrets/proof.txt').read_bytes()
    writable = False
    try: Path('/etc/secrets/proof.txt').write_bytes(b'bad')
    except OSError: pass
    else: writable = True
    emit('ENV_FILE', environment_contract(os.environ, payload,
         Path('/var/run/secrets/kubernetes.io/serviceaccount/token').exists(),
         Path('/etc/secrets/.dockerconfigjson').exists(), writable))
    versions = {}
    for program in ('node', 'npm', 'yarn', 'pnpm', '/usr/bin/python3', 'python', 'python3', 'python3-config'):
        resolved = shutil.which(program)
        if resolved is None:
            versions[program] = {'present': False}
            continue
        argv = [resolved, '--includes' if program == 'python3-config' else '--version']
        result, stdout = capture(argv, min(5, max(.1, deadline - time.monotonic())))
        versions[program] = {'present': True, 'resolved': resolved, 'realpath': os.path.realpath(resolved),
                             'command': result, 'stdout': stdout.decode(errors='replace')}
        if program in ('node', '/usr/bin/python3'):
            completed(result)
            if program == 'node': assert stdout.decode().strip().startswith('v24.')
    emit('VERSIONS', versions)
    # Separate absolute-interpreter child; utilities retain the normal image PATH.
    empty = dict(os.environ, PATH='')
    argv = ['/usr/bin/python3', '-c', 'import json,os;assert os.environ["PATH"]=="";print(json.dumps({"PATH":os.environ["PATH"],"cwd":os.getcwd()}))']
    result, stdout = capture(argv, min(5, max(.1, deadline - time.monotonic())), empty)
    completed(result)
    emit('EMPTY_PATH_CHILD_ONLY', {'observation': json.loads(stdout), 'utilities_run_with_empty_PATH': False})
    output = ROOT / 'qa-output'
    assert not list(output.glob('runtime-*-predeploy.json')), 'predeploy proof already exists; no stale proof reuse'
    summaries = []
    for argv in PHASE_COMMANDS:
        result, stdout = capture(argv, min(240, max(.1, deadline - time.monotonic())))
        completed(result)
        summary = json.loads(stdout)
        assert summary.get('pass') is True and summary.get('phase') == 'predeploy'
        summaries.append(summary)
    assert summaries[1].get('mode') == 'node'
    assert {row['mid'] for row in summaries[1]['original_cases']} == set(NODE_MIDS)
    emit('MAINTAINED_PROGRAMS', summaries)
    proofs = {path.name: json.loads(path.read_text()) for path in sorted(output.glob('runtime-*-predeploy.json'))}
    result = proofs_complete(proofs)
    emit('HTTP_PROOFS', proofs)
    artifacts = {}
    for mid in NODE_MIDS:
        log = output / ('build-' + str(mid) + '.log')
        assert log.is_file(), ('retained authored build log absent', mid)
        artifacts[str(log.relative_to(ROOT))] = identity(log)
        work = output / ('m' + str(mid))
        assert work.is_dir()
        for path in sorted(work.rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                artifacts[str(path.relative_to(ROOT))] = identity(path)
    emit('RETAINED_BUILD_ARTIFACTS', artifacts)
    emit('PASS', {**result, 'scope': 'same-common Node compute child predeploy; no13/28/all-family/adoption claim'})


if __name__ == '__main__':
    try: main()
    except BaseException as error:
        emit('FAILURE', {'pass': False, 'error_class': type(error).__name__})
        raise
