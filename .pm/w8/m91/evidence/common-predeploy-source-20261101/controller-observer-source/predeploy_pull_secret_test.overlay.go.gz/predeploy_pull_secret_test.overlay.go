/*
Copyright 2026.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package controller

import (
	"context"
	"bytes"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"testing"

	batchv1 "k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/types"
	clientgoscheme "k8s.io/client-go/kubernetes/scheme"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/client/fake"

	"github.com/bex-co/bex/lego/operator/internal/predeploy"
	"github.com/bex-co/bex/lego/operator/internal/registry"
	appv1alpha1 "github.com/bex-co/bex/lego/types/v1alpha1"
)

// TestPreDeployJobRunsInAppNamespace pins the ADR043-D8 co-location fix: even
// with BEX_BUILD_NAMESPACE set, the pre-deploy Job lands in the App's OWN
// namespace — a Job in the shared build namespace cannot reach the workspace's
// managed Postgres through the tenant default-deny, so a migration's
// connections timed out there. Co-location also retires the w9/012 relocation
// machinery this file used to pin: pull secrets are exactly the app pod's
// imagePullSecrets() (no build-namespace credential, no external-secret
// relocation) and no referenced Secret is copied across namespaces.
func TestPreDeployJobRunsInAppNamespace(t *testing.T) {
	ctx := context.Background()
	scheme := runtime.NewScheme()
	_ = clientgoscheme.AddToScheme(scheme)
	_ = appv1alpha1.AddToScheme(scheme)

	app := &appv1alpha1.App{
		ObjectMeta: metav1.ObjectMeta{
			Name: "myapp", Namespace: "default", Generation: 1, UID: "uid-myapp",
			Labels: map[string]string{labelWorkspace: "tea-ws"},
		},
		Spec: appv1alpha1.AppSpec{
			Image:                      "zot.svc:5000/myapp:gen-1",
			PreDeployCommand:           "migrate",
			EnvFromSecret:              "myapp-env",
			ExternalRegistryPullSecret: "ext-pull",
		},
	}
	envSecret := &corev1.Secret{ObjectMeta: metav1.ObjectMeta{Name: "myapp-env", Namespace: "default"}}
	extPull := &corev1.Secret{
		ObjectMeta: metav1.ObjectMeta{Name: "ext-pull", Namespace: "default"},
		Type:       corev1.SecretTypeDockerConfigJson,
		Data:       map[string][]byte{corev1.DockerConfigJsonKey: []byte(`{"auths":{}}`)},
	}
	cl := fake.NewClientBuilder().WithScheme(scheme).
		WithObjects(app, envSecret, extPull).
		WithStatusSubresource(&appv1alpha1.App{}).
		Build()
	r := &AppReconciler{
		Client: cl, BuildClient: cl, Scheme: scheme,
		Mode: ModeKubernetes, BuildNamespace: "bex-build",
		Registry: "zot.svc:5000", PerAppRegistry: &registry.Creds{},
	}

	if _, _, err := r.reconcilePreDeploy(ctx, app, "zot.svc:5000/myapp:gen-1", 3000); err != nil {
		t.Fatalf("reconcilePreDeploy: %v", err)
	}

	// The Job runs beside the App, never in the build namespace.
	jobNN := client.ObjectKey{Namespace: "default", Name: predeploy.JobName("myapp", "gen-1")}
	var job batchv1.Job
	if err := cl.Get(ctx, jobNN, &job); err != nil {
		t.Fatalf("pre-deploy Job not in the App namespace: %v", err)
	}
	if err := cl.Get(ctx, client.ObjectKey{Namespace: "bex-build", Name: jobNN.Name}, &batchv1.Job{}); !apierrors.IsNotFound(err) {
		t.Fatalf("a pre-deploy Job exists in the build namespace: %v", err)
	}

	// Pull secrets are the app pod's own — the App-namespace tenant credential
	// plus the external-registry reference, resolved in place. Nothing is
	// relocated into the build namespace.
	got := job.Spec.Template.Spec.ImagePullSecrets
	want := []string{appIdentity(app).PullSecretName(), "ext-pull"}
	if len(got) != len(want) {
		t.Fatalf("job imagePullSecrets = %v, want %v", got, want)
	}
	for i := range want {
		if got[i].Name != want[i] {
			t.Fatalf("job imagePullSecrets[%d] = %q, want %q", i, got[i].Name, want[i])
		}
	}
	var buildNS batchv1.JobList
	if err := cl.List(ctx, &buildNS, client.InNamespace("bex-build")); err != nil {
		t.Fatal(err)
	}
	if len(buildNS.Items) != 0 {
		t.Errorf("build namespace holds %d Jobs", len(buildNS.Items))
	}
	var secrets corev1.SecretList
	if err := cl.List(ctx, &secrets, client.InNamespace("bex-build")); err != nil {
		t.Fatal(err)
	}
	if len(secrets.Items) != 0 {
		names := make([]string, 0, len(secrets.Items))
		for _, s := range secrets.Items {
			names = append(names, s.Name)
		}
		t.Errorf("secrets were mirrored into the build namespace: %v — the Job resolves every reference in the App namespace now", names)
	}
}


// Scratch-only common-child exporter. It invokes the CURRENT reconciler with a
// fake client; it never contacts a cluster or creates a real resource.
func TestScratchCommonPredeployExport(t *testing.T) {
	output := os.Getenv("BEX_COMMON_PREDEPLOY_OUTPUT")
	inputPath := os.Getenv("BEX_COMMON_PREDEPLOY_INPUT")
	if !filepath.IsAbs(output) || !filepath.IsAbs(inputPath) {
		t.Fatal("explicit absolute owned output and input paths required")
	}
	info, err := os.Lstat(output)
	if err != nil || !info.IsDir() || info.Mode().Perm()&0077 != 0 {
		t.Fatal("fresh private0700 output directory required")
	}
	entries, err := os.ReadDir(output)
	if err != nil || len(entries) != 0 {
		t.Fatal("output directory must initially be empty")
	}
	read := func(path string, maximum int64) []byte {
		info, err := os.Lstat(path)
		if err != nil || !info.Mode().IsRegular() || info.Size() > maximum {
			t.Fatalf("bounded regular input required: %s", path)
		}
		body, err := os.ReadFile(path)
		if err != nil || int64(len(body)) > maximum {
			t.Fatalf("input read failed: %s", path)
		}
		return body
	}
	var input struct {
		Name       string `json:"name"`
		Namespace  string `json:"namespace"`
		AnchorName string `json:"anchor_name"`
		AnchorUID  string `json:"anchor_uid"`
		Image      string `json:"image"`
		ImageRevision string `json:"image_revision"`
		Registry   string `json:"registry"`
		PullSecret string `json:"pull_secret"`
		EnvSecret  string `json:"env_secret"`
		FileSecret string `json:"file_secret"`
		Command    string `json:"command_file"`
		Generation int64  `json:"generation"`
	}
	decoder := json.NewDecoder(bytes.NewReader(read(inputPath, 65536)))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&input); err != nil { t.Fatal(err) }
	if err := decoder.Decode(new(any)); err != io.EOF { t.Fatal("trailing input JSON") }
	if !regexp.MustCompile(`^qa-common-predeploy-[a-f0-9]{12}$`).MatchString(input.Name) ||
		input.Namespace != "dev-8" || input.Generation < 1 || input.AnchorUID == "" ||
		input.AnchorName != input.Name+"-anchor" || input.EnvSecret != input.Name+"-env" ||
		input.FileSecret != input.Name+"-files" ||
		(input.PullSecret != "" && input.PullSecret != input.Name+"-pull") {
		t.Fatal("explicit fresh own dev-8 synthetic identity required")
	}
	if !regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._:/-]*@sha256:[a-f0-9]{64}$`).MatchString(input.Image) ||
		input.Image == "ghcr.io/bex-co/bex-cnb-run@sha256:56c58abb41abd6becfa1810834c6cba46b742703e2beffdb3a88387772b3b986" {
		t.Fatal("a supplied immutable COMPUTE CHILD reference, not the common foundation, is required")
	}
	if !filepath.IsAbs(input.Command) { t.Fatal("explicit observer command path required") }
	command := read(input.Command, 65536)
	if fmt.Sprintf("%x", sha256.Sum256(command)) != "e911bebf2cddc77ccd00a8667b0d6669512432be9480858b43dee443d371e232" { t.Fatal("reviewed observer command bytes differ") }
	type sourceIdentity struct {
		Bytes int    `json:"bytes"`
		SHA   string `json:"sha256"`
	}
	var expected map[string]sourceIdentity
	if err := json.Unmarshal([]byte(`{
  "lego/operator/internal/controller/predeploy_pull_secret_test.go": {
    "bytes": 4819,
    "sha256": "aba5d02731083634a34d7c5d16b1c2e3aba510742051af99dbd5864ba96c4d12"
  },
  "lego/operator/internal/controller/app_controller.go": {
    "bytes": 367123,
    "sha256": "697135be6bd8c65d4345d19c3a3a3f66a44bef50d916860ff38a6f07b68e490c"
  },
  "lego/operator/internal/controller/platform_env.go": {
    "bytes": 7129,
    "sha256": "8cb099522057ddb80d9cde9e576221eaaf54559ba3c63250654c3cf6f5d92668"
  },
  "lego/operator/internal/controller/container_policy.go": {
    "bytes": 4134,
    "sha256": "2c3841633148787f3e86997c959718e9dc50f8074e9f13321361ca18618ae9d5"
  },
  "lego/operator/internal/controller/deployment_projection.go": {
    "bytes": 30287,
    "sha256": "fe00a6fc3deac657ec2687c15b9bbb08dea36c12c3b7f368dffeec361feccb23"
  },
  "lego/operator/internal/controller/shell_command.go": {
    "bytes": 6186,
    "sha256": "1701be0f1491541408967236d3f9bb870041c7796b86baec7d952a63cd842365"
  },
  "lego/operator/internal/controller/release_config_snapshot.go": {
    "bytes": 35561,
    "sha256": "ce1f6ae0666db56ed529fc66bb38c1284c5a17b70759ed876a87dc0caa3269df"
  },
  "lego/operator/internal/predeploy/predeploy.go": {
    "bytes": 18984,
    "sha256": "58733801fc517ec0b15abe2969a99b76f527c6371bcca82b6f392346f557b95c"
  },
  "lego/operator/internal/execution/security.go": {
    "bytes": 5430,
    "sha256": "52051249d74093d426e0054b1e5ad7a0acd77c3e86f6930ea228b79cb728a04c"
  },
  "lego/operator/internal/build/nativeutility_integration_test.go": {
    "bytes": 16556,
    "sha256": "7854020f6c2c5a71ac784ab1e8f7b4df0aac890ab860ed689a7211326b6896b5"
  },
  "lego/types/v1alpha1/app_types.go": {
    "bytes": 95401,
    "sha256": "1b78314109c3837864943100802ca37dc79c21edd50522c5d4b48e6dc6045752"
  },
  "lego/operator/internal/execution/literal.go": {
    "bytes": 915,
    "sha256": "ea69cbdf5322143d8fa0f590ba412e7e43921a6a1f12a777635ac3416096a6cf"
  },
  "lego/operator/internal/controller/image_network.go": {
    "bytes": 19470,
    "sha256": "3ece8675348c1305f2f43e3d19c6ac18e5bd36da8b2c13fb8046155c6ab03ef5"
  }
}`), &expected); err != nil { t.Fatal(err) }
	actual := make(map[string]sourceIdentity, len(expected))
	for name, want := range expected {
		body := read(filepath.Join("..", "..", "..", "..", filepath.FromSlash(name)), 2<<20)
		got := sourceIdentity{Bytes: len(body), SHA: fmt.Sprintf("%x", sha256.Sum256(body))}
		if got != want { t.Fatalf("current canonical source differs: %s", name) }
		actual[name] = got
	}
	ctx := context.Background()
	scheme := runtime.NewScheme()
	if err := clientgoscheme.AddToScheme(scheme); err != nil { t.Fatal(err) }
	if err := appv1alpha1.AddToScheme(scheme); err != nil { t.Fatal(err) }
	app := &appv1alpha1.App{ObjectMeta: metav1.ObjectMeta{
		Name: input.Name, Namespace: input.Namespace, Generation: input.Generation,
		UID: types.UID(input.AnchorUID), Labels: map[string]string{labelWorkspace: "dev-8"},
	}, Spec: appv1alpha1.AppSpec{
		Image: input.Image, Runtime: "node", Builder: "native", Tier: "starter",
		Repo: "https://github.com/bex-co/git-fixtures", PreDeployCommand: string(command),
		EnvFromSecret: input.EnvSecret, FilesFromSecrets: []string{input.FileSecret}, ExternalRegistryPullSecret: input.PullSecret,
		Env: []appv1alpha1.EnvVar{
			{Name: "QA_LITERAL", Value: "literal $(QA_SECRET_MARKER) $HOME; \"雪\"\ntrailing\n"},
			{Name: "QA_EMPTY", Value: ""}, {Name: "QA_OVERRIDE", Value: "literal-wins"},
			{Name: "PORT", Value: "20000"},
		},
	}}
	// Explicit fake status prevents a registry lookup while exporting a template.
	// It is not an independent OCI revision/RENDER_GIT_COMMIT observation.
	app.Status.ImageRevision = &appv1alpha1.ImageRevisionStatus{Image: input.Image, Commit: input.ImageRevision}
	envSecret := &corev1.Secret{ObjectMeta: metav1.ObjectMeta{Name: input.EnvSecret, Namespace: input.Namespace},
		Type: corev1.SecretTypeOpaque, Data: map[string][]byte{
			"QA_SECRET_MARKER": []byte("own-synthetic-only"), "QA_ENVFROM": []byte("envFrom-text-雪\n"),
			"QA_OVERRIDE": []byte("secret-loses"), "PORT": []byte("30000"),
		}}
	fileSecret := &corev1.Secret{ObjectMeta: metav1.ObjectMeta{Name: input.FileSecret, Namespace: input.Namespace},
		Type: corev1.SecretTypeOpaque, Data: map[string][]byte{"proof.txt": []byte("own-dev8-file\x00\xff\n")}}
	objects := []client.Object{app, envSecret, fileSecret}
	if input.PullSecret != "" {
		objects = append(objects, &corev1.Secret{ObjectMeta: metav1.ObjectMeta{Name: input.PullSecret, Namespace: input.Namespace},
			Type: corev1.SecretTypeDockerConfigJson, Data: map[string][]byte{corev1.DockerConfigJsonKey: []byte(`{"auths":{}}`)}})
	}
	cl := fake.NewClientBuilder().WithScheme(scheme).WithObjects(objects...).WithStatusSubresource(&appv1alpha1.App{}).Build()
	r := &AppReconciler{Client: cl, BuildClient: cl, Scheme: scheme, Mode: ModeKubernetes,
		BuildNamespace: "bex-build", Registry: input.Registry}
	result, halt, err := r.reconcilePreDeploy(ctx, app, input.Image, 10000)
	if err != nil { t.Fatal(err) }
	var job batchv1.Job
	if err := cl.Get(ctx, client.ObjectKey{Namespace: input.Namespace,
		Name: predeploy.JobName(input.Name, appv1alpha1.BuildRevision(input.Generation))}, &job); err != nil { t.Fatal(err) }
	job.TypeMeta = metav1.TypeMeta{APIVersion: "batch/v1", Kind: "Job"}
	anchored := job.DeepCopy()
	controller := true
	anchored.OwnerReferences = []metav1.OwnerReference{{APIVersion: "v1", Kind: "ConfigMap",
		Name: input.AnchorName, UID: types.UID(input.AnchorUID), Controller: &controller}}
	podBefore, err := json.Marshal(job.Spec.Template); if err != nil { t.Fatal(err) }
	podAfter, err := json.Marshal(anchored.Spec.Template); if err != nil { t.Fatal(err) }
	if !bytes.Equal(podBefore, podAfter) { t.Fatal("anchor changed canonical PodTemplate") }
	comparison := anchored.DeepCopy(); comparison.OwnerReferences = job.OwnerReferences
	jobBefore, err := json.Marshal(job); if err != nil { t.Fatal(err) }
	jobAfter, err := json.Marshal(comparison); if err != nil { t.Fatal(err) }
	if !bytes.Equal(jobBefore, jobAfter) { t.Fatal("change outside outer Job ownerReferences") }
	write := func(name string, value any) {
		body, err := json.MarshalIndent(value, "", "  "); if err != nil { t.Fatal(err) }
		file, err := os.OpenFile(filepath.Join(output, name), os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
		if err != nil { t.Fatal(err) }
		if _, err := file.Write(body); err != nil { file.Close(); t.Fatal(err) }
		if err := file.Close(); err != nil { t.Fatal(err) }
	}
	write("canonical-app.json", app)
	write("canonical-job.json", &job)
	write("canonical-podtemplate.json", job.Spec.Template)
	write("anchored-job.json", anchored)
	write("synthetic-secrets.json", []*corev1.Secret{envSecret, fileSecret})
	write("export-source.json", map[string]any{"scope": "fake-client current reconcilePreDeploy export, not a live Job",
		"input": input, "source_hashes": actual, "command_sha256": fmt.Sprintf("%x", sha256.Sum256(command)),
		"podtemplate_sha256": fmt.Sprintf("%x", sha256.Sum256(podBefore)), "podtemplate_unchanged": true,
		"only_outer_job_ownerReferences_changed": true, "halt": halt, "result": result,
		"image_revision_cache_scope": "explicit fake-client input; no registry request or independent OCIlabel claim"})
}
