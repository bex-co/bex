"""Private portable export of already-completed actual V11 evidence. No verification jobs.
Only local regular-file copies/hashes/gzip integrity and read-only Git source reads.
"""
import datetime,gzip,hashlib,importlib.util,json,os,re,shutil,stat,subprocess,threading,time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/tianpan/projects/bex7')
RUN=Path('/private/tmp/bex-w8-common-actual-review-run-20261101-qq32k8wf')
CASE=RUN/'evidence/native-common-bookworm-99cdc5c5a5b53629e2a98963d43d373511a91c1f'
RESOURCE=Path('/private/tmp/bex-w8-common-v11-resource-source-20261101-ipmv7y8i/source')
AUDIT=Path('/private/tmp/bex-w8-common-actual-result-independent-20261101-c40xkbwt')
PUB=Path('/private/tmp/bex-w8-common-publication-gate-20261101-jam14h2w/job.stdout')
VERIFIER='99cdc5c5a5b53629e2a98963d43d373511a91c1f'
PREFIX=Path('.pm/w8/m91/evidence/common-artifact-review-20261101')
STAGE=ROOT/'staging';OUT=STAGE/PREFIX
CAP=96<<20;SOURCE_CAP=2<<20;FLOOR=(1<<30)+(128<<20)
CONTROL_SHA='8ae50548300ce79a06109e8b7e49dc1d19cf80ce'  # Explicit local control, not CI.

def require(value,message):
    if not value:raise ValueError(message)
def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for body in iter(lambda:stream.read(1<<20),b''):h.update(body)
    return h.hexdigest()
def identity(path):return {'sha256':digest(path),'bytes':Path(path).stat().st_size}
def regular(path):
    path=Path(path);require(path.is_file() and not path.is_symlink() and stat.S_ISREG(path.stat().st_mode),'regular input required:'+str(path))
    require(all(not p.is_symlink() for p in path.parents),'symlink ancestor refused:'+str(path));return path
def dump(path,value):
    path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def descriptor(path):return {'path':str(path.relative_to(STAGE)),**identity(path)}
def git(*args):
    p=subprocess.run(['git',*args],cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
    require(p.returncode==0,'read-only Git failed');return p.stdout

def main():
    os.umask(0o077)
    require(not (REPO/PREFIX).exists(),'Root-owned final path already exists')
    require(not STAGE.exists(),'new private stage required')
    module_path=REPO/'.github/scripts/native-common-qualify.py';helper_hash=digest(module_path)
    spec=importlib.util.spec_from_file_location('local_actual_image_validator',module_path);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    review=json.loads(regular(CASE/'receipt.json').read_bytes());outer=json.loads(regular(RUN/'RESULT.json').read_bytes())
    require(outer['exit']==0 and outer['stop'] is None and outer['candidate_approved'] is True and outer['source_unchanged'] is True and outer['own_group_absent'] is True,'actual outer result not complete')
    require(digest(CASE/'receipt.json')=='f3cccfadddf2e5632de24d44fe6f43607d8964dd3c1dc98d5bf72457f7c442d2','actual receipt changed')
    expected_gz={row[key]:row[key+'_sha256'] for row in review['signed_payloads'] for key in ('full_bundle_gzip','full_predicate_gzip')}
    raw_bundles={row['path']:row for row in review['signed_payloads']}
    inputs={};git_bodies={};source_modes={}
    for path in sorted(helper.IMAGE_INPUT_PATHS):
        source=regular(REPO/path)
        tree=git('ls-tree',VERIFIER,'--',path).decode().strip().split(None,3)
        require(len(tree)==4 and tree[1]=='blob' and tree[0] in ('100644','100755'),'regular actual verifier Git source required')
        raw=git('show',VERIFIER+':'+path)
        observed={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'mode':tree[0],'type':'regular'}
        require(observed=={k:v for k,v in helper.file_identity(source).items() if k in observed},'image-critical current/verifier mismatch:'+path)
        inputs[path]=observed;git_bodies[path]=raw;source_modes[path]=0o755 if tree[0]=='100755' else 0o644
    require(len(inputs)==33,'exact33 image-critical inputs required')
    # Frozen exact regular set; public trust caches are evidence, not layer caches.
    case_files=[]
    for path in sorted(CASE.rglob('*')):
        require(not path.is_symlink(),'case symlink refused')
        if path.is_file():
            regular(path)
            if str(path) not in raw_bundles:case_files.append(path)
    extras={RUN/name:'outer/'+name for name in ['run.py','RESULT.json','SCOPE.json','ENTRY-PREFLIGHT.json','PROCESS.json','EXECUTION.json','review.log']}
    extras.update({PUB:'publication/job.json',RESOURCE/'common-v11-adapter.py':'tools/common-v11-adapter.py',RESOURCE/'PLAN.json':'tools/PLAN.json',RESOURCE/'retained/loopx-w8-verify-native-artifact.py':'support/loopx-w8-verify-native-artifact.py'})
    audit_manifest=json.loads(regular(AUDIT/'MANIFEST.json').read_bytes())
    for name,want in audit_manifest.items():
        path=regular(AUDIT/name);require(identity(path)==want,'quiescent actual independent audit changed');extras[path]='independent-review/'+name
    extras[AUDIT/'MANIFEST.json']='independent-review/MANIFEST.json'
    projected=sum(p.stat().st_size for p in case_files)+sum(regular(p).stat().st_size for p in extras)+2*sum(len(b) for b in git_bodies.values())+2*1024*1024
    require(projected<CAP,'projected export exceeds96MiB')
    require(shutil.disk_usage(ROOT).free>=FLOOR+projected,'export does not fit physical reserve')
    dump(ROOT/'COPY-PLAN.json',{'case_regular_files':len(case_files),'case_copy_bytes':sum(p.stat().st_size for p in case_files),'omitted_raw_bundle_bytes':sum(row['bundle_bytes'] for row in raw_bundles.values()),'existing_gzip_files_copied_as_is':len(expected_gz),'source_context_files':33,'verifier_source_files':33,'projected_total_with2MiB_margin':projected,'cap':CAP,'physical_floor_margin':FLOOR,'exclude':['five raw bundle bodies linked losslessly to existinggzs','layer/blob caches','ROOT tmp','anonymous Docker config','credential/config/env/kube files','Cosign executable body (pinned hash retained in exact originalEXECUTION)']})
    STAGE.mkdir(mode=0o700);OUT.mkdir(mode=0o700,parents=True)
    samples=[];errors=[];done=threading.Event()
    def guard():
        while not done.is_set():
            total=sum(p.stat().st_size for p in STAGE.rglob('*') if p.is_file());free=shutil.disk_usage(ROOT).free
            samples.append({'at':time.time(),'staging_bytes':total,'free':free})
            if total>CAP or free<FLOOR:errors.append(samples[-1]);return
            done.wait(1)
    watcher=threading.Thread(target=guard);watcher.start()
    files={};raw_custody={}
    def check():require(not errors and shutil.disk_usage(ROOT).free>=FLOOR,'export physical/staging guard stopped')
    def copy(source,relative):
        check();source=regular(source);target=OUT/relative;target.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        require(not target.exists(),'duplicate export destination')
        shutil.copyfile(source,target);require(identity(source)==identity(target),'byte-exact copy differs')
        target.chmod(0o600);d=descriptor(target);files[str(source)]=d
        raw_custody[str(source)]={'raw_sha256':d['sha256'],'raw_bytes':d['bytes'],'representation':'byte-exact-copy','retained':d}
        return d
    try:
        for source in case_files:
            if str(source) in expected_gz:require(digest(source)==expected_gz[str(source)],'recorded existinggzip SHA differs')
            copy(source,'actual/'+str(source.relative_to(CASE)))
        for source,relative in extras.items():copy(source,relative)
        # Stream only for integrity linkage; do not materialize189MiB raw bodies.
        for row in review['signed_payloads']:
            for key,rawsha,rawsize in [('full_bundle_gzip',row['bundle_digest'].removeprefix('sha256:'),row['bundle_bytes']),
                                      ('full_predicate_gzip',row['decoded_predicate_sorted_json_sha256'],row['decoded_predicate_sorted_json_bytes'])]:
                original=regular(Path(row[key]));h=hashlib.sha256();count=0
                with gzip.open(original,'rb') as stream:
                    for body in iter(lambda:stream.read(1<<20),b''):
                        count+=len(body);require(count<=rawsize,'existinggzip raw exceeds recorded size');h.update(body)
                require(count==rawsize and h.hexdigest()==rawsha,'existinggzip fullraw SHA/size linkage differs')
                raw_key=row['path'] if key=='full_bundle_gzip' else 'decoded-predicate:'+row['full_predicate_gzip']
                raw_custody[raw_key]={'raw_sha256':rawsha,'raw_bytes':rawsize,'representation':'original-existing-gzip-no-recompression',
                    'retained':files[str(original)],'uncompressed_stream_SHA_size_rechecked':True}
        # Alias original executed paths to exact retained bytes. Never relabel support.
        for original,want in review['evidence_tool_sha256'].items():
            if original in files:require(files[original]['sha256']==want,'actual executed tool changed');continue
            retained=CASE/'executed-tools'/Path(original).name
            require(str(retained) in files and files[str(retained)]['sha256']==want,'executed tool missing portable raw custody')
            files[original]=files[str(retained)]
        support_original=str(RESOURCE/'retained/loopx-w8-verify-native-artifact.py')
        require(files[support_original]['sha256']==helper.V11_SUPPORT_INPUTS['loopx-w8-verify-native-artifact.py'],'supportcf5932 differs')
        image_keys={}
        for path,body in git_bodies.items():
            check();key='git:'+VERIFIER+':'+path;target=OUT/'verifier-source'/path;target.parent.mkdir(mode=0o700,parents=True,exist_ok=True);target.write_bytes(body);target.chmod(source_modes[path])
            files[key]=descriptor(target);image_keys[path]=key
            current=STAGE/path;current.parent.mkdir(mode=0o700,parents=True,exist_ok=True);shutil.copyfile(regular(REPO/path),current);current.chmod(source_modes[path])
            require(identity(current)=={'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()},'current33 context body changed')
            raw_custody[key]={'raw_sha256':inputs[path]['sha256'],'raw_bytes':inputs[path]['bytes'],'representation':'actual-local-Git-blob',
                'source':VERIFIER,'path':path,'git_mode':inputs[path]['mode'],'retained':files[key]}
        image_manifest=OUT/'IMAGE-INPUTS.json';dump(image_manifest,{'source':VERIFIER,'files':inputs});image_desc=descriptor(image_manifest)
        files['export:IMAGE-INPUTS.json']=image_desc
        custody_path=OUT/'CUSTODY.json';dump(custody_path,{'files':files,'support_inputs':{'loopx-w8-verify-native-artifact.py':support_original},'image_inputs':image_keys})
        pub=json.loads(PUB.read_bytes());actual_head=git('rev-parse','HEAD').decode().strip()
        candidate={'schema':helper.CANDIDATE_SCHEMA,'candidate':{'ref':review['ref'],'base':review['official_base'],'producer':VERIFIER,'verification':VERIFIER,
            'publication':{'run_id':pub['run_id'],'run_attempt':pub['run_attempt'],'job_id':pub['id'],'metadata':files[str(PUB)]},
            'platforms':{arch:{key:review['platforms'][arch][key] for key in ('manifest_digest','config_digest')} for arch in ('amd64','arm64')},
            'approval':{'receipt':files[str(CASE/'receipt.json')],'custody':descriptor(custody_path),'plan':files[str(RESOURCE/'PLAN.json')],'inputs':image_desc},'source':None,'utilities':None}}
        dump(STAGE/helper.CANDIDATE_PATH,candidate)
        dump(OUT/'RAW-CUSTODY.json',{'schema':'bex.native-common-export-raw-custody/v1','files':raw_custody,
            'omitted_raw_bundles':'All5 bodies complete via originalexistinggzip exactrawSHA/size links; no data omitted/reformatted/doublegzip.','excluded_not_read':['anonymous Dockerconfig','temp','layer/blob caches','credentials/.env/kubeconfigs']})
        dump(OUT/'EXPORT.json',{'schema':'bex.native-common-image-only-export/v1','actual_ref':review['ref'],'actual_producer':VERIFIER,'actual_verifier':VERIFIER,
            'actual_review_generator':review['producer_verification_provenance']['generator_sha'],'repository_head_at_export':actual_head,
            'local_control_GITHUB_SHA':CONTROL_SHA,'source_baseline':None,'utilities':None,'target_evidence':str(PREFIX),'record_path':helper.CANDIDATE_PATH,
            'actual_outer_result':files[str(RUN/'RESULT.json')],'actual_independent_audit':str(AUDIT),'reviewed_at':review['reviewed_at'],
            'full_5_signed_reports_retained':True,'both_platforms':True,'all_41_blob_bytes_hashed':review['anonymous_pull'],
            'trivy_summaries_unfiltered':review['trivy_summaries_by_architecture'],'findings_policy':'Complete original Trivy vulnerability reports and counts retained; no zero-findings or generated/runtime/utility/adoption/hosted claim.',
            'apply_only':[str(PREFIX),helper.CANDIDATE_PATH],'private_only_context33':'Staging33currentfiles only for local image-critical validator; do not apply them as changes.',
            'scope':'Export of completed actual image approval; no crypto/network/CI/Go/Docker/QA/production write. Source/utility approval staysnull.'})
        previous=os.environ.get('GITHUB_SHA');os.environ['GITHUB_SHA']=CONTROL_SHA
        try:
            valid=helper.validate_image_candidate(root=STAGE)
            try:helper.validate_test_candidate(root=STAGE)
            except ValueError as error:full_error=str(error)
            else:raise ValueError('full family validator incorrectly accepted nullsource/utilities')
        finally:
            if previous is None:os.environ.pop('GITHUB_SHA',None)
            else:os.environ['GITHUB_SHA']=previous
        require(full_error=='family reuse requires a complete utility baseline source','fullfamily rejected at unexpected gate')
        require(digest(module_path)==helper_hash,'applied current validator source changed')
        dump(OUT/'LOCAL-VALIDATION.json',{'image_candidate':'PASS','ref':valid['ref'],'baseline_status':valid['baseline_status'],
            'full_family':'EXPECTED_REFUSAL','full_family_error':full_error,'source':candidate['candidate']['source'],'utilities':candidate['candidate']['utilities'],
            'validator_source':str(module_path),'validator_sha256':helper_hash,'controlled_GITHUB_SHA':CONTROL_SHA,'repository_HEAD':actual_head,
            'command':'import CURRENT .github/scripts/native-common-qualify.py; validate_image_candidate(root=STAGING); validate_test_candidate(root=STAGING) expects missing source refusal',
            'not_CI':'Localvalidation only; GITHUB_SHA is explicit task control, not a GitHub run/utility/source approval.'})
        check()
    finally:
        done.set();watcher.join(2)
        dump(ROOT/'CAPACITY.json',{'cap':CAP,'source_cap':SOURCE_CAP,'floor_margin':FLOOR,'interval_seconds':1,'samples':samples,'errors':errors,'kernelquota_claim':False})
    require(not errors,'export watcher stopped')
    dump(OUT/'MANIFEST.json',{str(path.relative_to(OUT)):identity(path) for path in sorted(OUT.rglob('*')) if path.is_file() and path!=OUT/'MANIFEST.json'})
    dump(ROOT/'ASSEMBLY-RESULT.json',{'stage':str(STAGE),'evidence':str(OUT),'evidence_bytes':sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file()),'stage_bytes':sum(p.stat().st_size for p in STAGE.rglob('*') if p.is_file()),'image_validation':'PASS','fullfamily':'EXPECTED_REFUSAL','record':identity(STAGE/helper.CANDIDATE_PATH)})
    print(json.dumps(json.loads((ROOT/'ASSEMBLY-RESULT.json').read_bytes())))

if __name__=='__main__':main()
