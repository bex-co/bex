"""In-place frozen export checks; read-only Git, no crypto/network/resources."""
from pathlib import Path
import collections,gzip,hashlib,importlib.util,json,os,re,stat,subprocess,sys
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;ROOT=Path('/private/tmp/bex-w8-common-artifact-export-20261101-048lr4rd');STAGE=ROOT/'staging';REPO=Path('/Users/tianpan/projects/bex7');EVID=Path('.pm/w8/m91/evidence/common-artifact-review-20261101');E=STAGE/EVID
MAX=256*1024*1024

def identity(path):
 digest=hashlib.sha256();size=0
 with path.open('rb') as stream:
  for b in iter(lambda:stream.read(1024*1024),b''):size+=len(b);digest.update(b)
 return {'bytes':size,'sha256':digest.hexdigest()}
def obj(path):return json.loads(path.read_text())
def regular(root,n):
 relative=Path(n);assert not relative.is_absolute() and '..' not in relative.parts
 p=root
 for part in relative.parts:p/=part;assert not p.is_symlink()
 assert stat.S_ISREG(p.stat().st_mode);return p
assert identity(ROOT/'MANIFEST.json')['sha256']=='00b4bc7eaa279ff6cfbf3ec39a5a832f88c7c012340e3af7d4e20e0b2afa2280'
assert identity(ROOT/'RECEIPT.json')['sha256']=='26033e1bfe8cfdd43a33b9d3c918f76cf527a093925b6618d42fee045426fd83'
full=obj(ROOT/'MANIFEST.json');assert len(full)==325
for n,x in full.items():assert identity(regular(ROOT,n))==x,n
actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()};assert actual-set(full)=={'MANIFEST.json','RECEIPT.json'}
em=obj(E/'MANIFEST.json');assert identity(E/'MANIFEST.json')['sha256']=='fa114cda2d7f2241e05f4cf2acf10436266865a1a98b873239b37ab022162879'
for n,x in em.items():assert identity(regular(E,n))==x,n
assert {str(p.relative_to(E)) for p in E.rglob('*') if p.is_file()}-set(em)=={'MANIFEST.json'}
assert sum(p.stat().st_size for p in E.rglob('*') if p.is_file())==47049858
record=obj(STAGE/'.github/native-common-test-candidate.json');assert identity(STAGE/'.github/native-common-test-candidate.json')['sha256']=='eedf83744128a6945b6530f546fdc6e36e62c3fe85258f6654891ab56baa8ea8'
c=record['candidate'];assert c['source'] is None and c['utilities'] is None
ref='ghcr.io/bex-co/bex-cnb-run@sha256:56c58abb41abd6becfa1810834c6cba46b742703e2beffdb3a88387772b3b986';producer='99cdc5c5a5b53629e2a98963d43d373511a91c1f'
assert c['ref']==ref and c['producer']==c['verification']==producer
cust=obj(E/'CUSTODY.json');raw=obj(E/'RAW-CUSTODY.json');assert len(raw['files'])==289
for key,desc in cust['files'].items():assert identity(regular(STAGE,desc['path']))=={k:desc[k] for k in ('sha256','bytes')},key
representations=collections.Counter();compressed=[];raw_rows={}
for key,row in raw['files'].items():
 desc=row['retained'];assert identity(regular(STAGE,desc['path']))=={k:desc[k] for k in ('sha256','bytes')}
 representations[row['representation']]+=1
 if row['representation']=='byte-exact-copy':
  assert (row['raw_sha256'],row['raw_bytes'])==(desc['sha256'],desc['bytes'])
  # Read only the export-allowlisted source proof bodies, no private config/cache.
  source=Path(key);assert source.is_absolute() and '/private/tmp/'==str(source)[:13]
  assert source.is_file() and not source.is_symlink();assert identity(source)=={k:desc[k] for k in ('sha256','bytes')}
 elif row['representation']=='original-existing-gzip-no-recompression':
  assert row['uncompressed_stream_SHA_size_rechecked'] is True
  original=Path(key.removeprefix('decoded-predicate:'))
  if not key.startswith('decoded-predicate:'):original=Path(key+'.gz')
  assert identity(original)=={k:desc[k] for k in ('sha256','bytes')},key
  digest=hashlib.sha256();size=0
  with gzip.open(regular(STAGE,desc['path']),'rb') as stream:
   while True:
    b=stream.read(1024*1024)
    if not b:break
    size+=len(b);assert size<=MAX;digest.update(b)
  assert (size,digest.hexdigest())==(row['raw_bytes'],row['raw_sha256']),key
  compressed.append({'original':key,'retained':desc,'uncompressed_sha256':digest.hexdigest(),'uncompressed_bytes':size})
 else:assert row['representation']=='actual-local-Git-blob'
 raw_rows[key]=row
assert representations=={'byte-exact-copy':246,'actual-local-Git-blob':33,'original-existing-gzip-no-recompression':10}
review=obj(E/'actual/receipt.json');assert len(review['signed_payloads'])==5
pairs={(x['kind'],x['architecture']) for x in review['signed_payloads']};assert pairs=={('image-signature',None),('sbom','amd64'),('sbom','arm64'),('vulnerability','amd64'),('vulnerability','arm64')}
for row in review['signed_payloads']:
 for key in ('full_bundle_gzip','full_predicate_gzip'):
  desc=cust['files'][row[key]];assert desc['sha256']==row[key+'_sha256']
  path=Path(row[key]);assert identity(path)=={k:desc[k] for k in ('sha256','bytes')}
 bundle=raw_rows[row['path']];pred=raw_rows['decoded-predicate:'+row['full_predicate_gzip']]
 assert (bundle['raw_sha256'],bundle['raw_bytes'])==(row['bundle_digest'].split(':')[1],row['bundle_bytes'])
 assert (pred['raw_sha256'],pred['raw_bytes'])==(row['decoded_predicate_sorted_json_sha256'],row['decoded_predicate_sorted_json_bytes'])
# Actual local Git and current filesystem identities, never importing source.
inputs=obj(E/'IMAGE-INPUTS.json');assert inputs['source']==producer and len(inputs['files'])==33
cmd=['git','-C',str(REPO),'ls-tree','-r',producer,'--',*sorted(inputs['files'])]
tree=subprocess.run(cmd,check=True,capture_output=True).stdout.decode();gitfiles={}
for line in tree.splitlines():
 mode,kind,tail=line.split(' ',2);blob,path=tail.split('\t',1);assert kind=='blob';gitfiles[path]=(mode,blob)
assert set(gitfiles)==set(inputs['files'])
for n,want in inputs['files'].items():
 mode,blob=gitfiles[n];body=subprocess.run(['git','-C',str(REPO),'cat-file','blob',blob],check=True,capture_output=True).stdout
 assert want=={'sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body),'mode':mode,'type':'regular'}
 actualpath=regular(REPO,n);assert identity(actualpath)=={k:want[k] for k in ('sha256','bytes')};assert ('100755' if actualpath.stat().st_mode & 0o111 else '100644')==mode
 staged=regular(STAGE,n);assert identity(staged)=={k:want[k] for k in ('sha256','bytes')}
 retained=cust['files'][cust['image_inputs'][n]];assert retained['path']==str(EVID/'verifier-source'/n)
 assert identity(regular(STAGE,retained['path']))=={k:want[k] for k in ('sha256','bytes')}
 rawrow=raw_rows['git:'+producer+':'+n];assert (rawrow['source'],rawrow['path'],rawrow['git_mode'])==(producer,n,mode)
# Same production helper as shipped1c06; no initializers or resource functions run.
helper=REPO/'.github/scripts/native-common-qualify.py';assert identity(helper)['sha256']=='bccfd53a1d0d683671baeb7a786f42e1942a1c11ceca0f9b2163cdeb50e24e2d'
head=subprocess.run(['git','-C',str(REPO),'rev-parse','HEAD'],capture_output=True,check=True,text=True).stdout.strip();os.environ['GITHUB_SHA']=head
spec=importlib.util.spec_from_file_location('export_review_qualification',helper);q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
assert set(inputs['files'])==q.IMAGE_INPUT_PATHS
with patch.object(q.subprocess,'run',side_effect=AssertionError('NO external/resource command')),patch.object(q,'dump',side_effect=AssertionError('NO source/evidence writes')):
 image=q.validate_image_candidate(STAGE);assert image['ref']==ref and image['baseline_status']=='image-only-requalification'
 try:q.validate_test_candidate(STAGE)
 except ValueError as error:
  reason=str(error);assert reason=='family reuse requires a complete utility baseline source'
 else:raise AssertionError('null baseline family accepted')
assert image['generator_source']==head and image['producer']==image['verification']==producer
# Inherited approval validator verifies original job identity/gates/tool/plan/fullreport mapping.
job=obj(STAGE/c['publication']['metadata']['path']);assert job['id']==124689058047 and job['run_id']==41249441151 and job['head_sha']==producer and job['conclusion']=='success'
provenance=review['producer_verification_provenance'];assert provenance['producer_sha']==provenance['verification_sha']==producer and provenance['generator_sha']=='8ae50548300ce79a06109e8b7e49dc1d19cf80ce'
assert review['anonymous_pull']['unique_blob_count']==41 and len(review['anonymous_pull']['blob_receipts'])==41
assert len({x['digest'] for x in review['anonymous_pull']['blob_receipts']})==41
assert review['anonymous_pull']['all_unique_config_and_layer_bytes_fully_hashed'] is True
out={'full_manifest_files':len(full),'full_manifest_payload_bytes':sum(x['bytes'] for x in full.values()),'evidence_files':len(em)+1,'evidence_bytes':47049858,'custody_files':len(cust['files']),'raw_custody_rows':len(raw['files']),'representations':dict(representations),'gzip_original_identity_and_stream_checks':compressed,'image_critical_git_source':producer,'image_critical_paths':33,'current_files_and_staging_and_retained_and_original_Git_bytes_mode_exact':True,'publisher':{'run_id':job['run_id'],'job_id':job['id'],'source':job['head_sha'],'name':job['name'],'conclusion':job['conclusion']},'ref':ref,'current_helper':identity(helper),'validation':{'image':'PASS','baseline_status':image['baseline_status'],'generator_source':head,'producer':image['producer'],'verification':image['verification'],'family':'EXPECTED_REFUSAL','reason':reason,'source':None,'utilities':None,'resource_commands':0,'writes':0},'actual_review_provenance':provenance,'retained_full_blobs':41,'strict_proofs':'Full retained actual V11 evidence and original independent c40audit preserved; no fresh cryptographic verification or image/layer download performed.'}
(HERE/'RESULT.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='gzip_original_identity_and_stream_checks'},indent=2))
