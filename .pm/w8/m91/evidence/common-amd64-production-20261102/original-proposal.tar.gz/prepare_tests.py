import ast
from pathlib import Path
R=Path(__file__).resolve().parent;S=R/'source'
p=S/'.github/scripts/native-common-qualify.py';t=p.read_text().replace('{"amd64"} <= set(c["utilities"]) <= {"amd64", "arm64"}', 'set(c["utilities"]) == {"amd64"}');p.write_text(t)
p=S/'.github/scripts/test_native_oci_common_qualification.py';t=p.read_text()
# Keep retained ARM64 full-report parser controls intact; only full-job init/routing
# controls change to production AMD64. Existing historical V11 remains two-arch.
t=t.replace('TARGET_PLATFORM="linux/arm64"','TARGET_PLATFORM="linux/amd64"').replace("TARGET_PLATFORM='linux/arm64'","TARGET_PLATFORM='linux/amd64'")
t=t.replace('arch: [amd64, arm64]','arch: [amd64]')
t=t.replace('test_workflow_preserves_original_job_and_requires_both_architectures_before_pilot','test_workflow_preserves_complete_amd64_job_before_pilot')
t=t.replace('self.assertEqual(set(jobs), {"plan", "publish", "qualify", "qualify-profile"})','self.assertEqual(set(jobs), {"plan", "publish", "qualify", "qualify-profile", "common-arm64-local"})')
t=t.replace('enumerate(("amd64", "arm64"))','enumerate(("amd64",))')
t=t.replace('utility = self.candidate["utilities"].pop("arm64"); self.save()','utility = self.candidate["utilities"].pop("amd64"); self.save()').replace('self.candidate["utilities"]["arm64"] = utility','self.candidate["utilities"]["amd64"] = utility')
t=t.replace("self.candidate['utilities'] = {'amd64': original['amd64']}", "self.candidate['utilities'] = {'arm64': self.utility('arm64', 30)}")
t=t.replace('both original utility architectures','complete original AMD64 utility artifact')
# New methods run the real filesystem validator with only the closed transition
# constant rebound to small synthetic identities, never a stubbed success.
extra=r'''
    def d3_transition_fixture(self):
        path = '.github/workflows/native-base-image.yml'
        recorded = qualification.image_source_inventory(self.root)
        self.write(path, b'CONTROL ONLY exact reviewed D3 publisher policy\n')
        current = qualification.image_source_inventory(self.root)
        transition = dict(ref=self.ref, producer=self.source, verification=self.source,
                          approval_inputs_sha256=self.candidate['approval']['inputs']['sha256'],
                          path=path, before=recorded[path], after=current[path])
        patched = patch.object(qualification, 'D3_LEGACY_0941', transition)
        patched.start()
        self.addCleanup(patched.stop)
        return path

    def test_d3_closed_policy_transition_allows_image_only_not_stale_family(self):
        self.d3_transition_fixture()
        self.assertEqual(qualification.validate_image_candidate(self.root)['ref'], self.ref)
        with self.assertRaisesRegex(ValueError, 'stale qualification source'):
            qualification.validate_test_candidate(self.root)

    def test_d3_transition_rejects_unreviewed_policy_bytes_mode_and_other_input(self):
        path = self.d3_transition_fixture()
        for relative, value, mode in ((path, b'unreviewed follow-on policy', 0o644),
                                      (path, None, 0o755),
                                      ('deploy/native-base/install.sh', b'changed image recipe', 0o644)):
            with self.subTest(path=relative, mode=mode):
                actual = self.root / relative
                before, permissions = actual.read_bytes(), actual.stat().st_mode & 0o777
                if value is not None:
                    actual.write_bytes(value)
                actual.chmod(mode)
                with self.assertRaisesRegex(ValueError, 'image-critical inputs'):
                    qualification.validate_image_candidate(self.root)
                actual.write_bytes(before); actual.chmod(permissions)

    def test_d3_transition_rejects_another_candidate_or_verifier_input_manifest(self):
        self.d3_transition_fixture()
        self.candidate['ref'] = 'ghcr.io/bex-co/bex-cnb-run@sha256:' + 'f' * 64
        self.save()
        with self.assertRaisesRegex(ValueError, 'image-critical inputs'):
            qualification.validate_image_candidate(self.root)
        self.candidate['ref'] = self.ref
        self.rewrite_evidence(self.candidate['approval']['inputs'], lambda x: x.update(source='f' * 40))
        with self.assertRaisesRegex(ValueError, 'image-critical inputs'):
            qualification.validate_image_candidate(self.root)

    def test_d3_migration_keeps_all_historical_signed_roles_and_subject_checks(self):
        self.d3_transition_fixture()
        descriptor = self.candidate['approval']['receipt']
        before, identity = (self.root / descriptor['path']).read_bytes(), dict(descriptor)
        for mutate in (lambda x: x.update(ref='ghcr.io/bex-co/bex-cnb-run@sha256:' + 'f' * 64),
                       lambda x: x.update(signed_payloads=[row for row in x['signed_payloads']
                                                         if (row['kind'], row['architecture']) != ('sbom', 'arm64')]),
                       lambda x: x.update(signed_payloads=[row for row in x['signed_payloads']
                                                         if (row['kind'], row['architecture']) != ('vulnerability', 'amd64')])):
            self.rewrite_evidence(descriptor, mutate)
            with self.assertRaises(ValueError):
                qualification.validate_image_candidate(self.root)
            (self.root / descriptor['path']).write_bytes(before); descriptor.update(identity); self.save()

    def test_d3_amd64_only_baseline_passes_and_arm64_cannot_start_full_job(self):
        self.assertEqual(set(self.candidate['utilities']), {'amd64'})
        self.assertEqual(qualification.validate_test_candidate(self.root)['baseline_status'], 'current-complete')
        env = dict(QUALIFICATION_PROFILE='utilities', QUALIFICATION_CASE='all', QUALIFICATION_SOURCE='fresh',
                   COMMON_IMAGE=self.ref, PRODUCER_SHA='b' * 40, VERIFICATION_SHA='b' * 40,
                   TARGET_PLATFORM='linux/arm64')
        with patch.dict(os.environ, env), patch.object(qualification.tempfile, 'mkdtemp', side_effect=AssertionError('no resources')):
            with self.assertRaisesRegex(ValueError, 'fully gated immutable common image'):
                qualification.initialize()

    def test_d3_local_unsigned_arm_reference_is_not_a_production_approval(self):
        self.candidate['platforms'] = {'arm64': self.candidate['platforms']['arm64']}
        self.save()
        with self.assertRaisesRegex(ValueError, 'both actual platforms'):
            qualification.validate_image_candidate(self.root)
'''
anchor='\n\nif __name__ == "__main__":';assert t.count(anchor)==1;t=t.replace(anchor,'\n'+extra+anchor)
# The exact transition is an actual source pin, not a test-only record accepted by production.
# Additional workflow controls inspect actual job dependency boundaries and the smoke source.
extra2=r'''
    def test_d3_local_arm_smoke_is_unsigned_and_not_a_production_dependency(self):
        jobs = self.jobs()
        local = jobs['common-arm64-local']
        self.assertIn('needs: plan\n', local)
        self.assertIn('continue-on-error: true', local)
        self.assertIn("needs.plan.outputs.source == 'fresh'", local)
        self.assertIn('runs-on: [self-hosted, Linux, ARM64, bex-build]', local)
        self.assertIn('platforms: linux/arm64', local)
        self.assertEqual(local.count('provenance: false'), 2)
        self.assertEqual(local.count('sbom: false'), 2)
        for forbidden in ('cosign', 'trivy', 'syft', 'QUALIFICATION_SELECTOR', 'nativeCommonBase'):
            self.assertNotIn(forbidden, local)
        for name in ('publish', 'qualify', 'qualify-profile'):
            self.assertNotIn('common-arm64-local', jobs[name])
        self.assertLess(local.index('check common ARM64 startup'), local.index('expose only the lightly checked'))
        self.assertIn('if: always()', local)
        smoke = (ROOT / 'deploy/native-common/check-local.Dockerfile').read_text()
        self.assertIn('RUN --network=none', smoke)
        self.assertIn('= aarch64', smoke)
        self.assertIn('VERSION_CODENAME=bookworm', smoke)
        self.assertNotIn('check-tools.py', smoke)
'''
# Insert within ProfileRoutingControls before the following class.
anchor='\n\nclass ReviewedCandidateControls';assert t.count(anchor)==1;t=t.replace(anchor,'\n'+extra2+anchor)
p.write_text(t);ast.parse(t)
p=S/'.github/scripts/test_native_oci_workflow.py';t=p.read_text()
t=t.replace("predicate=='native-arm64.trivy.json'", "predicate=='native-amd64.trivy.json'")
t=t.replace('test_happy_both_architectures_five_proofs_and_two_tags','test_happy_amd64_three_proofs_and_two_tags')
t=t.replace('self.assert_counts(events, (1, 1), (1, 1), 4, 2)','self.assert_counts(events, (1, 0), (1, 0), 2, 2)')
t=t.replace('), 5)', '), 3)')
t=t.replace('["spdxjson", TRIVY_TYPE] * 2','["spdxjson", TRIVY_TYPE]')
# One per-arch verification in happy case; keep run_case sentinels for both arches.
start=t.index('    def test_happy_amd64_three_proofs_and_two_tags');end=t.index('    def test_stage_amd_deadline',start)
part=t[start:end].replace('for arch in ("amd64", "arm64"):', 'for arch in ("amd64",):');t=t[:start]+part+t[end:]
# Replace old ARM-only failure assertions: the same exact fail stubs are inert in D3.
mod=ast.parse(t); cls=next(x for x in mod.body if isinstance(x,ast.ClassDef) and x.name=='PublisherShellControls')
lines=t.splitlines(keepends=True)
for n in reversed(cls.body):
    if isinstance(n,ast.FunctionDef) and n.name in ('test_stage_arm_failure_preserves_amd_proofs_but_never_publishes','test_syft_arm_exhaustion_removes_partial_and_blocks_arm_proofs'):
        del lines[n.lineno-1:n.end_lineno]
t=''.join(lines)
t=t.replace('self.assert_counts(events, (1, 1), (3, 1), 4, 2)','self.assert_counts(events, (1, 0), (3, 0), 2, 2)')
t=t.replace('self.assert_counts(events, (1, 1), (1, 1), 6, 0)','self.assert_counts(events, (1, 0), (1, 0), 4, 0)')
t=t.replace('["native-arm64.trivy.json", REF]', '["native-amd64.trivy.json", REF]')
extra3=r'''
    def test_arm_failure_stubs_are_not_invoked_or_production_gates(self):
        for mode in ('stage_arm_fail', 'syft_arm_fail'):
            with self.subTest(mode=mode):
                process, root, events = self.run_case(mode)
                self.assertEqual(process.returncode, 0, process.stderr)
                self.assert_counts(events, (1, 0), (1, 0), 2, 2)
                self.assertTrue((root / 'native-arm64.spdx.json').is_symlink())
                self.assertFalse(any(row.get('arch') == 'arm64' for row in events))
'''
anchor='\n\nclass PublisherInputControls';assert t.count(anchor)==1;t=t.replace(anchor,'\n'+extra3+anchor)
extra4=r'''
    def test_d3_publisher_targets_only_amd64_and_preserves_complete_amd_gates(self):
        self.assertEqual(WORKFLOW_TEXT.count('platforms: linux/amd64\n'), 2)
        self.assertNotIn('platforms: linux/amd64,linux/arm64', WORKFLOW_TEXT)
        self.assertNotIn('name: scan arm64 candidate', WORKFLOW_TEXT)
        self.assertIn('name: scan amd64 candidate', WORKFLOW_TEXT)
        self.assertIn('for arch in amd64; do', signing_shell())
        self.assertNotIn('steps.recovery.outputs', WORKFLOW_TEXT)
        self.assertNotIn("path = Path('.github/native-base-recovery.json')", WORKFLOW_TEXT)
        self.assertIn('Historical recovery authorizations name multiarch indexes', WORKFLOW_TEXT)
        self.assertIn('runs-on: [self-hosted, Linux, ARM64, bex-build]', WORKFLOW_TEXT)
        self.assertLess(WORKFLOW_TEXT.index('sign and attest the immutable candidate'),
                        WORKFLOW_TEXT.index('expose the fully gated immutable image'))
'''
anchor='\n\nclass NodeBackportInputControls';assert t.count(anchor)==1;t=t.replace(anchor,'\n'+extra4+anchor)
p.write_text(t);ast.parse(t)
print('Prepared proposed host controls; AST syntax inspected only. No proposed test or helper was executed.')
