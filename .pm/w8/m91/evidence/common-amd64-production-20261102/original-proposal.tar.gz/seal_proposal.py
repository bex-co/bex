from pathlib import Path
import ast,datetime,difflib,hashlib,json,os,stat,subprocess
R=Path(__file__).resolve().parent;repo=Path('/Users/tianpan/projects/bex7');S=R/'source'
def digest(raw):return hashlib.sha256(raw).hexdigest()
def write(name,value):(R/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def read_constants(p):
    tree=ast.parse(p.read_text());names=('FACTORY_PATHS','SOURCE_FILES','SOURCE_PACKAGES','IMAGE_POLICY_FILES')
    return {n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in names}
def inventory_paths(c,tracked):
    result=set(c['SOURCE_FILES'])|{'deploy/'+p for p in c['FACTORY_PATHS']}
    result.update(p for p in tracked if p.startswith('lego/operator/internal/build/'))
    for package in c['SOURCE_PACKAGES']:
        prefix='lego/'+package+'/'
        result.update(p for p in tracked if p.startswith(prefix) and p[len(prefix):].endswith('.go') and '/' not in p[len(prefix):])
    return result
tracked=set(subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0'))-{''}
old=read_constants(R/'before/.github/scripts/native-common-qualify.py');new=read_constants(S/'.github/scripts/native-common-qualify.py')
old_paths=inventory_paths(old,tracked);new_paths=inventory_paths(new,tracked)|{'deploy/native-common/check-local.Dockerfile'}
# Tracked-byte inventory only. Known ignored pyc bodies are not read or copied.
rows=[];diffs=[]
for path in sorted(new_paths|old_paths):
    current=repo/path
    before=current.read_bytes() if path in old_paths else None
    after=(S/path).read_bytes() if (S/path).exists() else before
    if before!=after:rows.append({'path':path,'before':None if before is None else {'sha256':digest(before),'bytes':len(before)},'after':{'sha256':digest(after),'bytes':len(after)}})
for p in sorted(S.rglob('*')):
    if not p.is_file():continue
    relative=str(p.relative_to(S));before=R/'before'/relative
    a=before.read_text().splitlines(keepends=True) if before.exists() else []
    diffs.extend(difflib.unified_diff(a,p.read_text().splitlines(keepends=True),fromfile='a/'+relative,tofile='b/'+relative))
(R/'SOURCE.diff').write_text(''.join(diffs))
write('SOURCE-INVENTORY-IMPACT.json',{'scope':'static actual tracked file bytes only; proposed code not executed','before_paths':len(old_paths),'after_paths':len(new_paths),'added':sorted(new_paths-old_paths),'removed':sorted(old_paths-new_paths),'changed':rows,'ignored_pycs':'not read, copied, removed, normalized or waived; existing physical inventory remains conservative','baseline':'existing0b7 source equality cannot satisfy the proposed full source; one fresh complete AMD64 SAME0941 baseline required'})
# Exact old proof source and current/new image-critical manifest comparison.
approval=json.loads((repo/'.pm/w8/m91/evidence/common-current0941-20261101/IMAGE-INPUTS.json').read_text())
imagepaths={'deploy/'+p for p in old['FACTORY_PATHS']}|set(old['IMAGE_POLICY_FILES'])
image_changes=[]
for path in sorted(imagepaths):
    p=repo/path;info=p.lstat();raw=p.read_bytes();observed={'sha256':digest(raw),'bytes':len(raw),'mode':'100755' if info.st_mode&0o111 else '100644','type':'regular'}
    if approval['files'][path]!=observed:image_changes.append({'path':path,'recorded':approval['files'][path],'current':observed})
    if (S/path).exists():
        raw=(S/path).read_bytes();after={'sha256':digest(raw),'bytes':len(raw),'mode':'100644','type':'regular'}
        if approval['files'][path]!=after:
            assert path=='.github/workflows/native-base-image.yml'
# Retain actual producer policy bytes without importing any old helper.
command=['git','show','1feba939b4697894e800ed0abb4f25a0bf415641:.github/workflows/native-base-image.yml']
process=subprocess.run(command,cwd=repo,capture_output=True,check=True)
(R/'producer-native-base-image.yml').write_bytes(process.stdout)
assert digest(process.stdout)==approval['files']['.github/workflows/native-base-image.yml']['sha256']
write('IMAGE-POLICY-IMPACT.json',{'actual_source':approval['source'],'image_inputs':len(imagepaths),'unchanged_other_inputs':len(imagepaths)-1,'current_main_changes_from_actual_review':image_changes,'producer_read':{'argv':command,'exit_code':process.returncode,'stdout_sha256':digest(process.stdout),'stdout_bytes':len(process.stdout),'stderr_sha256':digest(process.stderr)},'transition':'one exact old/new full workflow hash for existing0941 only; no general ignore, normalization, arbitrary policy match, producer rewrite, report projection or weakened crypto'})
proposal={
 'status':'PRIVATE PROPOSAL ONLY: no repository edits, tests, runtime, resources, network, candidate mutation or dispatch',
 'base_commit':'a5f65eec3f2feac90ae44beed39ac57b88e26145',
 'decision_sources':[{'path':'.pm/w8/m91/README.md','lines':[384,394]},{'path':'.pm/w8/m91/t007.md','lines':[21,26]},{'path':'.pm/w1/blocked/m188/README.md','lines':[458,468]}],
 'architecture':{'production':'linux/amd64 only, including all donor lines/companions/fullutilities/fullruntimechecks/Trivy/SBOM/signatures/adoption','local':'common Bookworm only ARM64, unsigned/no SBOM/no full scan/no per-runtime family qualification; separate startup/core-tool job and discovery tag','job_dependencies':'publish,qualify,qualify-profile never need common-arm64-local; local job continue-on-error true and no production ref output; a failure is explicit unproved local status','runners':'existing ARM64 hardware labels unchanged; AMD64 workload may be emulated, no native AMD64 performance claim','programs':'no Go source, original13/28 programs/data/commands, positive9 manifests, versions, runtime maps or production pins changed'},
 'publication':{'amd64':'same factory20/matrix selection/upstream pin; full check.Dockerfile, full Trivy metadata/layers/findings, Syft SPDX, exact cosign flags/Rekor/TSA/signature and attestation ordering/tag gates remain','local_arm64_tag':'native-common-bookworm-arm64-local','local_candidate_tag':'native-common-bookworm-arm64-local-candidate-${github.sha}, never production approval','local_check':'no-cache network=none BuildKit RUN checks actual aarch64+Bookworm, system Python ssl/ffi, private Node and core tool launch/version output; no extension/full transformation or runtime-family claims','local_bounds':'180-minute job operating bound reused from existing full utility job, not measured capacity; normal pinned Buildx action-owned builder cleanup + existing publisher login/logout pattern; no changes to qualifier owner/config cleanup','recovery':'old multiarch recovery authorizations untouched but no longer consumed; D3 publisher fresh-build-only rather than signing ARM members via an old index. Same0941 reviewed-image reuse is a separate explicit candidate route'},
 'legacy0941':{'ref':'ghcr.io/bex-co/bex-cnb-run@sha256:0941c204f87643c2faad308e72acdf584976e67d8fb980a0646c5ab662dcc5d0','producer_verifier':'1feba939b4697894e800ed0abb4f25a0bf415641','proof':'retain original both-platform identities, five signed role pairs, all signed rows/full report/custody/tools/plan/source/publisher steps unchanged','policy_bridge':'D3_LEGACY_0941 pins exact subject+producer+verifier+original input-manifest SHA+old/new workflow SHA/size/mode/type; remaining32 image inputs exact','new_d3_image_limit':'the retained V11 adapter and helper still accept only the actual historical both-platform proof shape. Future fresh AMD64-only image approval needs a separately reviewed D3-capable V11 adapter/pin and actual three-role proof; no fabricated role upgrade or automatic acceptance','baseline':'full captured-source equality unchanged. Current0b7 artifacts stay historical and retained. After final D3 source lands, manual source=reviewed-candidate/profile=utilities on SAME0941 runs only full AMD64; inspect complete actual artifact then update source/utilities with AMD64 only before new family admission','arm_local_historical':'0941 actual original ARM startup/full publisher+utility proof exceeds lightweight scope for unchanged image bytes; no new per-runtime ARM or paired utility gate'},
 'tests':{'executed':False,'inspection':'AST parse only, not imported/executed','proposed':['actual publisher shell AMD64 three signed roles, two tags; AMD stage/Syft/sign/attest failure blockers and full finding retention','ARM failure stubs never invoked as production gates','AMD only matrix/complete original selector/budgets/cleanup/auth unchanged; unsigned local job not in production dependencies','real filesystem image-validator positive exact reviewed policy transition; stale family baseline still rejects','current policy byte/mode, other image input, wrong subject/verifier manifest, missing historical role refuse','AMD-only complete artifact passes; ARM-only utility/unsigned local subject/fullARM init refuse before resources','full preexisting retained SBOM/raw/gzip/ownership/cancellation/branch-table controls continue (historical ARM parser controls preserved)']},
 'apply_order':['Root source review and explicit test authorization','bounded existing Python host suites + actionlint/Actions guard; no image execution for source verification','independent source review; source/helper static closure proof','ship D3 change without changing candidate producer/proof','one genuine manual AMD64 fullutility run on reviewed0941; fullcontentaudit/update through strict validator','AMD64-only minimal affected family replays and proof-backed dated nonimpact evidence; no newly paired dispatches'],
 'limits':['No real new baseline/family/ARM startup/publication/test/crypto result claimed','No new source approval, production adoption, hosted acceptance or replay authority','Old0b7 and original paired records remain unchanged and dated','Fresh common publish may produce another digest; it is not automatically substituted for0941']}
write('PROPOSAL.json',proposal)
# Test/source AST shapes can be read by Root without importing any module.
write('PROPOSED-TESTS.json',{str(p.relative_to(S)):[n.name for c in ast.parse(p.read_text()).body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')] for p in S.rglob('test_*.py')})
source={str(p.relative_to(S)):{'sha256':digest(p.read_bytes()),'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode&0o777)} for p in sorted(S.rglob('*')) if p.is_file()}
write('SOURCE-MANIFEST.json',source)
# Freeze exact source boundary before Root reads it. Source generation scripts are history,
# not required execution inputs and not an authorization to regenerate/change source.
write('RECEIPT.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':proposal['status'],'source_files':len(source),'source_manifest':{'sha256':digest((R/'SOURCE-MANIFEST.json').read_bytes()),'bytes':(R/'SOURCE-MANIFEST.json').stat().st_size},'source_diff':{'sha256':digest((R/'SOURCE.diff').read_bytes()),'bytes':(R/'SOURCE.diff').stat().st_size},'current_repository_preimages_unchanged':all((repo/p).read_bytes()==(R/'before'/p).read_bytes() for p in json.loads((R/'BASE.json').read_text())['paths']),'test_execution':'NOT RUN; await Root approval','new_utility_baseline':'OPEN; current0b7 cannot be relabeled to D3 source'})
manifest={str(p.relative_to(R)):{'sha256':digest(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(R.rglob('*')) if p.is_file() and p.name!='MANIFEST.json'}
write('MANIFEST.json',manifest)
print(json.dumps({'root':str(R),'source_files':len(source),'source_manifest_sha256':digest((R/'SOURCE-MANIFEST.json').read_bytes()),'diff_sha256':digest((R/'SOURCE.diff').read_bytes()),'diff_bytes':(R/'SOURCE.diff').stat().st_size,'receipt_sha256':digest((R/'RECEIPT.json').read_bytes()),'manifest_sha256':digest((R/'MANIFEST.json').read_bytes()),'payload_files':len(manifest),'payload_bytes':sum(x['bytes'] for x in manifest.values()),'source_inventory_before':len(old_paths),'source_inventory_after':len(new_paths)},indent=2))
