import ast, hashlib, json
from pathlib import Path
R=Path(__file__).resolve().parent
S=R/'source'
def edit(path, old, new, count=1):
    p=S/path; text=p.read_text(); assert text.count(old)==count,(path,old[:80],text.count(old),count);p.write_text(text.replace(old,new))
base='.github/workflows/native-base-image.yml'
p=S/base;t=p.read_text()
start=t.index('      - name: select a reviewed recovery artifact when its recipe is unchanged\n')
end=t.index('      - id: build\n',start)
t=t[:start]+'''      # Historical recovery authorizations name multiarch indexes. D3 must not
      # sign their ARM64 content; keep those records as history and build this
      # explicitly requested production artifact afresh. Common was fresh-only.
'''+t[end:]
t=t.replace("        if: steps.recovery.outputs.digest == ''\n",'')
t=t.replace('platforms: linux/amd64,linux/arm64','platforms: linux/amd64')
t=t.replace('          RECOVERED: ${{ steps.recovery.outputs.digest }}\n          PRODUCER: ${{ steps.recovery.outputs.producer }}\n','')
t=t.replace('digest="${RECOVERED:-$BUILT}"','digest="$BUILT"').replace('echo "producer=${PRODUCER:-$GITHUB_SHA}"','echo "producer=$GITHUB_SHA"')
t=t.replace('verify real native tool transformations without network on both architectures','verify real native tool transformations without network on amd64')
start=t.index('      - name: scan arm64 candidate\n');end=t.index('      - uses: sigstore/cosign-installer@',start)
t=t[:start]+t[end:]
t=t.replace('for arch in amd64 arm64; do','for arch in amd64; do')
p.write_text(t)
workflow_digest=hashlib.sha256(p.read_bytes()).hexdigest()
common='.github/workflows/native-common-image.yml'
edit(common,'Single-case measurement after both original utility cohorts','Single AMD64 case after the complete original AMD64 utility cohort')
edit(common,'arch: [amd64, arm64]','arch: [amd64]',2)
# This job is independent of publish/qualify/profile. Failure is visible but
# cannot fail the production result. Its discovery tag moves only after light check.
with (S/common).open('a') as f:f.write('''
  common-arm64-local:
    # D3: one local-development variant, never a runtime-family/production gate.
    needs: plan
    if: github.ref == 'refs/heads/main' && needs.plan.outputs.source == 'fresh'
    continue-on-error: true
    runs-on: [self-hosted, Linux, ARM64, bex-build]
    permissions:
      contents: read
      packages: write
    timeout-minutes: 180
    concurrency:
      group: native-common-arm64-local
      cancel-in-progress: false
    steps:
      - uses: actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1 # v7.0.1
        with:
          persist-credentials: false
      - uses: docker/setup-buildx-action@37fe631027851001ddb9b187196cc803df7f5f0e # v4.3.0
      - name: log in to GHCR with bounded transport retries
        env:
          GHCR_TOKEN: ${{ secrets.GITHUB_TOKEN }}
        run: |
          for attempt in 1 2 3; do
            if printf '%s' "$GHCR_TOKEN" | timeout 60s docker login ghcr.io --username "$GITHUB_ACTOR" --password-stdin; then
              exit 0
            fi
            [ "$attempt" -lt 3 ] || exit 1
            sleep "$((attempt * 5))"
          done
      - id: build
        uses: docker/build-push-action@53b7df96c91f9c12dcc8a07bcb9ccacbed38856a # v7.3.0
        with:
          context: deploy
          file: deploy/native-common/Dockerfile
          platforms: linux/arm64
          push: true
          provenance: false
          sbom: false
          cache-from: type=registry,ref=ghcr.io/bex-co/bex-cnb-run:native-common-bookworm-arm64-local
          cache-to: type=inline
          labels: |
            org.opencontainers.image.source=https://github.com/${{ github.repository }}
            org.opencontainers.image.revision=${{ github.sha }}
            co.bex.native-scope=local-arm64-unqualified-for-production
          tags: ghcr.io/bex-co/bex-cnb-run:native-common-bookworm-arm64-local-candidate-${{ github.sha }}
      - name: check common ARM64 startup and core tools only
        uses: docker/build-push-action@53b7df96c91f9c12dcc8a07bcb9ccacbed38856a # v7.3.0
        with:
          context: deploy/native-common
          file: deploy/native-common/check-local.Dockerfile
          platforms: linux/arm64
          push: false
          provenance: false
          sbom: false
          build-args: COMMON_IMAGE=ghcr.io/bex-co/bex-cnb-run@${{ steps.build.outputs.digest }}
      - name: expose only the lightly checked local ARM64 variant
        env:
          LOCAL_DIGEST: ${{ steps.build.outputs.digest }}
        run: |
          [[ "$LOCAL_DIGEST" =~ ^sha256:[a-f0-9]{64}$ ]]
          ref="ghcr.io/bex-co/bex-cnb-run@$LOCAL_DIGEST"
          docker buildx imagetools create --tag ghcr.io/bex-co/bex-cnb-run:native-common-bookworm-arm64-local "$ref"
          echo "D3 LOCAL ARM64 ONLY: $ref; startup/core tools checked; no full scan, SBOM, signature, runtime-family or production approval" >> "$GITHUB_STEP_SUMMARY"
      - name: record local ARM64 failure without changing production admission
        if: failure()
        run: echo 'D3 local ARM64 variant failed or is unproved; no local discovery update or production approval claimed' >> "$GITHUB_STEP_SUMMARY"
      - name: remove GHCR credentials
        if: always()
        run: docker logout ghcr.io
''')
light=S/'deploy/native-common/check-local.Dockerfile'
light.write_text('''# syntax=docker/dockerfile:1.7
# D3 local-development smoke only. No selected primary, extension or full tool
# transformation claim; production uses the complete AMD64 publisher checks.
ARG COMMON_IMAGE
FROM ${COMMON_IMAGE}
RUN --network=none test "$(uname -m)" = aarch64 \\
  && grep -qx 'VERSION_CODENAME=bookworm' /etc/os-release \\
  && /usr/bin/python3 -c 'import ssl, ctypes; assert ssl.OPENSSL_VERSION; ctypes.CDLL("libffi.so.8")' \\
  && /opt/bex/native-node-tools/node --version \\
  && jq --version && psql --version && pg_restore --version \\
  && gcc --version && tsc --version && webpack --version
''')
helper='.github/scripts/native-common-qualify.py'
p=S/helper;t=p.read_text()
t=t.replace('manual run measures one case on both architectures after the full original','manual run measures one AMD64 case after the full original AMD64')
t=t.replace('    ".github/workflows/native-base-image.yml",\n    ".github/workflows/native-common-image.yml",', '    ".github/workflows/native-base-image.yml", "deploy/native-common/check-local.Dockerfile",\n    ".github/workflows/native-common-image.yml",')
# Actual V11 historical proofs keep their original two-platform gate names.
t=t.replace('PUBLICATION_GATES = {','LEGACY_PUBLICATION_GATES = {',1)
t=t.replace('PUBLICATION_GATES - {next(x for x in PUBLICATION_GATES if x.startswith("Run "))}', 'LEGACY_PUBLICATION_GATES - {next(x for x in LEGACY_PUBLICATION_GATES if x.startswith("Run "))}')
t=t.replace('ci["job_name"], PUBLICATION_GATES)', 'ci["job_name"], LEGACY_PUBLICATION_GATES)')
# Keep public constant name for retained synthetic/legacy V11 controls.
anchor='UTILITY_GATE = "actual generated offline builds, original replays and exact-default SPDX"\n'
old=json.loads((Path('/Users/tianpan/projects/bex7')/'.pm/w8/m91/evidence/common-current0941-20261101/IMAGE-INPUTS.json').read_text())['files'][base]
transition={'ref':'ghcr.io/bex-co/bex-cnb-run@sha256:0941c204f87643c2faad308e72acdf584976e67d8fb980a0646c5ab662dcc5d0','producer':'1feba939b4697894e800ed0abb4f25a0bf415641','verification':'1feba939b4697894e800ed0abb4f25a0bf415641','approval_inputs_sha256':'822f75fe0b44129c5b4fefa9ec0f30fd5f6e325aaf3674f6234f24f540a20797','path':base,'before':old,'after':{'sha256':workflow_digest,'bytes':(S/base).stat().st_size,'mode':'100644','type':'regular'}}
insert='''# Historical0941 still must prove every original publication/signature role.
# D3 changes future production architecture scope, never its executed provenance.
PUBLICATION_GATES = LEGACY_PUBLICATION_GATES

# One reviewed compatibility transition, not an arbitrary source-policy waiver.
# Only the exact original0941 proof may cross this exact workflow-byte change;
# the other32 image inputs, all retained proof bodies and source identities stay exact.
D3_LEGACY_0941 = '''+repr(transition)+'''


def image_inputs_compatible(candidate, recorded, current):
    if recorded == current:
        return True
    transition = D3_LEGACY_0941
    path = transition["path"]
    return (set(recorded) == set(current) == IMAGE_INPUT_PATHS
            and all(candidate[key] == transition[key] for key in ("ref", "producer", "verification"))
            and candidate["approval"]["inputs"]["sha256"] == transition["approval_inputs_sha256"]
            and recorded[path] == transition["before"] and current[path] == transition["after"]
            and all(recorded[name] == current[name] for name in IMAGE_INPUT_PATHS - {path}))

'''
assert anchor in t;t=t.replace(anchor,insert+anchor)
t=t.replace('and image_inputs["files"] == image_source_inventory(root), "stale or wrong verifier-source image-critical inputs")','and image_inputs_compatible(c, image_inputs["files"], image_source_inventory(root)), "stale or wrong verifier-source image-critical inputs")')
t=t.replace('"""Family reuse additionally needs both complete current utility artifacts."""','"""D3 family reuse needs the complete current AMD64 utility artifact."""')
t=t.replace('require(isinstance(c["utilities"], dict) and set(c["utilities"]) == {"amd64", "arm64"}, "both original utility architectures required")','require(isinstance(c["utilities"], dict) and {"amd64"} <= set(c["utilities"]) <= {"amd64", "arm64"}, "complete original AMD64 utility artifact required")')
t=t.replace('or platform not in ("linux/amd64", "linux/arm64")):', 'or platform != "linux/amd64"):')
p.write_text(t)
# README changes only replace undated operative instructions; histories elsewhere stay untouched.
p=S/'deploy/native-common/README.md';t=p.read_text().replace('Both architecture utility checks, full scans, SPDX reports and signing gates remain shared.','D3 (2026-11-01) limits production publication, full utility/family checks, scans, SPDX reports and signatures to linux/amd64. The separate common-only ARM64 local variant receives startup/core-tool checks and is unsigned; it cannot fail production admission or serve as a production candidate.')
t=t.replace('Run each architecture separately with its compatible wheels and corresponding Docker engine/platform; host-only execution does not establish both architectures.','Run production qualification on linux/amd64 with compatible wheels and its actual target platform. The common-only ARM64 smoke is a local-development check and establishes no per-runtime ARM64 qualification.')
t+='''\n## D3 historical candidate migration\n\nThe already reviewed0941 index retains its actual1feba producer/verifier, both platform identities, five signed image/report roles and full custody. The helper permits only the pinned original publisher-workflow bytes to the exact reviewed D3 workflow bytes for this subject; every other32 image input remains exact. No old receipt or source is rewritten. The runner-pool-only change is included in that exact reviewed diff.\n\nChanging the qualification helper/workflow/tests or smoke source changes the full captured source. Family reuse still requires exact equality, so run one complete new AMD64 utility baseline on the same0941 subject before new family admission. Old0b7 results remain dated evidence; no ARM64 full baseline is required by D3. New AMD64-only image approvals need an actually reviewed D3-capable V11 adapter/pin; the retained historical adapter is not relabeled or claimed to verify a new proof shape. Production pins stay empty until separate adoption review.\n\nThe local-only discovery tag is `native-common-bookworm-arm64-local`. Its candidate tag may exist before the smoke finishes; the discovery tag moves only on smoke success. Its immutable reference is recorded as local-only, never substituted into the production output or checked-in approved candidate. A failed/cancelled smoke is unproved and does not fail the AMD64 production jobs. Historical0941 ARM64 full proof already exceeds this smoke scope for its unchanged image bytes; no repeated ARM64 family work is implied.\n''';p.write_text(t)
p=S/'deploy/native-base/README.md';t=p.read_text()
t=t.replace('on both amd64 and arm64.','on linux/amd64 under D3 (2026-11-01).').replace('published for `linux/amd64,linux/arm64`.','published for `linux/amd64`. The common Bookworm factory alone additionally supplies a separate unsigned ARM64 local variant with startup/core-tool smoke checks.').replace('on both architectures.','on linux/amd64.').replace('both architectures must pass','linux/amd64 must pass').replace('per-architecture SBOM and vulnerability-report attestations','AMD64 SBOM and vulnerability-report attestations').replace('verify equivalent library/runtime behavior on both architectures','verify equivalent library/runtime behavior on linux/amd64').replace('both architecture checks','the complete AMD64 checks').replace('for each architecture','for AMD64')
a=t.index('A reviewer may authorize an already-built immutable index in `.github/native-base-recovery.json`')
b=t.index('\nPublication retries interrupted Python-tool transfers',a)
t=t[:a]+'''D3 publication builds the explicitly requested production artifact afresh. Existing `.github/native-base-recovery.json` authorizations retain their historical multiarch subjects and are not consumed by the AMD64-only publisher: signing those index subjects would also sign their ARM64 members. A later recovery route requires an explicitly reviewed AMD64 subject and truthful producer/verifier identities; no old subject is projected or relabeled here. Common production publication was already fresh-only.\n'''+t[b:]
p.write_text(t)
# Syntax inspection is not execution of any proposed helper/test.
ast.parse((S/helper).read_text())
(R/'D3-TRANSITION.json').write_text(json.dumps(transition,indent=2)+'\n')
print(json.dumps({'root':str(R),'publisher_sha256':workflow_digest,'source_status':'draft; tests not executed; repository unchanged'}))
