import json,hashlib,importlib.util,urllib.error,datetime,shutil
from pathlib import Path
HERE=Path(__file__).resolve().parent

def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def dump(n,x): (HERE/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
paths={'driver':Path('/tmp/loopx-w8-native-review-v11.py'),'ranged_policy':Path('/tmp/loopx-w8-verify-native-artifact-ranged.py'),'original_policy':Path('/tmp/loopx-w8-verify-native-artifact.py')}
hashes={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()}
assert hashes['driver']=='ea03d2a9c7a21fde50c0d55f6ead84910c2c431f8c7b52c490624fc5ff8bff85'
assert hashes['ranged_policy']=='ca4a765d547b92f567f7e08149183a8cb094249d544ae594655c92b93d09ae15'
assert hashes['original_policy']=='cf5932b2c5598bc9140a4bf9b99ab8c6ae0aa9613e73ec88140f492b086f1bb2'
v=load('policy',paths['ranged_policy']);f=load('freshness',v.ROOT/'scripts/lib/toolchain-freshness.py')
sha='9cb21ded95659fdc6eb9aeef449457f1a50c00a2';name='elixir-1.20';base=v.matrix_base(sha,name)
u,h=v.public_registry(f,'ghcr.io',v.REPOSITORY)
i,raw,d=v.manifest_document(u,h,'native-'+name+'-'+sha);(HERE/'candidate-index.json').write_bytes(raw);v.image_platforms(i)
ci=v.github_candidate_job(sha,name,'41144656779');assert ci['job_id']==124367871533;dump('ci-metadata.json',ci)
provenance=v.recovery_provenance(sha,name,base,d,ci,HERE);dump('producer-provenance.json',provenance)
labels={}
for arch,child in v.image_platforms(i).items():
 manifest,mraw,_=v.manifest_document(u,h,child);(HERE/(arch+'-manifest.json')).write_bytes(mraw)
 config,craw=v.config_document(u,h,manifest['config']);(HERE/(arch+'-config.json')).write_bytes(craw)
 lab=config['config'].get('Labels',{});assert config['architecture']==arch and config['os']=='linux';assert lab.get('org.opencontainers.image.revision')==provenance['producer_sha'] and lab.get('org.opencontainers.image.source')=='https://github.com/bex-co/bex'
 labels[arch]={'child_digest':child,'config_digest':manifest['config']['digest'],'producer_source':lab['org.opencontainers.image.revision']}
dump('immutable-identity.json',{'name':name,'verifier':sha,'base':base,'ref':'ghcr.io/'+v.REPOSITORY+'@'+d,'producer':provenance['producer_sha'],'architectures':labels,'qualification_not_yet_executed':True})
dump('source-recipe-context.json',{'sha':sha,'non_documentation_files':v.recipe_tree(sha),'scope':'Immutable reviewed factory context; no recovery is presumed for a successful fresh build.'})
try:
 raw,_=v.small_get(u+'/referrers/'+d,h,v.MAX_DOCUMENT);index=json.loads(raw);method='native-referrers'
except urllib.error.HTTPError as e:
 if e.code!=404:raise
 index,raw,_=v.manifest_document(u,h,d.replace(':','-'));method='sha-verified-fallback'
(HERE/'referrers-index.json').write_bytes(raw)
rows=[]
for desc in index.get('manifests',[]):
 if desc.get('artifactType')!='application/vnd.dev.sigstore.bundle.v0.3+json':continue
 m,body,md=v.manifest_document(u,h,desc['digest']);assert len(body)==desc['size'];assert m.get('subject',{}).get('digest')==d;assert len(m.get('layers',[]))==1
 bd,size=v.descriptor(m['layers'][0]);(HERE/(md.split(':')[1]+'.manifest.json')).write_bytes(body)
 rows.append({'manifest_digest':md,'bundle_digest':bd,'bundle_bytes':size,'predicate_type':desc.get('annotations',{}).get('dev.sigstore.bundle.predicateType')})
total=sum(x['bundle_bytes'] for x in rows)
# Reserve the complete original raw bundle sum, another full sum for derived
# compressed/canonical custody, plus128MiB for seven isolated TUF caches,
# parsed/source receipts and transient small metadata. No body/predicate fetched.
projected=2*total+(128<<20)
free=shutil.disk_usage(HERE).free;reserve=2<<30
out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':sha,'name':name,'run_id':41144656779,'expected_job_id':124367871533,'official_base':base,'candidate_ref':'ghcr.io/'+v.REPOSITORY+'@'+d,'metadata_only':True,'artifact_approved':False,'bundle_discovery_method':method,'bundles':rows,'raw_bundle_bytes':total,'projected_additional_case_bytes':projected,'projection_policy':'2x complete signed bundle descriptor sum +128MiB for raw/gzip/canonical custody,TUF,source/metadata; candidate layers stream/discard','free_bytes':free,'reserve_bytes':reserve,'projected_required_free_bytes':reserve+projected,'projected_fit':free>=reserve+projected,'tool_sha256':hashes,'no_payload_bodies_downloaded':True,'no_cache_or_receipt_seeding':True}
dump('intake.json',out);print(json.dumps(out,ensure_ascii=False))
