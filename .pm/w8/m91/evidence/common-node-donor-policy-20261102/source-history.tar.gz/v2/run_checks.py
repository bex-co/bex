"""Inert until explicitly invoked: bounded private donor-policy overlay checks."""
from pathlib import Path
import hashlib, importlib.util, json, os, shutil, signal, stat, subprocess, sys, time

R = Path(__file__).resolve().parent
REPO = Path('/Users/tianpan/projects/bex7')
TMP = R / 'tmp'
FLOOR, MARGIN, TMPCAP, LOGCAP, WHOLE = 8 << 30, 128 << 20, 384 << 20, 16 << 20, 900
GO = Path('/opt/homebrew/Cellar/go/1.26.4/libexec/bin/go')
LINT = REPO / 'lego/operator/bin/golangci-lint'
PYTHON = '/opt/homebrew/bin/python3.14'
CLEANUP = Path('/private/tmp/bex-w8-node14-local-pilot-v4-source-20261101-bop3sbht/run_pilot.py')


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def dump(name, value):
    (R / name).write_text(json.dumps(value, indent=2) + '\n')


def identity(path):
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or path.is_symlink():
        raise RuntimeError('nonregular input: ' + str(path))
    return dict(sha256=digest(path), bytes=info.st_size, mode='100755' if info.st_mode & 0o111 else '100644',
                type='regular', permissions=stat.S_IMODE(info.st_mode))


def owned_size(path):
    result = 0
    def missing_only(error):
        if not isinstance(error, FileNotFoundError):
            raise error
    for base, dirs, files in os.walk(path, onerror=missing_only, followlinks=False):
        for name in files:
            try:
                info = (Path(base) / name).lstat()
            except FileNotFoundError:
                continue
            if stat.S_ISREG(info.st_mode):
                result += info.st_size
    return result


def snapshot(inputs):
    constants = inputs['source_policy_constants']
    paths = set(constants['SOURCE_FILES']) | {'deploy/' + p for p in constants['FACTORY_PATHS']}
    paths.update(str(p.relative_to(REPO)) for p in (REPO / 'lego/operator/internal/build').rglob('*')
                 if not p.is_dir() or p.is_symlink())
    for package in constants['SOURCE_PACKAGES']:
        paths.update(str(p.relative_to(REPO)) for p in (REPO / 'lego' / package).glob('*.go'))
    expected = set(inputs['source_paths'])
    untracked = {}
    for name in sorted(paths - expected):
        info = (REPO / name).lstat()
        untracked[name] = dict(bytes=info.st_size, permissions=stat.S_IMODE(info.st_mode),
                               mtime_ns=info.st_mtime_ns, type='regular' if stat.S_ISREG(info.st_mode) else 'other')
    return {'tracked_functional': {name: identity(REPO / name) for name in sorted(expected)},
            'extra_inputs': {name: identity(REPO / name) for name in inputs['extra']},
            'untracked_metadata_only': untracked,
            'private_sources': {name: identity(R / 'source' / name) for name in json.loads((R / 'SOURCE-MANIFEST.json').read_bytes())}}


def main():
    if sys.flags.optimize or sys.version_info[:2] != (3, 14):
        raise RuntimeError('ordinary Python3.14 required')
    inputs = json.loads((R / 'CHECK-INPUTS.json').read_bytes())
    if str(Path(PYTHON).resolve()) != inputs['python']['resolved'] or digest(Path(PYTHON)) != inputs['python']['sha256']:
        raise RuntimeError('Python command target changed')
    for name, expected in inputs['tools'].items():
        if identity(Path(name)) != expected:
            raise RuntimeError('tool identity changed: ' + name)
    if digest(CLEANUP) != 'e158acde2c44aac290d09f109ddf4f3bf2ca93dc660161dd326fb3ad7cc72c03':
        raise RuntimeError('reviewed reaper changed')
    # Definition-only import of the unchanged, main-guarded reviewed reaper.
    spec = importlib.util.spec_from_file_location('reviewed_group_reaper', CLEANUP)
    cleanup = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cleanup)
    before = snapshot(inputs)
    if digest(R / 'SOURCE-TRACKED-BEFORE.json') != inputs['source_before_sha256'] or before['tracked_functional'] != json.loads((R / 'SOURCE-TRACKED-BEFORE.json').read_bytes()):
        raise RuntimeError('current functional preimages changed')
    if before['extra_inputs'] != inputs['extra'] or before['untracked_metadata_only'] != inputs['untracked_paths']:
        raise RuntimeError('extra inputs or preserved ignored-file metadata changed')
    if before['private_sources'] != json.loads((R / 'SOURCE-MANIFEST.json').read_bytes()):
        raise RuntimeError('private source proposal changed')
    for name, expected in json.loads((R / 'PREIMAGE-MANIFEST.json').read_bytes()).items():
        if identity(R / 'before' / name) != expected or identity(REPO / name) != expected:
            raise RuntimeError('owned preimage changed: ' + name)
    command_count = len(json.loads((R / 'COMMANDS.json').read_bytes())['commands'])
    entry_required = FLOOR + MARGIN + TMPCAP + command_count * LOGCAP
    start_free = shutil.disk_usage(R).free
    if start_free < entry_required:
        raise RuntimeError('physical floor plus margin and full owned TMP/log allowance unavailable')
    TMP.mkdir(mode=0o700)
    routing = TMP / 'routing'
    for name, expected in inputs['routing_view'].items():
        proposed = R / 'source' / name
        source = proposed if proposed.is_file() else REPO / name
        if identity(source) != expected:
            raise RuntimeError('routing input changed: ' + name)
        target = routing / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    profile = TMP / 'offline.sb'
    profile.write_text('(version 1) (allow default) (deny network-outbound) '
                       '(allow network-outbound (remote ip "localhost:*")) '
                       '(deny file-write* (subpath "' + str(REPO) + '")) '
                       '(deny file-write* (subpath "/Users/tianpan/go/pkg/mod"))\n')
    env = os.environ.copy()
    for key in list(env):
        if key.startswith(('BEX_', 'GITHUB_', 'RUNNER_')) or key in ('CI', 'KUBECONFIG', 'DOCKER_HOST', 'DOCKER_CONTEXT', 'PYTHONPATH', 'PYTHONOPTIMIZE'):
            env.pop(key, None)
    env.update(TMPDIR=str(TMP), GOTMPDIR=str(TMP), GOCACHE=inputs['ordinary_cache'],
               GOLANGCI_LINT_CACHE=str(TMP / 'lint-cache'), GOWORK='off', GOTOOLCHAIN='local',
               GOPROXY='off', GOSUMDB='off', GOTELEMETRY='off', GOENV='off', GOMAXPROCS='2',
               GOMEMLIMIT='512MiB', PYTHONDONTWRITEBYTECODE='1')
    policy = '^TestCommonNodeRuntimeArtifactPolicy$/^(node|ruby)-uncovered-exact$'
    python_tests = ['test_all_routes_are_exact_single_cases_and_bounds_are_fixed',
                    'test_every_route_tracks_an_existing_go_test_and_actual_subtest_contract',
                    'test_donor_route_keeps_source_fallback_separate_and_rejects_unpublished_patch',
                    'test_invalid_selections_fail_before_any_output_or_resource_operation',
                    'test_profile_environment_clears_all_other_opt_ins_and_rejects_original_gate']
    commands = [
        ('go-version', [str(GO), 'version'], 10, 0, 'overlay.json', REPO / 'lego/operator'),
        ('lint-version', [str(LINT), 'version'], 10, 0, 'overlay.json', REPO / 'lego/operator'),
        ('old-runtime-red', [str(GO), 'test', '-p', '1', '-count=1', './internal/build', '-run', policy], 180, 1, 'overlay-old-runtime.json', REPO / 'lego/operator'),
        ('new-focused', [str(GO), 'test', '-p', '1', '-count=1', './internal/build', '-run', '^(TestCommonNode|TestCommonRuntimeArtifacts|TestCommonExactCompanions|TestNativeCommonAdoptionData)'], 300, 0, 'overlay.json', REPO / 'lego/operator'),
        ('full-buildpkg', [str(GO), 'test', '-p', '1', '-count=1', './internal/build'], 600, 0, 'overlay.json', REPO / 'lego/operator'),
        ('scoped-lint', [str(LINT), 'run', '--concurrency', '2', './internal/build'], 300, 0, 'overlay.json', REPO / 'lego/operator'),
        ('routing-host', [PYTHON, '-B', '-m', 'unittest', '-v'] + ['test_native_oci_common_qualification.ProfileRoutingControls.' + name for name in python_tests], 60, 0, 'overlay.json', routing / '.github/scripts'),
    ]
    planned = json.loads((R / 'COMMANDS.json').read_bytes())['commands']
    actual = [[label, argv, seconds, expected, overlay, str(cwd)] for label, argv, seconds, expected, overlay, cwd in commands]
    if actual != planned:
        raise RuntimeError('command plan drift')
    dump('CHECK-SCOPE.json', {'commands': actual,
                            'operating_limits': dict(physical_floor_bytes=FLOOR, free_margin_bytes=MARGIN, own_TMP_cap_bytes=TMPCAP, per_command_log_cap_bytes=LOGCAP, whole_seconds=WHOLE),
                            'cache': 'Ordinary Go-managed shared cache reads/writes, never cloned/pruned/deleted; module source and repository write-denied by sandbox.',
                            'CPU_memory': 'GOMAXPROCS2/GOMEMLIMIT512MiB/go-p1/lint-concurrency2, operating controls rather than OS CPU/RSS reservations.',
                            'source_scope': '301 tracked functional files plus explicit untouched metadata-only inventory of three pre-existing ignored pycs; no clean physical qualification-source assertion.',
                            'before': before, 'start_free_bytes': start_free, 'entry_required_bytes': entry_required, 'full_log_allowance_bytes': command_count * LOGCAP})
    results, groups, cancelled, handlers = [], {}, [], {}
    started = time.monotonic()
    minimum, peak, failure, after = start_free, 0, None, None
    def bounds(command_start, seconds, stdout, stderr):
        nonlocal minimum, peak
        free, own = shutil.disk_usage(R).free, owned_size(TMP)
        minimum, peak = min(minimum, free), max(peak, own)
        if cancelled or free < FLOOR + MARGIN or own > TMPCAP or time.monotonic() - started > WHOLE or time.monotonic() - command_start > seconds or stdout.stat().st_size + stderr.stat().st_size > LOGCAP:
            return dict(signals=list(cancelled), free_bytes=free, owned_TMP_bytes=own, command_seconds=time.monotonic() - command_start, whole_seconds=time.monotonic() - started)
        return None
    try:
        for sig in (signal.SIGINT, signal.SIGTERM):
            handlers[sig] = signal.getsignal(sig)
            signal.signal(sig, lambda number, frame: cancelled.append(number))
        for label, argv, seconds, expected, overlay, cwd in commands:
            if groups or cancelled or snapshot(inputs) != before:
                raise RuntimeError('pending group, cancellation or input drift before command')
            stdout, stderr = R / (label + '.stdout'), R / (label + '.stderr')
            stdout.touch(exist_ok=False)
            stderr.touch(exist_ok=False)
            command_start, stop, process, absent = time.monotonic(), None, None, False
            stop = bounds(command_start, seconds, stdout, stderr)
            if stop:
                raise RuntimeError('pre-spawn resource guard: ' + str(stop))
            command_env = dict(env, GOFLAGS='-mod=readonly -overlay=' + str(R / overlay))
            with stdout.open('wb') as out, stderr.open('wb') as err:
                try:
                    process = subprocess.Popen(['/usr/bin/sandbox-exec', '-f', str(profile)] + argv, cwd=cwd, env=command_env,
                                               stdin=subprocess.DEVNULL, stdout=out, stderr=err, start_new_session=True)
                    groups[process.pid] = process
                    dump(label + '-PROCESS.json', dict(pid=process.pid, pgid=process.pid, argv=process.args))
                    while process.poll() is None:
                        stop = bounds(command_start, seconds, stdout, stderr)
                        if stop:
                            break
                        time.sleep(.25)
                finally:
                    if process is not None:
                        absent = cleanup.stop_group(process)
                        if absent:
                            groups.pop(process.pid, None)
            stop = stop or bounds(command_start, seconds, stdout, stderr)
            red_reason = True
            if label == 'old-runtime-red':
                text = stdout.read_text(errors='replace') + stderr.read_text(errors='replace')
                red_reason = all(value in text for value in ['TestCommonNodeRuntimeArtifactPolicy/node-uncovered-exact',
                               'TestCommonNodeRuntimeArtifactPolicy/ruby-uncovered-exact', 'runtime tree/source qualification changed'])
            result = dict(label=label, argv=argv, exit=process.returncode if process else None, expected_exit=expected,
                          resource_stop=stop, group_absent=absent, expected_counterfactual_reason=red_reason,
                          seconds=time.monotonic() - command_start, stdout_sha256=digest(stdout), stderr_sha256=digest(stderr))
            result['PASS'] = process is not None and process.returncode == expected and stop is None and absent and red_reason
            results.append(result)
            dump(label + '-RESULT.json', result)
            print(json.dumps(result), flush=True)
            if not result['PASS']:
                break
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
    finally:
        for pgid, process in list(groups.items()):
            if cleanup.stop_group(process):
                groups.pop(pgid, None)
        for sig, handler in handlers.items():
            signal.signal(sig, handler)
        try:
            after = snapshot(inputs)
            dump('CHECK-SOURCE-AFTER.json', after)
        except BaseException as error:
            failure = failure or 'final input observer: ' + type(error).__name__ + ': ' + str(error)
        free, own = shutil.disk_usage(R).free, owned_size(TMP)
        minimum, peak = min(minimum, free), max(peak, own)
        late_guard = cancelled or free < FLOOR + MARGIN or own > TMPCAP or time.monotonic() - started > WHOLE
        if not groups:
            shutil.rmtree(TMP)
        report = dict(PASS=len(results) == len(commands) and all(row['PASS'] for row in results) and not groups and before == after and not late_guard and failure is None,
                      results=results, failure=failure, source_unchanged=before == after,
                      tracked_functional_files=len(before['tracked_functional']), ignored_pycs_metadata_unchanged=after is not None and before['untracked_metadata_only'] == after['untracked_metadata_only'],
                      foreign_sum_unchanged=after is not None and before['extra_inputs']['lego/go.work.sum'] == after['extra_inputs']['lego/go.work.sum'],
                      minimum_free_bytes=minimum, peak_own_TMP_bytes=peak, pending_pgids=sorted(groups), cancelled=cancelled,
                      own_TMP_removed=not TMP.exists(), shared_cache_retained=Path(inputs['ordinary_cache']).is_dir(),
                      actual_image_or_CI_or_adoption_claim=False)
        dump('CHECK-RESULT.json', report)
    print(json.dumps(report), flush=True)
    return 0 if report['PASS'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
