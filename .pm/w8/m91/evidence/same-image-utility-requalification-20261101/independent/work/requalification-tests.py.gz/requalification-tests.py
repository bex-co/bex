    def test_reviewed_image_with_null_baseline_plans_full_utilities_but_not_family(self):
        self.candidate['source'] = None
        self.candidate['utilities'] = None
        self.save()
        approved = qualification.validate_image_candidate(self.root)
        self.assertEqual(approved['baseline_status'], 'image-only-requalification')
        with self.assertRaisesRegex(ValueError, 'family reuse requires'):
            qualification.validate_test_candidate(self.root)
        output = self.root / 'plan-output'
        env = dict(REQUESTED_SOURCE='reviewed-candidate', REQUESTED_PROFILE='utilities', REQUESTED_CASE='all', GITHUB_OUTPUT=str(output))
        with patch.object(qualification, '__file__', str(self.root / '.github/scripts/native-common-qualify.py')), \
             patch.object(qualification.tempfile, 'mkdtemp', side_effect=AssertionError('plan creates no resources')), patch.dict(os.environ, env):
            qualification.plan()
        planned = dict(line.split('=', 1) for line in output.read_text().splitlines())
        self.assertEqual(planned['baseline_status'], 'image-only-requalification')
        self.assertEqual(planned['ref'], self.ref)
        self.assertEqual(planned['case'], 'all')
        self.assertEqual(planned['selector'], qualification.profile_selection('utilities', 'all')['selector'])
        output.unlink()
        with patch.object(qualification, '__file__', str(self.root / '.github/scripts/native-common-qualify.py')), \
             patch.dict(os.environ, env, REQUESTED_PROFILE='node', REQUESTED_CASE='node-14'), self.assertRaises(ValueError):
            qualification.plan()
        self.assertFalse(output.exists())

    def test_generator_and_qualification_changes_allow_image_requalification_only(self):
        for path in ('lego/operator/internal/build/native.go', '.github/scripts/native-common-qualify.py',
                     '.github/workflows/native-common-image.yml', '.github/scripts/test_native_oci_common_qualification.py'):
            self.assertNotIn(path, qualification.IMAGE_INPUT_PATHS)
            self.write(path, b'CONTROL ONLY changed generator or qualification source')
        self.assertEqual(qualification.validate_image_candidate(self.root)['ref'], self.ref)
        with self.assertRaisesRegex(ValueError, 'stale qualification source'):
            qualification.validate_test_candidate(self.root)

    def test_partial_or_failed_old_utilities_never_authorize_a_family(self):
        original = self.candidate['utilities']
        self.candidate['utilities'] = {'amd64': original['amd64']}
        self.save()
        qualification.validate_image_candidate(self.root)
        with self.assertRaisesRegex(ValueError, 'both original utility architectures'):
            qualification.validate_test_candidate(self.root)
        self.candidate['utilities'] = original
        self.rewrite_evidence(original['amd64']['metadata'], lambda x: x.update(conclusion='failure'))
        qualification.validate_image_candidate(self.root)
        with self.assertRaisesRegex(ValueError, 'actual job/source/status differs'):
            qualification.validate_test_candidate(self.root)

    def test_null_baseline_init_captures_new_source_without_relabeling_image(self):
        self.candidate['source'] = None
        self.candidate['utilities'] = None
        self.save()
        approved = qualification.validate_image_candidate(self.root)
        env = dict(QUALIFICATION_PROFILE='utilities', QUALIFICATION_CASE='all', QUALIFICATION_SOURCE='reviewed-candidate',
                   COMMON_IMAGE=self.ref, PRODUCER_SHA=self.source, VERIFICATION_SHA=self.source, TARGET_PLATFORM='linux/arm64',
                   CANDIDATE_RECEIPT_SHA256=approved['receipt_sha256'], RUNNER_TEMP=str(self.root), GITHUB_RUN_ID='3', GITHUB_RUN_ATTEMPT='1',
                   GITHUB_OUTPUT=str(self.root / 'outputs'), GITHUB_ENV=str(self.root / 'environment'))
        with patch.object(qualification, '__file__', str(self.root / '.github/scripts/native-common-qualify.py')), patch.dict(os.environ, env):
            qualification.initialize()
        outputs = dict(line.split('=', 1) for line in (self.root / 'outputs').read_text().splitlines())
        evidence = Path(outputs['root'])
        recorded = json.loads((evidence / 'inputs.json').read_text())
        self.assertEqual((recorded['producer'], recorded['verification'], recorded['generator_source']), (self.source, self.source, 'b' * 40))
        self.assertEqual(recorded['baseline_status'], 'image-only-requalification')
        self.assertEqual(recorded['previous_baseline_state'], 'absent')
        self.assertIsNone(recorded['utility_baseline_source'])
        self.assertIsNone(recorded['utility_jobs'])
        self.assertEqual(recorded['image_approval_inputs_sha256'], self.candidate['approval']['inputs']['sha256'])
        self.assertEqual(json.loads((evidence / 'qualification-source.json').read_text()),
                         {'source': 'b' * 40, 'files': qualification.source_inventory(self.root)})
        config = Path(recorded['docker_config'])
        self.assertEqual(config.stat().st_mode & 0o777, 0o700)
        self.assertFalse((config / 'config.json').exists())  # No login occurred.

    def test_requalification_init_revalidates_image_before_credentials(self):
        self.candidate['source'] = None
        self.candidate['utilities'] = None
        self.save()
        planned = qualification.validate_image_candidate(self.root)
        env = dict(QUALIFICATION_PROFILE='utilities', QUALIFICATION_CASE='all', QUALIFICATION_SOURCE='reviewed-candidate',
                   COMMON_IMAGE=self.ref, PRODUCER_SHA=self.source, VERIFICATION_SHA=self.source, TARGET_PLATFORM='linux/arm64',
                   CANDIDATE_RECEIPT_SHA256=planned['receipt_sha256'])
        self.write('deploy/native-common/prepare-node14-tools.py', b'changed after planning')
        with patch.object(qualification, '__file__', str(self.root / '.github/scripts/native-common-qualify.py')), \
             patch.object(qualification.tempfile, 'mkdtemp', side_effect=AssertionError('no resources')), patch.dict(os.environ, env):
            with self.assertRaisesRegex(ValueError, 'image-critical inputs'):
                qualification.initialize()

    def test_image_critical_changed_bytes_mode_and_type_reject(self):
        target = self.root / 'deploy/native-base/check-tools.py'
        original = target.read_bytes()
        permissions = target.stat().st_mode & 0o777
        for mutation in ('bytes', 'mode', 'type'):
            with self.subTest(mutation=mutation):
                if mutation == 'bytes': target.write_bytes(b'changed publisher check')
                elif mutation == 'mode': target.chmod(0o755)
                else: target.unlink(); target.mkdir()
                with self.assertRaises(ValueError): qualification.validate_image_candidate(self.root)
                if target.is_dir(): target.rmdir()
                target.write_bytes(original); target.chmod(permissions)

    def test_image_source_proof_must_be_original_verifier_and_exact_set(self):
        descriptor = self.candidate['approval']['inputs']
        self.rewrite_evidence(descriptor, lambda x: x.update(source='b' * 40))
        with self.assertRaisesRegex(ValueError, 'wrong verifier-source image-critical inputs'):
            qualification.validate_image_candidate(self.root)

    def test_omitted_image_source_path_is_not_an_equivalence_boolean(self):
        self.rewrite_evidence(self.candidate['approval']['inputs'], lambda x: x['files'].pop('.github/scripts/native-oci-mirror.py'))
        with self.assertRaisesRegex(ValueError, 'image-critical inputs'):
            qualification.validate_image_candidate(self.root)

    def test_image_source_body_and_manifest_need_portable_custody(self):
        self.rewrite_evidence(self.candidate['approval']['custody'], lambda x: x['image_inputs'].pop('.github/scripts/native-oci-stage.py'))
        with self.assertRaisesRegex(ValueError, 'image-critical source custody set differs'):
            qualification.validate_image_candidate(self.root)

    def test_image_manifest_itself_needs_portable_custody(self):
        self.rewrite_evidence(self.candidate['approval']['custody'], lambda x: x['files'].pop('/retained/image-inputs.json'))
        with self.assertRaisesRegex(ValueError, 'image input manifest has no portable custody'):
            qualification.validate_image_candidate(self.root)

    def test_image_only_requalification_still_rejects_wrong_index_and_platform(self):
        self.candidate['platforms']['amd64']['config_digest'] = 'sha256:' + 'f' * 64
        self.save()
        with self.assertRaisesRegex(ValueError, 'V11 platform identities differ'):
            qualification.validate_image_candidate(self.root)

    def test_image_only_requalification_requires_successful_original_publication(self):
        self.rewrite_evidence(self.candidate['publication']['metadata'], lambda x: x.update(conclusion='failure'))
        with self.assertRaisesRegex(ValueError, 'actual job/source/status differs'):
            qualification.validate_image_candidate(self.root)

    def test_complete_utility_command_and_resource_bounds_remain_unchanged(self):
        jobs = ProfileRoutingControls().jobs()
        original = jobs['qualify']
        for literal in ('timeout-minutes: 180', 'max-parallel: 1', 'arch: [amd64, arm64]', 'QUALIFICATION_PROFILE: utilities', 'QUALIFICATION_CASE: all'):
            self.assertIn(literal, original)
        command = ProfileRoutingControls().run_block(original, qualification.UTILITY_GATE)
        self.assertIn("-run '^(TestNativeUtilityGeneratedImages|TestNativeOriginalReplayHTTPOracles)$'", command)
        self.assertIn('-timeout 150m', command)
        self.assertNotIn('QUALIFICATION_SELECTOR', command)
        self.assertIn("needs.plan.outputs.baseline_status == 'current-complete'", jobs['qualify-profile'])

    def test_actual_utility_job_branch_table_has_no_failed_fresh_fallback(self):
        job = ProfileRoutingControls().jobs()['qualify']
        expression = ' '.join(job.split('    if: >-\n', 1)[1].split('    permissions:', 1)[0].split())
        expression = expression.removeprefix('${{ ').removesuffix(' }}')
        for mode in ('fresh', 'reviewed-candidate', 'unknown'):
            for profile in ('utilities', 'node'):
                for published in ('success', 'failure', 'cancelled', 'skipped'):
                    for baseline in ('image-only-requalification', 'current-complete', ''):
                        for event in ('push', 'workflow_dispatch'):
                            for cancelled in (False, True):
                                values = {'always()': True, '!cancelled()': not cancelled, 'github.ref': 'refs/heads/main',
                                          'github.event_name': event, 'needs.plan.result': 'success',
                                          'needs.plan.outputs.source': mode, 'needs.plan.outputs.profile': profile,
                                          'needs.plan.outputs.baseline_status': baseline, 'needs.publish.result': published,
                                          'needs.publish.outputs.ref': self.ref if published == 'success' else '',
                                          'needs.plan.outputs.ref': self.ref, 'needs.plan.outputs.receipt_sha256': 'c' * 64}
                                translated = expression
                                for token in sorted(values, key=len, reverse=True):
                                    translated = translated.replace(token, repr(values[token]))
                                actual = eval(translated.replace('&&', ' and ').replace('||', ' or '), {'__builtins__': {}}, {})
                                expected = not cancelled and ((mode == 'fresh' and published == 'success') or
                                    (mode == 'reviewed-candidate' and profile == 'utilities' and event == 'workflow_dispatch'
                                     and baseline == 'image-only-requalification' and published == 'skipped'))
                                self.assertEqual(actual, expected, (mode, profile, published, baseline, event, cancelled))
