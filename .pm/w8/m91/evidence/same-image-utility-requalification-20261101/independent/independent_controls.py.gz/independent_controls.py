"""Synthetic filesystem tier boundaries only; no actual artifact/CI authority."""
from pathlib import Path
import importlib.util,json,os
from unittest.mock import patch
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('independent_controls_source',ROOT/'work/source/.github/scripts/test_native_oci_common_qualification.py');t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t);q=t.qualification
assert q.V11_TOOLS['common-v11-adapter.py']=='4746a5022ab6df57ed95b6354d56b92eff15976d1737c2aa5a5ca15aa0080a4b'
assert len(q.IMAGE_INPUT_PATHS)==33
rows=[]
def case(name,mutate,image_ok,family_ok):
 f=t.ReviewedCandidateControls();f.setUp()
 try:
  assert q.validate_test_candidate(f.root)['baseline_status']=='current-complete'
  mutate(f);f.save();observed={}
  for key,validator in [('image',q.validate_image_candidate),('family',q.validate_test_candidate)]:
   try:observed[key]={'accepts':True,'tier':validator(f.root)['baseline_status']}
   except ValueError as e:observed[key]={'accepts':False,'error':str(e)}
  assert observed['image']['accepts'] is image_ok and observed['family']['accepts'] is family_ok,(name,observed)
  rows.append({'case':name,**observed})
 finally:f.doCleanups()
case('complete_baseline',lambda f:None,True,True)
def absent(f):f.candidate['source']=None;f.candidate['utilities']=None
case('null_baseline_utility_requalification_only',absent,True,False)
case('generator_fix_can_requalify_same_image',lambda f:f.write('lego/operator/internal/build/native.go',b'CONTROL ONLY independently changed generator'),True,False)
case('qualification_helper_fix_can_requalify_same_image',lambda f:f.write('.github/scripts/native-common-qualify.py',b'CONTROL ONLY independently changed qualification'),True,False)
case('changed_image_factory_stops_both_tiers',lambda f:f.write('deploy/native-common/Dockerfile',b'CONTROL ONLY changed image factory'),False,False)
case('changed_publisher_policy_stops_both_tiers',lambda f:f.write('.github/workflows/native-base-image.yml',b'CONTROL ONLY changed publisher policy'),False,False)
case('different_index_is_never_rawref_reuse',lambda f:f.candidate.update(ref='ghcr.io/bex-co/bex-cnb-run@sha256:'+'f'*64),False,False)
f=t.ReviewedCandidateControls();f.setUp()
try:
 absent(f);f.save();approved=q.validate_image_candidate(f.root)
 env={'QUALIFICATION_PROFILE':'utilities','QUALIFICATION_CASE':'all','QUALIFICATION_SOURCE':'reviewed-candidate','COMMON_IMAGE':f.ref,'PRODUCER_SHA':f.source,'VERIFICATION_SHA':f.source,'TARGET_PLATFORM':'linux/arm64','CANDIDATE_RECEIPT_SHA256':approved['receipt_sha256']}
 f.write('.github/scripts/native-oci-stage.py',b'CONTROL ONLY changed after planning')
 with patch.dict(os.environ,env),patch.object(q,'__file__',str(f.root/'.github/scripts/native-common-qualify.py')),patch.object(q.tempfile,'mkdtemp',side_effect=AssertionError('must not create resources')):
  try:q.initialize();raise AssertionError('changed image inputs accepted by init')
  except ValueError as e:rows.append({'case':'requalification_rechecks_before_resources','accepts':False,'error':str(e)})
finally:f.doCleanups()
(ROOT/'INDEPENDENT-CONTROLS.json').write_text(json.dumps({'scope':'Synthetic, explicitly CONTROL ONLY fake proof/source metadata. No cryptographic or actual image approval; no actual resources/auth/network.','cases':rows,'all_expected_outcomes':True},indent=2)+'\n')
print(json.dumps({'independent_cases':len(rows),'all_expected_outcomes':True}))
