"""Actual CLI transport/identity smoke on unpublished synthetic OCI bytes only."""
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parent
SOURCE_DB = Path('/Users/tianpan/Library/Caches/trivy/db/trivy.db')
BINARY = Path('/var/folders/q2/zn9w8byj2zv19rgy4kvwg0gm0000gn/T/bex-trivy-c4xp6np1/trivy')

def digest(data):
    return 'sha256:' + hashlib.sha256(data).hexdigest()

def hashed(path):
    h = hashlib.sha256()
    with path.open('rb') as source:
        while chunk := source.read(1 << 20):
            h.update(chunk)
    return h.hexdigest()

def dump(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')

def encoded(value):
    return json.dumps(value, indent=3).encode() + b'\n'

def descriptor(data, media):
    return {'mediaType': media, 'digest': digest(data), 'size': len(data)}

class Response(io.BytesIO):
    status = 200
    def __init__(self, data):
        super().__init__(data)
        self.headers = {'Content-Length': str(len(data))}

class SyntheticRegistry:
    def __init__(self, bodies):
        self.bodies, self.calls = bodies, []
    def open(self, kind, key, offset):
        assert kind in ('manifests', 'blobs') and offset == 0 and key in self.bodies
        self.calls.append({'kind': kind, 'digest': key, 'offset': offset, 'synthetic_in_memory': True})
        return Response(self.bodies[key])

def main():
    provenance = json.loads((ROOT / 'tool-provenance.json').read_text())
    assert hashed(BINARY) == provenance['binary_sha256']
    for name, expected in [('native-oci-mirror.py', '78b070104bfe1c532b6dcca099dd0d0046250dda32ec425ab27f305ef353ac06'), ('native-oci-stage.py', '891d6581c29c8d3d39be80b60882c0e05f974e167c5f1784713b69d3fa159d59')]:
        assert hashed(ROOT / 'source' / name) == expected
    assert shutil.disk_usage(ROOT).free >= 2 << 30
    cloned = ROOT / 'cache/db/trivy.db'
    assert cloned.exists() and cloned.stat().st_ino != SOURCE_DB.stat().st_ino
    before = {'source_sha256': hashed(SOURCE_DB), 'clone_sha256': hashed(cloned), 'source_metadata_sha256': hashed(SOURCE_DB.with_name('metadata.json')), 'source_mtime_ns': SOURCE_DB.stat().st_mtime_ns}
    assert before['source_sha256'] == before['clone_sha256']
    dump('database-before.json', before)
    spec = importlib.util.spec_from_file_location('synthetic_stage', ROOT / 'source/native-oci-stage.py')
    stage = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(stage)
    payloads = {
        'etc/os-release': b'NAME="Debian GNU/Linux"\nID=debian\nVERSION_ID="12"\nPRETTY_NAME="SYNTHETIC MIRROR TRANSPORT CONTROL ONLY"\n',
        'var/lib/dpkg/status': b'Package: synthetic-mirror-transport-control\nStatus: install ok installed\nArchitecture: arm64\nVersion: 0.0.0\nDescription: Unpublished synthetic transport fixture, not a production image.\n\n',
        'SYNTHETIC-ONLY.txt': b'CLI transport and raw identity control only. Never published; no image qualification.\n',
    }
    archive = io.BytesIO()
    with tarfile.open(fileobj=archive, mode='w', format=tarfile.USTAR_FORMAT) as tar:
        for name, body in sorted(payloads.items()):
            item = tarfile.TarInfo(name)
            item.size, item.mode, item.mtime = len(body), 0o644, 0
            tar.addfile(item, io.BytesIO(body))
    raw_tar = archive.getvalue()
    layer = gzip.compress(raw_tar, mtime=0)
    bodies = {digest(layer): layer}
    children, configs = [], {}
    for arch in ('amd64', 'arm64'):
        config = encoded({'architecture': arch, 'os': 'linux', 'config': {'Labels': {'org.opencontainers.image.title': 'SYNTHETIC MIRROR TRANSPORT CONTROL ONLY'}}, 'rootfs': {'type': 'layers', 'diff_ids': [digest(raw_tar)]}, 'history': [{'created_by': 'unpublished synthetic fixture'}]})
        manifest = encoded({'schemaVersion': 2, 'mediaType': 'application/vnd.oci.image.manifest.v1+json', 'config': descriptor(config, 'application/vnd.oci.image.config.v1+json'), 'layers': [descriptor(layer, 'application/vnd.oci.image.layer.v1.tar+gzip')]})
        bodies[digest(config)], bodies[digest(manifest)] = config, manifest
        child = descriptor(manifest, 'application/vnd.oci.image.manifest.v1+json')
        child['platform'] = {'os': 'linux', 'architecture': arch}
        children.append(child)
        configs[arch] = digest(config)
    index = encoded({'schemaVersion': 2, 'mediaType': 'application/vnd.oci.image.index.v1+json', 'manifests': children})
    bodies[digest(index)] = index
    ref = stage.REPOSITORY + '@' + digest(index)
    fixtures = ROOT / 'synthetic-payloads'
    fixtures.mkdir(mode=0o700)
    for key, body in bodies.items():
        (fixtures / (key[7:] + '.blob')).write_bytes(body)
    (fixtures / 'layer.tar').write_bytes(raw_tar)
    expected = {'SYNTHETIC_ONLY': True, 'published': False, 'ref': ref, 'platform': 'linux/arm64', 'root_digest': digest(index), 'config_digest': configs['arm64'], 'diff_id': digest(raw_tar), 'layer_digest': digest(layer), 'selected_manifest': children[1]['digest'], 'scope': 'Actual pinned CLI transport and raw report identity only, not production/full-vulnerability or image qualification.'}
    dump('expected-synthetic.json', expected)
    registry = SyntheticRegistry(bodies)
    stage.Stager(ref, 'linux/arm64', ROOT / 'layout', ROOT / 'stage.json', registry).run()
    dump('synthetic-stage-input-calls.json', registry.calls)
    command = [sys.executable, str(ROOT / 'source/native-oci-mirror.py'), '--ref', ref, '--platform', 'linux/arm64', '--layout', str(ROOT / 'layout'), '--stage-proof', str(ROOT / 'stage.json'), '--proof', str(ROOT / 'mirror.json'), '--parent-pid', str(os.getpid()), '--', str(BINARY), 'image', ref, '--image-src', 'remote', '--parallel', '1', '--max-image-size', '8589934592B', '--cache-dir', str(ROOT / 'cache'), '--skip-db-update', '--skip-java-db-update', '--offline-scan', '--skip-version-check', '--disable-telemetry', '--format', 'json', '--timeout', '60s']
    environment = {'PATH': '/usr/bin:/bin:/usr/sbin:/sbin', 'HOME': str(ROOT / 'home'), 'TMPDIR': str(ROOT / 'work'), 'XDG_CACHE_HOME': str(ROOT / 'cache'), 'TRIVY_PLATFORM': 'linux/arm64', 'TRIVY_OUTPUT': str(ROOT / 'raw-report.json'), 'PYTHONDONTWRITEBYTECODE': '1', 'DOCKER_CONFIG': str(ROOT / 'home/docker')}
    dump('command.json', {'argv': command, 'environment': environment, 'scope': expected['scope']})
    process = None
    started, reason = time.monotonic(), None
    try:
        with (ROOT / 'stdout.log').open('xb') as stdout, (ROOT / 'stderr.log').open('xb') as stderr:
            process = subprocess.Popen(command, env=environment, cwd=ROOT, stdout=stdout, stderr=stderr, start_new_session=True)
            dump('process.json', {'owned_mirror_pid': process.pid, 'pgid': os.getpgid(process.pid)})
            while process.poll() is None:
                if shutil.disk_usage(ROOT).free < 2 << 30:
                    reason = 'global-free-floor'
                    break
                if time.monotonic() - started > 120:
                    reason = 'outer-smoke-deadline'
                    break
                time.sleep(0.1)
            if reason:
                os.killpg(process.pid, signal.SIGTERM)
            status = process.wait(timeout=20)
        dump('execution.json', {'exit_code': status, 'monitor_stop_reason': reason, 'duration_seconds': time.monotonic() - started, 'owned_mirror_reaped': True})
        assert status == 0 and reason is None
        mirror = json.loads((ROOT / 'mirror.json').read_text())
        assert mirror['complete'] is True and mirror['ref'] == ref
        raw_report = ROOT / 'raw-report.json'
        report = json.loads(raw_report.read_text())
        metadata = report['Metadata']
        assert report['ArtifactName'] == ref and report['ArtifactType'] == 'container_image'
        assert metadata['ImageID'] == configs['arm64'] and ref in metadata['RepoDigests']
        assert metadata['ImageConfig']['architecture'] == 'arm64' and metadata['ImageConfig']['os'] == 'linux'
        assert metadata['DiffIDs'] == [digest(raw_tar)]
        dump('identity-validation.json', {'PASS': True, 'SYNTHETIC_ONLY': True, 'raw_report_sha256': hashed(raw_report), 'ArtifactName': report['ArtifactName'], 'RepoDigests': metadata['RepoDigests'], 'ImageID': metadata['ImageID'], 'architecture': metadata['ImageConfig']['architecture'], 'os': metadata['ImageConfig']['os'], 'DiffIDs': metadata['DiffIDs'], 'scope': expected['scope']})
    finally:
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            process.wait(timeout=20)
        source_after = hashed(SOURCE_DB)
        metadata_after = hashed(SOURCE_DB.with_name('metadata.json'))
        clone_after = hashed(cloned) if cloned.exists() else None
        assert source_after == before['source_sha256'] and metadata_after == before['source_metadata_sha256'] and SOURCE_DB.stat().st_mtime_ns == before['source_mtime_ns']
        assert clone_after == before['clone_sha256']
        mirror_file = ROOT / 'mirror.json'
        mirror = json.loads(mirror_file.read_text()) if mirror_file.exists() else {}
        port_closed, scanner_absent = None, None
        if 'loopback_port' in mirror:
            with socket.socket() as connection:
                connection.settimeout(1)
                port_closed = connection.connect_ex(('127.0.0.1', mirror['loopback_port'])) != 0
        if 'scan_pid' in mirror:
            try:
                os.kill(mirror['scan_pid'], 0)
                scanner_absent = False
            except ProcessLookupError:
                scanner_absent = True
        work_empty = not any((ROOT / 'work').iterdir())
        shutil.rmtree(ROOT / 'cache')
        shutil.rmtree(ROOT / 'home')
        dump('cleanup.json', {'owned_mirror_reaped': process is None or process.poll() is not None, 'owned_scanner_absent': scanner_absent, 'loopback_port_closed': port_closed, 'temporary_config_and_tool_work_empty': work_empty, 'private_COW_DB_and_cache_removed': not (ROOT / 'cache').exists(), 'foreign_DB_and_metadata_unchanged': True, 'foreign_DB_sha256': source_after, 'private_clone_unchanged_sha256': clone_after, 'cached_binary_preserved': BINARY.exists(), 'fresh_free_bytes': shutil.disk_usage(ROOT).free})
    print(json.dumps({'state': 'SYNTHETIC_CLI_TRANSPORT_IDENTITY_PASS', 'raw_report': str(ROOT / 'raw-report.json'), 'scope': expected['scope']}))

if __name__ == '__main__':
    main()
