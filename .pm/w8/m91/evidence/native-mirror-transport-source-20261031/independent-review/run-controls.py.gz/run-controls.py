import datetime,json,pathlib,subprocess
root=pathlib.Path(__file__).resolve().parent
command=['python3','-B','-m','unittest','discover','-s','.github/scripts','-p','test_native_oci_mirror.py','-v']
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/'controls.log').open('wb') as output:
 result=subprocess.run(command,cwd=root/'case',stdout=output,stderr=subprocess.STDOUT,timeout=60)
receipt={'command':command,'started_at':start,'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':result.returncode,'scope':'actual owned loopback HTTP/lifecycle and controlled scanner wrapper tests only; no real Trivy/image/runtime/CI execution'}
(root/'controls-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print((root/'controls.log').read_text())
