import json,pathlib,sys,tempfile
from unittest import mock
root=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(root/'case/.github/scripts'))
import test_native_oci_mirror as controls
case=controls.MirrorFixture('runTest');case.setUp()
original=tempfile.TemporaryDirectory
class CleanupFailure:
 def __init__(self,*args,**kwargs):self.inner=original(*args,**kwargs)
 def __enter__(self):return self.inner.__enter__()
 def __exit__(self,*args):
  self.inner.__exit__(*args)
  raise OSError('controlled owned config cleanup failure after successful mock scan')
try:
 try:
  with mock.patch.object(controls.mirror.tempfile,'TemporaryDirectory',CleanupFailure):case.run_scan()
 except controls.mirror.MirrorError as error:
  receipt=json.loads(case.proof.read_text())
  result={'source_helper_sha256':'8022371ddcc51aa7066247949ef7fa4fbf3eaec37d9ed567ff44e3c6b5359312','helper_raised':str(error),'receipt_complete':receipt['complete'],'receipt_error':receipt.get('error'),'raw_report_remains':case.output.exists(),'local_scope':'real owned loopback HTTP + controlled scanner stub; injected TemporaryDirectory cleanup OSError after actual scan exit0, not a filesystem fault or real Trivy execution','workflow_limit':'outer wrapper still sees nonzero and removes report; this is a contradictory helper failure receipt, not a demonstrated publication bypass'}
  assert receipt['complete'] is True and case.output.exists(),result
  (root/'cleanup-failure-probe-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
 else:raise AssertionError('expected cleanup failure')
finally:case.doCleanups()
