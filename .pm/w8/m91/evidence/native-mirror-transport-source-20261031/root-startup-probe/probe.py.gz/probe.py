import sys
sys.path.insert(0, '.github/scripts')
import test_native_oci_mirror as t
f=t.MirrorFixture(); f.setUp()
original=t.mirror.threading.Thread.start
calls=0
def start(thread):
 global calls
 calls+=1
 if calls==2: raise RuntimeError('controlled server-thread startup failure')
 return original(thread)
t.mirror.threading.Thread.start=start
try:
 f.run_scan()
finally:
 f.doCleanups()
