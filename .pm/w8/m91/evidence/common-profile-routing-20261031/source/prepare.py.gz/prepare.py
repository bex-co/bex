from pathlib import Path
root=Path(__file__).resolve().parent
source=root/'source'
helper=source/'.github/scripts/native-common-qualify.py'
text=helper.read_text()
insert=r'''
# These are existing Go subtests, not an arbitrary regex/timeout surface. Each
# manual run measures one case on both architectures after the full original
# cohort. Bounds come from existing command contexts, not measured capacity.
PROFILES = {
    "node": ("TestCommonNodeGeneratedImages", "BEX_NATIVE_TEST_NODE_PROFILE",
             ("node-14", "node-16", "node-18", "node-20", "node-22", "node-26",
              "node-exact14212", "ruby-node-exact14212"), 90, 120),
    "modern-python": ("TestNativeModernPythonGeneratedImages", "BEX_NATIVE_TEST_MODERN_PYTHON_PROFILE",
                      ("3.9", "3.10", "3.11", "3.12", "3.14"), 110, 140),
    "legacy-python": ("TestNativeLegacyPythonGeneratedImages", "BEX_NATIVE_LEGACY_PYTHON_INTEGRATION",
                      ("3.7", "3.8"), 110, 140),
    "ruby": ("TestCommonRubyGeneratedImages", "BEX_NATIVE_TEST_RUBY_PROFILE",
             ("ruby30", "ruby31", "ruby32", "ruby33", "ruby34", "ruby40",
              "ruby344-creation-default", "node-static-ruby34"), 75, 105),
    "go-rust": ("TestNativeGoRustGeneratedImages", "BEX_NATIVE_TEST_GORUST_PROFILE",
                ("go", "rust"), 75, 105),
    "elixir": ("TestCommonElixirOfflineQualification", "BEX_NATIVE_ELIXIR_INTEGRATION",
               ("elixir-1.18", "elixir-1.17", "elixir-1.19", "elixir-1.20",
                "elixir-exact-otp280"), 90, 120),
    "native-init": ("TestCommonNativeInitQualification", "BEX_NATIVE_TEST_INIT_PROFILE",
                    ("all-launches",), 60, 90),
}


def profile_selection(profile, case):
    """Resolve one fixed case, with the original full utility gate unchanged."""
    if profile == "utilities":
        if case not in ("pilot", "all"):
            raise ValueError("utilities always requires its complete original cohort")
        return {"profile": profile, "case": "all", "flag": "",
                "selector": "^(TestNativeUtilityGeneratedImages|TestNativeOriginalReplayHTTPOracles)$",
                "go_timeout": "150m", "job_minutes": "180",
                "scope": "complete original utility cohort; no hosted or adoption claim"}
    if profile not in PROFILES:
        raise ValueError("unknown common qualification profile")
    test, flag, cases, minutes, job_minutes = PROFILES[profile]
    selected = cases[0] if case == "pilot" else case
    if selected not in cases:
        raise ValueError("unknown case for the selected common qualification profile")
    selector = "^" + test + "$"
    if profile != "native-init":
        selector += "/^" + re.escape(selected) + "$"
    return {"profile": profile, "case": selected, "flag": flag, "selector": selector,
            "go_timeout": str(minutes) + "m", "job_minutes": str(job_minutes),
            "scope": "single-case pilot measurement only; not full-family acceptance or a capacity guarantee"}


def plan():
    event = os.environ["GITHUB_EVENT_NAME"]
    profile = os.environ.get("REQUESTED_PROFILE", "utilities")
    case = os.environ.get("REQUESTED_CASE", "pilot")
    if event not in ("push", "workflow_dispatch") or (event == "push" and profile != "utilities"):
        raise ValueError("extra profiles require an explicit manual dispatch")
    selection = profile_selection(profile, case)
    # Validate everything before opening any output or creating any resources.
    with Path(os.environ["GITHUB_OUTPUT"]).open("a") as output:
        for key in ("profile", "case", "flag", "selector", "go_timeout", "job_minutes"):
            output.write(key + "=" + selection[key] + "\n")


def profile_environment():
    selection = profile_selection(os.environ["QUALIFICATION_PROFILE"], os.environ["QUALIFICATION_CASE"])
    if selection["profile"] == "utilities":
        raise ValueError("manual profile environment cannot replace the original utility step")
    environment = {entry[1]: "0" for entry in PROFILES.values()}
    environment[selection["flag"]] = "1"
    environment.update(BEX_BUILDKIT_INTEGRATION="1", QUALIFICATION_PROFILE=selection["profile"],
                       QUALIFICATION_CASE=selection["case"], QUALIFICATION_SELECTOR=selection["selector"],
                       QUALIFICATION_GO_TIMEOUT=selection["go_timeout"])
    with Path(os.environ["GITHUB_ENV"]).open("a") as output:
        for key, value in environment.items():
            output.write(key + "=" + value + "\n")

'''
text=text.replace('\ndef initialize():\n','\n'+insert+'\ndef initialize():\n',1)
text=text.replace('def initialize():\n    ref =', 'def initialize():\n    selection = profile_selection(os.environ.get("QUALIFICATION_PROFILE", "utilities"),\n                                  os.environ.get("QUALIFICATION_CASE", "all"))\n    ref =',1)
text=text.replace('"verification": verification, "platform": platform,','"verification": verification, "platform": platform,\n                               "generator_source": os.environ["GITHUB_SHA"], "selection": selection,',1)
text=text.replace('commands.add_parser("init")','commands.add_parser("init")\n    commands.add_parser("plan")\n    commands.add_parser("profile-env")',1)
text=text.replace('if args.command == "init":\n        initialize()','if args.command == "plan":\n        plan()\n    elif args.command == "profile-env":\n        profile_environment()\n    elif args.command == "init":\n        initialize()',1)
helper.write_text(text)
workflow=source/'.github/workflows/native-common-image.yml'
text=workflow.read_text()
text=text.replace('  workflow_dispatch: {}','''  workflow_dispatch:
    inputs:
      profile:
        description: Single-case measurement after both original utility cohorts
        type: choice
        default: utilities
        options: [utilities, node, modern-python, legacy-python, ruby, go-rust, elixir, native-init]
      case:
        description: Exact allowlisted Go case, or pilot for the first case; no family-wide run
        type: string
        default: pilot''',1)
text=text.replace('jobs:\n  publish:', '''jobs:
  plan:
    if: github.ref == 'refs/heads/main'
    permissions:
      contents: read
    runs-on: [self-hosted, Linux, ARM64, bex-ci]
    timeout-minutes: 2
    outputs:
      profile: ${{ steps.selection.outputs.profile }}
      case: ${{ steps.selection.outputs.case }}
      job_minutes: ${{ steps.selection.outputs.job_minutes }}
    steps:
      - uses: actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1 # v7.0.1
        with:
          persist-credentials: false
      - id: selection
        name: validate the fixed profile and case before publication resources
        env:
          REQUESTED_PROFILE: ${{ inputs.profile || 'utilities' }}
          REQUESTED_CASE: ${{ inputs.case || 'pilot' }}
        run: python3 .github/scripts/native-common-qualify.py plan

  publish:
    needs: plan''',1)
# Preserve the entire original qualify job and utility test step unchanged.
original=text.split('  qualify:\n',1)[1]
family=original
family=family.replace('    needs: publish','    needs: [plan, publish, qualify]',1)
family=family.replace("    if: github.ref == 'refs/heads/main' && needs.publish.outputs.ref != ''", "    if: github.ref == 'refs/heads/main' && github.event_name == 'workflow_dispatch' && needs.plan.outputs.profile != 'utilities' && needs.qualify.result == 'success' && needs.publish.outputs.ref != ''",1)
family=family.replace('    timeout-minutes: 180','    timeout-minutes: ${{ fromJSON(needs.plan.outputs.job_minutes) }}',1)
owned='''      - id: owned
        name: record gated inputs and assign ownership before creating resources'''
family=family.replace(owned,'''      - name: export only the validated single-case profile environment
        env:
          QUALIFICATION_PROFILE: ${{ needs.plan.outputs.profile }}
          QUALIFICATION_CASE: ${{ needs.plan.outputs.case }}
        run: python3 .github/scripts/native-common-qualify.py profile-env
'''+owned,1)
start=family.index('      - uses: anchore/sbom-action/download-syft@')
end=family.index('      - name: record capacity observations before owned cleanup',start)
family=family[:start]+'''      - name: measure the selected family case without claiming full-family acceptance
        working-directory: lego/operator
        env:
          BEX_NATIVE_TEST_COMMON_IMAGE: ${{ needs.publish.outputs.ref }}
          BEX_NATIVE_TEST_BUILDER: ${{ steps.owned.outputs.owner }}
          BEX_NATIVE_TEST_OWNER: ${{ steps.owned.outputs.owner }}
          BEX_NATIVE_TEST_PLATFORM: linux/${{ matrix.arch }}
          BEX_NATIVE_TEST_OUTPUT: ${{ steps.owned.outputs.root }}/generated
          QUALIFICATION_ROOT: ${{ steps.owned.outputs.root }}
        run: |
          set -o pipefail
          go test -p 1 -count=1 -timeout "$QUALIFICATION_GO_TIMEOUT" ./internal/build \\
            -run "$QUALIFICATION_SELECTOR" -v \\
            2>&1 | tee "$QUALIFICATION_ROOT/qualification.log"
'''+family[end:]
family=family.replace('name: common-generated-${{ github.sha }}-${{ matrix.arch }}-${{ github.run_attempt }}','name: common-pilot-${{ needs.plan.outputs.profile }}-${{ needs.plan.outputs.case }}-${{ github.sha }}-${{ matrix.arch }}-${{ github.run_attempt }}',1)
text+='\n  qualify-profile:\n'+family
workflow.write_text(text)
print('Prepared private helper/workflow only')
