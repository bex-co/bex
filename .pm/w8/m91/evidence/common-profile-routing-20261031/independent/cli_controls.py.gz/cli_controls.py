"""Independent real CLI plan controls; no Docker/Go or resource APIs."""
import importlib.util,json,os
from pathlib import Path
import subprocess,sys,tempfile
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent
helper=root/'work/.github/scripts/native-common-qualify.py'
spec=importlib.util.spec_from_file_location('private_plan',helper);q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
expected={
 'node':('TestCommonNodeGeneratedImages',['node-14','node-16','node-18','node-20','node-22','node-26','node-exact14212','ruby-node-exact14212']),
 'modern-python':('TestNativeModernPythonGeneratedImages',['3.9','3.10','3.11','3.12','3.14']),
 'legacy-python':('TestNativeLegacyPythonGeneratedImages',['3.7','3.8']),
 'ruby':('TestCommonRubyGeneratedImages',['ruby30','ruby31','ruby32','ruby33','ruby34','ruby40','ruby344-creation-default','node-static-ruby34']),
 'go-rust':('TestNativeGoRustGeneratedImages',['go','rust']),
 'elixir':('TestCommonElixirOfflineQualification',['elixir-1.18','elixir-1.17','elixir-1.19','elixir-1.20','elixir-exact-otp280']),
 'native-init':('TestCommonNativeInitQualification',['all-launches'])}
records=[]
with tempfile.TemporaryDirectory(prefix='owned-routing-cli-control-') as temporary:
    tmp=Path(temporary)
    for profile,(test,cases) in expected.items():
        for selected in cases:
            output=tmp/('output-'+str(len(records)))
            env=dict(os.environ,GITHUB_EVENT_NAME='workflow_dispatch',REQUESTED_PROFILE=profile,REQUESTED_CASE=selected,GITHUB_OUTPUT=str(output),RUNNER_TEMP=str(tmp))
            p=subprocess.run([sys.executable,'-B',str(helper),'plan'],env=env,text=True,capture_output=True,timeout=5)
            assert p.returncode==0,(profile,selected,p.stderr)
            values=dict(line.split('=',1) for line in output.read_text().splitlines())
            selector='^'+test+'$'+('' if profile=='native-init' else '/^'+selected.replace('.','\\.').replace('-','\\-')+'$')
            assert values['profile']==profile and values['case']==selected and values['selector']==selector
            assert values['job_minutes'].isdigit() and int(values['go_timeout'][:-1])<int(values['job_minutes'])
            assert set(values)=={'profile','case','flag','selector','go_timeout','job_minutes'}
            records.append({'profile':profile,'case':selected,'selector':values['selector'],'exit':p.returncode})
    assert len(records)==31
    invalid=[('node','node-14\nINJECTED=1'),('ruby','ruby30/.*'),('utilities','pilot;echo injected'),('native-init','npm'),('NODE','pilot'),('go-rust','rust\n')]
    for i,(profile,selected) in enumerate(invalid):
        output=tmp/('invalid-'+str(i))
        env=dict(os.environ,GITHUB_EVENT_NAME='workflow_dispatch',REQUESTED_PROFILE=profile,REQUESTED_CASE=selected,GITHUB_OUTPUT=str(output),RUNNER_TEMP=str(tmp))
        p=subprocess.run([sys.executable,'-B',str(helper),'plan'],env=env,text=True,capture_output=True,timeout=5)
        assert p.returncode!=0 and not output.exists()
    assert sorted(p.name for p in tmp.iterdir())==sorted('output-'+str(i) for i in range(31))
print(json.dumps({'status':'PASS','valid_real_cli_cases':records,'invalid_real_cli_cases':len(invalid),'only_expected_output_files_created':True,'no_Go_Docker_CI_network':True},indent=2))
