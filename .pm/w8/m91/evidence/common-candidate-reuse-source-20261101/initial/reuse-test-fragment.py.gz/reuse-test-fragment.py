class ReviewedCandidateControls(unittest.TestCase):
    """Synthetic, real-filesystem admission controls; NOT real crypto or approval."""
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name).resolve()
        self.ref = "ghcr.io/bex-co/bex-cnb-run@" + IMAGE
        self.source = "a" * 40
        self.tool_bytes = {name: ("CONTROL ONLY " + name).encode() for name in qualification.V11_TOOLS}
        self.tool_hashes = {name: qualification.hashlib.sha256(raw).hexdigest() for name, raw in self.tool_bytes.items()}
        patched = patch.dict(qualification.V11_TOOLS, self.tool_hashes, clear=True)
        patched.start()
        self.addCleanup(patched.stop)
        self.env = patch.dict(os.environ, GITHUB_SHA="b" * 40, GITHUB_REF="refs/heads/main", GITHUB_EVENT_NAME="workflow_dispatch")
        self.env.start()
        self.addCleanup(self.env.stop)
        for relative in set(qualification.SOURCE_FILES) | {"deploy/" + path for path in qualification.FACTORY_PATHS}:
            self.write(relative, b"CONTROL ONLY SOURCE\n")
        for package in qualification.SOURCE_PACKAGES:
            self.write("lego/" + package + "/control.go", b"package control\n")
        self.write("lego/operator/internal/build/native.go", b"package build\n")
        self.originals = [{"mid": n, "runtime": "node" if n < 100 else "python"} for n in range(93, 106)]
        self.write("lego/operator/internal/build/testdata/native-utilities/original-cases.json", self.originals)
        inputs = qualification.source_inventory(self.root)
        self.candidate = {"ref": self.ref, "base": "buildpack-deps:bookworm@sha256:" + "d" * 64,
                          "producer": self.source, "verification": self.source,
                          "platforms": {arch: {"manifest_digest": "sha256:" + digit * 64, "config_digest": "sha256:" + digit * 64}
                                        for arch, digit in (("amd64", "c"), ("arm64", "e"))},
                          "source": {"sha": self.source, "manifest": self.evidence("source.json", {"files": inputs})}}
        job_name = "publish / build (common-bookworm, buildpack-deps:bookworm@sha256:control)"
        publication = dict(run_id=1, run_attempt=1, job_id=11)
        publication["metadata"] = self.evidence("publication.json", self.job(publication, self.source, job_name, qualification.PUBLICATION_GATES))
        self.candidate["publication"] = publication
        custody = {}
        tools = {}
        for name, raw in self.tool_bytes.items():
            original = "/retained/" + name
            custody[original] = self.evidence("tools/" + name, raw)
            tools[original] = custody[original]["sha256"]
        payloads = []
        for kind, arch in (("image-signature", None), ("sbom", "amd64"), ("sbom", "arm64"),
                           ("vulnerability", "amd64"), ("vulnerability", "arm64")):
            row = dict(kind=kind, architecture=arch)
            for field in ("full_bundle_gzip", "full_predicate_gzip"):
                original = "/retained/" + kind + "-" + str(arch) + "-" + field
                custody[original] = self.evidence(original.removeprefix("/retained/"), b"CONTROL ONLY synthetic custody bytes")
                row[field], row[field + "_sha256"] = original, custody[original]["sha256"]
            payloads.append(row)
        review = dict(ref=self.ref, official_base=self.candidate["base"], producer_workflow_sha=self.source,
                      verification_workflow_sha=self.source, approved_supplier_candidate=True,
                      anonymous_manifest_bytes_sha_verified=True, strict_keyless_signature_and_sbom_and_vulnerability_attestations_verified=True,
                      strict_actual_Rekor_v2_and_RFC3161_TSA_verified=True, wrong_source_and_subject_negative_checks_rejected=True,
                      anonymous_pull={"all_unique_config_and_layer_bytes_fully_hashed": True},
                      producer_verification_provenance={"mode": "fresh-build", "producer_sha": self.source, "verification_sha": self.source},
                      platforms=self.candidate["platforms"], evidence_tool_sha256=tools, signed_payloads=payloads,
                      ci_runtime_scan_signing_evidence={"run_id": "1", "job_id": 11, "job_name": job_name,
                                                      "job_conclusion": "success", "verified_steps": sorted(qualification.PUBLICATION_GATES)})
        fixed = dict(schema="bex.native-common-review-plan/v1", name="common-bookworm", ref=self.ref,
                     base=self.candidate["base"], producer_sha=self.source, verification_sha=self.source,
                     factory_inputs={"deploy/" + path: inputs["deploy/" + path] for path in qualification.FACTORY_PATHS},
                     selection_inputs={path: inputs[path] for path in ("deploy/native-common/matrix.py", "deploy/native-common/upstream.json")},
                     freshness_sha256=inputs["scripts/lib/toolchain-freshness.py"]["sha256"], run_id=1, job_id=11)
        self.candidate["approval"] = dict(receipt=self.evidence("review.json", review), plan=self.evidence("plan.json", fixed),
                                          custody=self.evidence("custody.json", {"files": custody}))
        self.candidate["utilities"] = {arch: self.utility(arch, 20 + n) for n, arch in enumerate(("amd64", "arm64"))}
        self.save()

    def write(self, relative, value):
        path = self.root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(value if isinstance(value, bytes) else (json.dumps(value) + "\n").encode())
        return path

    def evidence(self, name, value):
        path = self.write(".pm/w8/m91/evidence/CONTROL-ONLY/" + name, value)
        return {"path": str(path.relative_to(self.root)), "sha256": qualification.sha(path), "bytes": path.stat().st_size}

    def save(self):
        self.write(qualification.CANDIDATE_PATH, {"schema": qualification.CANDIDATE_SCHEMA, "candidate": self.candidate})

    def job(self, identity, source, name, gates):
        return {"id": identity["job_id"], "run_id": identity["run_id"], "run_attempt": identity["run_attempt"],
                "head_sha": source, "head_branch": "main", "name": name, "status": "completed", "conclusion": "success",
                "run_url": "https://api.github.com/repos/bex-co/bex/actions/runs/" + str(identity["run_id"]),
                "steps": [{"name": gate, "status": "completed", "conclusion": "success"} for gate in sorted(gates)]}

    def utility(self, arch, job_id):
        row = dict(run_id=2, run_attempt=1, job_id=job_id, artifact_id=100 + job_id)
        row["metadata"] = self.evidence(arch + "-job.json", self.job(row, self.source, "qualify (" + arch + ")", {qualification.UTILITY_GATE}))
        row["artifact_metadata"] = self.evidence(arch + "-artifact.json", {"id": row["artifact_id"],
            "name": "common-generated-" + self.source + "-" + arch + "-1", "workflow_run": {"id": 2, "head_sha": self.source}})
        row["root"] = ".pm/w8/m91/evidence/CONTROL-ONLY/" + arch
        records = []
        def put(path, value):
            actual = self.write(row["root"] + "/" + path, value)
            records.append({"path": path, "sha256": qualification.sha(actual), "bytes": actual.stat().st_size})
        put("inputs.json", dict(common_image=self.ref, producer=self.source, verification=self.source, generator_source=self.source,
                                platform="linux/" + arch, run_id="2", run_attempt="1", selection=qualification.profile_selection("utilities", "all")))
        put("qualification.log", b"CONTROL ONLY complete host fixture\n")
        put("cleanup.json", {"CONTROL_ONLY": True})
        prefix = "generated/native-utilities-control/"
        for case in ("node-compute", "node-static", "python313-original", "python3148-default"):
            put(prefix + case + "/receipt.json", dict(common_base=self.ref, image_platform="linux/" + arch, image_config_id=IMAGE,
                network="none", runtime_command_executed=case != "node-static", static_artifacts_extracted=case == "node-static"))
        for name in ("jq", "rsync", "python-metadata", "python-pip", "python-headers"):
            put(prefix + "missing-" + name + "/omission-receipt.json", dict(removed_supplier=name, common_base=self.ref,
                healthy_independent_prerequisites_observed=True, original_command_expected_failure_observed=True))
        for case in self.originals:
            name = "node-compute" if case["runtime"] == "node" else "python313-original"
            put(prefix + name + "/qa-output/build-" + str(case["mid"]) + ".log", b"CONTROL ONLY authored build log")
            put(prefix + name + "/qa-output/runtime-" + str(case["mid"]) + "-runtime.json", [{"pass": True}] * 3)
        custody = {}
        for kind in ("syft", "spdx"):
            custody[kind] = {"roundtrip": True}
            for form in ("raw", "gzip"):
                name = "generated-" + kind + "." + form
                put(prefix + "python3148-default/" + name, b"CONTROL ONLY full report")
                custody[kind].update({form + "_file": name, form + "_sha256": records[-1]["sha256"], form + "_bytes": records[-1]["bytes"]})
        put(prefix + "python3148-default/generated-spdx-binding.json", dict(platform="linux/" + arch, python="3.14.8",
            image_config_id=IMAGE, syft_manifest_digest=MANIFEST, libbrotli1_versions=["CONTROL ONLY"], custody=custody))
        path = self.write(row["root"] + "/MANIFEST.json", {"files": records, "scope": "CONTROL ONLY"})
        row["manifest"] = {"path": str(path.relative_to(self.root)), "sha256": qualification.sha(path), "bytes": path.stat().st_size}
        return row

    def rewrite_evidence(self, descriptor, mutate):
        path = self.root / descriptor["path"]
        value = json.loads(path.read_text())
        mutate(value)
        path.write_text(json.dumps(value))
        descriptor.update(sha256=qualification.sha(path), bytes=path.stat().st_size)
        self.save()

    def test_real_filesystem_positive_pm_only_and_receipt_exclusion(self):
        self.write(".pm/w8/m91/README.md", b"new PM-only commit")
        self.write("lego/go.work.sum", b"outside GOWORK=off")
        actual = qualification.validate_test_candidate(self.root)
        self.assertEqual(actual["producer"], self.source)
        self.assertEqual(actual["generator_source"], "b" * 40)
        self.assertEqual(actual["receipt_sha256"], qualification.sha(self.root / qualification.CANDIDATE_PATH))
        self.assertNotIn(qualification.CANDIDATE_PATH, qualification.source_inventory(self.root))

    def test_source_add_delete_bytes_mode_and_helper_changes_reject(self):
        path = self.root / "lego/operator/internal/build/native.go"
        before = path.read_bytes()
        changes = (lambda: path.write_bytes(b"changed"), lambda: path.chmod(0o755), lambda: path.unlink(),
                   lambda: self.write("lego/operator/internal/build/new-helper.py", b"added"))
        for change in changes:
            with self.subTest(change=change):
                path.write_bytes(before); path.chmod(0o644)
                added = self.root / "lego/operator/internal/build/new-helper.py"
                added.unlink(missing_ok=True)
                change()
                with self.assertRaises((ValueError, FileNotFoundError)):
                    qualification.validate_test_candidate(self.root)

    def test_null_and_unreviewed_ref_or_identity_reject(self):
        self.write(qualification.CANDIDATE_PATH, {"schema": qualification.CANDIDATE_SCHEMA, "candidate": None})
        with self.assertRaises(ValueError): qualification.validate_test_candidate(self.root)
        for field, value in (("ref", "ghcr.io/bex-co/bex-cnb-run:latest"), ("verification", "c" * 40)):
            old = self.candidate[field]
            self.candidate[field] = value; self.save()
            with self.assertRaises(ValueError): qualification.validate_test_candidate(self.root)
            self.candidate[field] = old

    def test_tampered_retained_evidence_rejects(self):
        for descriptor in (self.candidate["approval"]["receipt"], self.candidate["approval"]["custody"],
                           self.candidate["source"]["manifest"], self.candidate["utilities"]["amd64"]["manifest"]):
            with self.subTest(path=descriptor["path"]):
                path = self.root / descriptor["path"]; before = path.read_bytes(); path.write_bytes(before + b" ")
                with self.assertRaises(ValueError): qualification.validate_test_candidate(self.root)
                path.write_bytes(before)

    def test_wrong_v11_subject_flags_platform_and_report_custody_reject(self):
        descriptor = self.candidate["approval"]["receipt"]
        original = (self.root / descriptor["path"]).read_bytes()
        original_descriptor = dict(descriptor)
        for mutate in (lambda x: x.update(ref="ghcr.io/bex-co/bex-cnb-run@sha256:" + "f" * 64),
                       lambda x: x.update(strict_actual_Rekor_v2_and_RFC3161_TSA_verified=False),
                       lambda x: x["platforms"]["amd64"].update(config_digest="sha256:" + "f" * 64),
                       lambda x: x["signed_payloads"][0].update(full_bundle_gzip_sha256="f" * 64)):
            self.rewrite_evidence(descriptor, mutate)
            with self.assertRaises(ValueError): qualification.validate_test_candidate(self.root)
            (self.root / descriptor["path"]).write_bytes(original); descriptor.update(original_descriptor)

    def test_wrong_job_arch_artifact_and_old_source_reject(self):
        descriptor = self.candidate["utilities"]["amd64"]["metadata"]
        original = (self.root / descriptor["path"]).read_bytes(); original_descriptor = dict(descriptor)
        for mutate in (lambda x: x.update(conclusion="failure"), lambda x: x.update(status="in_progress"),
                       lambda x: x.update(head_sha="f" * 40), lambda x: x.update(name="qualify (arm64)"),
                       lambda x: x.update(run_attempt=2), lambda x: x["steps"][0].update(conclusion="skipped")):
            self.rewrite_evidence(descriptor, mutate)
            with self.assertRaises(ValueError): qualification.validate_test_candidate(self.root)
            (self.root / descriptor["path"]).write_bytes(original); descriptor.update(original_descriptor)
        self.candidate["utilities"]["amd64"]["artifact_id"] += 1; self.save()
        with self.assertRaises(ValueError): qualification.validate_test_candidate(self.root)

    def test_missing_arch_required_proof_or_full_report_reject(self):
        utility = self.candidate["utilities"].pop("arm64"); self.save()
        with self.assertRaises(ValueError): qualification.validate_test_candidate(self.root)
        self.candidate["utilities"]["arm64"] = utility
        descriptor = self.candidate["utilities"]["amd64"]["manifest"]
        self.rewrite_evidence(descriptor, lambda x: x.update(files=[row for row in x["files"] if not row["path"].endswith("/missing-jq/omission-receipt.json")]))
        with self.assertRaises(ValueError): qualification.validate_test_candidate(self.root)

    def test_init_revalidates_before_creds_outputs_or_resources(self):
        with patch.object(qualification, "validate_test_candidate", side_effect=ValueError("changed after plan")), \
             patch.object(qualification.tempfile, "mkdtemp", side_effect=AssertionError("no resources")):
            env = dict(QUALIFICATION_PROFILE="node", QUALIFICATION_CASE="node-14", QUALIFICATION_SOURCE="reviewed-candidate",
                       COMMON_IMAGE=self.ref, PRODUCER_SHA=self.source, VERIFICATION_SHA=self.source, TARGET_PLATFORM="linux/arm64")
            with patch.dict(os.environ, env), self.assertRaisesRegex(ValueError, "changed after plan"):
                qualification.initialize()

    def test_branch_table_never_heals_failed_fresh_and_init_records_reuse(self):
        for mode in ("fresh", "reviewed-candidate", "unknown"):
            for publish in ("success", "skipped", "failure", "cancelled"):
                for utilities in ("success", "skipped", "failure", "cancelled"):
                    for valid in (False, True):
                        expected = (mode == "fresh" and publish == utilities == "success") or (mode == "reviewed-candidate" and valid and publish == utilities == "skipped")
                        self.assertEqual(qualification.profile_admitted(mode, publish, utilities, valid), expected)
        candidate = qualification.validate_test_candidate(self.root)
        env = dict(QUALIFICATION_PROFILE="node", QUALIFICATION_CASE="node-14", QUALIFICATION_SOURCE="reviewed-candidate",
                   COMMON_IMAGE=self.ref, PRODUCER_SHA=self.source, VERIFICATION_SHA=self.source, TARGET_PLATFORM="linux/arm64",
                   CANDIDATE_RECEIPT_SHA256=candidate["receipt_sha256"], RUNNER_TEMP=str(self.root), GITHUB_RUN_ID="3", GITHUB_RUN_ATTEMPT="1",
                   GITHUB_OUTPUT=str(self.root / "outputs"), GITHUB_ENV=str(self.root / "environment"))
        with patch.dict(os.environ, env), patch.object(qualification, "validate_test_candidate", return_value=candidate):
            qualification.initialize()
        outputs = dict(line.split("=", 1) for line in (self.root / "outputs").read_text().splitlines())
        actual = json.loads((Path(outputs["root"]) / "inputs.json").read_text())
        self.assertEqual(actual["candidate_receipt_sha256"], candidate["receipt_sha256"])
        self.assertEqual(actual["utility_baseline_source"], self.source)
        self.assertEqual(actual["generator_source"], "b" * 40)
        self.assertEqual(actual["utility_jobs"], candidate["utilities"])


