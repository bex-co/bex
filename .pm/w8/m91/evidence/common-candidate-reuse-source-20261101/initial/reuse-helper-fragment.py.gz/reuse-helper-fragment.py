# A checked-in receipt authorizes TEST-ONLY reuse of one already reviewed image.
# It does not perform or replace the retained V11 cryptographic/blob review.
CANDIDATE_PATH = ".github/native-common-test-candidate.json"
CANDIDATE_SCHEMA = "bex.native-common-test-candidate/v1"
V11_TOOLS = {
    "loopx-w8-native-review-v11.py": "ea03d2a9c7a21fde50c0d55f6ead84910c2c431f8c7b52c490624fc5ff8bff85",
    "loopx-w8-verify-native-artifact-ranged.py": "ca4a765d547b92f567f7e08149183a8cb094249d544ae594655c92b93d09ae15",
}
FACTORY_PATHS = (
    "native-base/bex-native-python-tools", "native-base/fetch-python-tools.py",
    "native-base/install-python-tools.py", "native-base/install.sh", "native-base/node-brotli/check.js",
    "native-base/node-brotli/patch.sh", "native-base/package-lock.json", "native-base/package.json",
    "native-base/patch-system-brotli.sh", "native-base/python-tools.json", "native-base/tsc", "native-base/webpack",
    "native-common/Dockerfile", "native-common/Dockerfile.dockerignore", "native-common/build-otp",
    "native-common/check-common.py", "native-common/legacy-libs.preferences", "native-common/legacy-libs.sources",
    "native-common/otp-features.py", "native-common/prepare-node14-tools.py",
)
SOURCE_PACKAGES = (
    "operator/cmd/native-init", "operator/internal/execution", "operator/internal/execution/executiontest",
    "operator/internal/httpclient", "operator/internal/identity", "operator/internal/publish",
    "operator/internal/registry", "types/k8sname", "types/netutil", "types/v1alpha1",
)
SOURCE_FILES = (
    "lego/operator/go.mod", "lego/operator/go.sum", "lego/types/go.mod", "lego/types/go.sum",
    "lego/.dockerignore", "lego/Dockerfile", "deploy/native-base/testdata/archive.dump.b64",
    "deploy/native-base/testdata/archive.sql", "deploy/native-base/testdata/rows.txt",
    "deploy/native-common/check-runtime.py", "deploy/native-base/check-primary-python.py",
    "deploy/native-base/check-brotli.py", ".github/workflows/native-base-image.yml",
    ".github/workflows/native-common-image.yml", ".github/scripts/native-common-qualify.py",
    ".github/scripts/test_native_oci_common_qualification.py", ".github/scripts/native-oci-stage.py",
    ".github/scripts/native-oci-mirror.py", "deploy/native-common/matrix.py", "deploy/native-common/upstream.json",
    "scripts/lib/toolchain-freshness.py",
)
PUBLICATION_GATES = {
    "verify real native tool transformations without network on both architectures",
    "scan amd64 candidate", "scan arm64 candidate", "sign and attest the immutable candidate",
    "expose the fully gated immutable image",
    "Run docker/build-push-action@53b7df96c91f9c12dcc8a07bcb9ccacbed38856a",
}
UTILITY_GATE = "actual generated offline builds, original replays and exact-default SPDX"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate receipt key")
        result[key] = value
    return result


def json_file(path):
    require(path.stat().st_size <= 4 * 1024 * 1024, "receipt metadata exceeds bound")
    return json.loads(path.read_text(), object_pairs_hook=unique_object)


def regular_path(root, relative):
    require(isinstance(relative, str) and relative and not relative.startswith("/")
            and all(x not in ("", ".", "..") for x in relative.split("/")), "invalid retained path")
    path = root
    for part in relative.split("/"):
        path /= part
        require(not path.is_symlink(), "retained source/evidence symlink")
    require(path.is_file(), "missing retained source/evidence: " + relative)
    return path


def file_identity(path):
    return {"sha256": sha(path), "bytes": path.stat().st_size,
            "mode": "100755" if path.stat().st_mode & 0o111 else "100644"}


def source_inventory(root):
    """Exact functional set; receipt/evidence/PM prose are deliberately excluded."""
    paths = set(SOURCE_FILES) | {"deploy/" + path for path in FACTORY_PATHS}
    build = root / "lego/operator/internal/build"
    require(build.is_dir() and not build.is_symlink(), "missing build source root")
    paths.update(str(p.relative_to(root)) for p in build.rglob("*") if not p.is_dir() or p.is_symlink())
    for package in SOURCE_PACKAGES:
        directory = root / "lego" / package
        require(directory.is_dir() and not directory.is_symlink(), "missing local source package")
        files = list(directory.glob("*.go"))
        require(files, "empty local source package")
        paths.update(str(p.relative_to(root)) for p in files)
    return {path: file_identity(regular_path(root, path)) for path in sorted(paths)}


def evidence_file(root, descriptor):
    require(isinstance(descriptor, dict) and set(descriptor) == {"path", "sha256", "bytes"}, "bad evidence descriptor")
    require(descriptor["path"].startswith(".pm/w8/m91/evidence/")
            and re.fullmatch(r"[a-f0-9]{64}", descriptor["sha256"] or "")
            and type(descriptor["bytes"]) is int and descriptor["bytes"] >= 0, "bad evidence identity")
    path = regular_path(root, descriptor["path"])
    require(path.stat().st_size == descriptor["bytes"] and sha(path) == descriptor["sha256"], "retained evidence differs")
    return path


def evidence_json(root, descriptor):
    return json_file(evidence_file(root, descriptor))


def completed_job(root, descriptor, identity, source, name, gates):
    metadata = evidence_json(root, descriptor)
    jobs = metadata.get("jobs", [metadata])
    jobs = [row for row in jobs if row.get("id") == identity["job_id"]]
    require(len(jobs) == 1, "missing or ambiguous actual job")
    job = jobs[0]
    require(all(type(identity[key]) is int and identity[key] > 0 for key in ("run_id", "run_attempt", "job_id")), "bad job identity")
    require(job.get("run_id") == identity["run_id"] and job.get("run_attempt") == identity["run_attempt"]
            and job.get("head_sha") == source and job.get("head_branch") == "main"
            and job.get("name") == name and job.get("status") == "completed" and job.get("conclusion") == "success"
            and job.get("run_url") == "https://api.github.com/repos/bex-co/bex/actions/runs/" + str(identity["run_id"]),
            "actual job/source/status differs")
    rows = job.get("steps", [])
    steps = {row["name"]: row for row in rows}
    require(len(steps) == len(rows) and gates <= steps.keys()
            and all(steps[name].get("status") == "completed" and steps[name].get("conclusion") == "success" for name in gates),
            "actual required job gate incomplete")
    return job


def validate_test_candidate(root=None):
    root = Path(root) if root is not None else Path(__file__).resolve().parents[2]
    record = json_file(regular_path(root, CANDIDATE_PATH))
    require(set(record) == {"schema", "candidate"} and record["schema"] == CANDIDATE_SCHEMA
            and isinstance(record["candidate"], dict), "no reviewed test candidate authorization")
    c = record["candidate"]
    require(set(c) == {"ref", "base", "producer", "verification", "publication", "platforms", "approval", "source", "utilities"},
            "unknown or missing test candidate fields")
    require(re.fullmatch(r"ghcr.io/bex-co/bex-cnb-run@sha256:[a-f0-9]{64}", c["ref"])
            and re.fullmatch(r"buildpack-deps:bookworm@sha256:[a-f0-9]{64}", c["base"])
            and re.fullmatch(r"[a-f0-9]{40}", c["producer"])
            and c["producer"] == c["verification"], "invalid immutable common provenance")
    require(set(c["platforms"]) == {"amd64", "arm64"}, "both actual platforms required")
    for platform in c["platforms"].values():
        require(set(platform) == {"manifest_digest", "config_digest"}
                and all(IMAGE.fullmatch(value) for value in platform.values()), "bad common platform identity")
    baseline = c["source"]
    require(set(baseline) == {"sha", "manifest"} and re.fullmatch(r"[a-f0-9]{40}", baseline["sha"]), "bad utility baseline source")
    expected = evidence_json(root, baseline["manifest"])
    require(set(expected) == {"files"} and expected["files"] == source_inventory(root), "stale qualification source set/bytes/modes")
    approval = c["approval"]
    require(set(approval) == {"receipt", "custody", "plan"}, "bad retained approval fields")
    review, custody, fixed = (evidence_json(root, approval[key]) for key in ("receipt", "custody", "plan"))
    require(review.get("ref") == fixed.get("ref") == c["ref"] and review.get("official_base") == fixed.get("base") == c["base"]
            and review.get("producer_workflow_sha") == fixed.get("producer_sha") == c["producer"]
            and review.get("verification_workflow_sha") == fixed.get("verification_sha") == c["verification"], "V11 subject/source/base differs")
    require(fixed.get("schema") == "bex.native-common-review-plan/v1" and fixed.get("name") == "common-bookworm", "not a common V11 review")
    factory = {"deploy/" + path: expected["files"]["deploy/" + path] for path in FACTORY_PATHS}
    selection = {path: expected["files"][path] for path in ("deploy/native-common/matrix.py", "deploy/native-common/upstream.json")}
    require(fixed.get("factory_inputs") == factory and fixed.get("selection_inputs") == selection
            and fixed.get("freshness_sha256") == expected["files"]["scripts/lib/toolchain-freshness.py"]["sha256"], "V11 factory/selection policy differs")
    require(all(review.get(key) is True for key in ("approved_supplier_candidate", "anonymous_manifest_bytes_sha_verified",
            "strict_keyless_signature_and_sbom_and_vulnerability_attestations_verified",
            "strict_actual_Rekor_v2_and_RFC3161_TSA_verified", "wrong_source_and_subject_negative_checks_rejected"))
            and review.get("anonymous_pull", {}).get("all_unique_config_and_layer_bytes_fully_hashed") is True,
            "retained strict V11 review incomplete")
    provenance = review.get("producer_verification_provenance", {})
    require(provenance.get("producer_sha") == c["producer"] and provenance.get("verification_sha") == c["verification"]
            and provenance.get("mode") == "fresh-build", "retained producer/verifier relabeled")
    require(set(review.get("platforms", {})) == {"amd64", "arm64"}
            and all(all(review["platforms"][arch].get(key) == value for key, value in c["platforms"][arch].items()) for arch in c["platforms"]),
            "V11 platform identities differ")
    require(isinstance(custody, dict) and set(custody) == {"files"}, "missing portable full custody manifest")
    files = custody["files"]
    for descriptor in files.values():
        evidence_file(root, descriptor)
    tools = review.get("evidence_tool_sha256", {})
    for name, digest in V11_TOOLS.items():
        matches = [path for path, observed in tools.items() if Path(path).name == name and observed == digest]
        require(len(matches) == 1 and matches[0] in files and files[matches[0]]["sha256"] == digest, "retained V11 tool differs")
    payloads = review.get("signed_payloads", [])
    require(len(payloads) == 5 and {(row.get("kind"), row.get("architecture")) for row in payloads} == {
        ("image-signature", None), ("sbom", "amd64"), ("sbom", "arm64"), ("vulnerability", "amd64"), ("vulnerability", "arm64")},
        "complete signed image/SBOM/Trivy set required")
    for row in payloads:
        for key in ("full_bundle_gzip", "full_predicate_gzip"):
            require(row.get(key) in files and files[row[key]]["sha256"] == row.get(key + "_sha256"), "full signed report custody missing")
    pub = c["publication"]
    require(set(pub) == {"run_id", "run_attempt", "job_id", "metadata"}, "bad publication identity")
    ci = review.get("ci_runtime_scan_signing_evidence", {})
    require(str(pub["run_id"]) == ci.get("run_id") and pub["job_id"] == ci.get("job_id")
            and fixed.get("run_id") == pub["run_id"] and fixed.get("job_id") == pub["job_id"]
            and ci.get("job_name", "").startswith("publish / build (common-bookworm, ")
            and ci.get("job_conclusion") == "success" and PUBLICATION_GATES - {next(x for x in PUBLICATION_GATES if x.startswith("Run "))} <= set(ci.get("verified_steps", [])),
            "V11 actual publication provenance differs")
    completed_job(root, pub["metadata"], pub, c["verification"], ci["job_name"], PUBLICATION_GATES)
    require(set(c["utilities"]) == {"amd64", "arm64"}, "both original utility architectures required")
    for arch, utility in c["utilities"].items():
        require(set(utility) == {"run_id", "run_attempt", "job_id", "artifact_id", "metadata", "root", "manifest"}
                and type(utility["artifact_id"]) is int and utility["artifact_id"] > 0, "bad utility artifact identity")
        completed_job(root, utility["metadata"], utility, baseline["sha"], "qualify (" + arch + ")", {UTILITY_GATE})
        prefix = utility["root"] + "/"
        require(prefix.startswith(".pm/w8/m91/evidence/") and utility["manifest"]["path"] == prefix + "MANIFEST.json", "utility artifact scope differs")
        artifact = evidence_json(root, utility["manifest"])
        entries = artifact.get("files", [])
        retained = {row["path"]: row for row in entries}
        require(len(retained) == len(entries) and {"inputs.json", "qualification.log", "cleanup.json"} <= retained.keys(), "incomplete original utility artifacts")
        for path, row in retained.items():
            evidence_file(root, {"path": prefix + path, "sha256": row["sha256"], "bytes": row["bytes"]})
        inputs = json_file(regular_path(root, prefix + "inputs.json"))
        require(inputs.get("common_image") == c["ref"] and inputs.get("producer") == c["producer"]
                and inputs.get("verification") == c["verification"] and inputs.get("generator_source") == baseline["sha"]
                and inputs.get("platform") == "linux/" + arch and inputs.get("run_id") == str(utility["run_id"])
                and inputs.get("run_attempt") == str(utility["run_attempt"])
                and inputs.get("selection") == profile_selection("utilities", "all"), "utility inputs/selector/source differ")
        require(any(path.endswith("/python3148-default/generated-spdx-binding.json") for path in retained)
                and all(any(path.endswith("/missing-" + name + "/omission-receipt.json") for path in retained)
                        for name in ("jq", "rsync", "python-metadata", "python-pip", "python-headers")), "required exact-default/omission proof absent")
    return dict(c, receipt_sha256=sha(root / CANDIDATE_PATH), generator_source=os.environ["GITHUB_SHA"])


def profile_admitted(mode, publish, utilities, validated):
    """Mirror the workflow's explicit branch table; failed fresh never falls back."""
    return ((mode == "fresh" and publish == "success" and utilities == "success")
            or (mode == "reviewed-candidate" and validated and publish == utilities == "skipped"))


