"""Independent synthetic source/receipt probes; no candidate approval or crypto."""
import copy,hashlib,importlib.util,json,pathlib,sys
HERE=pathlib.Path(__file__).resolve().parent
p=HERE/'work/.github/scripts/test_native_oci_common_qualification.py'
s=importlib.util.spec_from_file_location('controls',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
results=[]
def run(name, mutate):
 c=m.ReviewedCandidateControls();c.setUp()
 try:
  m.qualification.validate_test_candidate(c.root)
  details=mutate(c)
  try:
   m.qualification.validate_test_candidate(c.root)
   result={'accepted':True}
  except Exception as e: result={'accepted':False,'exception':type(e).__name__,'error':str(e)}
  results.append({'name':name,**details,**result})
 finally:c.doCleanups()
def extra(c):
 d=c.candidate['approval']['receipt']
 def change(x):
  row=copy.deepcopy(x['signed_payloads'][0])
  custody_descriptor=c.candidate['approval']['custody']
  custody_path=c.root/custody_descriptor['path']; custody=json.loads(custody_path.read_text())
  for key in ('full_bundle_gzip','full_predicate_gzip'):
   original='/retained/additional-image-signature-'+key
   descriptor=c.evidence('additional-image-signature-'+key,b'CONTROL ONLY distinct additional fully custodied synthetic payload')
   custody['files'][original]=descriptor;row[key]=original;row[key+'_sha256']=descriptor['sha256']
  custody_path.write_text(json.dumps(custody));custody_descriptor.update(sha256=m.qualification.sha(custody_path),bytes=custody_path.stat().st_size)
  x['signed_payloads'].append(row)
 c.rewrite_evidence(d,change)
 return {'all_required_pairs_present':True,'all_six_rows_custodied':True,'additional_pair':['image-signature',None],'basis':'V11 finish checks image_count>=1 and both arch report sets; retains every signed statement, with no len==5 gate.'}
def adapter(c):
 d=c.candidate['approval']['receipt']
 c.rewrite_evidence(d,lambda x:x['evidence_tool_sha256'].update({'/retained/common-v11-adapter.py':'f'*64}))
 return {'adapter_expected_sha256':'920f3bb8a9d7473933517f96029e6e722dd16c968c28f1c6d6edb27082d400a6','adapter_observed_sha256':'f'*64,'adapter_custody_present':False,'basis':'CommonReview constructor records adapter+plan tool hashes; validator checks only two original tools.'}
def pyc(c):
 path='lego/operator/internal/build/testdata/native-utilities/__pycache__/original-cases.cpython-314.pyc'
 c.write(path,b'CONTROL ONLY untracked bytecode')
 return {'added_path':path,'functional_source_changed':False,'basis':'source_inventory includes every non-directory under build; arbitrary generated entries join exact functional set.'}
run('sixth_accepted_signed_payload',extra);run('wrong_uncustodied_common_adapter_tool',adapter);run('generated_untracked_pyc',pyc)
(HERE/'PROBES.json').write_text(json.dumps({'scope':'Synthetic real filesystem controls only, not real candidate proof, crypto or runtime','results':results},indent=2)+'\n')
print(json.dumps(results,indent=2))
