'use strict';
// New observation fixture only: no production launcher or original program change.
var fs = require('fs');
var cp = require('child_process');
function run(file, args) {
  var r = cp.spawnSync(file, args, {encoding: 'utf8', timeout: 3000, maxBuffer: 65536});
  return {file: file, args: args, exit: r.status, signal: r.signal,
    error: r.error ? String(r.error.code || r.error.message) : null,
    stdout: r.stdout || '', stderr: r.stderr || ''};
}
function fileView(file) {
  if (!file) return {literal: file || null, exists: false};
  try { var st = fs.statSync(file); return {literal: file, exists: true,
    realpath: fs.realpathSync(file), mode: st.mode & 511, bytes: st.size}; }
  catch (e) { return {literal: file, exists: false, error: String(e.code || e.message)}; }
}
var configured = process.env.npm_config_node_gyp || null;
var env = {};
['PATH', 'NODE', 'npm_node_execpath', 'npm_execpath', 'npm_config_node_gyp',
 'npm_lifecycle_event', 'npm_package_name', 'HOME', 'PNPM_HOME'].forEach(function (k) {
  env[k] = Object.prototype.hasOwnProperty.call(process.env, k) ? process.env[k] : null;
});
var configuredResult = null;
if (configured && fileView(configured).exists) {
  configuredResult = /\.js$/.test(configured) ? run(process.execPath, [configured, '--version']) : run(configured, ['--version']);
}
var result = {kind: process.argv[2] || 'unknown', process_version: process.version,
  exec_path: process.execPath, exec_realpath: fs.realpathSync(process.execPath),
  environment: env, path_node: run('/bin/sh', ['-c', 'command -v node']),
  gyp: {path_resolution: run('/bin/sh', ['-c', 'command -v node-gyp']),
    path_invocation: run('node-gyp', ['--version']), configured: fileView(configured),
    configured_invocation: configuredResult}};
console.log('BEX_PNPM_OBSERVER=' + JSON.stringify(result));
