"""Pure host controls. Never invokes Docker, downloads or external fixture programs."""
from pathlib import Path
import contextlib, copy, gzip, hashlib, importlib.util, io, json, os, sys, tarfile
import tempfile, threading, time, unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('bounded_pnpm_controller',HERE/'controller.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

class FakeBudget:
    def __init__(self,root):self.root=Path(root);self.lock=threading.RLock();self.cid=None;self.records={};self.fail=False
    def check(self):pass
    def reserve(self,*args):pass
    def checkpoint(self):pass
    def json(self,rel,value):
        if self.fail:raise OSError('synthetic output failure')
        self.records[rel]=copy.deepcopy(value)
        self.write(rel,c.encoded(value))
    def write(self,rel,raw):
        f=self.root/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw)

class FakeDocker:
    def __init__(self,nonce='0'*16,labels_good=True,rm_good=True):
        self.calls=[];self.exists=True;self.labels_good=labels_good;self.rm_good=rm_good;self.nonce=nonce
    def capture(self,argv,**kwargs):
        self.calls.append(argv)
        if argv[:2]==['docker','stop']:return {'exit':0,'stdout':'stopped','stderr':''}
        if argv[:2]==['docker','rm']:
            if self.rm_good:self.exists=False
            return {'exit':0 if self.rm_good else 1,'stdout':'','stderr':'' if self.rm_good else 'synthetic remove failure'}
        if argv[:2]==['docker','inspect']:
            if '--size' in argv:return {'exit':0,'stdout':'0\n','stderr':''}
            if not self.exists:return {'exit':1,'stdout':'','stderr':'Error: No such object: '+argv[-1]}
            frame={'Id':'a'*64,'Name':'/bex-w8-pnpm-'+self.nonce+'-node14','Image':c.BASE,'Labels':{'bex.owner':c.OWNER,'bex.nonce':self.nonce if self.labels_good else 'foreign','bex.case':'node14'}}
            return {'exit':0,'stdout':json.dumps(frame),'stderr':''}
        raise AssertionError('unexpected fake command:'+str(argv))

@contextlib.contextmanager
def scratch():
    with tempfile.TemporaryDirectory(prefix='host-control-',dir=HERE) as directory:yield Path(directory)

def tar_bytes(items):
    data=io.BytesIO()
    with tarfile.open(fileobj=data,mode='w') as tar:
        for name,body,link in items:
            member=tarfile.TarInfo(name);member.mode=0o755 if link else 0o644
            if link:member.type=tarfile.SYMTYPE;member.linkname=link
            else:member.size=len(body)
            tar.addfile(member,None if link else io.BytesIO(body))
    return gzip.compress(data.getvalue(),mtime=0)

def result(stdout='',exit=0):return {'stdout':stdout,'stderr':'','exit':exit}
def observed(kind='lifecycle',version='v14.21.3',gyp=True):
    return {'kind':kind,'process_version':version,'exec_realpath':'/opt/appnode/bin/node','environment':{'NODE':None},'gyp':{'path_resolution':{'exit':0},'path_invocation':{'exit':0 if gyp else 1},'configured':{'literal':None,'exists':False},'configured_invocation':None}}
def config_result(prepend=False):
    raw={'only-built-dependencies':[c.OBSERVER_DEP_PATH],'engine-strict':True,'side-effects-cache':False,'ignore-scripts':False,'manage-package-manager-versions':True,'dangerously-allow-all-builds':False}
    if prepend:raw['scripts-prepend-node-path']=True
    return result(json.dumps(raw))

def root_engine_result(version='14.21.3'):
    return result('ERR_PNPM_UNSUPPORTED_ENGINE\nYour Node version is incompatible with "/work/'+c.ROOT_ENGINE_SENTINEL+'".\n\nExpected version: >=18\nGot: '+version+'\n',1)

def synthetic_results():
    d={}
    for name,kind in [('baseline','lifecycle'),('exec','exec'),('run','run'),('path-prepend-install','lifecycle'),('path-prepend-run','run'),('seeded','lifecycle'),('explicit-override','lifecycle')]:
        row=observed(kind)
        if name=='seeded':row['environment']['NODE']='/opt/appnode/bin/node'
        if name=='explicit-override':row['environment']['NODE']='/opt/appnode/bin/../bin/node'
        d[name]=result('BEX_PNPM_OBSERVER='+json.dumps(row)+'\n')
    d['wrong-engine-root']=root_engine_result()
    d['local-file-engine-observation']=result('local file tarball accepted',0)
    d['effective-config-baseline']=config_result();d['effective-config-path-prepend']=config_result(True)
    return d

class Controls(unittest.TestCase):
    def test_amended_budget_and_unchanged_frozen_inputs(self):
        _,identity=c.verified_plan();self.assertEqual(2,len(identity['node']))
        self.assertEqual(1543503872,c.START_FREE);self.assertEqual(1207959552,c.STOP_FREE)
        self.assertEqual(301989888,c.STOP_TOTAL)
    def test_low_free_stops_before_root_network_or_process(self):
        with patch.object(c,'verified_plan',return_value=({},{})),patch.object(c,'free_bytes',return_value=1),patch.object(c.Path,'mkdir',side_effect=AssertionError('mkdir')),patch.object(c.subprocess,'Popen',side_effect=AssertionError('process')),patch.object(c.urllib.request,'urlopen',side_effect=AssertionError('network')):
            with self.assertRaisesRegex(c.Stop,'startfree'):c.execute()
    def test_inflight_archive_counts_in_correct_component(self):
        self.assertEqual('pnpm_archive',c.component('archives/pnpm.tgz.part'))
        self.assertEqual('node_archives',c.component('archives/node/node14.xz.part'))
    def test_command_timeout_reaps_own_child(self):
        with scratch() as root:
            r=c.Runner(FakeBudget(root)).capture([sys.executable,'-c','import time;time.sleep(5)'],timeout=.08)
            self.assertEqual(124,r['exit']);self.assertEqual('timeout',r['bound']);self.assertLess(r['seconds'],1)
    def test_noisy_command_is_bounded(self):
        with scratch() as root:
            r=c.Runner(FakeBudget(root)).capture([sys.executable,'-c','import os;os.write(1,b"x"*600000)'])
            self.assertEqual(124,r['exit']);self.assertEqual(512*1024,len(r['stdout']));self.assertEqual('512KiB output bound',r['bound'])
    def test_registration_precedes_artifact_failure_and_cleanup_still_runs(self):
        with scratch() as root:
            b=FakeBudget(root);d=FakeDocker();registry=c.Registry(root,b,d,'0'*16);intent=registry.intent('node14');b.fail=True
            with self.assertRaises(OSError):registry.adopt(intent,'a'*64)
            self.assertEqual('a'*64,intent['cid'])
            with self.assertRaisesRegex(c.Stop,'artifact_write_after_cleanup'):registry.cleanup()
            self.assertFalse(d.exists);self.assertEqual('deleted',intent['state'])
            self.assertTrue(any(x[:2]==['docker','stop'] for x in d.calls));self.assertTrue(any(x[:2]==['docker','rm'] for x in d.calls))
    def test_unknown_create_reconciles_exact_name_labels_and_config(self):
        with scratch() as root:
            b=FakeBudget(root);d=FakeDocker();registry=c.Registry(root,b,d,'0'*16);intent=registry.intent('node14');registry.cleanup()
            self.assertEqual('a'*64,intent['cid']);self.assertEqual('deleted',intent['state']);self.assertFalse(d.exists)
    def test_foreign_binding_refused_without_stop_or_remove(self):
        with scratch() as root:
            b=FakeBudget(root);d=FakeDocker(labels_good=False);registry=c.Registry(root,b,d,'0'*16);registry.intent('node14')
            with self.assertRaises(c.Stop):registry.cleanup()
            self.assertFalse(any(x[:2] in (['docker','stop'],['docker','rm']) for x in d.calls))
    def test_failed_remove_retains_raw_receipts_and_open_state(self):
        with scratch() as root:
            b=FakeBudget(root);d=FakeDocker(rm_good=False);registry=c.Registry(root,b,d,'0'*16);intent=registry.intent('node14')
            with self.assertRaises(c.Stop):registry.cleanup()
            self.assertNotEqual('deleted',intent['state']);self.assertEqual(1,b.records['meta/cleanup.json']['receipts'][0]['remove']['exit'])
    def test_transport_failure_is_not_absence(self):
        self.assertFalse(c.absent({'exit':1,'stderr':'Cannot connect to Docker daemon'},'a'*64))
    def test_traversal_and_escaping_link_rejected(self):
        for entries in [[('package/../escape',b'x',None)],[('package/link',b'','../../escape')]]:
            with scratch() as root:
                archive=root/'input.tgz';archive.write_bytes(tar_bytes(entries));b=FakeBudget(root)
                with self.assertRaises(c.Stop):c.extract(archive,root/'dest','package','pnpm',b,lambda _:True)
                self.assertFalse((root/'escape').exists())
    def test_original_bytes_modes_and_internal_links_preserved(self):
        with scratch() as root:
            archive=root/'input.tgz';archive.write_bytes(tar_bytes([('package/bin/program',b'original',None),('package/program',b'','bin/program')]))
            entries=c.extract(archive,root/'dest','package','pnpm',FakeBudget(root),lambda _:True)
            self.assertEqual(b'original',(root/'dest/bin/program').read_bytes());self.assertEqual('bin/program',os.readlink(root/'dest/program'))
            self.assertEqual(hashlib.sha256(b'original').hexdigest(),entries[0]['sha256'])
    def test_partial_download_never_qualifies_or_renames(self):
        class Reply(io.BytesIO):
            status=200;url='https://nodejs.org/dist/fixture.xz'
        with scratch() as root:
            target=root/'archives/node/test.xz'
            with patch.object(c.urllib.request,'urlopen',return_value=Reply(b'short')):
                with self.assertRaises(AssertionError):c.download(Reply.url,target,20,FakeBudget(root),exact_size=10)
            self.assertFalse(target.exists());self.assertTrue(target.with_suffix('.xz.part').exists())
    def test_deterministic_local_dependency_and_matching_root(self):
        a=c.fixture_tar('bex-pnpm-engine-sentinel','>=18',False);self.assertEqual(a,c.fixture_tar('bex-pnpm-engine-sentinel','>=18',False))
        with tarfile.open(fileobj=io.BytesIO(a),mode='r:gz') as tar:
            package=json.load(tar.extractfile('package/package.json'));self.assertEqual('>=18',package['engines']['node'])
        with scratch() as root:
            b=FakeBudget(root);c.make_fixtures(root,b,14)
            self.assertEqual('14.x',b.records['work/wrong-engine/package.json']['engines']['node'])
            self.assertEqual('pnpm@10.34.7',b.records['work/baseline/package.json']['packageManager'])
            self.assertIn('bex-pnpm-engine-sentinel',b.records['work/wrong-engine/package.json']['dependencies'])
            self.assertEqual('file:/fixtures/bex-pnpm-engine-sentinel.tgz',b.records['work/wrong-engine/package.json']['dependencies']['bex-pnpm-engine-sentinel'])
            self.assertIn(b'side-effects-cache=false',(root/'work/baseline/.npmrc').read_bytes())
            self.assertEqual(("packages:\n  - '.'\nonlyBuiltDependencies:\n  - "+c.OBSERVER_DEP_PATH+"\n").encode(),(root/'work/baseline/pnpm-workspace.yaml').read_bytes())
    def test_fresh_elf_architecture_required(self):
        with scratch() as root:
            f=root/'wrong';f.write_bytes(b'\x7fELF\x02\x01'+b'\0'*12+b'\x3e\0')
            with self.assertRaises(AssertionError):c.elf_arm64(f)
    def test_strict_engine_reason_and_real_observer_required(self):
        d=synthetic_results();self.assertEqual('PASS',c.assess(d,'14.21.3')['viability'])
        d['wrong-engine-root']=result('arbitrary filesystem failure',1);self.assertEqual('UNPROVED',c.assess(d,'14.21.3')['viability'])
        d=synthetic_results();d['baseline']=result('no observer',0);self.assertEqual('UNPROVED',c.assess(d,'14.21.3')['viability'])
    def test_seeded_comparison_cannot_heal_baseline_gyp_or_wrong_node(self):
        d=synthetic_results();d['baseline']=result('BEX_PNPM_OBSERVER='+json.dumps(observed(gyp=False)))
        self.assertEqual('FAIL',c.assess(d,'14.21.3')['viability']);self.assertEqual(0,c.assess(d,'14.21.3')['NODE_comparisons']['seeded']['exit'])
        d['baseline']=result('BEX_PNPM_OBSERVER='+json.dumps(observed(version='v24.0.0')));self.assertEqual('FAIL',c.assess(d,'14.21.3')['viability'])
    def test_configured_missing_gyp_is_visible_failure(self):
        row=observed();row['gyp']['configured']={'literal':'/missing/actual-gyp','exists':False};self.assertFalse(c.default_gyp_usable(row))
    def test_phase_marker_and_explicit_NODE_are_not_interchangeable(self):
        d=synthetic_results();d['exec']=result('BEX_PNPM_OBSERVER='+json.dumps(observed('lifecycle')))
        self.assertEqual('UNPROVED',c.assess(d,'14.21.3')['viability'])
        d=synthetic_results();row=observed();row['environment']['NODE']='/private/changed-node'
        d['explicit-override']=result('BEX_PNPM_OBSERVER='+json.dumps(row));self.assertEqual('FAIL',c.assess(d,'14.21.3')['viability'])
    def test_truncated_arm64_header_is_refused(self):
        with scratch() as root:
            f=root/'truncated';f.write_bytes(b'\x7fELF\x02\x01\x01'+b'\0'*11+b'\xb7')
            with self.assertRaises(AssertionError):c.elf_arm64(f)
    def test_unknown_create_name404_does_not_claim_final_cleanup(self):
        with scratch() as root:
            b=FakeBudget(root);d=FakeDocker();d.exists=False
            registry=c.Registry(root,b,d,'0'*16);intent=registry.intent('node14');intent['create_attempted']=True
            with self.assertRaisesRegex(c.Stop,'later reconciliation'):registry.cleanup()
            self.assertNotEqual('deleted',intent['state'])
            self.assertFalse(any(x[:2] in (['docker','stop'],['docker','rm']) for x in d.calls))
    def test_component_and_inflight_free_guards_stop_before_write(self):
        with scratch() as root,patch.object(c,'free_bytes',return_value=5*1024**3):
            b=c.Budget(root)
            with self.assertRaisesRegex(c.Stop,'component cap'):b.reserve('node',c.CAPS['node']+1)
            self.assertEqual(0,b.counts['node'])
            b.error='synthetic active guard stop'
            with self.assertRaises(c.Stop):b.write('outputs/must-not-exist',b'x')
            self.assertFalse((root/'outputs/must-not-exist').exists())
        with scratch() as root,patch.object(c,'free_bytes',return_value=c.STOP_FREE):
            with self.assertRaisesRegex(c.Stop,'physical free'):c.Budget(root).write('outputs/no',b'x')
    def exited_leader_probe(self,mode):
        with scratch() as root:
            ids=root/'owned-processes.json';closed=mode=='normal-background'
            code=("import json,os,subprocess,sys; "
                  "child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(20)'],"
                  +("stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL" if closed else "")+") ; "
                  "open(sys.argv[1],'w').write(json.dumps({'leader':os.getpid(),'child':child.pid,'pgid':os.getpgrp()})); "
                  "print('owned exited leader',flush=True)")
            actual=c.subprocess.Popen;leaders=[]
            def launch(*args,**kwargs):
                process=actual(*args,**kwargs);leaders.append(process);return process
            budget=FakeBudget(root);started=time.monotonic()
            if mode=='guard':
                def check():
                    if time.monotonic()-started>.15:raise c.Stop('synthetic running guard Stop')
                budget.check=check
            result=None;error=None;proof={'mode':mode};caught=None
            try:
                with patch.object(c.subprocess,'Popen',side_effect=launch):
                    if mode=='guard':
                        with self.assertRaisesRegex(c.Stop,'synthetic running guard'):c.Runner(budget).capture([sys.executable,'-c',code,str(ids)],timeout=1)
                        error='synthetic running guard Stop propagated'
                    else:result=c.Runner(budget).capture([sys.executable,'-c',code,str(ids)],timeout=.15 if not closed else 1)
                identity=json.loads(ids.read_text());self.assertEqual(0,leaders[0].returncode)
                self.assertEqual(leaders[0].pid,identity['leader']);self.assertEqual(leaders[0].pid,identity['pgid'])
                with self.assertRaises(ProcessLookupError):os.killpg(identity['pgid'],0)
                with self.assertRaises(ProcessLookupError):os.kill(identity['child'],0)
                if result:
                    self.assertEqual(124,result['exit']);self.assertTrue(result['group_cleanup']['group_absent'])
                    self.assertEqual('unexpected background descendant' if closed else 'timeout',result['bound'])
                proof.update(identity=identity,leader_reaped=leaders[0].poll() is not None,leader_exit=leaders[0].returncode,child_absent=True,group_absent=True,result=result,guard_error=error)
            except BaseException as failure:
                caught=failure;proof['failure']=type(failure).__name__+': '+str(failure)
            finally:
                if ids.exists():proof['identity']=json.loads(ids.read_text())
                cleanup=[]
                for process in leaders:
                    signal_error=None
                    try:os.killpg(process.pid,c.signal.SIGKILL)
                    except ProcessLookupError:pass
                    except PermissionError:signal_error='EPERM pending group absence'
                    process.wait(timeout=2);deadline=time.monotonic()+2
                    while c.group_exists(process.pid) and time.monotonic()<deadline:time.sleep(.01)
                    cleanup.append({'own_pgid':process.pid,'leader_reaped':process.poll() is not None,'group_absent':not c.group_exists(process.pid),'signal_error':signal_error})
                proof['test_finally_cleanup']=cleanup
                (HERE/('probe-'+mode+'.json')).write_text(json.dumps(proof,indent=2)+'\n')
            if caught:raise caught
    def test_exited_leader_pipeholder_timeout_group_is_absent(self):self.exited_leader_probe('timeout')
    def test_exited_leader_pipeholder_guard_group_is_absent(self):self.exited_leader_probe('guard')
    def test_normal_completion_cleans_unintended_background_group(self):self.exited_leader_probe('normal-background')
    def test_inflight_late_sampler_error_reaches_final_status_after_restore(self):
        with scratch() as root:
            budget=c.Budget(root);entered=threading.Event();events=['owned cleanup completed']
            def sample():
                entered.set();budget.done.wait(timeout=1)
                raise c.Stop('synthetic in-flight sampler error after cleanup completed')
            budget.sample=sample;budget.start();self.assertTrue(entered.wait(timeout=1))
            with patch.object(c.signal,'signal',side_effect=lambda number,handler:events.append(['restored',number,handler])):
                failure=c.finish_monitor(budget,{c.signal.SIGINT:'prior-handler'},None)
            self.assertFalse(budget.thread.is_alive());self.assertIn('synthetic in-flight sampler error',failure)
            self.assertEqual('owned cleanup completed',events[0]);self.assertEqual(['restored',c.signal.SIGINT,'prior-handler'],events[1])
            (HERE/'probe-late-monitor.json').write_text(json.dumps({'final_failure':failure,'watcher_error':budget.error,'thread_stopped':not budget.thread.is_alive(),'events':events,'scope':'Actual Budget.start/close and final status helper; no resource overflow/full experiment.'},indent=2)+'\n')
    def test_unfinished_monitor_cannot_report_success(self):
        class Thread:
            def join(self,timeout):pass
            def is_alive(self):return True
        with scratch() as root:
            budget=c.Budget(root);budget.thread=Thread();failure=c.finish_monitor(budget,{},None)
            self.assertIn('capacity monitor',failure);self.assertIn('did not stop',failure)
    def test_container_inventory_preserves_baseline_and_identifies_additions(self):
        class Inventory:
            def __init__(self):self.calls=[]
            def capture(self,args,**kwargs):self.calls.append(args);return result('a'*64+'\n'+'b'*64+'\n')
        runner=Inventory();before,_=c.container_inventory(runner)
        self.assertEqual([['docker','ps','--all','--no-trunc','--format','{{.ID}}']],runner.calls)
        after=before+['d'*64];intents=[{'case':'node14','name':'own-name','cid':'c'*64,'state':'deleted'}]
        report=c.compare_container_ids(before,after,intents)
        self.assertTrue(report['foreign_baseline_ids_present']);self.assertTrue(report['own_cids_absent']);self.assertEqual(['d'*64],report['concurrent_additions']);self.assertEqual([],report['concurrent_removals'])
    def test_container_inventory_reports_removals_and_owned_remainders_without_repair(self):
        before=['a'*64,'b'*64];after=['a'*64,'c'*64,'d'*64]
        report=c.compare_container_ids(before,after,[{'case':'node14','name':'own-name','cid':'c'*64,'state':'created'}])
        self.assertFalse(report['foreign_baseline_ids_present']);self.assertEqual(['b'*64],report['concurrent_removals']);self.assertEqual(['d'*64],report['concurrent_additions'])
        self.assertFalse(report['own_cids_absent']);self.assertEqual(['c'*64],report['own_remaining_ids']);self.assertEqual('created',report['unresolved_own_intents'][0]['state'])
    def test_container_inventory_rejects_invalid_or_duplicate_ids(self):
        class Inventory:
            def capture(self,args,**kwargs):return result('a'*64+'\n'+'a'*64+'\n')
        with self.assertRaisesRegex(c.Stop,'invalid/unbounded'):c.container_inventory(Inventory())
    def test_unknown_group_permission_state_never_counts_as_absence(self):
        class Process:
            pid=999999;returncode=0
            def poll(self):return 0
            def wait(self,timeout):return 0
        with patch.object(c.os,'killpg',side_effect=PermissionError('synthetic unknown group')),patch.object(c.time,'monotonic',side_effect=[0,3]):
            with self.assertRaisesRegex(c.Stop,'absence unproved'):c.terminate_owned_group(Process())
    def test_exact_local_artifact_approval_and_effective_config_are_required(self):
        valid=config_result();self.assertTrue(c.effective_config(valid)['valid'])
        raw=json.loads(valid['stdout']);raw['only-built-dependencies']=['bex-pnpm-node-observer']
        self.assertFalse(c.effective_config(result(json.dumps(raw)))['valid'])
        raw=json.loads(valid['stdout']);raw['dangerously-allow-all-builds']=True
        self.assertFalse(c.effective_config(result(json.dumps(raw)))['valid'])
        raw=json.loads(valid['stdout']);raw['node-version']='14.21.3'
        self.assertFalse(c.effective_config(result(json.dumps(raw)))['valid'])
    def test_root_engine_diagnostic_binds_cwd_range_and_selected_patch(self):
        self.assertTrue(c.root_engine_refusal(root_engine_result(),'14.21.3'))
        self.assertTrue(c.root_engine_refusal(root_engine_result('v14.21.3'),'14.21.3'))
        self.assertFalse(c.root_engine_refusal(root_engine_result('24.0.0'),'14.21.3'))
        r=root_engine_result();r['stdout']=r['stdout'].replace('/work/'+c.ROOT_ENGINE_SENTINEL,'/other/project')
        self.assertFalse(c.root_engine_refusal(r,'14.21.3'))
    def test_ignored_lifecycle_never_becomes_an_observed_gyp_failure(self):
        d=synthetic_results()
        for name in ['baseline','seeded','explicit-override','path-prepend-install']:d[name]=result('Ignored build scripts: bex-pnpm-node-observer',0)
        report=c.assess(d,'14.21.3');self.assertEqual('UNPROVED',report['viability']);self.assertEqual('UNEXERCISED',report['lifecycle_default_gyp']['state'])
        self.assertFalse(any('default gyp' in text for text in report['failures']));self.assertEqual('UNEXERCISED',report['NODE_comparisons']['seeded']['state'])
    def test_first_actual_raw_skips_reinterpret_as_unexercised_without_mutation(self):
        source=Path('/private/tmp/bex-w8-pnpm-small-live-55629e18e4c13b80/meta/node14-observations.json');before=source.read_bytes();data=json.loads(before)
        report=c.assess(data,'14.21.3');self.assertEqual('UNPROVED',report['viability']);self.assertEqual('UNEXERCISED',report['lifecycle_default_gyp']['state'])
        self.assertTrue(report['run_exec_gyp_observations']['run']);self.assertEqual(before,source.read_bytes())
    def test_local_tarball_observation_cannot_replace_root_engine_control(self):
        d=synthetic_results();d['local-file-engine-observation']=result('accepted',0)
        self.assertEqual('PASS',c.assess(d,'14.21.3')['viability'])
        d['wrong-engine-root']=result('arbitrary failure',1);d['local-file-engine-observation']=root_engine_result()
        self.assertEqual('UNPROVED',c.assess(d,'14.21.3')['viability'])
    def test_new_root_engine_fixture_retains_old_tarball_observation(self):
        with scratch() as root:
            b=FakeBudget(root);proof=c.make_fixtures(root,b,14)
            negative=b.records['work/'+c.ROOT_ENGINE_SENTINEL+'/package.json'];self.assertEqual('>=18',negative['engines']['node'])
            self.assertEqual(c.ROOT_ENGINE_SENTINEL,negative['name']);self.assertIn('bex-pnpm-node-observer',negative['dependencies'])
            self.assertEqual('14.x',b.records['work/wrong-engine/package.json']['engines']['node'])
            self.assertEqual(c.OBSERVER_DEP_PATH,proof['exact_artifact_approval'])
            self.assertEqual('/work/'+c.ROOT_ENGINE_SENTINEL,proof['projects'][c.ROOT_ENGINE_SENTINEL]['cwd'])
    def reuse_fixture(self,root,changed=False):
        source_root=root/'retained';source=source_root/'archives/pnpm.tgz';source.parent.mkdir(parents=True);body=b'synthetic qualified archive bytes';source.write_bytes(body)
        hashes={name:hashlib.new(name,body).hexdigest() for name in ['sha256','sha1','sha512']}
        receipt=source_root/'meta/qualification.json';receipt.parent.mkdir();receipt.write_text(json.dumps(hashes))
        proof={'source':str(source),'url':'https://registry.npmjs.org/@pnpm/linux-arm64/-/linux-arm64-10.34.7.tgz','bytes':len(body),**hashes,'receipt_path':str(receipt),'receipt_sha256':hashlib.sha256(receipt.read_bytes()).hexdigest()}
        metadata=root/'metadata';metadata.mkdir();plan={'exact_source_root':str(source_root),'entries':{'archives/pnpm.tgz':proof}};(metadata/'REUSE-PLAN.json').write_text(json.dumps(plan))
        if changed:source.write_bytes(b'X'+body[1:])
        return source,metadata,proof
    def test_qualified_reuse_physically_copies_readonly_and_rechecks_without_network(self):
        with scratch() as root:
            source,metadata,proof=self.reuse_fixture(root);before=source.read_bytes();mode=source.stat().st_mode;live=root/'new-live';live.mkdir();b=FakeBudget(live)
            with patch.object(c,'HERE',metadata),patch.object(c,'REUSE_PLAN_SHA',c.digest(metadata/'REUSE-PLAN.json')),patch.object(c.urllib.request,'urlopen',side_effect=AssertionError('network')):
                receipt=c.stage_archive(proof['url'],live/'archives/pnpm.tgz',1024,b,reuse=True,sha1=proof['sha1'],sri='sha512-'+__import__('base64').b64encode(bytes.fromhex(proof['sha512'])).decode())
            target=live/'archives/pnpm.tgz';self.assertEqual(before,target.read_bytes());self.assertEqual(before,source.read_bytes());self.assertEqual(mode,source.stat().st_mode)
            self.assertNotEqual(source.stat().st_ino,target.stat().st_ino);self.assertEqual(0o444,target.stat().st_mode&0o777);self.assertTrue(receipt['retained_original_not_modified'])
    def test_qualified_reuse_rejects_changed_body_before_final_target(self):
        with scratch() as root:
            source,metadata,proof=self.reuse_fixture(root,changed=True);live=root/'new-live';live.mkdir();b=FakeBudget(live)
            with patch.object(c,'HERE',metadata),patch.object(c,'REUSE_PLAN_SHA',c.digest(metadata/'REUSE-PLAN.json')),patch.object(c.urllib.request,'urlopen',side_effect=AssertionError('network')):
                with self.assertRaisesRegex(c.Stop,'copy hash/size mismatch'):c.stage_archive(proof['url'],live/'archives/pnpm.tgz',1024,b,reuse=True)
            self.assertFalse((live/'archives/pnpm.tgz').exists());self.assertTrue((live/'archives/pnpm.tgz.part').exists())
    def test_root_engine_requires_completed_canonical_exit_one(self):
        valid=root_engine_result();valid.update(bound=None,signal=None)
        self.assertTrue(c.root_engine_refusal(valid,'14.21.3'))
        for code in [2,124,-9,True]:
            incomplete=copy.deepcopy(valid);incomplete['exit']=code
            self.assertFalse(c.root_engine_refusal(incomplete,'14.21.3'))
    def test_engine_timeout_partial_diagnostic_cannot_pass(self):
        d=synthetic_results();d['wrong-engine-root'].update(exit=124,bound='timeout')
        self.assertFalse(c.root_engine_refusal(d['wrong-engine-root'],'14.21.3'))
        report=c.assess(d,'14.21.3');self.assertEqual('UNPROVED',report['root_engine_control']);self.assertEqual('UNPROVED',report['viability'])
    def test_engine_signal_partial_diagnostic_cannot_pass(self):
        for code,signal_value in [(-15,'SIGTERM'),(1,'SIGTERM')]:
            d=synthetic_results();d['wrong-engine-root'].update(exit=code,signal=signal_value)
            self.assertFalse(c.root_engine_refusal(d['wrong-engine-root'],'14.21.3'))
            self.assertEqual('UNPROVED',c.assess(d,'14.21.3')['viability'])
    def test_engine_resource_bound_partial_diagnostic_cannot_pass(self):
        for bound in ['512KiB output bound','resource guard','timeout']:
            d=synthetic_results();d['wrong-engine-root'].update(exit=1,bound=bound)
            self.assertFalse(c.root_engine_refusal(d['wrong-engine-root'],'14.21.3'))
            self.assertEqual('UNPROVED',c.assess(d,'14.21.3')['viability'])
    def test_frozen_review_counterexample_is_now_unproved(self):
        path=HERE/'history/V3/engine-timeout-counterexample.json';proof=json.loads(path.read_text())
        d=synthetic_results();d['wrong-engine-root']=proof['input_negative']
        report=c.assess(d,'14.21.3');self.assertNotEqual('PASS',report['root_engine_control']);self.assertEqual('UNPROVED',report['viability'])
    def test_actual_one_second_host_sampler_includes_own_sizerw(self):
        with scratch() as root,patch.object(c,'free_bytes',return_value=5*1024**3):
            d=FakeDocker();b=c.Budget(root,d);b.cid='a'*64;b.start()
            deadline=time.monotonic()+3.5
            while len(b.samples)<3 and time.monotonic()<deadline:time.sleep(.02)
            b.close();self.assertIsNone(b.error);self.assertGreaterEqual(len(b.samples),3)
            self.assertEqual(len(b.samples),len(d.calls));gaps=[b.samples[i]['elapsed']-b.samples[i-1]['elapsed'] for i in range(1,len(b.samples))]
            self.assertTrue(all(.8<=g<=1.3 for g in gaps));self.assertTrue(all(x['actual_bytes']['daemon']==0 for x in b.samples))

if __name__=='__main__':unittest.main(verbosity=2)
