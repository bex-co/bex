'use strict';
var fs = require('fs');
var cp = require('child_process');
var base = '/opt/appnode/lib/node_modules/npm/node_modules/node-gyp';
var result = {comparison_only: true, selected_node: process.version, exec_path: process.execPath};
try {
  result.package_version = JSON.parse(fs.readFileSync(base + '/package.json', 'utf8')).version;
  result.path = base + '/bin/node-gyp.js';
  var r = cp.spawnSync(process.execPath, [result.path, '--version'], {encoding:'utf8',timeout:3000,maxBuffer:65536});
  result.exit = r.status; result.signal = r.signal;
  result.error = r.error ? String(r.error.code || r.error.message) : null;
  result.stdout = r.stdout || ''; result.stderr = r.stderr || '';
} catch (e) { result.error = String(e.code || e.message); result.exit = null; }
console.log('BEX_BUNDLED_GYP_COMPARISON=' + JSON.stringify(result));
