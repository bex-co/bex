"""Bounded, explicitly invoked pnpm/legacy-Node observation. Import has no actions."""
from pathlib import Path, PurePosixPath
import argparse, base64, gzip, hashlib, io, json, lzma, math
import os, re, secrets, selectors, shutil, signal, subprocess, tarfile
import threading, time, urllib.request

HERE = Path(__file__).resolve().parent
PLAN_ROOT = Path('/private/tmp/bex-w8-pnpm-small-plan-20261031-vogaks3c')
PLAN_SHA = '026007e252be901b270b87c42f0b59cc7309f6f0fdbdf1a4a965e4df9061453f'
MANIFEST_SHA = '39765f507ae703ad2c32270038d4b8666ca7d62086ea6d88a166f8b4ef4a919e'
BASE = 'sha256:26ad49adcb6923b3faa00ee6654943de9bdda7cfcb1c42a9b9cef334a48dfb33'
OWNER = 'w8-pnpm-viability'
MIB = 1024 * 1024
FLOOR, MARGIN, CAP = 1024**3, 128 * MIB, 320 * MIB
START_FREE, STOP_FREE, STOP_TOTAL = FLOOR + MARGIN + CAP, FLOOR + 128 * MIB, 288 * MIB
CAPS = {'node_archives':48*MIB,'pnpm_archive':32*MIB,'pnpm':64*MIB,
        'node':112*MIB,'work':16*MIB,'outputs':8*MIB,'meta':4*MIB,'daemon':16*MIB}
AMENDMENT_SHA = '26a62d137c7578ae1d6a44f1eb76ea5c63d7b2bf66279677fd5db3fee3536a8f'
OBSERVER_DEP_PATH = 'bex-pnpm-node-observer@file:../../fixtures/bex-pnpm-node-observer.tgz'
ROOT_ENGINE_SENTINEL = 'bex-pnpm-engine-root-sentinel'
REUSE_PLAN_SHA = 'cc5482df39a1496d1133b06e6a4b66db2c2f342071c39d96d41b020a6ea4358b'
PNPM_SHA = 'c57bafc919110f5b942b7778bff0f2170a896d6dc0952c2ff042ca1e228655c3'
CID_RE = re.compile(r'[0-9a-f]{64}\Z')

class Stop(RuntimeError): pass

def encoded(value): return (json.dumps(value, separators=(',',':'), sort_keys=True)+'\n').encode()
def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(65536),b''): h.update(b)
    return h.hexdigest()
def free_bytes():
    s=os.statvfs('/private/tmp');return s.f_bavail*s.f_frsize

def verified_plan():
    assert digest(HERE/'BUDGET-AMENDMENT.json')==AMENDMENT_SHA
    amendment=json.loads((HERE/'BUDGET-AMENDMENT.json').read_text())
    assert (amendment['new_global_reserve_bytes'],amendment['own_cap_bytes'],amendment['new_fresh_start_bytes'],amendment['stop_physical_free_bytes'])==(FLOOR,CAP,START_FREE,STOP_FREE)
    assert digest(PLAN_ROOT/'execution-plan.json')==PLAN_SHA
    assert digest(PLAN_ROOT/'MANIFEST.json')==MANIFEST_SHA
    for rel,proof in json.loads((PLAN_ROOT/'MANIFEST.json').read_text()).items():
        f=PLAN_ROOT/rel;assert f.is_file() and f.stat().st_size==proof['bytes'] and digest(f)==proof['sha256']
    return json.loads((PLAN_ROOT/'execution-plan.json').read_text()),json.loads((PLAN_ROOT/'input-identity.json').read_text())

def component(rel):
    p=PurePosixPath(rel);s=str(p)
    if p.parts[:2]==('archives','node'):return 'node_archives'
    if s in ('archives/pnpm.tgz','archives/pnpm.tgz.part'):return 'pnpm_archive'
    if p.parts[:2]==('inputs','pnpm'):return 'pnpm'
    if p.parts[:2]==('inputs','node'):return 'node'
    if p.parts and p.parts[0] in ('work','outputs'):return p.parts[0]
    return 'meta'

def measured(root):
    totals={k:0 for k in CAPS}
    for parent,dirs,files in os.walk(root,followlinks=False):
        for name in dirs+files:
            f=Path(parent)/name;s=f.lstat();n=max(s.st_size,s.st_blocks*512)
            totals[component(f.relative_to(root).as_posix())]+=n
    return totals

class Budget:
    def __init__(self,root,runner=None):
        self.root=Path(root);self.lock=threading.RLock();self.counts=measured(root)
        self.runner=runner;self.cid=None;self.error=None;self.done=threading.Event()
        self.started=time.monotonic();self.thread=None;self.samples=[]
    def check(self):
        if self.error:raise Stop(self.error)
        if free_bytes()<=STOP_FREE:raise Stop('physical free reached1GiB+128MiB')
        if time.monotonic()-self.started>420:raise Stop('whole experiment420s deadline')
    def reserve(self,key,size):
        with self.lock:
            self.check();amount=max(4096,math.ceil(size/4096)*4096)
            if self.counts[key]+amount>CAPS[key]:raise Stop('component cap:'+key)
            if sum(self.counts.values())+amount>=STOP_TOTAL:raise Stop('own288MiB stop margin')
            self.counts[key]+=amount
    def write(self,rel,raw):
        key=component(rel);self.reserve(key,len(raw));f=self.root/rel
        f.parent.mkdir(parents=True,exist_ok=True);temp=f.with_name(f.name+'.tmp')
        temp.write_bytes(raw);temp.replace(f)
    def json(self,rel,value):self.write(rel,encoded(value))
    def checkpoint(self):
        with self.lock:
            actual=measured(self.root);actual['daemon']=self.counts.get('daemon',0)
            self.counts=actual;self.check()
            for key,n in actual.items():
                if n>CAPS[key]:raise Stop('measured component cap:'+key)
            if sum(actual.values())>=STOP_TOTAL:raise Stop('measured own288MiB stop margin')
    def sample(self):
        with self.lock:
            actual=measured(self.root);rw=0
            if self.cid:
                r=self.runner.capture(['docker','inspect','--size','--format','{{.SizeRw}}',self.cid],timeout=.6,guarded=False)
                if r['exit'] or not re.fullmatch(r'\d+\s*',r['stdout']):raise Stop('own SizeRw sample unavailable')
                rw=int(r['stdout'])
            actual['daemon']=rw
            for key,n in actual.items():
                self.counts[key]=max(self.counts[key],n)
                if n>CAPS[key]:raise Stop('sample component cap:'+key)
            self.check()
            if sum(actual.values())>=STOP_TOTAL:raise Stop('sample own288MiB stop margin')
            row={'elapsed':round(time.monotonic()-self.started,3),'physical_free':free_bytes(),'actual_bytes':actual,'reserved_bytes':dict(self.counts),'owned_cid':self.cid}
            raw=encoded(row);self.reserve('outputs',len(raw));f=self.root/'outputs/capacity.jsonl';f.parent.mkdir(exist_ok=True)
            with f.open('ab') as out:out.write(raw)
            self.samples.append(row)
    def start(self):
        def watch():
            deadline=time.monotonic()
            while not self.done.is_set():
                try:self.sample()
                except BaseException as e:self.error=type(e).__name__+': '+str(e);return
                deadline+=1;self.done.wait(max(0,deadline-time.monotonic()))
        self.thread=threading.Thread(target=watch,name='own-capacity-1s',daemon=True);self.thread.start()
    def close(self):
        self.done.set()
        if self.thread:self.thread.join(timeout=2)
        if self.thread and self.thread.is_alive():self.error=(self.error+'; ' if self.error else '')+'capacity monitor did not stop'
        return self.error

def finish_monitor(budget,handlers,failure):
    late=None
    try:late=budget.close()
    except BaseException as error:late='monitor close failed:'+str(error)
    finally:
        for signum,handler in handlers.items():signal.signal(signum,handler)
    late=budget.error or late
    if budget.thread and budget.thread.is_alive():late=(late+'; ' if late else '')+'capacity monitor still running'
    return ((failure+'; ' if failure else '')+'capacity_monitor:'+late) if late else failure

def group_exists(pgid):
    try:os.killpg(pgid,0);return True
    except ProcessLookupError:return False
    except PermissionError:return True  # Unknown/pending is never absence.

def terminate_owned_group(process):
    pgid=process.pid
    if pgid<=1 or pgid==os.getpgrp():raise Stop('invalid owned process group')
    leader_exited=process.poll() is not None
    present=group_exists(pgid)
    signal_error=None
    try:os.killpg(pgid,signal.SIGKILL)
    except ProcessLookupError:pass
    except PermissionError:signal_error='EPERM; absence must still be proven'
    try:process.wait(timeout=2)
    except subprocess.TimeoutExpired:raise Stop('direct child could not be reaped; owned PGID='+str(pgid))
    deadline=time.monotonic()+2
    while group_exists(pgid) and time.monotonic()<deadline:time.sleep(.01)
    if group_exists(pgid):raise Stop('owned process group absence unproved; PGID='+str(pgid))
    return {'pgid':pgid,'direct_child_reaped':True,'group_absent':True,'leader_exit':process.returncode,'background_descendants':leader_exited and present,'signal_error':signal_error}

class Runner:
    def __init__(self,budget):self.budget=budget;self.sequence=0
    def capture(self,argv,timeout=30,guarded=True):
        if guarded:self.budget.check()
        started=time.monotonic();p=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        selector=selectors.DefaultSelector();output={'stdout':bytearray(),'stderr':bytearray()};problem=None
        for name,pipe in [('stdout',p.stdout),('stderr',p.stderr)]:os.set_blocking(pipe.fileno(),False);selector.register(pipe,selectors.EVENT_READ,name)
        try:
            while selector.get_map() or p.poll() is None:
                if guarded:self.budget.check()
                if time.monotonic()-started>=timeout:problem='timeout';break
                if not selector.get_map():time.sleep(.01);continue
                for key,_ in selector.select(.02):
                    raw=os.read(key.fileobj.fileno(),16384)
                    if not raw:selector.unregister(key.fileobj);continue
                    dest=output[key.data];room=512*1024-len(dest);dest.extend(raw[:max(0,room)])
                    if len(raw)>room:problem='512KiB output bound';break
                if problem:break
        finally:
            try:group_cleanup=terminate_owned_group(p)
            finally:selector.close();p.stdout.close();p.stderr.close()
        if group_cleanup['background_descendants'] and not problem:problem='unexpected background descendant'
        return {'argv':argv,'exit':124 if problem else p.returncode,'bound':problem,'seconds':round(time.monotonic()-started,3),'group_cleanup':group_cleanup,**{k:bytes(v).decode(errors='replace') for k,v in output.items()}}
    def record(self,result):
        self.sequence+=1;self.budget.json('outputs/command-%04d.json'%self.sequence,result);return result
    def run(self,argv,timeout=30,guarded=True):return self.record(self.capture(argv,timeout,guarded))

def absent(result,lookup):
    return result['exit']!=0 and lookup in result['stderr'] and re.search(r'No such (?:object|container)',result['stderr'],re.I) is not None

class Registry:
    def __init__(self,root,budget,runner,nonce):
        self.root=Path(root);self.budget=budget;self.runner=runner;self.nonce=nonce;self.intents=[]
    def save(self):self.budget.json('meta/intents.json',{'owner':OWNER,'nonce':self.nonce,'base':BASE,'intents':self.intents})
    def intent(self,case):
        assert case in ('node14','node16') and not any(x['case']==case for x in self.intents)
        x={'case':case,'name':'bex-w8-pnpm-'+self.nonce+'-'+case,'state':'intent','cid':None,'create_attempted':False};self.intents.append(x);self.save();return x
    def adopt(self,intent,cid):
        assert CID_RE.fullmatch(cid)
        intent['cid']=cid;intent['state']='created'  # Register in RAM BEFORE any artifact write.
        self.save()
    def inspect(self,intent):
        lookup=intent['cid'] or intent['name'];r=self.runner.capture(['docker','inspect','--type','container','--format','{"Id":{{json .Id}},"Name":{{json .Name}},"Image":{{json .Image}},"Labels":{{json .Config.Labels}}}',lookup],timeout=5,guarded=False)
        if absent(r,lookup):return None,r
        if r['exit']:raise Stop('owned identity inspection failed')
        obj=json.loads(r['stdout']);labels=obj.get('Labels') or {}
        assert CID_RE.fullmatch(obj['Id']) and obj['Image']==BASE and obj['Name'].lstrip('/')==intent['name']
        assert labels.get('bex.owner')==OWNER and labels.get('bex.nonce')==self.nonce and labels.get('bex.case')==intent['case']
        if intent['cid']:assert obj['Id']==intent['cid']
        else:intent['cid']=obj['Id']  # Interrupted create: exact name+all labels+config only.
        return obj,r
    def cleanup(self):
        receipts=[];errors=[]
        with self.budget.lock:self.budget.cid=None
        for intent in self.intents:
            if intent['state']=='deleted':continue
            try:
                receipt={'intent':dict(intent)};receipts.append(receipt)
                obj,proof=self.inspect(intent);receipt['before']=proof
                if obj is None and intent['cid'] is None and intent.get('create_attempted'):
                    intent['state']='unknown create response; exact name observed absent'
                    raise Stop('Unknown create response requires later reconciliation; one name404 is not final creation evidence')
                if obj:
                    cid=obj['Id'];stop=self.runner.capture(['docker','stop','--time','5',cid],timeout=12,guarded=False)
                    rm=self.runner.capture(['docker','rm',cid],timeout=12,guarded=False)
                    after_obj,after=self.inspect(intent);receipt.update(stop=stop,remove=rm,after=after)
                    if after_obj is not None or rm['exit']!=0:raise Stop('exact own container absence unproved')
                intent['state']='deleted'
            except BaseException as e:errors.append({'case':intent['case'],'error':str(e)})
        # Complete all stop/rm/absence attempts before attempting fallible writes.
        try:self.budget.json('meta/cleanup.json',{'receipts':receipts,'errors':errors});self.save()
        except BaseException as e:errors.append({'artifact_write_after_cleanup':str(e)})
        if errors:raise Stop(json.dumps({'cleanup_errors':errors,'completed_cleanup':receipts}))
        return receipts

def download(url,target,limit,budget,exact_size=None,sha256=None,sha1=None,sri=None):
    assert url.startswith('https://nodejs.org/dist/') or url=='https://registry.npmjs.org/@pnpm/linux-arm64/-/linux-arm64-10.34.7.tgz'
    rel=target.relative_to(budget.root).as_posix();budget.reserve(component(rel),exact_size or limit)
    target.parent.mkdir(parents=True,exist_ok=True);part=target.with_suffix(target.suffix+'.part');assert not target.exists() and not part.exists()
    count=0;hashes={name:hashlib.new(name) for name in ['sha256','sha1','sha512']}
    with urllib.request.urlopen(url,timeout=20) as response,part.open('xb') as out:
        assert response.status==200 and response.url==url
        while True:
            budget.check();raw=response.read(min(65536,limit-count+1))
            if not raw:break
            count+=len(raw)
            if count>limit:raise Stop('download hard bound')
            out.write(raw)
            for h in hashes.values():h.update(raw)
    assert exact_size is None or count==exact_size
    assert sha256 is None or hashes['sha256'].hexdigest()==sha256
    assert sha1 is None or hashes['sha1'].hexdigest()==sha1
    assert sri is None or sri=='sha512-'+base64.b64encode(hashes['sha512'].digest()).decode()
    part.replace(target);budget.checkpoint()
    return {'url':url,'bytes':count,**{k:v.hexdigest() for k,v in hashes.items()}}

def stage_archive(url,target,limit,budget,*,reuse=False,exact_size=None,sha256=None,sha1=None,sri=None):
    if not reuse:return download(url,target,limit,budget,exact_size,sha256,sha1,sri)
    if digest(HERE/'REUSE-PLAN.json')!=REUSE_PLAN_SHA:raise Stop('qualified reuse plan changed')
    plan=json.loads((HERE/'REUSE-PLAN.json').read_text());rel=target.relative_to(budget.root).as_posix()
    proof=plan['entries'][rel];source=Path(proof['source']);expected_source=Path(plan['exact_source_root'])/rel
    if digest(Path(proof['receipt_path']))!=proof['receipt_sha256']:raise Stop('retained source qualification receipt changed')
    if source!=expected_source or source.is_symlink() or not source.is_file() or proof['url']!=url:raise Stop('outside fixed qualified archive reuse scope')
    if proof['bytes']>limit or (exact_size is not None and proof['bytes']!=exact_size):raise Stop('reuse archive size differs from frozen input')
    if sha256 is not None and proof['sha256']!=sha256:raise Stop('reuse Node SHA differs from frozen official input')
    if sha1 is not None and proof['sha1']!=sha1:raise Stop('reuse pnpm SHA1 differs from frozen input')
    if sri is not None and sri!='sha512-'+base64.b64encode(bytes.fromhex(proof['sha512'])).decode():raise Stop('reuse pnpm SRI differs from frozen input')
    budget.reserve(component(rel),proof['bytes']);target.parent.mkdir(parents=True,exist_ok=True);part=target.with_suffix(target.suffix+'.part')
    if target.exists() or part.exists():raise Stop('new archive reuse target already exists')
    before=source.stat();hashes={k:hashlib.new(k) for k in ['sha256','sha1','sha512']};count=0
    with source.open('rb') as src,part.open('xb') as out:
        while True:
            budget.check();body=src.read(65536)
            if not body:break
            count+=len(body)
            if count>limit or count>proof['bytes']:raise Stop('qualified archive copy exceeded size bound')
            out.write(body)
            for h in hashes.values():h.update(body)
    after=source.stat()
    if (before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_ino,after.st_size,after.st_mtime_ns):raise Stop('retained original archive changed during read-only copy')
    if count!=proof['bytes'] or any(hashes[k].hexdigest()!=proof[k] for k in hashes):raise Stop('fresh complete qualified archive copy hash/size mismatch')
    part.replace(target);target.chmod(0o444);budget.checkpoint()
    return {'url':url,'bytes':count,**{k:h.hexdigest() for k,h in hashes.items()},'input_mode':'fresh fully reverified read-only physical copy; no HTTP download','source':str(source),'source_receipt_sha256':proof['receipt_sha256'],'retained_original_not_modified':True}

class DecompressedBound:
    def __init__(self,stream,limit):self.stream=stream;self.limit=limit;self.count=0
    def read(self,n=-1):
        raw=self.stream.read(n);self.count+=len(raw)
        if self.count>self.limit:raise Stop('decompressed stream cap')
        return raw

def extract(archive,dest,prefix,key,budget,selected):
    assert not dest.exists();dest.mkdir(parents=True);entries=[];links=[];seen=set()
    opener=lzma.open if archive.name.endswith('.xz') else gzip.open
    with opener(archive,'rb') as stream:
        limited=DecompressedBound(stream,256*MIB)
        with tarfile.open(fileobj=limited,mode='r|') as tar:
            for member in tar:
                budget.check();parts=PurePosixPath(member.name).parts
                if not parts or parts[0]!=prefix or len(member.name)>1024 or '..' in parts or member.name.startswith('/'):raise Stop('archive path outside exact prefix')
                rel=PurePosixPath(*parts[1:])
                if not rel.parts or not selected(rel):continue
                if str(rel) in seen or len(seen)>=10000:raise Stop('duplicate/too many archive entries')
                seen.add(str(rel));out=dest/str(rel)
                if member.isdev() or member.isfifo() or member.islnk():raise Stop('unsupported archive entry type')
                budget.reserve(key,member.size if member.isfile() else 0)
                # No symlinks are installed until regular files/directories are complete.
                out.parent.mkdir(parents=True,exist_ok=True)
                if member.isdir():out.mkdir(exist_ok=True);out.chmod(member.mode&0o777)
                elif member.issym():
                    target=PurePosixPath(member.linkname)
                    resolved=(out.parent/member.linkname).resolve(strict=False)
                    if target.is_absolute() or not resolved.is_relative_to(dest):raise Stop('archive symlink escape')
                    links.append((out,member.linkname))
                elif member.isfile():
                    source=tar.extractfile(member);assert source is not None
                    copied=0
                    with out.open('xb') as sink:
                        while True:
                            budget.check();raw=source.read(65536)
                            if not raw:break
                            sink.write(raw);copied+=len(raw)
                    if copied!=member.size:raise Stop('partial selected archive member')
                    out.chmod(member.mode&0o777)
                else:raise Stop('unsupported archive member')
                entries.append({'path':str(rel),'type':member.type.decode(errors='replace'),'mode':member.mode,'bytes':member.size,'link':member.linkname if member.issym() else None})
    for out,target in links:
        if out.exists() or out.is_symlink():raise Stop('symlink output already exists')
        out.symlink_to(target)
    for parent,dirs,files in os.walk(dest):
        Path(parent).chmod(0o755)
    dest.chmod(0o755)
    for entry in entries:
        f=dest/entry['path']
        if f.is_file() and not f.is_symlink():entry['sha256']=digest(f)
    budget.checkpoint();return entries

def elf_arm64(path):
    with path.open('rb') as f:header=f.read(64)
    assert len(header)==64 and header[:7]==b'\x7fELF\x02\x01\x01' and int.from_bytes(header[18:20],'little')==183 and int.from_bytes(header[52:54],'little')==64

def fixture_tar(name,engine,observer):
    package={'name':name,'version':'1.0.0','engines':{'node':engine}}
    if observer:package['scripts']={'install':'node observer.js lifecycle'}
    raw=io.BytesIO()
    with tarfile.open(fileobj=raw,mode='w') as tar:
        items={'package/package.json':encoded(package)}
        if observer:items['package/observer.js']=(HERE/'observe.js').read_bytes()
        for path,body in sorted(items.items()):
            info=tarfile.TarInfo(path);info.size=len(body);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(body))
    return gzip.compress(raw.getvalue(),mtime=0)

def make_fixtures(root,budget,major):
    target=root/'fixtures';target.mkdir(exist_ok=True);budget.write('fixtures/observe.js',(HERE/'observe.js').read_bytes());budget.write('fixtures/bundled-gyp.js',(HERE/'bundled-gyp.js').read_bytes())
    budget.write('fixtures/bex-pnpm-node-observer.tgz',fixture_tar('bex-pnpm-node-observer',str(major)+'.x',True))
    budget.write('fixtures/bex-pnpm-engine-sentinel.tgz',fixture_tar('bex-pnpm-engine-sentinel','>=18',False));target.chmod(0o755)
    for f in target.iterdir():f.chmod(0o644)
    for name in ['baseline','wrong-engine',ROOT_ENGINE_SENTINEL,'seeded','explicit-override','path-prepend','pm-other']:
        work=root/'work'/name;work.mkdir(parents=True);work.chmod(0o777)
        wrong=name=='wrong-engine';root_wrong=name==ROOT_ENGINE_SENTINEL;dep='bex-pnpm-engine-sentinel' if wrong else 'bex-pnpm-node-observer'
        package={'name':ROOT_ENGINE_SENTINEL if root_wrong else 'bex-pnpm-smoke-root','version':'1.0.0','private':True,'engines':{'node':'>=18' if root_wrong else str(major)+'.x'},'packageManager':'pnpm@'+('10.34.6' if name=='pm-other' else '10.34.7'),'scripts':{'observe':'node /fixtures/observe.js run'},'dependencies':{dep:'file:/fixtures/'+('bex-pnpm-engine-sentinel.tgz' if wrong else 'bex-pnpm-node-observer.tgz')}}
        budget.json('work/'+name+'/package.json',package)
        budget.write('work/'+name+'/.npmrc',b'engine-strict=true\nside-effects-cache=false\n'+(b'scripts-prepend-node-path=true\n' if name=='path-prepend' else b''))
        budget.write('work/'+name+'/pnpm-workspace.yaml',("packages:\n  - '.'\nonlyBuiltDependencies:\n  - "+OBSERVER_DEP_PATH+"\n").encode())
        for generated in ['package.json','.npmrc','pnpm-workspace.yaml']:(work/generated).chmod(0o644)
    (root/'work').chmod(0o777)
    projects={}
    for work in sorted((root/'work').iterdir()):
        projects[work.name]={'cwd':'/work/'+work.name,'files':{name:{'sha256':digest(work/name),'content':(work/name).read_text()} for name in ['package.json','.npmrc','pnpm-workspace.yaml']}}
    return {'exact_artifact_approval':OBSERVER_DEP_PATH,'projects':projects,'tarballs':{f.name:{'sha256':digest(f),'bytes':f.stat().st_size} for f in sorted(target.glob('*.tgz'))}}


def marker_rows(result):
    rows=[]
    for line in (result['stdout']+'\n'+result['stderr']).splitlines():
        prefix='BEX_PNPM_OBSERVER=';at=line.find(prefix)
        if at<0:continue
        try:value,_=json.JSONDecoder().raw_decode(line[at+len(prefix):]);rows.append(value)
        except (ValueError,TypeError):continue
    return rows

def default_gyp_usable(row):
    try:
        gyp=row['gyp'];configured=gyp['configured']
        return (gyp['path_resolution']['exit']==0 and gyp['path_invocation']['exit']==0
                and (not configured.get('literal') or (configured.get('exists') is True
                     and gyp['configured_invocation'] is not None and gyp['configured_invocation']['exit']==0)))
    except (KeyError,TypeError):return False

def effective_config(result,prepend=False):
    if not result or result['exit']!=0:return {'valid':False,'reasons':['effective config command unproved']}
    try:raw=json.loads(result['stdout'])
    except (ValueError,TypeError):return {'valid':False,'reasons':['effective config JSON unproved']}
    if not isinstance(raw,dict):return {'valid':False,'reasons':['effective config is not an object']}
    expected={'only-built-dependencies':[OBSERVER_DEP_PATH],'engine-strict':True,'side-effects-cache':False,'ignore-scripts':False,'manage-package-manager-versions':True}
    if prepend:expected['scripts-prepend-node-path']=True
    reasons=[key+': effective value differs' for key,value in expected.items() if raw.get(key)!=value]
    if raw.get('dangerously-allow-all-builds') is True:reasons.append('allow-all dependency builds is forbidden')
    if raw.get('node-version') is not None:reasons.append('Node version override observed; selected PATH Node control not qualified')
    return {'valid':not reasons,'reasons':reasons,'selected_values':{key:raw.get(key) for key in [*expected,'dangerously-allow-all-builds','node-version']}}

def root_engine_refusal(result,version):
    if not result or type(result.get('exit')) is not int or result['exit']!=1:return False
    if result.get('bound') is not None or result.get('signal') is not None:return False
    text=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',result['stdout']+'\n'+result['stderr'])
    return (('ERR_PNPM_UNSUPPORTED_ENGINE' in text)
            and ('Your Node version is incompatible with "/work/'+ROOT_ENGINE_SENTINEL+'"' in text)
            and re.search(r'Expected version:\s*>=18(?:\s|$)',text) is not None
            and re.search(r'Got:\s*v?'+re.escape(version)+r'(?:\s|$)',text) is not None)

def assess(results,version):
    failures=[];unexercised=[];expected='v'+version
    configs={name:effective_config(results.get('effective-config-'+name),prepend=name=='path-prepend') for name in ['baseline','path-prepend']}
    for name,proof in configs.items():
        if not proof['valid']:unexercised.append(name+': effective fixture configuration unqualified: '+', '.join(proof['reasons']))
    kinds={'baseline':'lifecycle','exec':'exec','run':'run','path-prepend-install':'lifecycle','path-prepend-run':'run'}
    for name,kind in kinds.items():
        result=results.get(name);rows=marker_rows(result) if result else []
        if not result:unexercised.append(name+': command not observed');continue
        if result['exit']!=0:unexercised.append(name+': command nonzero; inspect raw failure')
        if not any(row.get('kind')==kind for row in rows):unexercised.append(name+': '+kind+' observer UNEXERCISED')
        if any(row.get('process_version')!=expected or row.get('exec_realpath')!='/opt/appnode/bin/node' for row in rows):failures.append(name+': actual observer used wrong selected appNode')
    lifecycle=[row for row in marker_rows(results.get('baseline',{'stdout':'','stderr':''})) if row.get('kind')=='lifecycle']
    if not lifecycle:lifecycle_gyp={'state':'UNEXERCISED','reason':'No dependency lifecycle marker; no lifecycle gyp conclusion.'}
    else:
        usable=all(default_gyp_usable(row) for row in lifecycle);lifecycle_gyp={'state':'PASS' if usable else 'FAIL','observed_lifecycle_rows':lifecycle}
        if not usable:failures.append('baseline: actual observed lifecycle default gyp unavailable/broken')
    negative=results.get('wrong-engine-root');root_control='UNEXERCISED'
    if negative:
        message=negative['stdout']+negative['stderr']
        if root_engine_refusal(negative,version):root_control='PASS'
        elif type(negative.get('exit')) is int and negative['exit']==0 and negative.get('bound') is None and negative.get('signal') is None and configs['baseline']['valid']:root_control='FAIL';failures.append('wrong-engine-root: actual incompatible project install was accepted')
        else:root_control='UNPROVED';unexercised.append('wrong-engine-root: completed canonical engine refusal/current selected Node unproved')
    else:unexercised.append('wrong-engine-root: command not observed')
    comparisons={}
    for name,literal in [('seeded','/opt/appnode/bin/node'),('explicit-override','/opt/appnode/bin/../bin/node')]:
        result=results.get(name);rows=marker_rows(result) if result else []
        preserved=bool(rows) and all(row.get('environment',{}).get('NODE')==literal for row in rows)
        comparisons[name]={'exit':result['exit'] if result else None,'rows':rows,'literal_NODE_preserved':preserved if rows else None,'state':'OBSERVED' if rows else 'UNEXERCISED'}
        if not rows:unexercised.append(name+': lifecycle comparison UNEXERCISED')
        elif result['exit']!=0 or not preserved or any(row.get('process_version')!=expected or row.get('exec_realpath')!='/opt/appnode/bin/node' for row in rows):failures.append(name+': actual selectedNode/literalNODE comparison failed')
    run_gyp={name:[row['gyp'] for row in marker_rows(results.get(name,{'stdout':'','stderr':''})) if 'gyp' in row] for name in ['exec','run','path-prepend-run']}
    return {'viability':'FAIL' if failures else ('UNPROVED' if unexercised else 'PASS'),'failures':failures,'unexercised':unexercised,
            'effective_configuration':configs,'lifecycle_default_gyp':lifecycle_gyp,'root_engine_control':root_control,
            'run_exec_gyp_observations':run_gyp,'NODE_comparisons':comparisons,
            'cold_local_file_engine':'Observation retained only; tagged local-resolver returns no manifest before requester installability check. Not an engine rejection control.',
            'different_packageManager':'Bounded offline command outcome retained; no successful self-switch or observed network request claimed.'}

def container_inventory(runner,guarded=True):
    receipt=runner.capture(['docker','ps','--all','--no-trunc','--format','{{.ID}}'],guarded=guarded)
    if receipt['exit']!=0:raise Stop('read-only container ID inventory failed')
    ids=receipt['stdout'].splitlines()
    if len(ids)>1000 or len(set(ids))!=len(ids) or any(not CID_RE.fullmatch(cid) for cid in ids):raise Stop('invalid/unbounded container ID inventory')
    return sorted(ids),receipt

def compare_container_ids(before,after,intents):
    old,new=set(before),set(after);owned={x['cid'] for x in intents if x.get('cid')}
    if old&owned:raise Stop('own container ID overlaps original baseline')
    unresolved=[{'case':x['case'],'name':x['name'],'state':x['state']} for x in intents if x['state']!='deleted']
    return {'baseline_ids':sorted(old),'after_ids':sorted(new),'foreign_baseline_ids_present':old<=new,
            'surviving_baseline_ids':sorted(old&new),'concurrent_removals':sorted(old-new),
            'concurrent_additions':sorted(new-old-owned),'own_remaining_ids':sorted(owned&new),
            'own_cids_absent':not (owned&new) and not unresolved,'unresolved_own_intents':unresolved,
            'scope':'Read-only ID observations; concurrent changes are not attributed to this controller and never repaired.'}

def image_view(runner):
    result=runner.run(['docker','image','inspect',BASE,'--format','{{json .}}'])
    assert result['exit']==0;obj=json.loads(result['stdout']);assert obj['Id']==BASE and obj['Os']=='linux' and obj['Architecture']=='arm64'
    return {k:obj[k] for k in ['Id','Os','Architecture','RepoTags','RepoDigests','RootFS']}

def run_case(root,budget,runner,registry,plan,major,version):
    intent=registry.intent('node'+str(major));replacements={'${OWN_CASE_NAME}':intent['name'],'${NONCE}':registry.nonce,'${NODE_CASE}':intent['case'],'${OWN_NODE_TREE}':str(root/'inputs/node'),'${OWN_PNPM_TREE}':str(root/'inputs/pnpm'),'${OWN_FIXTURE}':str(root/'fixtures'),'${OWN_WORK}':str(root/'work')}
    argv=[]
    for value in plan['create_argv']:
        for key,replacement in replacements.items():value=value.replace(key,replacement)
        assert '${' not in value;argv.append(value)
    intent['create_attempted']=True;registry.save()
    created=runner.capture(argv)
    if CID_RE.fullmatch(created['stdout'].strip()):registry.adopt(intent,created['stdout'].strip())
    runner.record(created)
    assert created['exit']==0 and intent['cid'];obj,_=registry.inspect(intent);assert obj
    cid=intent['cid']
    with budget.lock:budget.cid=cid
    assert runner.run(['docker','start',cid])['exit']==0
    def execute(args,project=None,node=None,bound=30):
        command=['docker','exec']
        if project:command+=['--workdir','/work/'+project]
        if node:command+=['--env','NODE='+node]
        return runner.run(command+[cid,*args],timeout=bound)
    probes={}
    for name,args in [('os',['cat','/etc/os-release']),('glibc',['getconf','GNU_LIBC_VERSION']),('node-path',['/bin/sh','-c','command -v node']),('node',['node','--version']),('npm',['npm','--version']),('pnpm',['/opt/pnpm/pnpm','--version'])]:
        probes[name]=execute(args)
    if any(x['exit']!=0 for x in probes.values()):raise Stop('borrowed-base/startup setup failure; preserve probes')
    assert probes['node']['stdout'].strip()=='v'+version and probes['pnpm']['stdout'].strip()=='10.34.7' and probes['node-path']['stdout'].strip()=='/opt/appnode/bin/node'
    npm=json.loads((root/'inputs/node/lib/node_modules/npm/package.json').read_text());assert probes['npm']['stdout'].strip()==npm['version']
    install=['/usr/bin/env','-u','NODE','-u','npm_config_node_gyp','/opt/pnpm/pnpm','install','--offline','--reporter=append-only']
    results={'startup':probes}
    for project in ['baseline','path-prepend']:
        results['effective-config-'+project]=execute(['/opt/pnpm/pnpm','config','list','--location','project','--json'],project)
    results['baseline']=execute(install,'baseline')
    # Preserve baseline errors and still gather planned comparisons; never rewrite baseline.
    results['exec']=execute(['/opt/pnpm/pnpm','exec','node','/fixtures/observe.js','exec'],'baseline')
    results['run']=execute(['/opt/pnpm/pnpm','run','observe'],'baseline')
    results['local-file-engine-observation']=execute(install,'wrong-engine')
    results['wrong-engine-root']=execute(install+['--engine-strict'],ROOT_ENGINE_SENTINEL)
    results['bundled-gyp-comparison']=execute(['node','/fixtures/bundled-gyp.js'])
    for project,override in [('seeded','/opt/appnode/bin/node'),('explicit-override','/opt/appnode/bin/../bin/node')]:
        results[project]=execute(['/opt/pnpm/pnpm','install','--offline','--reporter=append-only'],project,node=override)
    results['path-prepend-install']=execute(install,'path-prepend')
    results['path-prepend-run']=execute(['/opt/pnpm/pnpm','run','observe'],'path-prepend')
    results['different-packageManager']=execute(['/opt/pnpm/pnpm','install','--offline','--reporter=append-only'],'pm-other',bound=15)
    results['assessment']=assess(results,version)
    budget.json('meta/'+intent['case']+'-observations.json',results)
    return results

def execute(reuse_qualified=False):
    plan,identity=verified_plan()
    if free_bytes()<START_FREE:raise Stop('startfree below1543503872; no root/network/container created')
    root=Path('/private/tmp')/('bex-w8-pnpm-small-live-'+secrets.token_hex(8));root.mkdir(mode=0o700)
    budget=Budget(root);runner=Runner(budget);budget.runner=runner;nonce=secrets.token_hex(8);registry=Registry(root,budget,runner,nonce)
    failure=None;before=None;observations={};before_containers=None;inventory_comparison=None;budget.start()
    def interrupted(signum,frame):raise Stop('own controller interrupted:'+str(signum))
    old_handlers={s:signal.signal(s,interrupted) for s in [signal.SIGINT,signal.SIGTERM]}
    try:
        budget.json('meta/source-binding.json',{'plan_sha256':PLAN_SHA,'manifest_sha256':MANIFEST_SHA,'controller_sha256':digest(HERE/'controller.py'),'observer_sha256':digest(HERE/'observe.js'),'owner':OWNER,'nonce':nonce,'root':str(root)})
        before=image_view(runner);budget.json('meta/image-before.json',before)
        before_containers,inventory_receipt=container_inventory(runner);runner.record(inventory_receipt);budget.json('meta/containers-before.json',before_containers)
        server=runner.run(['docker','version','--format','{{json .Server}}']);assert server['exit']==0;sv=json.loads(server['stdout']);assert sv['Os']=='linux' and sv['Arch']=='arm64'
        pnpm=identity['pnpm_dist'];body=stage_archive(pnpm['tarball'],root/'archives/pnpm.tgz',32*MIB,budget,reuse=reuse_qualified,sha1=pnpm['shasum'],sri=pnpm['integrity']);budget.json('meta/pnpm-download.json',body)
        entries=extract(root/'archives/pnpm.tgz',root/'inputs/pnpm','package','pnpm',budget,lambda _:True);budget.json('meta/pnpm-extraction.json',entries)
        binary=root/'inputs/pnpm/pnpm';elf_arm64(binary);assert binary.stat().st_size==63488279 and digest(binary)==PNPM_SHA
        for node in identity['node']:
            major=int(node['version'].split('.')[0]);budget.checkpoint()
            remaining=max(0,CAP-sum(measured(root).values()))
            if free_bytes()<FLOOR+MARGIN+remaining:raise Stop('fresh remaining-budget capacity gate')
            archive=root/'archives/node'/('node'+str(major)+'.xz')
            body=stage_archive(node['archive_url'],archive,24*MIB,budget,reuse=reuse_qualified,exact_size=node['archive_size'],sha256=node['archive_sha256']);budget.json('meta/node'+str(major)+'-download.json',body)
            selected=lambda rel:rel.parts[0]=='bin' or rel.parts[:3]==('lib','node_modules','npm') or (len(rel.parts)==1 and re.search(r'LICENSE|LICENCE|NOTICE|COPYING',rel.name,re.I))
            entries=extract(archive,root/'inputs/node','node-v'+node['version']+'-linux-arm64','node',budget,selected);budget.json('meta/node'+str(major)+'-extraction.json',entries);elf_arm64(root/'inputs/node/bin/node')
            fixture_proof=make_fixtures(root,budget,major);budget.json('meta/node'+str(major)+'-fixture.json',fixture_proof)
            try:observations['node'+str(major)]=run_case(root,budget,runner,registry,plan,major,node['version'])
            finally:registry.cleanup()
            # Only fresh own working extraction/work/fixture, full original archives retained.
            for rel in ['inputs/node','work','fixtures']:shutil.rmtree(root/rel)
            budget.checkpoint()
        after=image_view(runner);assert before==after;budget.json('meta/image-after.json',after)
        budget.json('meta/result.json',{'state':'OBSERVATIONS_COLLECTED','assessments':{k:v['assessment'] for k,v in observations.items()},'scope':'No Ccompile/common/slim/amd64/hosted claim; actual default-gyp/NODE failures retained.'})
    except BaseException as e:failure=type(e).__name__+': '+str(e)
    finally:
        try:registry.cleanup()
        except BaseException as e:failure=(failure or '')+';cleanup:'+str(e)
        if before_containers is not None:
            try:
                after_containers,inventory_receipt=container_inventory(runner,guarded=False)
                inventory_comparison=compare_container_ids(before_containers,after_containers,registry.intents)
                runner.record(inventory_receipt);budget.json('meta/containers-after.json',after_containers);budget.json('meta/container-comparison.json',inventory_comparison)
                if not inventory_comparison['own_cids_absent']:raise Stop('owned container absence inventory unproved')
                if not inventory_comparison['foreign_baseline_ids_present']:raise Stop('baseline IDs removed during observation; recorded without attribution or repair')
            except BaseException as e:failure=(failure+'; ' if failure else '')+'container_inventory:'+str(e)
        failure=finish_monitor(budget,old_handlers,failure)
    print(json.dumps({'root':str(root),'failure':failure,'assessments':{k:v['assessment'] for k,v in observations.items()},'container_inventory':inventory_comparison,'own_cids':[{k:x[k] for k in ['case','cid','state']} for x in registry.intents]}))
    if failure:raise SystemExit(1)
    if any(v['assessment']['viability']!='PASS' for v in observations.values()):raise SystemExit(2)

def reconcile(rawroot):
    root=Path(rawroot).resolve();assert root.parent==Path('/private/tmp') and re.fullmatch(r'bex-w8-pnpm-small-live-[0-9a-f]{16}',root.name)
    d=json.loads((root/'meta/intents.json').read_text());assert d['owner']==OWNER and d['base']==BASE and re.fullmatch(r'[0-9a-f]{16}',d['nonce'])
    budget=Budget(root);runner=Runner(budget);budget.runner=runner;registry=Registry(root,budget,runner,d['nonce']);registry.intents=d['intents']
    for x in registry.intents:
        assert x['case'] in ('node14','node16') and x['name']=='bex-w8-pnpm-'+d['nonce']+'-'+x['case'] and (x['cid'] is None or CID_RE.fullmatch(x['cid']))
    registry.cleanup();print(json.dumps({'root':str(root),'own_cleanup':'complete'}))

def main():
    if __debug__ is False:raise Stop('Do not use optimized Python; assertions are guards')
    os.umask(0o077);parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='action',required=True);execute_parser=sub.add_parser('execute');execute_parser.add_argument('--reuse-qualified',action='store_true',help='Use fixed first-run archives with fresh complete copy/hash/SRI verification; no redownload');r=sub.add_parser('reconcile');r.add_argument('root');args=parser.parse_args()
    if args.action=='execute':execute(args.reuse_qualified)
    else:reconcile(args.root)

if __name__=='__main__':main()
