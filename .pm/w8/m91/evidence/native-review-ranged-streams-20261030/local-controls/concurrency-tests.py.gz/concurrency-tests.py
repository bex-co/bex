"""Local synthetic stream/cache tests only; no public pull or candidate approval evidence."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from contextlib import redirect_stdout
import concurrent.futures, hashlib, importlib.util, io, json, tempfile, threading, time, unittest

ROOT = Path('/private/tmp/loopx-w8-native-v11-local-validation-20261030')
s = importlib.util.spec_from_file_location('v11_local_test', '/tmp/loopx-w8-native-review-v11.py')
g = importlib.util.module_from_spec(s);s.loader.exec_module(g)

def review(directory, payloads, workers=2):
    r = g.Review.__new__(g.Review)
    r.v = g.load('local_policy_' + directory.name, '/tmp/loopx-w8-verify-native-artifact-ranged.py')
    r.out = directory;r.a = SimpleNamespace(layer_workers=workers, name='UNIT-ONLY-NOT-A-CANDIDATE')
    r.lock = threading.Lock();r.v2 = r.v.BlobReceipts(directory / 'local-unit-only-cache')
    r.blobs = {}
    for payload in payloads:
        digest = 'sha256:' + hashlib.sha256(payload).hexdigest()
        r.blobs[digest] = {'digest': digest, 'size': len(payload)}
    issued = [];lock = threading.Lock()
    def public():
        with lock:
            token = 'UNIT-ONLY-ANONYMOUS-' + str(len(issued));issued.append(token)
        return 'https://unit.invalid/v2/bex-co/bex-cnb-run', {'Authorization': 'Bearer ' + token}
    r.public = public
    return r, issued

class Transport:
    def __init__(self, payloads, expected, barrier=False, first_waits=False):
        self.payloads = payloads;self.expected = expected;self.barrier = threading.Barrier(2) if barrier else None
        self.first_waits = first_waits;self.second_closed = threading.Event();self.lock = threading.Lock()
        self.active = 0;self.maximum = 0;self.calls = [];self.closed = [];self.finished = []
        self.hold_second = False;self.second_started = threading.Event();self.second_release = threading.Event();self.closed_events = {digest:threading.Event() for digest in expected}
    def open(self, request, timeout):
        digest = request.full_url.rsplit('/', 1)[-1];method = request.get_method()
        with self.lock:self.calls.append((digest, method, request.get_header('Authorization')))
        data = b'' if method == 'HEAD' else self.payloads[digest]
        owner = self
        class Body(io.BytesIO):
            def __init__(self,data):super().__init__(data);self.headers = {}
            def __enter__(self):
                if method == 'GET':
                    with owner.lock:owner.active += 1;owner.maximum = max(owner.maximum, owner.active)
                    if owner.barrier and digest in owner.expected[:2]:owner.barrier.wait(timeout=3)
                    if owner.hold_second and digest == owner.expected[1]:
                        owner.second_started.set()
                        if not owner.second_release.wait(timeout=3):raise AssertionError('started read was never released')
                    if owner.first_waits and digest == owner.expected[0]:
                        if not owner.second_closed.wait(timeout=3):raise AssertionError('second stream never completed')
                return self
            def __exit__(self, *args):
                if method == 'GET':
                    with owner.lock:owner.active -= 1;owner.closed.append(digest);owner.finished.append(digest)
                    owner.closed_events[digest].set()
                    if digest == owner.expected[1]:owner.second_closed.set()
                self.close()
        return Body(data)

class ConcurrencyTests(unittest.TestCase):
    def test_two_full_streams_overlap_ordered_results_and_locked_cache(self):
        with tempfile.TemporaryDirectory(prefix='v9-unit-streams-', dir=ROOT) as td:
            r, issued = review(Path(td), [b'first'*8192, b'second'*8192, b'third'*8192])
            expected = list(r.blobs);payloads = dict(zip(expected, [b'first'*8192, b'second'*8192, b'third'*8192]))
            net = Transport(payloads, expected, barrier=True, first_waits=True)
            with patch.object(g.urllib.request, 'urlopen', side_effect=net.open), redirect_stdout(io.StringIO()):rows = r.pull_blobs()
            self.assertEqual(net.maximum, 2);self.assertEqual(net.active, 0);self.assertEqual(net.finished[0], expected[1])
            self.assertEqual([row['digest'] for row in rows], expected);self.assertEqual(len(issued), 3)
            self.assertEqual(len({headers for _, _, headers in net.calls}), 3)
            self.assertTrue(all(not row['reused_prior_full_read'] for row in rows))
            self.assertEqual(set(r.v2.read()), set(expected));self.assertEqual(len(net.closed), 3)
            self.assertTrue(all(row['bytes_hashed'] == r.blobs[row['digest']]['size'] for row in rows))
            self.assertFalse(json.loads((r.out/'progress.json').read_text())['candidate_approved'])
            self.assertFalse((r.out/'receipt.json').exists())
            self.assertEqual(list(r.v2.path.glob('*.tmp-*')), [])
            reused = Transport(payloads, expected)
            with patch.object(g.urllib.request, 'urlopen', side_effect=reused.open):again = r.pull_blobs()
            self.assertEqual([row['digest'] for row in again], expected)
            self.assertTrue(all(row['reused_prior_full_read'] for row in again))
            self.assertTrue(all(method == 'HEAD' for _, method, _ in reused.calls))
    def test_existing_single_worker_setting_is_respected(self):
        with tempfile.TemporaryDirectory(prefix='v9-unit-single-', dir=ROOT) as td:
            bodies = [b'one', b'two'];r, _ = review(Path(td), bodies, workers=1);expected = list(r.blobs)
            net = Transport(dict(zip(expected, bodies)), expected)
            with patch.object(g.urllib.request, 'urlopen', side_effect=net.open), redirect_stdout(io.StringIO()):rows = r.pull_blobs()
            self.assertEqual(net.maximum, 1);self.assertEqual([row['digest'] for row in rows], expected)
    def test_bad_or_truncated_or_overlong_body_fails_before_final_approval_and_joins_started_reads(self):
        for mode in ['wrong-sha', 'truncated', 'overlong']:
            with self.subTest(mode=mode), tempfile.TemporaryDirectory(prefix='v9-unit-reject-', dir=ROOT) as td:
                bodies = [b'expected-owned-unit-body', b'other-owned-unit-body'];r, _ = review(Path(td), bodies);expected = list(r.blobs)
                supplied = [b'X'*len(bodies[0]) if mode=='wrong-sha' else bodies[0][:-1] if mode=='truncated' else bodies[0]+b'X', bodies[1]]
                net = Transport(dict(zip(expected, supplied)), expected, barrier=True);net.hold_second = True
                r.digest = 'sha256:'+'1'*64;r.tool_hashes = {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path('/tmp/loopx-w8-native-review-v11.py'),Path('/tmp/loopx-w8-verify-native-artifact-ranged.py')]}
                statements = []
                for number, (kind, arch) in enumerate([(g.SIGN,None),(r.v.SPDX_TYPE,'amd64'),(r.v.SPDX_TYPE,'arm64'),(r.v.TRIVY_TYPE,'amd64'),(r.v.TRIVY_TYPE,'arm64')]):
                    row = {'predicate_type':kind,'bundle_digest':'sha256:'+str(number+2)*64,'path':str(Path(td)/'UNIT-NOT-A-REAL-BUNDLE')}
                    bundle = {'verificationMaterial':{'tlogEntries':[{'kindVersion':{'kind':'hashedrekord','version':'0.0.2'}}],'timestampVerificationData':{'rfc3161Timestamps':[{}]}}}
                    statement = {'subject':[{'digest':{'sha256':r.digest[7:]}}],'predicate':{'architecture':arch}}
                    statements.append((row,bundle,statement,b'UNIT-ONLY'))
                r.signed_statements = lambda: iter(statements);r.ids = {};r.platforms = {};r.ref = 'UNIT-NOT-A-PUBLIC-IMAGE'
                errors = []
                def finish():
                    try:r.finish()
                    except BaseException as error:errors.append(error)
                with patch.object(g.urllib.request,'urlopen',side_effect=net.open),patch.object(r.v,'spdx_binding',side_effect=lambda pred, ids:(pred['architecture'],{})),patch.object(r.v,'trivy_binding',side_effect=lambda pred,*args:(pred['architecture'],{})),redirect_stdout(io.StringIO()):
                    thread = threading.Thread(target=finish);thread.start()
                    try:
                        self.assertTrue(net.second_started.wait(timeout=3));self.assertTrue(net.closed_events[expected[0]].wait(timeout=3))
                        self.assertTrue(thread.is_alive(), 'failure returned before the already-started second read was joined')
                    finally:net.second_release.set();thread.join(timeout=3)
                    self.assertFalse(thread.is_alive())
                self.assertEqual(len(errors),1);self.assertIsInstance(errors[0],RuntimeError)
                self.assertRegex(str(errors[0]),'blob returned more bytes|anonymous blob bytes differ')
                self.assertEqual(net.maximum,2);self.assertEqual(net.active,0);self.assertEqual(set(net.closed),set(expected))
                self.assertNotIn(expected[0],r.v2.read());self.assertFalse((r.out/'receipt.json').exists())
                self.assertFalse(json.loads((r.out/'progress.json').read_text())['candidate_approved'])
    def test_two_gib_floor_refuses_before_network(self):
        with tempfile.TemporaryDirectory(prefix='v9-unit-floor-',dir=ROOT) as td:
            r, issued = review(Path(td),[b'one',b'two'])
            low = SimpleNamespace(free=g.LAYER_FREE_RESERVE+2*r.v.MAX_DOCUMENT-1)
            with patch.object(g.shutil,'disk_usage',return_value=low),patch.object(g.urllib.request,'urlopen',side_effect=AssertionError('network attempted below reserve')):
                with self.assertRaisesRegex(RuntimeError,'Scratch disk reserve'):r.pull_blobs()
            self.assertEqual(issued,[]);self.assertFalse((r.out/'receipt.json').exists())

if __name__ == '__main__':unittest.main(verbosity=2)
