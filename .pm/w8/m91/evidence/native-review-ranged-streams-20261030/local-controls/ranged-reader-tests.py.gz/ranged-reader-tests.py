"""Synthetic local body streams and actual canonical hash/cache only; no public read or candidate approval."""
import contextlib,hashlib,http.client,importlib.util,io,json,tempfile,threading,unittest,urllib.error,urllib.request
from email.message import Message
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
ROOT=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('private_v11','/tmp/loopx-w8-native-review-v11.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
BASE='https://ghcr.io/v2/bex-co/bex-cnb-run'
def response(body,cl,status=200,cr=None,**extra):return dict(body=body,cl=cl,status=status,cr=cr,**extra)
class Net:
 def __init__(self,plans,barrier=False):self.plans=plans;self.calls=[];self.responses=[];self.lock=threading.Lock();self.active=0;self.maximum=0;self.barrier=threading.Barrier(2) if barrier else None
 def open(self,request,timeout):
  digest=request.full_url.rsplit('/',1)[-1]
  with self.lock:
   spec=self.plans[digest].pop(0);self.calls.append({'digest':digest,'range':request.get_header('Range'),'authorization':request.get_header('Authorization')})
   if isinstance(spec,BaseException):raise spec
   self.active+=1;self.maximum=max(self.maximum,self.active)
  if self.barrier and request.get_header('Range') is None:self.barrier.wait(timeout=3)
  owner=self
  class Body:
   def __init__(self):
    self.status=spec['status'];self.headers=Message();self.stream=io.BytesIO(spec['body']);self.read_sizes=[];self.closed=False
    if spec.get('cl') is not None:
     for value in (spec['cl'] if isinstance(spec['cl'],list) else [str(spec['cl'])]):self.headers.add_header('Content-Length',value)
    if spec.get('cr') is not None:self.headers.add_header('Content-Range',spec['cr'])
    self.headers.add_header('X-Private-Test','HEADER-SENTINEL-DO-NOT-LOG')
   def geturl(self):return spec.get('url','https://private.unit.invalid/blob?sig=URL-SENTINEL-DO-NOT-LOG')
   def read(self,n):
    self.read_sizes.append(n)
    if len(self.read_sizes)==spec.get('error_read'):raise spec['error']
    return self.stream.read(n)
   def close(self):
    if not self.closed:
     self.closed=True;self.stream.close()
     with owner.lock:owner.active-=1
  result=Body();self.responses.append(result);return result

def review(path,payloads,net,workers=1):
 r=g.Review.__new__(g.Review);r.v=g.load('ranged_policy_'+path.name,'/tmp/loopx-w8-verify-native-artifact-ranged.py');r.out=path;r.a=SimpleNamespace(name='UNIT-ONLY-NOT-A-CANDIDATE',layer_workers=workers);r.lock=threading.Lock();r.blobs={'sha256:'+hashlib.sha256(p).hexdigest():{'digest':'sha256:'+hashlib.sha256(p).hexdigest(),'size':len(p)} for p in payloads};issued=[]
 def public():
  token='UNIT-TOKEN-SENTINEL-'+str(len(issued));issued.append(token);return BASE,{'Accept':'unit','Authorization':'Bearer '+token}
 r.public=public;r.v2=r.v.BlobReceipts(path/'UNIT-ONLY-cache',opener=lambda request,timeout:g.RangedBlobReader(r,request,timeout,opener=net.open));return r,issued

def pull(r):
 with contextlib.redirect_stdout(io.StringIO()):return r.pull_blobs()
def metadata(r,digest):return json.loads((r.out/('ranged-body-'+digest[7:]+'.json')).read_text())
class Tests(unittest.TestCase):
 def test_short_eof_resumes_exact_offset_fresh_headers_and_whole_canonical_hash_then_head_reuses(self):
  p=b'whole-logical-unit-body-must-match';h='sha256:'+hashlib.sha256(p).hexdigest();n=len(p)
  with tempfile.TemporaryDirectory(prefix='v11-eof-',dir=ROOT) as td:
   net=Net({h:[response(p[:5],n),response(p[5:],n-5,206,f'bytes 5-{n-1}/{n}')]});r,issued=review(Path(td),[p],net);rows=pull(r)
   self.assertEqual([x['range'] for x in net.calls],[None,'bytes=5-']);self.assertNotEqual(net.calls[0]['authorization'],net.calls[1]['authorization']);self.assertEqual(rows[0]['digest'],h);self.assertEqual(rows[0]['bytes_hashed'],n);self.assertFalse(rows[0]['reused_prior_full_read']);self.assertEqual(r.v2.read()[h]['bytes_hashed'],n);self.assertEqual(net.active,0)
   d=metadata(r,h);self.assertEqual(d['logical_bytes_delivered'],n);self.assertEqual([a['outcome'] for a in d['attempts']],['premature-EOF','complete']);self.assertFalse((r.out/'receipt.json').exists())
   heads=[];r.v.small_get=lambda url,headers,limit,method='GET':(heads.append(method) or b'',None);again=pull(r);self.assertTrue(again[0]['reused_prior_full_read']);self.assertEqual(heads,['HEAD']);self.assertEqual(len(net.calls),2)
 def test_read_interruptions_resume_only_delivered_prefix_including_discarded_incomplete_read_partial(self):
  for mode in ['timeout-after-prefix','incomplete-before-prefix']:
   with self.subTest(mode=mode),tempfile.TemporaryDirectory(prefix='v11-interrupt-',dir=ROOT) as td:
    p=b'actual-canonical-unit-hash';h='sha256:'+hashlib.sha256(p).hexdigest();n=len(p);offset=5 if mode.startswith('timeout') else 0
    first=response(p[:5],n,error_read=2,error=TimeoutError('SECRET-URL?token=DO-NOT-LOG')) if offset else response(b'',n,error_read=1,error=http.client.IncompleteRead(b'abc',n-3))
    net=Net({h:[first,response(p[offset:],n-offset,206,f'bytes {offset}-{n-1}/{n}')]});r,_=review(Path(td),[p],net);rows=pull(r);self.assertEqual(rows[0]['bytes_hashed'],n);self.assertEqual(net.calls[1]['range'],f'bytes={offset}-');self.assertEqual(len(net.calls),2)
    d=metadata(r,h);self.assertEqual(d['attempts'][0]['outcome'],'read-interruption')
    if not offset:self.assertEqual(d['attempts'][0]['exception_partial_bytes_discarded'],3)
    self.assertNotIn('SECRET',json.dumps(d));self.assertNotIn('DO-NOT-LOG',json.dumps(d))
 def test_error_after_full_logical_size_does_not_issue_another_get(self):
  p=b'full-body-then-read-error';h='sha256:'+hashlib.sha256(p).hexdigest()
  with tempfile.TemporaryDirectory(prefix='v11-after-full-',dir=ROOT) as td:
   net=Net({h:[response(p,len(p),error_read=2,error=TimeoutError('UNIT-ERROR-NOT-FOR-LOG'))]});r,_=review(Path(td),[p],net)
   with self.assertRaises(TimeoutError):pull(r)
   self.assertEqual(len(net.calls),1);self.assertNotIn(h,r.v2.read());self.assertEqual(net.active,0)
 def test_three_read_interruptions_exhaust_same_total_get_budget(self):
  p=b'complete-body-needed';h='sha256:'+hashlib.sha256(p).hexdigest();n=len(p);plan=[]
  for offset in [0,3,6]:plan.append(response(p[offset:offset+3],n-offset,200 if offset==0 else 206,None if offset==0 else f'bytes {offset}-{n-1}/{n}',error_read=2,error=TimeoutError('UNIT-READ-INTERRUPTION')))
  with tempfile.TemporaryDirectory(prefix='v11-interrupt-limit-',dir=ROOT) as td:
   net=Net({h:plan});r,_=review(Path(td),[p],net)
   with self.assertRaises(TimeoutError):pull(r)
   self.assertEqual(len(net.calls),3);self.assertEqual([c['range'] for c in net.calls],[None,'bytes=3-','bytes=6-']);self.assertEqual(metadata(r,h)['logical_bytes_delivered'],9);self.assertNotIn(h,r.v2.read());self.assertEqual(net.active,0)
 def test_three_short_bodies_exhaust_exact_get_budget_without_receipt(self):
  p=b'complete-whole-unit-body';h='sha256:'+hashlib.sha256(p).hexdigest();n=len(p)
  with tempfile.TemporaryDirectory(prefix='v11-limit-',dir=ROOT) as td:
   net=Net({h:[response(p[:3],n),response(p[3:6],n-3,206,f'bytes 3-{n-1}/{n}'),response(p[6:9],n-6,206,f'bytes 6-{n-1}/{n}')]});r,_=review(Path(td),[p],net)
   with self.assertRaisesRegex(RuntimeError,'three body GET'):pull(r)
   self.assertEqual(len(net.calls),3);self.assertEqual([c['range'] for c in net.calls],[None,'bytes=3-','bytes=6-']);self.assertEqual(metadata(r,h)['logical_bytes_delivered'],9);self.assertNotIn(h,r.v2.read());self.assertEqual(net.active,0)
 def test_ignored_200_wrong_offset_end_total_length_and_malformed_range_fail_without_third_get(self):
  p=b'whole-body-reject-header-tamper';h='sha256:'+hashlib.sha256(p).hexdigest();n=len(p)
  variants={'ignored200':response(p[5:],n-5,200),'wrong-offset':response(p[5:],n-5,206,f'bytes 6-{n-1}/{n}'),'wrong-end':response(p[5:],n-5,206,f'bytes 5-{n-2}/{n}'),'wrong-total':response(p[5:],n-5,206,f'bytes 5-{n-1}/{n+1}'),'wrong-length':response(p[5:],n-4,206,f'bytes 5-{n-1}/{n}'),'missing-length':response(p[5:],None,206,f'bytes 5-{n-1}/{n}'),'duplicate-length':response(p[5:],[str(n-5),str(n-5)],206,f'bytes 5-{n-1}/{n}'),'malformed-range':response(p[5:],n-5,206,'SECRET-SENTINEL-DO-NOT-LOG')}
  for name,second in variants.items():
   with self.subTest(name=name),tempfile.TemporaryDirectory(prefix='v11-headers-',dir=ROOT) as td:
    net=Net({h:[response(p[:5],n),second]});r,_=review(Path(td),[p],net)
    with self.assertRaises(RuntimeError):pull(r)
    self.assertEqual(len(net.calls),2);self.assertEqual(net.responses[1].read_sizes,[]);self.assertNotIn(h,r.v2.read());self.assertEqual(net.active,0);d=metadata(r,h);self.assertEqual(d['attempts'][-1]['outcome'],'open-or-header-error');self.assertNotIn('SENTINEL',json.dumps(d))
 def test_full_size_sha_mismatch_overlong_and_tampered_resumed_prefix_never_retry_integrity_gate(self):
  p=b'canonical-unchanged-integrity-gate';h='sha256:'+hashlib.sha256(p).hexdigest();n=len(p)
  for name,plan,gets in [('fullSHA',[response(b'X'*n,n)],1),('overlong',[response(p+b'X',n)],1),('tampered-prefix',[response(b'X'*5,n),response(p[5:],n-5,206,f'bytes 5-{n-1}/{n}')],2)]:
   with self.subTest(name=name),tempfile.TemporaryDirectory(prefix='v11-integrity-',dir=ROOT) as td:
    net=Net({h:plan});r,_=review(Path(td),[p],net)
    with self.assertRaisesRegex(RuntimeError,'blob returned more bytes|anonymous blob bytes differ'):pull(r)
    self.assertEqual(len(net.calls),gets);self.assertNotIn(h,r.v2.read());self.assertEqual(net.active,0);self.assertFalse((r.out/'receipt.json').exists());self.assertFalse(metadata(r,h)['candidate_approved'])
 def test_http_open_errors_are_not_body_resume_and_bad_initial_length_or_https_fails_before_read(self):
  p=b'local-unit-body';h='sha256:'+hashlib.sha256(p).hexdigest();n=len(p)
  for name,first in [('HTTP500',urllib.error.HTTPError('https://unit.invalid/?token=SECRET',500,'unit',{},None)),('bad-length',response(p,n+1)),('http-downgrade',response(p,n,url='http://unit.invalid/?token=SECRET')),('initial206',response(p,n,206,f'bytes 0-{n-1}/{n}'))]:
   with self.subTest(name=name),tempfile.TemporaryDirectory(prefix='v11-open-',dir=ROOT) as td:
    net=Net({h:[first]});r,_=review(Path(td),[p],net)
    with self.assertRaises((RuntimeError,urllib.error.HTTPError)):pull(r)
    self.assertEqual(len(net.calls),1);self.assertNotIn(h,r.v2.read());self.assertEqual(net.active,0)
    if net.responses:self.assertEqual(net.responses[0].read_sizes,[])
    for f in r.out.glob('*.json'):
     self.assertNotIn('SECRET',f.read_text());self.assertNotIn('UNIT-TOKEN',f.read_text());self.assertNotIn('SENTINEL',f.read_text())
 def test_range_zero_ignored200_is_rejected_and_scope_change_never_opens_foreign_get(self):
  p=b'local-safe-unit';h='sha256:'+hashlib.sha256(p).hexdigest();n=len(p)
  with tempfile.TemporaryDirectory(prefix='v11-zero-',dir=ROOT) as td:
   net=Net({h:[response(b'',n),response(p,n)]});r,_=review(Path(td),[p],net)
   with self.assertRaisesRegex(RuntimeError,'exact206'):pull(r)
   self.assertEqual(net.calls[1]['range'],'bytes=0-');self.assertEqual(len(net.calls),2);self.assertNotIn(h,r.v2.read())
  with tempfile.TemporaryDirectory(prefix='v11-scope-',dir=ROOT) as td:
   net=Net({h:[response(p[:3],n)]});r,_=review(Path(td),[p],net);calls=[]
   def public():calls.append(1);return (BASE if len(calls)<=2 else 'https://foreign.invalid/v2/private'),{}
   r.public=public
   with self.assertRaisesRegex(RuntimeError,'different public scope'):pull(r)
   self.assertEqual(len(net.calls),1);self.assertNotIn(h,r.v2.read())
 def test_two_streams_overlap_but_never_exceed_existing_worker_bound_during_resume(self):
  bodies=[b'first-unit-canonical-body',b'second-unit-canonical-body'];plans={}
  for p in bodies:
   h='sha256:'+hashlib.sha256(p).hexdigest();n=len(p);plans[h]=[response(p[:5],n),response(p[5:],n-5,206,f'bytes 5-{n-1}/{n}')]
  with tempfile.TemporaryDirectory(prefix='v11-parallel-',dir=ROOT) as td:
   net=Net(plans,barrier=True);r,_=review(Path(td),bodies,net,workers=2);rows=pull(r);self.assertEqual(net.maximum,2);self.assertEqual(net.active,0);self.assertEqual([x['digest'] for x in rows],list(r.blobs));self.assertEqual(len(net.calls),4);self.assertEqual(len({x['authorization'] for x in net.calls}),4)
 def test_chunk_bound_and_space_floor_remain_enforced_with_no_body_files(self):
  p=b'U'*(2*(1<<20)+7);h='sha256:'+hashlib.sha256(p).hexdigest()
  with tempfile.TemporaryDirectory(prefix='v11-bounds-',dir=ROOT) as td:
   net=Net({h:[response(p,len(p))]});r,_=review(Path(td),[p],net);rows=pull(r);self.assertEqual(rows[0]['bytes_hashed'],len(p));self.assertTrue(all(0<n<=1<<20 for n in net.responses[0].read_sizes));self.assertFalse(any(f.suffix in ['.partial','.verified'] for f in r.out.rglob('*')))
  with tempfile.TemporaryDirectory(prefix='v11-floor-',dir=ROOT) as td:
   net=Net({h:[response(p,len(p))]});r,issued=review(Path(td),[p],net)
   with patch.object(g.shutil,'disk_usage',return_value=SimpleNamespace(free=g.LAYER_FREE_RESERVE+2*r.v.MAX_DOCUMENT-1)):
    with self.assertRaisesRegex(RuntimeError,'Scratch disk reserve'):pull(r)
   self.assertEqual(net.calls,[]);self.assertEqual(issued,[])

if __name__=='__main__':unittest.main(verbosity=2)
