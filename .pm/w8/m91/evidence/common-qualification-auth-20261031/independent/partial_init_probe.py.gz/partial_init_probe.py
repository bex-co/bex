"""Independent real-filesystem/child-process control; Docker is an owned stub."""
import hashlib, importlib.util, json, os
from pathlib import Path
import subprocess, sys, tempfile
from unittest.mock import patch
sys.dont_write_bytecode = True
case=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('q',case/'work/.github/scripts/native-common-qualify.py')
q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
with tempfile.TemporaryDirectory(prefix='auth-own-init-probe-') as tmp:
    root=Path(tmp).resolve(); badenv=root/'environment-directory';badenv.mkdir()
    foreign=root/'foreign';foreign.mkdir();(foreign/'config.json').write_text('foreign sentinel')
    values={'COMMON_IMAGE':'ghcr.io/bex-co/bex-cnb-run@sha256:'+'a'*64,
        'PRODUCER_SHA':'b'*40,'VERIFICATION_SHA':'b'*40,'GITHUB_SHA':'b'*40,
        'TARGET_PLATFORM':'linux/arm64','RUNNER_TEMP':str(root),'GITHUB_RUN_ID':'1',
        'GITHUB_RUN_ATTEMPT':'1','GITHUB_OUTPUT':str(root/'outputs'),'GITHUB_ENV':str(badenv)}
    with patch.dict(os.environ,values):
        try:q.initialize()
        except IsADirectoryError:pass
        else:raise AssertionError('environment write must fail')
    outputs=dict(line.split('=',1) for line in (root/'outputs').read_text().splitlines())
    evidence=Path(outputs['root']);inputs=json.loads((evidence/'inputs.json').read_text());config=Path(inputs['docker_config'])
    assert config.is_dir() and json.loads((config/'.qualification-owner.json').read_text())['owner']==outputs['owner']
    fake_token='CONTROL-ONLY-FAKE-TOKEN';(config/'config.json').write_text(fake_token)
    binary=root/'bin';binary.mkdir();docker=binary/'docker'
    docker.write_text('#!'+sys.executable+'\n'+'''import json,os,pathlib,sys
with pathlib.Path(os.environ['PROBE_EVENTS']).open('a') as f:f.write(json.dumps({'argv':sys.argv[1:],'config':os.environ['DOCKER_CONFIG']})+'\\n')
assert os.environ['DOCKER_CONFIG']==os.environ['PROBE_CONFIG']
if sys.argv[1:3]==['buildx','rm']:sys.exit(17)
if sys.argv[1]=='logout':print('CONTROL-ONLY-FAKE-TOKEN');print('CONTROL-ONLY-FAKE-TOKEN',file=sys.stderr)
sys.exit(0)
''');docker.chmod(0o700)
    with patch.dict(os.environ,{'PATH':str(binary)+os.pathsep+os.defpath,'DOCKER_CONFIG':str(foreign),
                                'PROBE_EVENTS':str(root/'events'),'PROBE_CONFIG':str(config)}):
        try:q.cleanup(evidence)
        except RuntimeError:pass
        else:raise AssertionError('builder failure must remain failure')
    assert not config.exists()
    assert (foreign/'config.json').read_text()=='foreign sentinel'
    cleanup=json.loads((evidence/'cleanup.json').read_text())
    assert cleanup['operations'][0]['exit_code']==17
    assert cleanup['operations'][-1]['removed'] and cleanup['operations'][-1]['logout_exit_code']==0
    assert fake_token not in (evidence/'cleanup.json').read_text()
    events=[json.loads(line) for line in (root/'events').read_text().splitlines()]
    assert events[0]['argv']==['buildx','rm',outputs['owner']]
    assert events[-1]['argv']==['logout','ghcr.io']
    assert all(event['config']==str(config) for event in events)
    result={'status':'PASS','control':'real initialization fails at GITHUB_ENV write; exact owner remains recorded; actual owned Docker stub processes receive isolated config; builder exit17 remains failure while credentials are removed and foreign config preserved',
            'actual_docker':False,'actual_authentication':False,'calls':[event['argv'] for event in events],
            'credential_output_discarded':True,'evidence_contains_fake_token':False}
    print(json.dumps(result,indent=2))
