import subprocess,json,time,pathlib,datetime,hashlib
p=pathlib.Path(__file__).parent;run='41066532463';end=time.monotonic()+1800;last=0;downloaded=False

def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def api(s):
 r=subprocess.run(['gh','api','repos/bex-co/bex/actions/runs/'+run+s],capture_output=True,timeout=30)
 if r.returncode:raise RuntimeError(r.stderr.decode()[:300])
 return json.loads(r.stdout)
def put(n,v):(p/n).write_text(json.dumps(v,indent=2)+'\n')
while time.monotonic()<end:
 try:
  jobs=api('/jobs');arts=api('/artifacts');now=utc();put('jobs-latest.json',jobs);put('artifacts-latest.json',arts)
  brief=[(j['name'],j['status'],j['conclusion'],[s['name'] for s in j['steps'] if s['status']=='in_progress']) for j in jobs['jobs']]
  if time.monotonic()-last>=30: print(now,brief,'artifacts',[(a['id'],a['name']) for a in arts['artifacts']],flush=True);last=time.monotonic()
  found=[a for a in arts['artifacts'] if a['name']=='m144-observer-channel-smoke' and not a['expired']]
  if found and not downloaded:
   assert len(found)==1;before=api('/jobs');started=utc();put('download-jobs-before.json',before);put('download-artifact.json',found[0]);put('download-artifacts-response.json',arts)
   r=subprocess.run(['gh','run','download',run,'--name','m144-observer-channel-smoke','--dir',str(p/'download')],capture_output=True,timeout=35)
   finished=utc();(p/'download-output.txt').write_bytes(r.stdout+r.stderr);after=api('/jobs');put('download-jobs-after.json',after)
   def active(v):return any(j['name']=='observer-channel-smoke' and j['status']=='in_progress' for j in v['jobs'])
   files={str(f.relative_to(p/'download')):{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in (p/'download').rglob('*') if f.is_file()} if (p/'download').exists() else {}
   receipt={'runId':int(run),'sourceSha':'f857566a8d7089b46126543804712a46acf58285','startedAt':started,'finishedAt':finished,'downloadExit':r.returncode,'jobActiveBefore':active(before),'jobActiveAfter':active(after),'files':files};put('download-receipt.json',receipt);print('DOWNLOAD',json.dumps(receipt),flush=True);assert r.returncode==0;downloaded=True
  if jobs['jobs'] and all(j['status']=='completed' for j in jobs['jobs']):
   result={'observedAt':utc(),'downloaded':downloaded,'jobs':brief};put('terminal.json',result);print('TERMINAL',json.dumps(result),flush=True);break
 except Exception as e:
  print(utc(),'ERROR',str(e),flush=True)
 time.sleep(5)
else:put('watch-expired.json',{'observedAt':utc(),'downloaded':downloaded});print('bounded watch expired',flush=True)
