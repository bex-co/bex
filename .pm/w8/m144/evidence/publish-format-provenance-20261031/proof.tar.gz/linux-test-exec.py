#!/usr/bin/env python3
"""Reuse the reviewed Linux Go -exec pattern for private unit binaries only."""
import datetime,json,os,secrets,signal,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent
binary=Path(sys.argv[1]).resolve();cwd=Path.cwd().resolve()
assert binary.is_relative_to(P/'build-tmp') and cwd.is_relative_to(P/'source')
nonce=secrets.token_hex(8);name='bex-m144-publish-unit-'+nonce
image='sha256:1c6b12f3136772863d17a9befca6ae3ef0ed828d38a7da3085b1373854ec4d1e'
env=os.environ.copy()
for key in ['DOCKER_CONTEXT','DOCKER_HOST','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','DOCKER_AUTH_CONFIG','BEX_CSI_KERNEL_TEST','BEX_CSI_PUBLISH_FIX_TEST','BEX_CSI_PUBLISH_SIM_TEST']:env.pop(key,None)
D=['docker','--config','/private/tmp/bex-w8-m144-t006-publish-simulation-v2-20261030/runtime-docker-config','--host','unix:///Users/tianpan/.orbstack/run/docker.sock']
proof=P/('unit-'+nonce+'.json');r={'name':name,'nonce':nonce,'configID':image,'binary':str(binary),'cwd':str(cwd),'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};proof.write_text(json.dumps(r,indent=2)+'\n')
child=None

def cancel(sig,frame):raise SystemExit('own unit wrapper cancelled '+str(sig))
signal.signal(signal.SIGTERM,cancel)
try:
 args=D+['run','--rm','--pull=never','--platform','linux/arm64','--name',name,'--label','bex.local-proof='+nonce,'--network','none','--read-only','--tmpfs','/tmp:rw,size=64m','--cap-drop','ALL','--security-opt','no-new-privileges=true','--pids-limit','128','--memory','512m','--mount','type=bind,src='+str(binary)+',dst=/audit.test,readonly','--mount','type=bind,src='+str(cwd)+',dst='+str(cwd),'--workdir',str(cwd),'--entrypoint','/audit.test',image,*sys.argv[2:]]
 child=subprocess.Popen(args,env=env);r['exit']=child.wait(timeout=150)
finally:
 state=subprocess.run(D+['inspect',name,'--format','{{json .}}'],env=env,text=True,capture_output=True,timeout=15)
 if state.returncode==0:
  obj=json.loads(state.stdout);assert obj['Name']=='/'+name and obj['Config']['Labels']['bex.local-proof']==nonce and obj['Image']==image
  r['containerID']=obj['Id']
  if obj['State']['Running']:subprocess.run(D+['stop','-t','5',obj['Id']],env=env,check=True,stdout=subprocess.DEVNULL,timeout=15)
  subprocess.run(D+['rm','-f',obj['Id']],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15)
 gone=subprocess.run(D+['inspect',name],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15);r['ownContainerAbsent']=gone.returncode!=0
 if child and child.poll() is None:
  child.terminate()
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:child.kill();child.wait()
 r['finishedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();proof.write_text(json.dumps(r,indent=2)+'\n')
 if not r['ownContainerAbsent']:raise RuntimeError('own unit container cleanup unproved')
raise SystemExit(r['exit'])
