package volumes

import (
	"context"
	"encoding/binary"
	"fmt"
	"k8s.io/utils/exec"
	"os"
	"strconv"
	"strings"
)

// ValidateFilesystemBytes bounds the opt-in ext4 contract before any node I/O.
func ValidateFilesystemBytes(bytes int64) error {
	if bytes < 1<<30 || bytes > 10000<<30 || bytes%4096 != 0 {
		return fmt.Errorf("filesystem capacity must be 4KiB-aligned within 1..10000GiB")
	}
	return nil
}

// boundedExt4 works on the unlocked device selected by the trusted CSI node.
// It never shrinks or reformats an existing filesystem. Empty-device formatting
// is allowed only when Publish initialized LUKS in that call, never by
// expansion or a read-only mount.
func boundedExt4(ctx context.Context, executor exec.Interface, device string, bytes int64, allowFormat, readonly bool) error {
	if err := ValidateFilesystemBytes(bytes); err != nil {
		return err
	}
	physical, err := blockDeviceBytes(device)
	if err != nil {
		return err
	}
	// LUKS consumes a header inside the provider volume. Its mapping can be a
	// little smaller than the logical request once the request reaches the floor.
	if uint64(bytes) > physical && uint64(bytes)-physical > 16<<20 {
		return fmt.Errorf("logical capacity exceeds unlocked block device beyond LUKS header overhead")
	}
	target := min(uint64(bytes), physical) / 4096 * 4096
	if target == 0 {
		return fmt.Errorf("empty block device")
	}
	output, inspectErr := executor.CommandContext(ctx, "blkid", "-p", "-s", "TYPE", "-o", "value", device).CombinedOutput()
	if inspectErr != nil {
		exit, ok := inspectErr.(exec.ExitError)
		if !ok || exit.ExitStatus() != 2 || len(output) != 0 || !allowFormat || readonly {
			return fmt.Errorf("refuse to format uninspectable or non-writable block device: %w", inspectErr)
		}
		_, err = executor.CommandContext(ctx, "mkfs.ext4", "-F", "-m0", "-b4096", device, strconv.FormatUint(target/4096, 10)).CombinedOutput()
		return err
	}
	if strings.TrimSpace(string(output)) != "ext4" {
		return fmt.Errorf("bounded filesystem requires ext4, found %q", output)
	}
	f, err := os.Open(device)
	if err != nil {
		return err
	}
	defer f.Close()
	super := make([]byte, 1024)
	if _, err = f.ReadAt(super, 1024); err != nil {
		return err
	}
	current, err := ext4Bytes(super)
	if err != nil {
		return err
	}
	if current > target {
		return fmt.Errorf("refuse filesystem shrink: current=%d target=%d; offline migration required", current, target)
	}
	if current == target || readonly {
		return nil
	}
	_, err = executor.CommandContext(ctx, "resize2fs", device, strconv.FormatUint(target/1024, 10)+"K").CombinedOutput()
	return err
}

func ext4Bytes(super []byte) (uint64, error) {
	if len(super) < 1024 || binary.LittleEndian.Uint16(super[56:]) != 0xef53 {
		return 0, fmt.Errorf("invalid ext4 superblock")
	}
	logBlock := binary.LittleEndian.Uint32(super[24:])
	if logBlock > 6 {
		return 0, fmt.Errorf("invalid ext4 block size")
	}
	blocks := uint64(binary.LittleEndian.Uint32(super[4:]))
	if binary.LittleEndian.Uint32(super[96:])&0x80 != 0 {
		blocks |= uint64(binary.LittleEndian.Uint32(super[336:])) << 32
	}
	blockSize := uint64(1024) << logBlock
	if blocks == 0 || blocks > ^uint64(0)/blockSize {
		return 0, fmt.Errorf("invalid ext4 block count")
	}
	return blocks * blockSize, nil
}
