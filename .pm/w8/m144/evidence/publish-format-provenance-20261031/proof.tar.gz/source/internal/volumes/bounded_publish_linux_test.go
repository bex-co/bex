//go:build linux

package volumes

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	mount "k8s.io/mount-utils"
	utilexec "k8s.io/utils/exec"
	testingexec "k8s.io/utils/exec/testing"
	"log/slog"
	"os"
	osexec "os/exec"
	"path/filepath"
	"reflect"
	"regexp"
	"slices"
	"strings"
	"testing"
)

type failureVolumeState struct {
	UUID     string
	Geometry string
	Sentinel [32]byte
}

func captureFailureState(t *testing.T, device, mountpoint string) failureVolumeState {
	t.Helper()
	readCommand := func(name string, args ...string) string {
		t.Helper()
		out, err := osexec.Command(name, args...).CombinedOutput()
		if err != nil {
			t.Fatalf("read-only %s: %v: %s", name, err, out)
		}
		return strings.TrimSpace(string(out))
	}
	uuid := readCommand("blkid", "-s", "UUID", "-o", "value", device)
	var geometry []string
	for _, line := range strings.Split(readCommand("dumpe2fs", "-h", device), "\n") {
		if strings.HasPrefix(line, "Block count:") || strings.HasPrefix(line, "Block size:") {
			geometry = append(geometry, strings.Join(strings.Fields(line), " "))
		}
	}
	if uuid == "" || len(geometry) != 2 {
		t.Fatal("independent filesystem identity/geometry unavailable")
	}
	data, err := os.ReadFile(filepath.Join(mountpoint, "sentinel"))
	if err != nil {
		t.Fatal(err)
	}
	return failureVolumeState{uuid, strings.Join(geometry, ";"), sha256.Sum256(data)}
}

type boundedMountFailure struct{ *mount.FakeMounter }

func (m boundedMountFailure) MountSensitive(string, string, string, []string, []string) error {
	return errors.New("simulated mount failure")
}

// Reuse the reviewed two-volume owner: only command results and mounts are mocked.
// No test command formats, resizes, unmounts or edits either healthy filesystem.
func TestBoundedPublishOwnedTransitions(t *testing.T) {
	if os.Getenv("BEX_CSI_PUBLISH_FIX_TEST") != "1" {
		t.Skip("explicitly authorized owned Linux fixture required")
	}
	if _, err := os.Stat("/.dockerenv"); err != nil {
		t.Fatal(err)
	}
	nonce := os.Getenv("BEX_CSI_PUBLISH_FIX_NONCE")
	if !regexp.MustCompile(`^[0-9a-f]{16}$`).MatchString(nonce) {
		t.Fatal("own nonce required")
	}
	mapping := "m144t006-" + nonce + "-a"
	device := "/dev/mapper/" + mapping
	var ready struct{ LoopA, MappingA, MappingB string }
	data, err := os.ReadFile("/proof/ready.json")
	if err != nil {
		t.Fatal(err)
	}
	if err := json.Unmarshal(data, &ready); err != nil {
		t.Fatal(err)
	}
	if ready.MappingA != mapping || ready.MappingB != "m144t006-"+nonce+"-b" || !regexp.MustCompile(`^/dev/loop[0-9]+$`).MatchString(ready.LoopA) {
		t.Fatal("owned fixture identity mismatch")
	}
	beforeA := captureFailureState(t, device, "/scratch/mount-a")
	beforeB := captureFailureState(t, "/dev/mapper/"+ready.MappingB, "/scratch/mount-b")
	outcomes := map[string]bool{}
	t.Cleanup(func() {
		a := captureFailureState(t, device, "/scratch/mount-a")
		b := captureFailureState(t, "/dev/mapper/"+ready.MappingB, "/scratch/mount-b")
		if a != beforeA || b != beforeB {
			t.Error("owned A/B geometry, UUID or sentinel changed")
		}
		proof := map[string]any{"scope": "Actual healthy own blockdevices; crypto format, inner blkid, fsck, mkfs results and mount are simulated; every real mutation refused", "BeforeA": beforeA, "BeforeB": beforeB, "AfterA": a, "AfterB": b, "AUnchanged": a == beforeA, "BUnchanged": b == beforeB, "cases": outcomes, "TestFailed": t.Failed()}
		encoded, e := json.MarshalIndent(proof, "", "  ")
		if e == nil {
			e = os.WriteFile("/proof/fixed-publish-result.json", append(encoded, '\n'), 0600)
		}
		if e != nil {
			t.Error(e)
		}
	})
	raw := filepath.Join("/scratch", mapping)
	if err := os.Symlink(ready.LoopA, raw); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if e := os.Remove(raw); e != nil {
			t.Error(e)
		}
	})
	actual := &mount.SafeFormatAndMount{Exec: utilexec.New()}
	kind, err := actual.GetDiskFormat(raw)
	if err != nil || kind != "crypto_LUKS" {
		t.Fatalf("actual outer=%q err=%v", kind, err)
	}
	realCrypt, err := osexec.LookPath("cryptsetup")
	if err != nil {
		t.Fatal(err)
	}
	realCrypt, err = filepath.Abs(realCrypt)
	if err != nil || !regexp.MustCompile(`^/[A-Za-z0-9_./-]+$`).MatchString(realCrypt) {
		t.Fatal("fixed cryptsetup path required")
	}
	status, err := osexec.Command(realCrypt, "status", mapping).CombinedOutput()
	if err != nil {
		t.Fatalf("actual status: %v %s", err, status)
	}
	var backing string
	for _, line := range strings.Split(string(status), "\n") {
		f := strings.Fields(line)
		if len(f) == 2 && f[0] == "device:" {
			backing = f[1]
		}
	}
	if backing != ready.LoopA {
		t.Fatal("active own mapping backing differs")
	}
	mountinfo, err := os.ReadFile("/proc/self/mountinfo")
	if err != nil {
		t.Fatal(err)
	}
	var guardMount string
	for _, line := range strings.Split(string(mountinfo), "\n") {
		f := strings.Fields(line)
		if len(f) > 6 && f[4] == "/guard-bin" {
			guardMount = line
			break
		}
	}
	f := strings.Fields(guardMount)
	if len(f) < 6 || !strings.Contains(guardMount, " - tmpfs ") {
		t.Fatal("own guard tmpfs absent")
	}
	flags := "," + f[5] + ","
	if strings.Contains(flags, ",noexec,") || !strings.Contains(flags, ",nosuid,") || !strings.Contains(flags, ",nodev,") {
		t.Fatal("guard mount flags differ")
	}
	if err := os.WriteFile("/proof/fixed-guard-mountinfo.txt", []byte(guardMount+"\n"), 0600); err != nil {
		t.Fatal(err)
	}
	outer := func(t *testing.T, blank bool) testingexec.FakeCommandAction {
		args := []string{"-p", "-s", "TYPE", "-s", "PTTYPE", "-o", "export", raw}
		if blank {
			return boundedTestCommand(t, "blkid", args, "", utilexec.CodeExitError{Err: errors.New("simulated command exit"), Code: 2})
		}
		return func(name string, got ...string) utilexec.Cmd {
			if name != "blkid" || !reflect.DeepEqual(got, args) {
				t.Fatalf("unexpected outer command %s %v", name, got)
			}
			return utilexec.New().Command(name, got...)
		}
	}
	inner := func(t *testing.T, blank bool) testingexec.FakeCommandAction {
		out, e := "ext4\n", error(nil)
		if blank {
			out, e = "", utilexec.CodeExitError{Err: errors.New("simulated command exit"), Code: 2}
		}
		return boundedTestCommand(t, "blkid", []string{"-p", "-s", "TYPE", "-o", "value", device}, out, e)
	}
	fsck := func(t *testing.T, e error) testingexec.FakeCommandAction {
		return boundedTestCommand(t, "fsck", []string{"-a", device}, "fsck-result", e)
	}
	mkfs := func(t *testing.T, e error) testingexec.FakeCommandAction {
		return boundedTestCommand(t, "mkfs.ext4", []string{"-F", "-m0", "-b4096", device, "262144"}, "", e)
	}
	logger := slog.New(slog.NewTextHandler(io.Discard, nil))
	for _, tc := range []struct {
		name         string
		script       func(*testing.T) []testingexec.FakeCommandAction
		opts         MountOpts
		formatExit   int // -1 refuses every crypto-format request; >=0 is a simulated result only.
		wantError    string
		wantType     mount.MountErrorType
		wantMount    bool
		mountFailure bool
	}{
		{name: "existing-ambiguous", script: func(t *testing.T) []testingexec.FakeCommandAction {
			return []testingexec.FakeCommandAction{outer(t, false), inner(t, true)}
		}, formatExit: -1, wantError: "refuse to format"},
		{name: "valid-remount", script: func(t *testing.T) []testingexec.FakeCommandAction {
			return []testingexec.FakeCommandAction{outer(t, false), inner(t, false), fsck(t, nil)}
		}, formatExit: -1, wantMount: true},
		{name: "corrected-fsck", script: func(t *testing.T) []testingexec.FakeCommandAction {
			return []testingexec.FakeCommandAction{outer(t, false), inner(t, false), fsck(t, utilexec.CodeExitError{Err: errors.New("simulated command exit"), Code: 1})}
		}, formatExit: -1, wantMount: true},
		{name: "uncorrected-fsck", script: func(t *testing.T) []testingexec.FakeCommandAction {
			return []testingexec.FakeCommandAction{outer(t, false), inner(t, false), fsck(t, utilexec.CodeExitError{Err: errors.New("simulated command exit"), Code: 4})}
		}, formatExit: -1, wantType: mount.HasFilesystemErrors},
		{name: "missing-fsck", script: func(t *testing.T) []testingexec.FakeCommandAction {
			return []testingexec.FakeCommandAction{outer(t, false), inner(t, false), fsck(t, utilexec.ErrExecutableNotFound)}
		}, formatExit: -1, wantMount: true},
		{name: "readonly-no-grow-or-fsck", script: func(t *testing.T) []testingexec.FakeCommandAction {
			return []testingexec.FakeCommandAction{outer(t, false), inner(t, false)}
		}, opts: MountOpts{Readonly: true, FilesystemBytes: 5 << 30}, formatExit: -1, wantMount: true},
		{name: "additional-ro-no-grow-or-fsck", script: func(t *testing.T) []testingexec.FakeCommandAction {
			return []testingexec.FakeCommandAction{outer(t, false), inner(t, false)}
		}, opts: MountOpts{Additional: []string{"ro"}, FilesystemBytes: 5 << 30}, formatExit: -1, wantMount: true},
		{name: "fresh-initialization", script: func(t *testing.T) []testingexec.FakeCommandAction {
			return []testingexec.FakeCommandAction{outer(t, true), inner(t, true), mkfs(t, nil)}
		}, formatExit: 0, wantMount: true},
		{name: "failed-crypto-format", script: func(t *testing.T) []testingexec.FakeCommandAction {
			return []testingexec.FakeCommandAction{outer(t, true)}
		}, formatExit: 125, wantError: "unable to format"},
		{name: "mount-error-wrap", script: func(t *testing.T) []testingexec.FakeCommandAction {
			return []testingexec.FakeCommandAction{outer(t, false), inner(t, false), fsck(t, nil)}
		}, formatExit: -1, wantType: mount.UnknownMountError, mountFailure: true},
		{name: "interrupted-initialization-refuses-retry", script: func(t *testing.T) []testingexec.FakeCommandAction {
			return []testingexec.FakeCommandAction{outer(t, true), inner(t, true), mkfs(t, errors.New("simulated first mkfs failure")), outer(t, false), inner(t, true)}
		}, formatExit: 0, wantError: "refuse to format"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			logPath := "/proof/fixed-crypto-" + tc.name + ".log"
			formatArgs := "luksFormat --type luks1 " + raw
			shim := fmt.Sprintf("#!/bin/sh\nprintf '%%s\\n' \"$*\" >> %s\nif [ \"$#\" -eq 2 ] && [ \"$1\" = status ] && [ \"$2\" = %s ]; then exec %s status %s; fi\nif [ \"$*\" = '%s' ] && [ %d -ge 0 ]; then exit %d; fi\nexit 125\n", logPath, mapping, realCrypt, mapping, formatArgs, tc.formatExit, tc.formatExit)
			guard := "/guard-bin/cryptsetup"
			if err := os.WriteFile(guard, []byte(shim), 0700); err != nil {
				t.Fatal(err)
			}
			t.Setenv("PATH", "/guard-bin:"+os.Getenv("PATH"))
			if path, e := osexec.LookPath("cryptsetup"); e != nil || path != guard {
				t.Fatalf("guard path %q %v", path, e)
			}
			if out, e := osexec.Command("cryptsetup", "status", mapping).CombinedOutput(); e != nil {
				t.Fatalf("guard preflight %v %s", e, out)
			}
			if got, e := os.ReadFile(logPath); e != nil || string(got) != "status "+mapping+"\n" {
				t.Fatalf("preflight log %q %v", got, e)
			}
			executor := &testingexec.FakeExec{CommandScript: tc.script(t)}
			mounts := mount.NewFakeMounter(nil)
			surface := mount.Interface(mounts)
			if tc.mountFailure {
				surface = boundedMountFailure{mounts}
			}
			service := NewLinuxMountService(logger)
			service.mounter = &mount.SafeFormatAndMount{Interface: surface, Exec: executor}
			opts := tc.opts
			opts.FSType = "ext4"
			opts.EncryptionPassphrase = "test-only-simulated-command"
			if opts.FilesystemBytes == 0 {
				opts.FilesystemBytes = 1 << 30
			}
			target := filepath.Join("/scratch", "fixed-target-"+tc.name)
			err := service.Publish(context.Background(), target, raw, opts)
			if tc.name == "interrupted-initialization-refuses-retry" {
				if err == nil || !strings.Contains(err.Error(), "simulated first mkfs failure") {
					t.Fatalf("first interruption %v", err)
				}
				err = service.Publish(context.Background(), target, raw, opts)
			}
			if tc.wantType != "" {
				var typed mount.MountError
				if !errors.As(err, &typed) || typed.Type != tc.wantType {
					t.Fatalf("mount type lost: %v", err)
				}
			} else if tc.wantError != "" {
				if err == nil || !strings.Contains(err.Error(), tc.wantError) {
					t.Fatalf("error=%v want %q", err, tc.wantError)
				}
			} else if err != nil {
				t.Fatal(err)
			}
			if executor.CommandCalls != len(executor.CommandScript) {
				t.Fatalf("commands consumed %d/%d", executor.CommandCalls, len(executor.CommandScript))
			}
			if tc.wantMount {
				if len(mounts.MountPoints) != 1 || mounts.MountPoints[0].Type != "ext4" || !slices.Contains(mounts.MountPoints[0].Opts, "defaults") {
					t.Fatalf("mount/defaults lost: %+v", mounts.MountPoints)
				}
				if (opts.Readonly || slices.Contains(opts.Additional, "ro")) && !slices.Contains(mounts.MountPoints[0].Opts, "ro") {
					t.Fatal("readonly option lost")
				}
			} else if len(mounts.GetLog()) != 0 {
				t.Fatal("unexpected mount")
			}
			crypto, err := os.ReadFile(logPath)
			if err != nil {
				t.Fatal(err)
			}
			formats := 0
			statuses := 0
			for _, line := range strings.Split(strings.TrimSpace(string(crypto)), "\n") {
				switch line {
				case "status " + mapping:
					statuses++
				case formatArgs:
					formats++
				default:
					t.Fatalf("unexpected crypto request %q", line)
				}
			}
			wantFormats := 0
			if tc.formatExit >= 0 {
				wantFormats = 1
			}
			wantStatuses := 2
			if tc.name == "failed-crypto-format" {
				wantStatuses = 1
			}
			if tc.name == "interrupted-initialization-refuses-retry" {
				wantStatuses = 3
			}
			if formats != wantFormats || statuses != wantStatuses {
				t.Fatalf("crypto format/status=%d/%d want %d/%d", formats, statuses, wantFormats, wantStatuses)
			}
			outcomes[tc.name] = true
			t.Logf("exact command script consumed=%d, simulatedCryptoFormats=%d, readOnlyStatuses=%d, fakeMounts=%d; all actual writes refused", executor.CommandCalls, formats, statuses, len(mounts.GetLog()))
		})
	}
}
