package volumes

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	mount "k8s.io/mount-utils"
	utilexec "k8s.io/utils/exec"
	testingexec "k8s.io/utils/exec/testing"
)

func boundedTestCommand(t *testing.T, name string, args []string, output string, err error) testingexec.FakeCommandAction {
	t.Helper()
	return func(got string, gotArgs ...string) utilexec.Cmd {
		if got != name || !reflect.DeepEqual(gotArgs, args) {
			t.Fatalf("command=%s %v, want %s %v", got, gotArgs, name, args)
		}
		return testingexec.InitFakeCmd(&testingexec.FakeCmd{CombinedOutputScript: []testingexec.FakeAction{func() ([]byte, []byte, error) {
			return []byte(output), nil, err
		}}}, got, gotArgs...)
	}
}

func TestBoundedFilesystemCheckPreservesMountUtilsSemantics(t *testing.T) {
	for _, tc := range []struct {
		name   string
		err    error
		refuse bool
	}{
		{name: "clean"},
		{name: "corrected", err: utilexec.CodeExitError{Err: errors.New("simulated command exit"), Code: 1}},
		{name: "reboot-required", err: utilexec.CodeExitError{Err: errors.New("simulated command exit"), Code: 2}},
		{name: "uncorrected", err: utilexec.CodeExitError{Err: errors.New("simulated command exit"), Code: 4}, refuse: true},
		{name: "operational-exit", err: utilexec.CodeExitError{Err: errors.New("simulated command exit"), Code: 8}},
		{name: "missing", err: utilexec.ErrExecutableNotFound},
		{name: "execution-error", err: errors.New("simulated execution failure")},
	} {
		t.Run(tc.name, func(t *testing.T) {
			executor := &testingexec.FakeExec{CommandScript: []testingexec.FakeCommandAction{boundedTestCommand(t, "fsck", []string{"-a", "/dev/owned-test"}, "fsck-result", tc.err)}}
			service := NewLinuxMountService(slog.New(slog.NewTextHandler(io.Discard, nil)))
			service.mounter.Exec = executor
			err := service.checkBoundedFilesystem("/dev/owned-test")
			if tc.refuse {
				var typed mount.MountError
				if !errors.As(err, &typed) || typed.Type != mount.HasFilesystemErrors || !strings.Contains(typed.Message, "fsck-result") {
					t.Fatalf("uncorrected error lost type/output: %v", err)
				}
			} else if err != nil {
				t.Fatal(err)
			}
			if executor.CommandCalls != 1 {
				t.Fatalf("fsck calls=%d", executor.CommandCalls)
			}
		})
	}
}

func TestBoundedReadonlyRefusesUnformattedOuterBeforeCryptsetup(t *testing.T) {
	for _, tc := range []struct {
		name       string
		readonly   bool
		additional []string
	}{
		{name: "readonly-option", readonly: true},
		{name: "additional-ro", additional: []string{"ro"}},
		{name: "additional-any-ro", additional: []string{"ro", "rw"}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			dir := t.TempDir()
			device := filepath.Join(dir, "device")
			if err := os.WriteFile(device, nil, 0600); err != nil {
				t.Fatal(err)
			}
			// No real cryptsetup can run even if this early refusal regresses.
			t.Setenv("PATH", dir)
			executor := &testingexec.FakeExec{CommandScript: []testingexec.FakeCommandAction{boundedTestCommand(t, "blkid", []string{"-p", "-s", "TYPE", "-s", "PTTYPE", "-o", "export", device}, "", utilexec.CodeExitError{Err: errors.New("simulated command exit"), Code: 2})}}
			service := NewLinuxMountService(slog.New(slog.NewTextHandler(io.Discard, nil)))
			mounts := mount.NewFakeMounter(nil)
			service.mounter = &mount.SafeFormatAndMount{Interface: mounts, Exec: executor}
			err := service.Publish(context.Background(), filepath.Join(dir, "target"), device, MountOpts{FilesystemBytes: 1 << 30, EncryptionPassphrase: "test-only", Readonly: tc.readonly, Additional: tc.additional})
			if err == nil || !strings.Contains(err.Error(), "read-only mode") {
				t.Fatalf("error=%v", err)
			}
			if executor.CommandCalls != 1 || len(mounts.GetLog()) != 0 {
				t.Fatal("readonly blank outer advanced to mount")
			}
		})
	}
}

func TestUnboundedPublishPreservesLegacyPlaintext(t *testing.T) {
	for _, fresh := range []bool{false, true} {
		t.Run(map[bool]string{false: "existing", true: "fresh"}[fresh], func(t *testing.T) {
			dir := t.TempDir()
			device := filepath.Join(dir, "device")
			if err := os.WriteFile(device, nil, 0600); err != nil {
				t.Fatal(err)
			}
			format, inspectErr := "TYPE=ext4\n", error(nil)
			if fresh {
				format, inspectErr = "", utilexec.CodeExitError{Err: errors.New("simulated command exit"), Code: 2}
			}
			script := []testingexec.FakeCommandAction{boundedTestCommand(t, "blkid", []string{"-p", "-s", "TYPE", "-s", "PTTYPE", "-o", "export", device}, format, inspectErr)}
			if fresh {
				script = append(script, boundedTestCommand(t, "mkfs.ext4", []string{"-F", "-m0", device}, "", nil))
			} else {
				script = append(script, boundedTestCommand(t, "fsck", []string{"-a", device}, "", nil))
			}
			executor := &testingexec.FakeExec{CommandScript: script}
			mounts := mount.NewFakeMounter(nil)
			service := NewLinuxMountService(slog.New(slog.NewTextHandler(io.Discard, nil)))
			service.mounter = &mount.SafeFormatAndMount{Interface: mounts, Exec: executor}
			if err := service.Publish(context.Background(), filepath.Join(dir, "target"), device, MountOpts{}); err != nil {
				t.Fatal(err)
			}
			if executor.CommandCalls != 2 || len(mounts.GetLog()) != 1 || !reflect.DeepEqual(mounts.MountPoints[0].Opts, []string{"defaults"}) {
				t.Fatalf("legacy route changed: commands=%d mounts=%+v", executor.CommandCalls, mounts.MountPoints)
			}
		})
	}
}
