package volumes

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"time"

	"github.com/moby/buildkit/frontend/dockerfile/shell"
	"golang.org/x/sys/unix"
	"k8s.io/mount-utils"
	"k8s.io/utils/exec"

	"github.com/hetznercloud/hcloud-go/v2/hcloud"
)

const (
	DefaultFSType = "ext4"
	// XFSDefaultConfigPath is the oldest Linux Version available from `xfsprogs`. If this becomes unavailable, we need to increase it to the next lowest version and announce the change in the Release Notes.
	XFSDefaultConfigPath = "/usr/share/xfsprogs/mkfs/lts_4.19.conf"
)

// MountOpts specifies options for mounting a volume.
type MountOpts struct {
	BlockVolume          bool
	FSType               string
	Readonly             bool
	Additional           []string // Additional mount options/flags passed to /bin/mount
	EncryptionPassphrase string
	FsFormatOptions      string
	FilesystemBytes      int64 // non-zero only for boundedFilesystem=ext4-v1
}

// MountService mounts volumes.
type MountService interface {
	Publish(ctx context.Context, targetPath string, devicePath string, opts MountOpts) error
	Unpublish(ctx context.Context, targetPath string) error
	PathExists(path string) (bool, error)
}

// LinuxMountService mounts volumes on a Linux system.
type LinuxMountService struct {
	logger     *slog.Logger
	mounter    *mount.SafeFormatAndMount
	cryptSetup *CryptSetup
}

func NewLinuxMountService(logger *slog.Logger) *LinuxMountService {
	return &LinuxMountService{
		logger: logger,
		mounter: &mount.SafeFormatAndMount{
			Interface: mount.New(""),
			Exec:      exec.New(),
		},
		cryptSetup: NewCryptSetup(logger),
	}
}

func (s *LinuxMountService) Publish(ctx context.Context, targetPath string, devicePath string, opts MountOpts) error {
	// Ensure device is ready via stat syscall. Otherwise, `blkid` might return
	// exit code 2, which is the same exit code as for an unformatted device.
	if err := s.waitDeviceReady(ctx, devicePath); err != nil {
		return fmt.Errorf("device %q not ready: %w", devicePath, err)
	}

	isMountPoint, err := s.mounter.IsMountPoint(targetPath)
	if err != nil {
		if os.IsNotExist(err) {
			isMountPoint = false
		} else {
			return err
		}
	}
	if isMountPoint {
		return nil
	}

	var mountOptions []string
	freshLUKS := false
	readOnly := opts.Readonly
	if opts.FilesystemBytes != 0 {
		readOnly = readOnly || slices.Contains(opts.Additional, "ro")
	}

	targetPathPermissions := os.FileMode(0o750)
	if opts.BlockVolume {
		mountOptions = append(mountOptions, "bind")
		if err := os.MkdirAll(filepath.Dir(targetPath), targetPathPermissions); err != nil {
			return err
		}

		mountFilePermissions := os.FileMode(0o660)
		mountFile, err := os.OpenFile(targetPath, os.O_CREATE, mountFilePermissions)
		if err != nil {
			return err
		}
		err = mountFile.Close()
		if err != nil {
			return err
		}
	} else {
		if opts.FSType == "" {
			// BlockVolume is created without file system, setting a default does not make sense
			opts.FSType = DefaultFSType
		}
		if err := os.MkdirAll(targetPath, targetPathPermissions); err != nil {
			return err
		}
	}

	if opts.Readonly {
		mountOptions = append(mountOptions, "ro")
	}

	if opts.EncryptionPassphrase != "" {
		existingFSType, err := s.mounter.GetDiskFormat(devicePath)
		if err != nil {
			return fmt.Errorf("unable to detect existing disk format of %s: %w", devicePath, err)
		}
		luksDeviceName := GenerateLUKSDeviceName(devicePath)
		if existingFSType == "" {
			if readOnly {
				return fmt.Errorf("cannot publish unformatted disk %s in read-only mode", devicePath)
			}
			if err = s.cryptSetup.Format(ctx, devicePath, opts.EncryptionPassphrase); err != nil {
				return err
			}
			freshLUKS = true
		} else if existingFSType != "crypto_LUKS" {
			return fmt.Errorf("requested encrypted volume, but disk %s already is formatted with %s", devicePath, existingFSType)
		}
		if err := s.cryptSetup.Open(ctx, devicePath, luksDeviceName, opts.EncryptionPassphrase); err != nil {
			return err
		}
		luksDevicePath := GenerateLUKSDevicePath(luksDeviceName)
		devicePath = luksDevicePath
	}

	s.logger.Info(
		"publishing volume",
		"target-path", targetPath,
		"device-path", devicePath,
		"fs-type", opts.FSType,
		"block-volume", opts.BlockVolume,
		"readonly", readOnly,
		"mount-options", strings.Join(mountOptions, ", "),
		"encrypted", opts.EncryptionPassphrase != "",
	)

	if opts.BlockVolume {
		return s.mounter.MountSensitive(devicePath, targetPath, opts.FSType, mountOptions, opts.Additional)
	}

	formatOptions := make([]string, 0)

	if opts.FsFormatOptions != "" {
		lexer := shell.NewLex('\\')
		formatOptions, err = lexer.ProcessWords(opts.FsFormatOptions, shell.EnvsFromSlice([]string{}))
		if err != nil {
			return err
		}
	} else if opts.FSType == "xfs" {
		formatOptions = append(formatOptions, "-c", fmt.Sprintf("options=%s", XFSDefaultConfigPath))
	}

	if opts.FilesystemBytes != 0 {
		if opts.FSType != "ext4" || len(formatOptions) != 0 {
			return fmt.Errorf("bounded ext4 refuses other filesystems and custom format options")
		}
		if err := boundedExt4(ctx, s.mounter.Exec, devicePath, opts.FilesystemBytes, freshLUKS, readOnly); err != nil {
			return err
		}
		if !freshLUKS && !readOnly {
			if err := s.checkBoundedFilesystem(devicePath); err != nil {
				return err
			}
		}
		mountOptions = append(mountOptions, "defaults")
		if err := s.mounter.MountSensitive(devicePath, targetPath, opts.FSType, mountOptions, opts.Additional); err != nil {
			return mount.NewMountError(mount.UnknownMountError, "%s", err.Error())
		}
		return nil
	}
	return s.mounter.FormatAndMountSensitiveWithFormatOptions(devicePath, targetPath, opts.FSType, mountOptions, opts.Additional, formatOptions)
}

// Keep mount-utils v0.36.2's fsck policy without its fallback to formatting.
func (s *LinuxMountService) checkBoundedFilesystem(source string) error {
	out, err := s.mounter.Exec.Command("fsck", "-a", source).CombinedOutput()
	if err == nil {
		return nil
	}
	exit, isExitError := err.(exec.ExitError)
	switch {
	case err == exec.ErrExecutableNotFound:
		s.logger.Warn("fsck unavailable; continuing mount", "device", source)
	case isExitError && exit.ExitStatus() == 1:
		s.logger.Info("fsck corrected filesystem errors", "device", source)
	case isExitError && exit.ExitStatus() == 4:
		return mount.NewMountError(mount.HasFilesystemErrors, "'fsck' found errors on device %s but could not correct them: %s", source, string(out))
	case isExitError && exit.ExitStatus() > 4:
		s.logger.Info("fsck error; continuing mount", "device", source, "output", string(out))
	default:
		s.logger.Warn("fsck failed; continuing mount", "device", source, "error", err, "output", string(out))
	}
	return nil
}

// waitDeviceReady ensures the device at devicePath exists. This is done by ensuring a stat
// syscall returns no error.
func (s *LinuxMountService) waitDeviceReady(ctx context.Context, devicePath string) error {
	const maxRetries = 7
	backoffFunc := hcloud.ExponentialBackoffWithOpts(hcloud.ExponentialBackoffOpts{
		Base:       time.Millisecond * 50,
		Multiplier: 2.0,
		Cap:        500 * time.Millisecond,
	})

	var err error
	for i := range maxRetries {
		var stat unix.Stat_t
		err = unix.Stat(devicePath, &stat)
		if err == nil {
			return nil
		}
		if !errors.Is(err, unix.ENOENT) {
			return err
		}

		s.logger.Debug("device not ready yet: stat syscall returned ENOENT", "devicePath", devicePath)

		if i == maxRetries-1 {
			break
		}

		select {
		case <-ctx.Done():
			return fmt.Errorf("waiting for device %s: %w", devicePath, ctx.Err())
		case <-time.After(backoffFunc(i)):
		}
	}

	return err
}

func (s *LinuxMountService) Unpublish(ctx context.Context, targetPath string) error {
	devicePath, _, err := mount.GetDeviceNameFromMount(mount.New(""), targetPath)
	if err != nil {
		return fmt.Errorf("failed to determine mount path for %s: %w", targetPath, err)
	}

	s.logger.Info(
		"unpublishing volume",
		"target-path", targetPath,
		"device-path", devicePath,
	)

	if err := mount.CleanupMountPoint(targetPath, s.mounter, true); err != nil {
		return err
	}

	luksDeviceName := GenerateLUKSDeviceName(devicePath)

	return s.cryptSetup.Close(ctx, luksDeviceName)
}

func (s *LinuxMountService) PathExists(path string) (bool, error) {
	return mount.PathExists(path)
}
