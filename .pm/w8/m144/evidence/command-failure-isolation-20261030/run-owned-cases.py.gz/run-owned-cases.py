"""One fixed two-case local execution; exact existing owner helper owns cleanup."""
from pathlib import Path
import datetime,hashlib,json,os,secrets,shutil,subprocess,time
P=Path(__file__).resolve().parent
binding=json.loads((P/'image-binding-plan.json').read_text());ref=binding['reference'];nonce=secrets.token_hex(8);proof=P/('run-'+nonce);proof.mkdir(mode=0o700);name='bex-m144-t006-failure-'+nonce
E=os.environ.copy()
for k in ['DOCKER_CONTEXT','DOCKER_HOST','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','DOCKER_AUTH_CONFIG']:E.pop(k,None)
E['DOCKER_CONFIG']=str(P/'runtime-docker-config');D=['docker','--config',E['DOCKER_CONFIG'],'--host','unix:///Users/tianpan/.orbstack/run/docker.sock']
owner=None;samples=[];receipt={'nonce':nonce,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Two simulated command errors on real own filesystems; no actual kernelEIO or billing proof','image':ref,'name':name}
def docker(*args,check=True,timeout=30):
 r=subprocess.run(D+list(args),env=E,text=True,capture_output=True,timeout=timeout)
 if check and r.returncode:raise RuntimeError('owned docker command failed: '+args[0]+': '+r.stderr[-1000:])
 return r
def state(identity):
 r=docker('inspect',identity,'--format','{{json .}}',check=False)
 return json.loads(r.stdout) if r.returncode==0 else None
def checked(identity):
 x=state(identity)
 if x is None:return None
 assert x['Name']=='/'+name and x['Config']['Labels']['bex.local-proof']==nonce and x['Image']==binding['expected_config_image_ID'],'owned container identity mismatch'
 return x
def capacity(owner_alloc=0,owner_finished=False):
 own=0
 for root,dirs,files in os.walk(P,followlinks=False):
  for n in dirs+files:
   try:own+=(Path(root)/n).lstat().st_blocks*512
   except FileNotFoundError:pass
 build=0
 for n in ['build-cache','build-tmp','build-go-path','volumes-failure.test']:
  f=P/n
  if f.is_file():build+=f.stat().st_blocks*512
  elif f.is_dir():
   for root,dirs,files in os.walk(f):
    for item in dirs+files:
     try:build+=(Path(root)/item).lstat().st_blocks*512
     except FileNotFoundError:pass
 A=own+(192<<20)+owner_alloc;remaining=(0 if owner_finished else max(0,(224<<20)-owner_alloc))+max(0,(16<<20)-(own-build))+(16<<20);free=shutil.disk_usage(P).free
 x={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'own_case_allocated_bytes':own,'compile_allocated_bytes':build,'owner_tmpfs_allocated_bytes':owner_alloc,'A_conservative_bytes':A,'remaining_P_bytes':remaining,'free_bytes':free};samples.append(x)
 assert build<=512<<20 and A+remaining<=960<<20 and free>=(2<<30)+remaining and free>=2<<30,x
 return x
def await_file(filename,seconds=45):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  capacity()
  if (proof/filename).exists():return json.loads((proof/filename).read_text())
  x=checked(owner)
  if not x or not x['State']['Running']:raise RuntimeError('own helper stopped before '+filename)
  time.sleep(.2)
 raise RuntimeError('own helper wait deadline '+filename)
def owner_size():
 r=docker('exec',owner,'du','-sk','/scratch','/run','/tmp');return sum(int(l.split()[0])*1024 for l in r.stdout.splitlines())
(proof/'intended-owner.json').write_text(json.dumps({'name':name,'nonce':nonce,'image':ref,'configID':binding['expected_config_image_ID']},indent=2)+'\n')
assert hashlib.sha256((P/'bounded_failure_test.go').read_bytes()).hexdigest()=='5a6262e29c58b94143bde17ae9e740aca1dfcee5b603b761cbe2964d26b4f1d7'
assert hashlib.sha256((P/'failure-owner.sh').read_bytes()).hexdigest()=='0e6bcef95e482ac78e61231a8d4789919c9c2a7d682213866a00b17506307686'
try:
 capacity()
 created=docker('run','-d','--pull=never','--name',name,'--label','bex.local-proof='+nonce,'--privileged','--network','none','--memory','384m','--log-opt','max-size=1m','--log-opt','max-file=1','--tmpfs','/scratch:rw,size=192m','--tmpfs','/run:rw,size=16m','--tmpfs','/tmp:rw,size=16m','--mount','type=bind,src='+str(proof)+',dst=/proof','--mount','type=bind,src='+str(P/'failure-owner.sh')+',dst=/owner.sh,readonly','--mount','type=bind,src='+str(P/'volumes-failure.test')+',dst=/audit.test,readonly','--entrypoint','/bin/sh',ref,'/owner.sh',nonce)
 owner=created.stdout.strip();receipt['ownerID']=owner;assert checked(owner)
 ready=await_file('ready.json');receipt['owned_devices']=ready;assert ready['mappingA']=='m144t006-'+nonce+'-a' and ready['mappingB']=='m144t006-'+nonce+'-b'
 allocated=owner_size();capacity(allocated);receipt['owner_tmpfs_ready_bytes']=allocated;print(json.dumps({'stage':'OWN_TWO_FILESYSTEMS_READY','nonce':nonce,'ownerID':owner,'owner_tmpfs_allocated':allocated}),flush=True)
 result=docker('exec','--env','BEX_CSI_FAILURE_TEST=1','--env','BEX_CSI_FAILURE_NONCE='+nonce,owner,'/audit.test','-test.run','^TestBoundedExt4CommandFailureIsolation$','-test.v','-test.timeout=45s',check=False,timeout=60)
 (proof/'two-cases.log').write_text(result.stdout+result.stderr);receipt['test_exit']=result.returncode;receipt['actual_cases_pass']=result.returncode==0 and all('--- PASS: TestBoundedExt4CommandFailureIsolation/'+n in result.stdout for n in ['inspection-refusal','resize-command-error']);assert receipt['actual_cases_pass'],result.stdout+result.stderr
 capacity(owner_size());(proof/'check').touch();receipt['independent_owner_check']=await_file('checked.json',15);print(json.dumps({'stage':'TWO_ACTUAL_CASES_PASS','nonce':nonce,'independent_check':receipt['independent_owner_check']}),flush=True)
finally:
 (proof/'stop').touch()
 if owner is None:
  candidate=checked(name)
  if candidate:owner=candidate['Id'];receipt['ownerID_recovered_from_exact_intent']=owner
 if owner:
  end=time.monotonic()+30;x=checked(owner)
  while x and x['State']['Running'] and time.monotonic()<end:time.sleep(.2);x=checked(owner)
  logs=docker('logs',owner,check=False);(proof/'owner.log').write_text(logs.stdout+logs.stderr)
  cleanup=json.loads((proof/'cleanup.json').read_text()) if (proof/'cleanup.json').exists() else {'cleanupExit':None,'scope':'unproved; owner retained'};receipt['cleanup']=cleanup;receipt['ownerStopped']=bool(x and not x['State']['Running'])
  if receipt['ownerStopped'] and cleanup.get('cleanupExit')==0:
   removed=docker('rm',owner,check=False);receipt['owner_remove_exit']=removed.returncode;receipt['owner_absent_after']=state(owner) is None
  else:receipt['owner_retained_for_own_recovery']=True
 receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['after_capacity']=capacity(owner_finished=True);receipt['capacity_samples']=samples;receipt['retained_assets']='Exact current image reference and isolated compile cache retained for root-authorized later sequential probe; no shared prune';(proof/'execution-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'proof':str(proof),'test_exit':receipt.get('test_exit'),'cleanup':receipt.get('cleanup'),'owner_absent':receipt.get('owner_absent_after'),'free':shutil.disk_usage(P).free}),flush=True)
assert receipt['actual_cases_pass'] and receipt['cleanup']['cleanupExit']==0 and receipt['owner_absent_after']
