#!/bin/sh
# Own two small sparse local loop/LUKS filesystems. No provider or tenant data.
set -eu
nonce="$1"
case "$nonce" in *[!0-9a-f]*|'') exit 2;; esac
loop_a='' loop_b=''
image_a="/scratch/$nonce-a.img"; image_b="/scratch/$nonce-b.img"
map_a="m144t006-$nonce-a"; map_b="m144t006-$nonce-b"
device_a="/dev/mapper/$map_a"; device_b="/dev/mapper/$map_b"
mount_a=/scratch/mount-a; mount_b=/scratch/mount-b

owns_loop() { [ -n "$1" ] && losetup "$1" 2>/dev/null | grep -F "$2" >/dev/null; }
cleanup() {
  result=$?
  trap - EXIT INT TERM
  set +e
  failed=0
  for path in "$mount_a" "$mount_b"; do
    if grep -F " $path " /proc/mounts >/dev/null; then umount "$path" || failed=1; fi
  done
  for pair in "$map_a:$loop_a" "$map_b:$loop_b"; do
    name=${pair%%:*}; loop=${pair#*:}
    if status=$(cryptsetup status "$name" 2>/dev/null); then
      actual=$(printf '%s\n' "$status" | awk '$1=="device:" {print $2}')
      if [ -n "$loop" ] && [ "$actual" = "$loop" ]; then cryptsetup close "$name" || failed=1; else failed=1; fi
    fi
  done
  if owns_loop "$loop_a" "$image_a"; then losetup -d "$loop_a" || failed=1; fi
  if owns_loop "$loop_b" "$image_b"; then losetup -d "$loop_b" || failed=1; fi
  if cryptsetup status "$map_a" >/dev/null 2>&1 || cryptsetup status "$map_b" >/dev/null 2>&1; then failed=1; fi
  if owns_loop "$loop_a" "$image_a" || owns_loop "$loop_b" "$image_b"; then failed=1; fi
  printf '{"cleanupExit":%s,"originalExit":%s}\n' "$failed" "$result" > /proof/cleanup.json
  [ "$failed" -eq 0 ] || result=1
  exit "$result"
}
trap cleanup EXIT
trap 'exit 143' INT TERM

geometry() {
  uuid=$(blkid -s UUID -o value "$1")
  values=$(dumpe2fs -h "$1" 2>/dev/null | awk '/^Block count:/ {blocks=$3} /^Block size:/ {size=$3} END {print blocks " " size}')
  blocks=${values%% *}; block_size=${values#* }
  printf '{"uuid":"%s","blocks":%s,"blockSize":%s}' "$uuid" "$blocks" "$block_size"
}

mkdir -p "$mount_a" "$mount_b"
truncate -s 80M "$image_a"; truncate -s 80M "$image_b"
loop_a=$(losetup -f); losetup "$loop_a" "$image_a"
loop_b=$(losetup -f); losetup "$loop_b" "$image_b"
for pair in "$loop_a:$map_a" "$loop_b:$map_b"; do
  loop=${pair%%:*}; name=${pair#*:}
  printf 'disposable-local-t006-key' | cryptsetup luksFormat --type luks1 --batch-mode --key-file=- "$loop"
  printf 'disposable-local-t006-key' | cryptsetup open --key-file=- "$loop" "$name"
  id
  awk '/^(CapEff|CapBnd|NoNewPrivs):/' /proc/self/status
  cryptsetup status "$name"
  ls -ln "/dev/mapper/$name"
  stat -c 'own-device type=%F major=%t minor=%T mode=%a' "/dev/mapper/$name"
  mkfs.ext4 -q -F -m0 -b4096 "/dev/mapper/$name" 16384
done
mount -t ext4 "$device_a" "$mount_a"; mount -t ext4 "$device_b" "$mount_b"
chmod 777 "$mount_a"
printf 'owned-t006-volume-A\n' > "$mount_a/sentinel"
printf 'owned-t006-volume-B\n' > "$mount_b/sentinel"
sha256sum "$mount_a/sentinel" "$mount_b/sentinel" > /proof/sentinels.sha256
geometry "$device_a" > /proof/geometry-a-before.json
geometry "$device_b" > /proof/geometry-b-before.json

# A device inode is a negative-test canary, never an allowed --device mapping.
major_a=$(stat -c %t "$loop_a"); minor_a=$(stat -c %T "$loop_a")
mknod "$mount_a/device-inode-a" b "$((0x$major_a))" "$((0x$minor_a))"
chmod 666 "$mount_a/device-inode-a"
printf '{"loopA":"%s","loopB":"%s","mappingA":"%s","mappingB":"%s","majorA":%s,"minorA":%s,"filesystemBytes":67108864,"sourceImagesBytes":167772160}\n' "$loop_a" "$loop_b" "$map_a" "$map_b" "$((0x$major_a))" "$((0x$minor_a))" > /proof/ready.json.tmp
mv /proof/ready.json.tmp /proof/ready.json

while [ ! -e /proof/check ]; do
  [ ! -e /proof/stop ] || exit 0
  sleep 0.1
done
sha256sum -c /proof/sentinels.sha256
geometry "$device_a" > /proof/geometry-a-after.json
geometry "$device_b" > /proof/geometry-b-after.json
cmp /proof/geometry-a-before.json /proof/geometry-a-after.json
cmp /proof/geometry-b-before.json /proof/geometry-b-after.json
printf '{"geometryAUnchanged":true,"geometryBUnchanged":true,"sentinelsUnchanged":true}\n' > /proof/checked.json
while [ ! -e /proof/stop ]; do sleep 0.1; done
