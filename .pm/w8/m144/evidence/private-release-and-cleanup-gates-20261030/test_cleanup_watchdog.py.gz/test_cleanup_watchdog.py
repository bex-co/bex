import copy
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import unittest

s = importlib.util.spec_from_file_location('cleanup_watchdog', Path(__file__).with_name('cleanup-watchdog.py'))
w = importlib.util.module_from_spec(s);s.loader.exec_module(w)

class DeadlineTests(unittest.TestCase):
    def setUp(self):
        self.spec = {'run':'synthetic','name':'qa-synthetic','workspace':'tea-synthetic','disk_name':'qa-synthetic-disk','mount':'/var/data','protected_existing_services':['srv-protected'],'historical_deleted_215_ids':['srv-history']}
        service = {'id':'srv-synthetic','name':self.spec['name'],'ownerId':self.spec['workspace'],'serviceDetails':{'plan':'starter','disk':{'name':self.spec['disk_name'],'mountPath':'/var/data','sizeGB':1}}}
        self.ledger = {'owned':service,'disk_id':'dsk-synthetic','baseline_ids':['srv-foreign'],'create_intent':{'created_at':'2026-10-30T10:00:00Z','name':self.spec['name'],'workspace':self.spec['workspace'],'body_sha256':'synthetic'},'fixture_expires_at':'2026-10-30T12:00:00Z','create_proof':{'HTTP':201,'request':{'body_sha256':'synthetic'},'response':json.dumps({'service':service})}}
    def at(self, t):return w.decision(self.spec,self.ledger,w.when('2026-10-30T'+t+'Z'))[0]
    def test_wait_then_cleanup_fifteen_minutes_before_actual_expiry(self):
        self.assertEqual(self.at('11:44:59'),'wait');self.assertEqual(self.at('11:45:00'),'cleanup')
    def test_missing_create_has_no_target(self):
        self.assertEqual(w.decision(self.spec,{},datetime.now(timezone.utc)),('await-create',None))
    def test_ambiguous_create_never_adopts_by_name(self):
        self.ledger.pop('owned');self.assertEqual(self.at('11:45:00'),'ambiguous-create')
    def test_ambiguous_delete_never_replays(self):
        self.ledger['cleanup_intent']={'service':'srv-synthetic'};self.ledger['cleanup_response']={'HTTP':None};self.assertEqual(self.at('11:45:00'),'cleanup-check')
    def test_successful_delete_only_checks_absence(self):
        self.ledger['cleanup_response']={'HTTP':204};self.assertEqual(self.at('11:45:00'),'cleanup-check');self.ledger['cleanup_api_verified']={'service_404':True};self.assertEqual(self.at('11:45:01'),'complete')
    def test_foreign_proof_and_budget_increase_are_refused(self):
        for key, val in [('fixture_expires_at','2026-10-30T12:00:01Z'),('owned',{'id':'srv-protected'})]:
            ledger=copy.deepcopy(self.ledger);ledger[key]=val
            with self.subTest(key=key),self.assertRaises(AssertionError):w.target(self.spec,ledger)
        self.ledger['create_proof']['HTTP']=200
        with self.assertRaises(AssertionError):w.target(self.spec,self.ledger)


class LoopTests(unittest.TestCase):
    setUp = DeadlineTests.setUp
    def run_loop(self, delete_timeout=False, start='11:45:00'):
        import tempfile
        from unittest.mock import patch
        import subprocess
        clock={'now':w.when('2026-10-30T'+start+'Z'),'mono':0.0};calls=[]
        class Clock(datetime):
            @classmethod
            def now(cls,tz=None):return clock['now']
        def sleep(seconds):
            from datetime import timedelta
            clock['now']+=timedelta(seconds=seconds);clock['mono']+=seconds
        with tempfile.TemporaryDirectory(prefix='m144-watchdog-synthetic-') as directory:
            root=Path(directory);(root/'spec.json').write_text(json.dumps(self.spec));(root/'ledger.json').write_text(json.dumps(self.ledger))
            def run(command,**kwargs):
                calls.append((command[-1],kwargs['timeout']));ledger=json.loads((root/'ledger.json').read_text())
                if command[-1]=='cleanup':
                    ledger['cleanup_intent']={'service':'srv-synthetic'}
                    if not delete_timeout:ledger['cleanup_response']={'HTTP':204}
                    (root/'ledger.json').write_text(json.dumps(ledger))
                    if delete_timeout:raise subprocess.TimeoutExpired(command,kwargs['timeout'])
                    return subprocess.CompletedProcess(command,0,b'accepted',b'')
                if len(calls)==2:return subprocess.CompletedProcess(command,1,b'',b'pending exact API absence')
                ledger['cleanup_api_verified']={'service_404':True,'disk_404':True};(root/'ledger.json').write_text(json.dumps(ledger));return subprocess.CompletedProcess(command,0,b'absent',b'')
            with patch.object(w,'ROOT',root),patch.object(w,'datetime',Clock),patch.object(w.time,'sleep',side_effect=sleep),patch.object(w.time,'monotonic',side_effect=lambda:clock['mono']),patch.object(w.subprocess,'run',side_effect=run):w.main()
        return calls
    def test_pending_after_accepted_delete_retries_only_read_checks(self):
        calls=self.run_loop();self.assertEqual([x[0] for x in calls],['cleanup','cleanup-check','cleanup-check'])
    def test_timed_out_delete_reconciles_without_second_delete(self):
        calls=self.run_loop(delete_timeout=True);self.assertEqual([x[0] for x in calls],['cleanup','cleanup-check','cleanup-check'])
    def test_subprocess_timeout_is_capped_by_remaining_deadline(self):
        calls=self.run_loop(start='12:00:50');self.assertEqual(calls[0],('cleanup',10.0));self.assertLessEqual(calls[1][1],8.0)

if __name__ == '__main__':
    unittest.main()
