"""Local proof checks only; importing this module performs no I/O or authentication."""

from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
import re
import subprocess

REPOSITORY = Path('/Users/tianpan/projects/bex7')
REQUIREMENTS = Path(__file__).with_name('rollout-requirements.json')
IMAGE = r'ghcr\.io/bex-co/bex-operator@sha256:[0-9a-f]{64}'
SIGNER = 'https://github.com/bex-co/bex/.github/workflows/deploy.yml@refs/heads/main'
CSI_SIGNER = 'https://github.com/bex-co/bex/.github/workflows/hcloud-csi-image.yml@refs/heads/main'
ISSUER = 'https://token.actions.githubusercontent.com'


def instant(value):
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    assert parsed.tzinfo is not None, 'aware UTC evidence timestamp required'
    return parsed.astimezone(timezone.utc)


def receipt(reference, repository=REPOSITORY):
    assert isinstance(reference, dict), 'actual evidence receipt reference required'
    path = Path(reference['path']).resolve()
    allowed = (repository / '.pm/w8/m144/evidence').resolve()
    assert path.is_relative_to(allowed), 'evidence must be sanitized m144 evidence, never credential files'
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == reference['sha256'], 'evidence receipt bytes changed'
    return json.loads(raw)


def ancestor(required, source, repository):
    return subprocess.run(['git', '-C', str(repository), 'merge-base', '--is-ancestor', required, source], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10).returncode == 0


def blob_sha256(source, path, repository):
    result = subprocess.run(['git', '-C', str(repository), 'show', source + ':' + path], capture_output=True, timeout=10)
    assert result.returncode == 0, 'signed source Git blob unavailable; do not fetch or guess'
    return hashlib.sha256(result.stdout).hexdigest()


def committed_fixture_proof(commit, repository):
    assert re.fullmatch(r'[0-9a-f]{40}', commit), 'full immutable binding review commit required'
    result = subprocess.run(['git', '-C', str(repository), 'show', commit + ':deploy/hcloud-csi/fixture-proof.json'], capture_output=True, timeout=10)
    assert result.returncode == 0, 'committed actual fixture proof is unavailable'
    return result.stdout


def validate_image_signature(signature, image, source, signer, repository):
    assert type(signature['exit_code']) is int and signature['exit_code'] == 0 and signature['certificate_identity'] == signer and signature['oidc_issuer'] == ISSUER and signature['workflow_sha'] == source, 'actual strict public signature/source verification required'
    signatures = receipt(signature['receipt'], repository)
    assert isinstance(signatures, list) and any(item.get('critical', {}).get('type') == 'https://sigstore.dev/cosign/sign/v1' and item['critical'].get('identity', {}).get('docker-reference') == image and item['critical'].get('image', {}).get('docker-manifest-digest') == image.split('@')[1] for item in signatures), 'signature receipt does not name this exact image'


def validate_bounded_csi(gate, requirements, repository):
    release = gate['bounded_csi_release']
    image, source = release['image'], release['source_commit']
    assert re.fullmatch(IMAGE, image) and image == gate['bounded_csi_image'], 'exact newly qualified bounded CSI image required'
    assert re.fullmatch(r'[0-9a-f]{40}', source) and source == requirements['tested_csi_source_commit'], 'CSI factory source is not the qualified exact full commit'
    required = requirements['bounded_csi_key_guard_commit']
    assert re.fullmatch(r'[0-9a-f]{40}', required) and ancestor(required, source, repository), 'CSI image lacks the required missing-passphrase refusal commit'
    patch = requirements['bounded_csi_patch_sha256']
    assert re.fullmatch(r'[0-9a-f]{64}', patch) and release['patch_sha256'] == patch and blob_sha256(source, 'deploy/hcloud-csi/bounded-ext4.patch', repository) == patch, 'CSI source differs from the qualified key-refusal patch'
    validate_image_signature(release['signature_verification'], image, source, CSI_SIGNER, repository)
    ready = receipt(release['ready_rollout_receipt'], repository)
    assert ready['workflow'] == 'hcloud-csi-rollout.yml' and re.fullmatch(r'https://github\.com/bex-co/bex/actions/runs/[1-9][0-9]*', ready['run']), 'actual fixed CSI rollout workflow/run required'
    assert ready['step'] == 'upgrade only CSI and verify every controller/node driver pod' and ready['conclusion'] == 'success' and type(ready['exit_code']) is int and ready['exit_code'] == 0 and ready['allOldPodsTerminated'] is True, 'actual successful rollout and old-node termination evidence required'
    rollout_source = ready['source_commit']
    assert re.fullmatch(r'[0-9a-f]{40}', rollout_source) and ancestor(required, rollout_source, repository), 'rollout workflow source predates the key guard'
    validator = requirements['bounded_csi_readiness_validator_sha256']
    assert re.fullmatch(r'[0-9a-f]{64}', validator) and ready['readinessValidatorSha256'] == validator and blob_sha256(rollout_source, 'scripts/hcloud_csi.py', repository) == validator, 'rollout readiness validator differs from the reviewed exact source'
    summary = ready['driver_readiness']
    assert summary['image'] == image and all(type(summary[key]) is int and summary[key] > 0 for key in ('readyControllerPods', 'readyNodePods')), 'newly signed CSI image is not proven Ready on all driver roles'


def validate_release(gate, requirements, repository=REPOSITORY):
    release = gate['platform_release']
    image, source = release['image'], release['source_commit']
    assert re.fullmatch(IMAGE, image) and gate['operator_image'] == image, 'exact platform digest required'
    assert re.fullmatch(r'[0-9a-f]{40}', source), 'full signed image source commit required'
    for key in ('backend_retention_commit', 'operator_purge_commit'):
        assert release[key] == requirements[key] and re.fullmatch(r'[0-9a-f]{40}', release[key]), 'required final source ancestor missing'
        assert ancestor(requirements[key], source, repository), 'signed image does not contain both required commits'
    expected = {**requirements['tested_operator_source_sha256'], **requirements['tested_backend_source_sha256']}
    assert release['tested_operator_source_sha256'] == requirements['tested_operator_source_sha256'], 'tested operator map differs from final gates'
    assert release['git_blob_sha256'] == expected, 'full required Git-blob SHA256 map missing or different'
    assert all(blob_sha256(source, path, repository) == sha for path, sha in expected.items()), 'signed source differs from exact tested operator/backend bytes'
    validate_image_signature(release['signature_verification'], image, source, SIGNER, repository)
    ready = receipt(release['ready_inventory_receipt'], repository)
    assert ready['all_selected_platform_pods_running_ready_nonterminating'] is True and ready['actual_image_ids_equal_requested_pins'] is True, 'actual Ready runtime-image evidence required'
    for deployment, container in (('bex-api', 'api'), ('bex-controller-manager', 'manager')):
        status = ready['platform_deployments'][deployment]
        desired = status['desired']
        assert type(desired) is int and desired > 0 and status['converged'] is True and status['observedGeneration'] >= status['generation'], 'platform rollout is not converged'
        assert all(status[key] == desired for key in ('updated', 'ready', 'available')) and status['images'][container] == image, 'both backend and operator must run the signed image'
        pods = [pod for pod in ready['platform_pods'] if pod['name'].startswith(deployment + '-')]
        assert len(pods) == desired and all(pod['uid'] and pod['phase'] == 'Running' and not pod['deletingAt'] and pod['containerReady'][container] is True and pod['containerImages'][container] == image and pod['containerImageIds'][container] == image for pod in pods), 'old or unready platform Pod remains'
    assert ready['operator_disk_storage_class'] == 'hcloud-volumes-luks-bounded' and ready['manager_selects_bounded_class'] is True, 'operator does not globally select the bounded class'
    assert gate.get('bounded_class_global') is True and gate.get('bounded_csi_signature_verified') is True, 'signed bounded CSI/global class evidence is absent'
    assert ready['bounded_class_matches_reviewed_contract'] is True and gate['all_old_csi_node_pods_terminated'] is True and gate['bounded_class_active'] is True
    assert re.fullmatch(IMAGE, gate['bounded_csi_image']), 'exact reviewed bounded CSI digest required'
    validate_bounded_csi(gate, requirements, repository)
    budget = gate['ci_queue_budget']
    assert budget['root_verified_current_capacity'] is True and budget['observer_and_backup_can_overlap'] is True, 'post-create CI queue/runner capacity is unproved'
    assert budget['cleanup_reserve_seconds'] >= 900 and budget['estimated_post_create_seconds'] > 0 and budget['estimated_post_create_seconds'] + budget['cleanup_reserve_seconds'] <= 7200, 'CI queue and cleanup reserve do not fit the unchanged two-hour budget'
    return release


def validate_observer(gate, spec, ledger, repository=REPOSITORY):
    assert gate.get('fixture_binding_reviewed') is True, 'root immutable binding review has not completed'
    raw = committed_fixture_proof(gate['fixture_proof_commit'], repository)
    assert hashlib.sha256(raw).hexdigest() == gate['fixture_proof_sha256'], 'committed fixture proof bytes changed'
    proof = json.loads(raw)
    assert (proof['run'], proof['workspace'], proof['namespace'], proof['service_id'], proof['disk_id']) == (spec['run'], spec['workspace'], spec['workspace'], ledger['owned']['id'], ledger['disk_id']), 'committed proof targets a different fixture'
    assert proof['create_proof']['HTTP'] == 201 and proof['create_proof']['request_body_sha256'] == ledger['create_intent']['body_sha256'], 'immutable binding lacks this actual guarded HTTP201'
    evidence = receipt(gate['observer_ready_receipt'], repository)
    ready = evidence['cleanupObservation']
    assert evidence['run'] == spec['run'] and evidence['serviceId'] == ledger['owned']['id'], 'observer belongs to a different run or service'
    assert ready['state'] == 'observerReady' and ready['namespace'] == spec['workspace'] and ready['appUid'] == proof['app_uid'], 'real matching observerReady marker required'
    assert ready['watchResourceVersions']['app'] and ready['watchResourceVersions']['purgeJob'] and ready['providerBaseline']['http'] == 200 and ready['providerBaseline']['state'] == 'present', 'server-established watches and positive provider baseline required'
    assert instant(ready['startedAt']) >= instant(ledger['created_at']) and instant(ready['fixtureExpiresAt']) == instant(ledger['fixture_expires_at']), 'observer deadline differs from the actual fixture budget'
    assert instant(proof['expires_at']) == instant(ledger['fixture_expires_at']) and ready['providerBaseline']['volumeHandle'] == proof['binding']['volume_handle'] and str(ready['providerBaseline']['volumeId']) == proof['binding']['volume_handle'].split(':')[1], 'observer provider baseline differs from the committed binding'
    assert ready['maximumSeconds'] == 6000, 'reviewed bounded observer duration changed'
    return ready


def fixed_usage_path(workspace, created_at):
    # IDs and month come exclusively from this driver's owned creation proof.
    assert re.fullmatch(r'tea-[a-z0-9]+', workspace)
    return '/v1/usage?ownerId=' + workspace + '&period=' + instant(created_at).strftime('%Y-%m')


def project_usage(payload, workspace, service_id):
    matched = payload.get('workspaceId') == workspace
    services = []
    if matched:
        for service in payload.get('services', []):
            if service.get('serviceId') == service_id:
                services.append({'serviceId': service_id, 'resourceKind': service.get('resourceKind'), 'deleted': service.get('deleted', False), 'rows': [{'kind': row.get('kind'), 'tier': row.get('tier', ''), 'total': row.get('total')} for row in service.get('rows', []) if row.get('kind') == 'disk_gb_seconds']})
    coverage = payload.get('coverage') or {}
    return {'workspaceId': workspace if matched else None, 'workspaceMatched': matched, 'period': payload.get('period'), 'services': services, 'coverage': {key: coverage.get(key) for key in ('state', 'through')}, 'projection': 'only this HTTP201-owned service and requested-capacity disk_gb_seconds; foreign services, estimates and invoices discarded before persistence'}


def requested_usage_interval(ledger, service_id, through, current_disk):
    initial = ledger['disk_create_binding']['first_observed']
    growth = ledger['disk_growth_transition']
    before, response = growth['before'], growth['receipt']
    assert response['HTTP'] == 200 and response['request']['method'] == 'PATCH' and response['request']['path'] == '/v1/disks/' + ledger['disk_id'] and response['request']['body'] == {'sizeGB': 5}, 'the one actual owned grow PATCH receipt is missing'
    assert hashlib.sha256(response['response'].encode()).hexdigest() == response['response_sha256'], 'exact grow response bytes changed'
    after = json.loads(response['response'])
    for disk in (initial, before, after, current_disk):
        assert disk['id'] == ledger['disk_id'] and disk['serviceId'] == service_id, 'disk lifecycle belongs to a different disk/service'
        assert all(disk[key] == initial[key] for key in ('name', 'mountPath')), 'owned disk name or mount changed'
    assert initial['sizeGB'] == before['sizeGB'] == 1 and after['sizeGB'] == current_disk['sizeGB'] == 5, 'only the recorded 1-to-5 requested-size lifecycle is admissible'
    created = instant(initial['createdAt'])
    assert all(instant(disk['createdAt']) == created for disk in (before, after, current_disk)), 'server disk creation instant changed'
    creation = ledger['create_proof']
    assert creation['HTTP'] == 201, 'actual creation proof missing'
    assert ledger['owned']['id'] == service_id and service_id not in ledger['baseline_ids'] and ledger['disk_id'] not in ledger['baseline_disks'], 'usage target was not this fresh HTTP201-owned service/disk'
    assert ledger['disk_create_binding']['from_service_inline_create'] == creation['request']['body_sha256'], 'initial disk timing is not bound to the actual inline creation request'
    create_start, create_end = instant(creation['request_started_at']), instant(creation['response_received_at'])
    grow_start, grow_end = instant(response['request_started_at']), instant(response['response_received_at'])
    assert timedelta(0) <= create_end - create_start <= timedelta(seconds=120) and timedelta(0) <= grow_end - grow_start <= timedelta(seconds=120) and create_end <= grow_start, 'creation/grow clock brackets are inconsistent or too wide'
    # The same DB supplies createdAt/updatedAt and billing period boundaries.
    # Creation anchors its offset from the client's request/response clocks;
    # no guessed cross-machine clock offset widens the permitted charge.
    lower = created + (grow_start - create_end)
    upper = created + (grow_end - create_start)
    basis = 'actual grow request/response brackets anchored to server disk createdAt'
    if after.get('updatedAt'):
        changed = instant(after['updatedAt'])
        assert lower <= changed <= upper, 'server grow timestamp falls outside its anchored request/response brackets'
        assert instant(current_disk['updatedAt']) == changed, 'current disk has an unrecorded update after the grow'
        lower = upper = changed
        basis = 'exact REST server createdAt/updatedAt, validated against anchored request/response brackets'
    else:
        assert not current_disk.get('updatedAt'), 'grow response/current timestamp exposure differs'
    assert created < lower <= upper < through and through - created <= timedelta(hours=2), 'both 1Gi and 5Gi requested intervals must be inside the bounded closed window'

    def seconds(delta):
        return Decimal(delta.days * 86400 + delta.seconds) + Decimal(delta.microseconds) / Decimal(1000000)

    def quantity(grown_at=None):
        total = 0
        window = created.replace(minute=0, second=0, microsecond=0)
        while window < through:
            start, end = max(created, window), min(through, window + timedelta(hours=1))
            if grown_at is None:
                raw = Decimal(10) * seconds(end - start)
            else:
                old_end, new_start = min(end, grown_at), max(start, grown_at)
                raw = max(Decimal(0), seconds(old_end - start)) + Decimal(5) * max(Decimal(0), seconds(end - new_start))
            # Each closed hour is rounded by SUM(...)::bigint before REST sums
            # this fresh service's hourly rows. This compares units, never price.
            total += int(raw.quantize(Decimal(1), rounding=ROUND_HALF_UP))
            window += timedelta(hours=1)
        return total

    return {'minimumGBSeconds': quantity(upper), 'maximumGBSeconds': quantity(lower), 'physical10GiGBSeconds': quantity(), 'diskCreatedAt': created.isoformat(), 'growEarliestAt': lower.isoformat(), 'growLatestAt': upper.isoformat(), 'coverageThrough': through.isoformat(), 'timestampBasis': basis, 'rounding': 'positive nearest-integer GB-seconds per closed UTC hour, then sum; no pricing/invoice calculation'}


def assess_usage(payload, workspace, service_id, created_at, current, ledger=None, current_disk=None):
    created, current = instant(created_at), current.astimezone(timezone.utc)
    closed_end = current.replace(minute=0, second=0, microsecond=0)
    first_end = created.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
    result = {'state': 'unproved', 'serviceId': service_id, 'workspaceId': workspace, 'collectedAt': current.isoformat(), 'firstCreationHourEnd': first_end.isoformat(), 'latestClosedHourEnd': closed_end.isoformat(), 'financialSealing': 'unproved: usage REST exposes no per-hour seal/export state; the default billing seal horizon is 48h', 'invoiceClaim': False}
    if payload.get('workspaceId') != workspace or payload.get('workspaceMatched') is not True:
        return {**result, 'reason': 'workspace mismatch'}
    own = payload.get('services') or []
    if len(own) != 1 or own[0].get('serviceId') != service_id or own[0].get('deleted') is True or own[0].get('resourceKind') != 'service':
        return {**result, 'reason': 'owned live service row is absent, duplicated or stale'}
    if payload.get('period') != created.strftime('%Y-%m') or current < first_end:
        return {**result, 'reason': 'no closed creation hour in the requested period'}
    coverage = payload.get('coverage') or {}
    try:
        through = instant(coverage['through'])
    except (KeyError, TypeError, AttributeError, ValueError):
        return {**result, 'reason': 'usage coverage timestamp is absent or invalid'}
    if coverage.get('state') != 'complete' or through < first_end or through != closed_end:
        return {**result, 'reason': 'usage coverage is stale, partial or extends into an unclosed hour'}
    rows = own[0].get('rows') or []
    if len(rows) != 1 or rows[0].get('kind') != 'disk_gb_seconds' or rows[0].get('tier', '') != '' or type(rows[0].get('total')) is not int or rows[0]['total'] <= 0:
        return {**result, 'reason': 'positive own requested-capacity meter row is unavailable'}
    result.update(meterPresence='observed', requestedMeter=rows[0], coverageThrough=through.isoformat())
    try:
        expected = requested_usage_interval(ledger, service_id, through, current_disk)
    except (AssertionError, KeyError, TypeError, AttributeError, ValueError) as error:
        return {**result, 'reason': str(error) if isinstance(error, AssertionError) else 'recorded actual disk creation/grow timing proof is missing or malformed'}
    result['expectedRequestedUsage'] = expected
    total = rows[0]['total']
    if total == expected['physical10GiGBSeconds']:
        return {**result, 'reason': 'quantity matches the physical 10Gi floor, not proven requested-capacity billing'}
    if not expected['minimumGBSeconds'] <= total <= expected['maximumGBSeconds']:
        return {**result, 'reason': 'own closed-window quantity differs from bounded requested 1-to-5 GB-seconds'}
    return {**result, 'state': 'requested-size-verified', 'requestedSizeRollup': 'verified', 'parityRequestedMeterVerified': True, 'qualification': 'fresh own SID total matches the bounded closed-window requested 1-to-5 GB-second sum; financial sealing/export and invoice acceptance remain unproved'}
