"""Synthetic proof shapes and read-only local Git checks; never import the live driver."""

import copy
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import tempfile
import time
import unittest
import urllib.error
import urllib.parse
import urllib.request
from unittest.mock import Mock, patch

import m144_guards as guards


class PrivateGateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='m144-synthetic-proof-')
        self.addCleanup(self.temp.cleanup)
        self.repo = Path(self.temp.name)
        self.requirements = json.loads(guards.REQUIREMENTS.read_text())
        self.source = self.requirements['tested_source_commit']
        self.image = 'ghcr.io/bex-co/bex-operator@sha256:' + 'a' * 64
        self.maps = {**self.requirements['tested_operator_source_sha256'], **self.requirements['tested_backend_source_sha256']}
        self.ready = {'all_selected_platform_pods_running_ready_nonterminating': True, 'actual_image_ids_equal_requested_pins': True, 'operator_disk_storage_class': 'hcloud-volumes-luks-bounded', 'manager_selects_bounded_class': True, 'bounded_class_matches_reviewed_contract': True, 'platform_deployments': {}, 'platform_pods': []}
        for deployment, container in (('bex-api', 'api'), ('bex-controller-manager', 'manager')):
            self.ready['platform_deployments'][deployment] = {'desired': 1, 'updated': 1, 'ready': 1, 'available': 1, 'converged': True, 'generation': 2, 'observedGeneration': 2, 'images': {container: self.image}}
            self.ready['platform_pods'].append({'name': deployment + '-synthetic', 'uid': 'synthetic', 'phase': 'Running', 'deletingAt': '', 'containerReady': {container: True}, 'containerImages': {container: self.image}, 'containerImageIds': {container: self.image}})
        self.signature = [{'critical': {'type': 'https://sigstore.dev/cosign/sign/v1', 'identity': {'docker-reference': self.image}, 'image': {'docker-manifest-digest': self.image.split('@')[1]}}}]
        self.gate = {'operator_image': self.image, 'bounded_csi_image': 'ghcr.io/bex-co/bex-operator@sha256:' + 'b' * 64, 'all_old_csi_node_pods_terminated': True, 'bounded_class_active': True, 'bounded_class_global': True, 'bounded_csi_signature_verified': True, 'platform_release': {'image': self.image, 'source_commit': self.source, 'backend_retention_commit': self.requirements['backend_retention_commit'], 'operator_purge_commit': self.requirements['operator_purge_commit'], 'tested_operator_source_sha256': self.requirements['tested_operator_source_sha256'], 'git_blob_sha256': self.maps, 'signature_verification': {'exit_code': 0, 'certificate_identity': guards.SIGNER, 'oidc_issuer': guards.ISSUER, 'workflow_sha': self.source}}}
        self.gate['ci_queue_budget'] = {'root_verified_current_capacity': True, 'observer_and_backup_can_overlap': True, 'cleanup_reserve_seconds': 900, 'estimated_post_create_seconds': 5400}
        self.csi_source = self.requirements['tested_csi_source_commit']
        self.csi_image = self.gate['bounded_csi_image']
        self.csi_maps = {'deploy/hcloud-csi/bounded-ext4.patch': self.requirements['bounded_csi_patch_sha256'], 'scripts/hcloud_csi.py': self.requirements['bounded_csi_readiness_validator_sha256']}
        self.csi_signature = [{'critical': {'type': 'https://sigstore.dev/cosign/sign/v1', 'identity': {'docker-reference': self.csi_image}, 'image': {'docker-manifest-digest': self.csi_image.split('@')[1]}}}]
        self.csi_ready = {'workflow': 'hcloud-csi-rollout.yml', 'run': 'https://github.com/bex-co/bex/actions/runs/123', 'source_commit': self.csi_source, 'step': 'upgrade only CSI and verify every controller/node driver pod', 'conclusion': 'success', 'exit_code': 0, 'allOldPodsTerminated': True, 'readinessValidatorSha256': self.requirements['bounded_csi_readiness_validator_sha256'], 'driver_readiness': {'image': self.csi_image, 'readyControllerPods': 1, 'readyNodePods': 12}}
        self.gate['bounded_csi_release'] = {'image': self.csi_image, 'source_commit': self.csi_source, 'patch_sha256': self.requirements['bounded_csi_patch_sha256'], 'signature_verification': {'exit_code': 0, 'certificate_identity': guards.CSI_SIGNER, 'oidc_issuer': guards.ISSUER, 'workflow_sha': self.csi_source}}
        self.refresh_receipts()

    def reference(self, name, value):
        path = self.repo / '.pm/w8/m144/evidence/synthetic' / name
        path.parent.mkdir(parents=True, exist_ok=True)
        raw = json.dumps(value).encode()
        path.write_bytes(raw)
        return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest()}

    def refresh_receipts(self):
        self.gate['platform_release']['ready_inventory_receipt'] = self.reference('ready.json', self.ready)
        self.gate['platform_release']['signature_verification']['receipt'] = self.reference('signature.json', self.signature)
        self.gate['bounded_csi_release']['signature_verification']['receipt'] = self.reference('csi-signature.json', self.csi_signature)
        self.gate['bounded_csi_release']['ready_rollout_receipt'] = self.reference('csi-ready.json', self.csi_ready)

    def validate(self, gate=None, ancestry=True, blob=None):
        with patch.object(guards, 'ancestor', return_value=ancestry), patch.object(guards, 'blob_sha256', side_effect=lambda source, path, repo: blob or {**self.maps, **self.csi_maps}[path]):
            return guards.validate_release(gate or self.gate, self.requirements, self.repo)

    def test_complete_synthetic_shape_is_only_a_schema_test(self):
        self.assertEqual(self.validate()['source_commit'], self.source)

    def test_old_or_missing_csi_key_guard_release_is_refused_even_with_old_true_flags(self):
        target = copy.deepcopy(self.gate)
        target.pop('bounded_csi_release')
        with self.assertRaises(KeyError):
            self.validate(target)
        for field, value in (('source_commit', '9026301316233effaaee71e5ba49730c093bd446'), ('source_commit', 'short'), ('source_commit', 'a' * 40), ('patch_sha256', 'f8b98df3b24b3c84662949029160dad46ee2e394aa9ec5357271c0d88a83bf19'), ('image', self.image)):
            target = copy.deepcopy(self.gate)
            target['bounded_csi_release'][field] = value
            with self.subTest(field=field), self.assertRaises(AssertionError):
                self.validate(target)
        with patch.object(guards, 'ancestor', return_value=True), patch.object(guards, 'blob_sha256', side_effect=lambda source, path, repo: 'f8b98df3b24b3c84662949029160dad46ee2e394aa9ec5357271c0d88a83bf19' if path == 'deploy/hcloud-csi/bounded-ext4.patch' else {**self.maps, **self.csi_maps}[path]):
            with self.assertRaises(AssertionError):
                guards.validate_release(self.gate, self.requirements, self.repo)

    def test_unsigned_wrong_workflow_source_or_digest_csi_is_refused(self):
        for field, value in (('exit_code', False), ('exit_code', 1), ('certificate_identity', guards.SIGNER), ('oidc_issuer', 'https://wrong.invalid'), ('workflow_sha', self.source)):
            target = copy.deepcopy(self.gate)
            target['bounded_csi_release']['signature_verification'][field] = value
            with self.subTest(field=field), self.assertRaises(AssertionError):
                self.validate(target)
        target = copy.deepcopy(self.gate)
        target['bounded_csi_release']['signature_verification']['receipt'] = self.reference('wrong-csi-signature.json', self.signature)
        with self.assertRaises(AssertionError):
            self.validate(target)

    def test_csi_readiness_requires_actual_fixed_rollout_and_new_exact_image(self):
        for field, value in (('workflow', 'deploy.yml'), ('run', 'https://wrong.invalid/123'), ('source_commit', 'short'), ('conclusion', 'failure'), ('exit_code', False), ('allOldPodsTerminated', False), ('readinessValidatorSha256', '0' * 64)):
            target = copy.deepcopy(self.gate)
            target['bounded_csi_release']['ready_rollout_receipt'] = self.reference('wrong-csi-ready.json', {**self.csi_ready, field: value})
            with self.subTest(field=field), self.assertRaises(AssertionError):
                self.validate(target)
        for summary in ({'image': self.image}, {'readyNodePods': 0}, {'readyControllerPods': True}):
            changed = copy.deepcopy(self.csi_ready)
            changed['driver_readiness'].update(summary)
            target = copy.deepcopy(self.gate)
            target['bounded_csi_release']['ready_rollout_receipt'] = self.reference('old-csi-ready.json', changed)
            with self.assertRaises(AssertionError):
                self.validate(target)

    def test_csi_pins_match_shipped_local_git_but_do_not_claim_live_evidence(self):
        self.assertTrue(guards.ancestor(self.requirements['bounded_csi_key_guard_commit'], self.csi_source, guards.REPOSITORY))
        for path, expected in self.csi_maps.items():
            self.assertEqual(guards.blob_sha256(self.csi_source, path, guards.REPOSITORY), expected)

    def test_missing_or_false_platform_evidence_is_refused(self):
        for key in ('platform_release', 'bounded_class_global', 'bounded_csi_signature_verified'):
            target = copy.deepcopy(self.gate)
            target.pop(key)
            with self.subTest(key=key), self.assertRaises((AssertionError, KeyError)):
                self.validate(target)
        for key in ('bounded_class_global', 'bounded_csi_signature_verified', 'all_old_csi_node_pods_terminated'):
            target = copy.deepcopy(self.gate)
            target[key] = False
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.validate(target)

    def test_old_ancestor_inexact_source_map_and_unsigned_image_are_refused(self):
        for key, value in (('backend_retention_commit', '0' * 40), ('operator_purge_commit', '1' * 40), ('source_commit', 'short'), ('git_blob_sha256', {}), ('tested_operator_source_sha256', {})):
            target = copy.deepcopy(self.gate)
            target['platform_release'][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.validate(target)
        with self.assertRaises(AssertionError):
            self.validate(ancestry=False)
        with self.assertRaises(AssertionError):
            self.validate(blob='0' * 64)
        for value in (False, 1, None):
            target = copy.deepcopy(self.gate)
            target['platform_release']['signature_verification']['exit_code'] = value
            with self.subTest(exit_code=value), self.assertRaises(AssertionError):
                self.validate(target)

    def test_old_backend_or_operator_runtime_and_unready_pods_are_refused(self):
        for field, value in (('phase', 'Pending'), ('deletingAt', '2026-10-30T00:00:00Z')):
            changed = copy.deepcopy(self.ready)
            changed['platform_pods'][0][field] = value
            target = copy.deepcopy(self.gate)
            target['platform_release']['ready_inventory_receipt'] = self.reference('changed.json', changed)
            with self.subTest(field=field), self.assertRaises(AssertionError):
                self.validate(target)
        for index, container in ((0, 'api'), (1, 'manager')):
            changed = copy.deepcopy(self.ready)
            changed['platform_pods'][index]['containerImageIds'][container] = 'old-image'
            target = copy.deepcopy(self.gate)
            target['platform_release']['ready_inventory_receipt'] = self.reference('changed.json', changed)
            with self.subTest(container=container), self.assertRaises(AssertionError):
                self.validate(target)

    def test_receipt_hash_and_credential_path_refused_before_read(self):
        with self.assertRaises(AssertionError):
            guards.receipt({'path': str(self.repo / 'credentials/cli.yaml'), 'sha256': '0' * 64}, self.repo)
        ref = copy.deepcopy(self.gate['platform_release']['ready_inventory_receipt'])
        ref['sha256'] = '0' * 64
        with self.assertRaises(AssertionError):
            guards.receipt(ref, self.repo)

    def test_unknown_queue_capacity_or_budget_overrun_refuses_paid_fixture(self):
        for key, value in (('root_verified_current_capacity', False), ('observer_and_backup_can_overlap', False), ('cleanup_reserve_seconds', 0), ('estimated_post_create_seconds', 7000)):
            target = copy.deepcopy(self.gate)
            target['ci_queue_budget'][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.validate(target)

    def test_pinned_requirements_match_real_local_git_without_live_evidence(self):
        for key in ('backend_retention_commit', 'operator_purge_commit'):
            self.assertTrue(guards.ancestor(self.requirements[key], self.source, guards.REPOSITORY))
        for path, expected in self.maps.items():
            self.assertEqual(guards.blob_sha256(self.source, path, guards.REPOSITORY), expected)

    def test_observer_marker_requires_actual_committed_binding_and_matching_sid(self):
        spec = {'run': 'synthetic-run', 'workspace': 'tea-synthetic'}
        ledger = {'owned': {'id': 'srv-synthetic'}, 'disk_id': 'dsk-synthetic', 'created_at': '2026-10-30T10:00:00+00:00', 'fixture_expires_at': '2026-10-30T12:00:00+00:00', 'create_intent': {'body_sha256': 'a' * 64}}
        proof = {'run': spec['run'], 'workspace': spec['workspace'], 'namespace': spec['workspace'], 'service_id': 'srv-synthetic', 'disk_id': 'dsk-synthetic', 'app_uid': 'synthetic-uid', 'expires_at': ledger['fixture_expires_at'], 'create_proof': {'HTTP': 201, 'request_body_sha256': 'a' * 64}, 'binding': {'volume_handle': 'bounded-ext4-v1:42'}}
        raw = json.dumps(proof).encode()
        marker = {'run': spec['run'], 'serviceId': 'srv-synthetic', 'cleanupObservation': {'state': 'observerReady', 'namespace': spec['workspace'], 'appUid': 'synthetic-uid', 'watchResourceVersions': {'app': '100', 'purgeJob': '101'}, 'providerBaseline': {'http': 200, 'state': 'present', 'volumeHandle': 'bounded-ext4-v1:42', 'volumeId': 42}, 'startedAt': '2026-10-30T10:01:00+00:00', 'fixtureExpiresAt': ledger['fixture_expires_at'], 'maximumSeconds': 6000}}
        gate = {'fixture_binding_reviewed': True, 'fixture_proof_commit': 'f' * 40, 'fixture_proof_sha256': hashlib.sha256(raw).hexdigest(), 'observer_ready_receipt': self.reference('observer.json', marker)}
        with patch.object(guards, 'committed_fixture_proof', return_value=raw):
            self.assertEqual(guards.validate_observer(gate, spec, ledger, self.repo)['state'], 'observerReady')
            bad = copy.deepcopy(marker)
            bad['serviceId'] = 'srv-foreign'
            gate['observer_ready_receipt'] = self.reference('wrong-observer.json', bad)
            with self.assertRaises(AssertionError):
                guards.validate_observer(gate, spec, ledger, self.repo)


class PrivateBillingTests(unittest.TestCase):
    def setUp(self):
        self.created = '2026-10-30T10:15:00+00:00'
        self.current = datetime(2026, 10, 30, 11, 20, tzinfo=timezone.utc)
        self.payload = {'workspaceId': 'tea-synthetic', 'period': '2026-10', 'coverage': {'state': 'complete', 'through': '2026-10-30T11:00:00Z'}, 'services': [{'serviceId': 'srv-synthetic', 'resourceKind': 'service', 'rows': [{'kind': 'disk_gb_seconds', 'total': 6300}, {'kind': 'instance_seconds', 'total': 3600}]}, {'serviceId': 'srv-foreign', 'serviceName': 'PRIVATE_CANARY', 'rows': [{'kind': 'disk_gb_seconds', 'total': 99999}]}], 'estimatedCost': {'PRIVATE_CANARY': 99}, 'billing': {'PRIVATE_CANARY': 'invoice'}}
        initial = {'id': 'dsk-synthetic', 'serviceId': 'srv-synthetic', 'name': 'data', 'mountPath': '/var/data', 'sizeGB': 1, 'createdAt': self.created, 'updatedAt': self.created}
        self.current_disk = {**initial, 'sizeGB': 5, 'updatedAt': '2026-10-30T10:45:00+00:00'}
        raw = json.dumps(self.current_disk)
        self.ledger = {'disk_id': 'dsk-synthetic', 'disk_create_binding': {'first_observed': initial}, 'create_proof': {'HTTP': 201, 'request_started_at': '2026-10-30T10:14:59+00:00', 'response_received_at': '2026-10-30T10:15:01+00:00'}, 'disk_growth_transition': {'before': initial, 'receipt': {'HTTP': 200, 'request': {'method': 'PATCH', 'path': '/v1/disks/dsk-synthetic', 'body': {'sizeGB': 5}}, 'request_started_at': '2026-10-30T10:44:59+00:00', 'response_received_at': '2026-10-30T10:45:01+00:00', 'response': raw, 'response_sha256': hashlib.sha256(raw.encode()).hexdigest()}}}
        self.ledger.update(owned={'id': 'srv-synthetic'}, baseline_ids=['srv-foreign'], baseline_disks=['dsk-foreign'])
        self.ledger['create_proof']['request'] = {'body_sha256': 'd' * 64}
        self.ledger['disk_create_binding']['from_service_inline_create'] = 'd' * 64

    def assess(self, payload=None, current=None):
        selected = guards.project_usage(payload or self.payload, 'tea-synthetic', 'srv-synthetic')
        return guards.assess_usage(selected, 'tea-synthetic', 'srv-synthetic', self.created, current or self.current, self.ledger, self.current_disk)

    def test_fixed_path_and_projection_keep_only_own_requested_capacity_meter(self):
        self.assertEqual(guards.fixed_usage_path('tea-synthetic', self.created), '/v1/usage?ownerId=tea-synthetic&period=2026-10')
        selected = guards.project_usage(self.payload, 'tea-synthetic', 'srv-synthetic')
        encoded = json.dumps(selected)
        self.assertNotIn('PRIVATE_CANARY', encoded)
        self.assertNotIn('srv-foreign', encoded)
        self.assertNotIn('instance_seconds', encoded)
        self.assertNotIn('estimatedCost', selected)
        self.assertNotIn('billing', selected)

    def test_observed_closed_hour_rollup_never_claims_financial_sealing_or_invoice(self):
        result = self.assess()
        self.assertEqual(result['state'], 'requested-size-verified')
        self.assertEqual(result['requestedSizeRollup'], 'verified')
        self.assertEqual(result['expectedRequestedUsage']['minimumGBSeconds'], 6300)
        self.assertEqual(result['expectedRequestedUsage']['maximumGBSeconds'], 6300)
        self.assertIn('unproved', result['financialSealing'])
        self.assertIs(result['invoiceClaim'], False)
        self.assertEqual(result['latestClosedHourEnd'], '2026-10-30T11:00:00+00:00')

    def test_physical_ten_gib_and_wrong_requested_quantity_cannot_pass(self):
        for quantity in (27000, 6301, 6299):
            bad = copy.deepcopy(self.payload)
            bad['services'][0]['rows'][0]['total'] = quantity
            with self.subTest(quantity=quantity):
                result = self.assess(bad)
                self.assertEqual(result['state'], 'unproved')
                self.assertNotIn('parityRequestedMeterVerified', result)

    def test_unrecorded_update_wrong_grow_timing_or_no_closed_five_gib_interval_is_unproved(self):
        for when in ('2026-10-30T10:35:00+00:00', '2026-10-30T11:05:00+00:00'):
            original = copy.deepcopy(self.ledger)
            self.current_disk['updatedAt'] = when
            raw = json.dumps(self.current_disk)
            self.ledger['disk_growth_transition']['receipt'].update(response=raw, response_sha256=hashlib.sha256(raw.encode()).hexdigest())
            with self.subTest(updatedAt=when):
                self.assertNotIn('requestedSizeRollup', self.assess())
            self.ledger = original
        self.current_disk['updatedAt'] = '2026-10-30T10:46:00+00:00'
        self.assertIn('unrecorded update', self.assess()['reason'])

    def test_missing_server_grow_timestamp_uses_bounded_bracket_interval(self):
        self.current_disk.pop('updatedAt')
        raw = json.dumps(self.current_disk)
        self.ledger['disk_growth_transition']['receipt'].update(response=raw, response_sha256=hashlib.sha256(raw.encode()).hexdigest())
        result = self.assess()
        self.assertEqual(result['expectedRequestedUsage']['minimumGBSeconds'], 6292)
        self.assertEqual(result['expectedRequestedUsage']['maximumGBSeconds'], 6308)
        self.assertIs(result['parityRequestedMeterVerified'], True)
        bad = copy.deepcopy(self.payload)
        bad['services'][0]['rows'][0]['total'] = 27000
        self.assertEqual(self.assess(bad)['state'], 'unproved')

    def test_valid_grow_after_coverage_is_not_a_closed_five_gib_billing_proof(self):
        self.current_disk['updatedAt'] = '2026-10-30T11:05:00+00:00'
        raw = json.dumps(self.current_disk)
        self.ledger['disk_growth_transition']['receipt'].update(request_started_at='2026-10-30T11:04:59+00:00', response_received_at='2026-10-30T11:05:01+00:00', response=raw, response_sha256=hashlib.sha256(raw.encode()).hexdigest())
        result = self.assess()
        self.assertEqual(result['state'], 'unproved')
        self.assertIn('closed window', result['reason'])

    def test_reused_sid_or_changed_grow_response_bytes_is_unproved(self):
        self.ledger['baseline_ids'].append('srv-synthetic')
        self.assertEqual(self.assess()['state'], 'unproved')
        self.ledger['baseline_ids'].remove('srv-synthetic')
        self.ledger['disk_growth_transition']['receipt']['response_sha256'] = '0' * 64
        self.assertIn('response bytes changed', self.assess()['reason'])

    def test_multi_hour_weighting_matches_sum_of_integer_hour_rows(self):
        # 1Gi for 30m + 5Gi for 30m, then one full hour at 5Gi.
        initial = self.ledger['disk_create_binding']['first_observed']
        initial['createdAt'] = initial['updatedAt'] = '2026-10-30T10:00:00+00:00'
        self.created = initial['createdAt']
        self.current_disk.update(createdAt=self.created, updatedAt='2026-10-30T10:30:00+00:00')
        raw = json.dumps(self.current_disk)
        self.ledger['create_proof'].update(request_started_at='2026-10-30T09:59:59+00:00', response_received_at='2026-10-30T10:00:01+00:00')
        self.ledger['disk_growth_transition']['receipt'].update(request_started_at='2026-10-30T10:29:59+00:00', response_received_at='2026-10-30T10:30:01+00:00', response=raw, response_sha256=hashlib.sha256(raw.encode()).hexdigest())
        self.payload['coverage']['through'] = '2026-10-30T12:00:00Z'
        self.payload['services'][0]['rows'][0]['total'] = 28800
        result = self.assess(current=datetime(2026, 10, 30, 12, 0, tzinfo=timezone.utc))
        self.assertEqual(result['state'], 'requested-size-verified')
        self.assertEqual(result['expectedRequestedUsage']['minimumGBSeconds'], 28800)

    def test_subsecond_server_times_preserve_hourly_integer_rounding(self):
        initial = self.ledger['disk_create_binding']['first_observed']
        initial['createdAt'] = initial['updatedAt'] = '2026-10-30T10:00:00.250000+00:00'
        self.created = initial['createdAt']
        self.current_disk.update(createdAt=self.created, updatedAt='2026-10-30T10:30:00.250000+00:00')
        raw = json.dumps(self.current_disk)
        self.ledger['create_proof'].update(request_started_at='2026-10-30T09:59:59+00:00', response_received_at='2026-10-30T10:00:01+00:00')
        self.ledger['disk_growth_transition']['receipt'].update(request_started_at='2026-10-30T10:29:59+00:00', response_received_at='2026-10-30T10:30:01+00:00', response=raw, response_sha256=hashlib.sha256(raw.encode()).hexdigest())
        self.payload['services'][0]['rows'][0]['total'] = 10799
        result = self.assess()
        self.assertEqual(result['state'], 'requested-size-verified')
        self.assertEqual(result['expectedRequestedUsage']['minimumGBSeconds'], 10799)

    def test_grow_saves_intent_and_exact_response_once_even_when_transport_is_ambiguous(self):
        source = Path(__file__).with_name('hosted-disk.py')
        function = next(node for node in ast.parse(source.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == 'grow')
        for status in (200, None):
            ledger, calls = {}, []
            rec = copy.deepcopy(self.ledger['disk_growth_transition']['receipt'])
            rec['HTTP'] = status

            def request(method, path, body):
                self.assertEqual(ledger['disk_growth_transition']['phase'], 'intent_before_single_PATCH')
                calls.append((method, path, body))
                return rec

            def value(receipt):
                assert receipt['HTTP'] == 200
                return json.loads(receipt['response'])

            namespace = {'L': ledger, 'gate': lambda action: None, 'disk': lambda: copy.deepcopy(self.ledger['disk_create_binding']['first_observed']), 'latest': lambda path: {'observed_enospc': True, 'failure': {'errno': 28}, 'after': {'capacity_bytes': 1024**3}}, 'probe': lambda path: {}, 'save': lambda: None, 'now': lambda: self.current.isoformat(), 'request': request, 'value': value}
            exec(compile(ast.Module(body=[function], type_ignores=[]), str(source), 'exec'), namespace)
            if status == 200:
                namespace['grow']()
            else:
                with self.assertRaises(AssertionError):
                    namespace['grow']()
            self.assertEqual(ledger['disk_growth_transition']['receipt'], rec)
            self.assertEqual(ledger['disk_growth_transition']['phase'], 'response_recorded' if status == 200 else 'ambiguous_response')
            with self.assertRaises(AssertionError):
                namespace['grow']()
            self.assertEqual(len(calls), 1)

    def test_foreign_sid_wrong_metric_and_deleted_service_are_unproved(self):
        cases = []
        bad = copy.deepcopy(self.payload); bad['services'][0]['serviceId'] = 'srv-foreign'; cases.append(bad)
        bad = copy.deepcopy(self.payload); bad['services'][0]['rows'] = [{'kind': 'storage_gb_seconds', 'total': 6000}]; cases.append(bad)
        bad = copy.deepcopy(self.payload); bad['services'][0]['deleted'] = True; cases.append(bad)
        bad = copy.deepcopy(self.payload); bad['workspaceId'] = 'tea-foreign'; cases.append(bad)
        for payload in cases:
            with self.subTest(payload=payload):
                self.assertNotIn('requestedSizeRollup', self.assess(payload))

    def test_unclosed_stale_partial_or_future_coverage_is_unproved(self):
        self.assertNotIn('requestedSizeRollup', self.assess(current=datetime(2026, 10, 30, 10, 50, tzinfo=timezone.utc)))
        for state, through in (('partial', '2026-10-30T11:00:00Z'), ('complete', '2026-10-30T10:00:00Z'), ('complete', '2026-10-30T12:00:00Z'), ('complete', None)):
            bad = copy.deepcopy(self.payload)
            bad['coverage'] = {'state': state, 'through': through}
            with self.subTest(state=state, through=through):
                self.assertNotIn('requestedSizeRollup', self.assess(bad))

    def test_driver_usage_transport_projects_before_persistence_and_refuses_other_queries(self):
        # Compile only this function; the live driver's top level and credentials
        # are never opened, and its transport is an in-memory stub.
        source = Path(__file__).with_name('hosted-disk.py')
        function = next(node for node in ast.parse(source.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == 'request')
        with tempfile.TemporaryDirectory(prefix='m144-synthetic-usage-') as directory:
            root = Path(directory)
            (root / 'receipts').mkdir()
            response = Mock(code=200)
            response.read.return_value = json.dumps(self.payload).encode()
            response.headers = {}
            opener, token = Mock(), Mock(return_value='SYNTHETIC_TOKEN')
            opener.open.return_value = response
            namespace = {'P': root, 'L': {'created_at': self.created}, 'WS': 'tea-synthetic', 'S': {}, 'OPENER': opener, 'own': lambda read=False: {'id': 'srv-synthetic'}, 'private_token': token, 'scrub': lambda value: value, 'now': lambda: self.current.isoformat(), 'fixed_usage_path': guards.fixed_usage_path, 'project_usage': guards.project_usage, 'json': json, 'time': time, 'hashlib': hashlib, 'urllib': urllib}
            exec(compile(ast.Module(body=[function], type_ignores=[]), str(source), 'exec'), namespace)
            path = guards.fixed_usage_path('tea-synthetic', self.created)
            result = namespace['request']('GET', path)
            self.assertEqual(result['HTTP'], 200)
            self.assertEqual(result['request_started_at'], self.current.isoformat())
            self.assertEqual(result['response_received_at'], self.current.isoformat())
            persisted = ''.join(item.read_text() for item in (root / 'receipts').iterdir())
            self.assertNotIn('PRIVATE_CANARY', persisted)
            self.assertNotIn('srv-foreign', persisted)
            opener.reset_mock(); token.reset_mock()
            for method, other in (('POST', path), ('GET', path.replace('tea-synthetic', 'tea-foreign')), ('GET', path + '&serviceId=srv-foreign')):
                with self.subTest(method=method, path=other), self.assertRaises(AssertionError):
                    namespace['request'](method, other)
            opener.open.assert_not_called()
            token.assert_not_called()


if __name__ == '__main__':
    unittest.main(verbosity=2)
