"""One fixed full-Publish inner-probe simulation execution; exact existing owner helper owns cleanup."""
from pathlib import Path
import datetime,hashlib,json,os,secrets,shutil,signal,subprocess,time
P=Path(__file__).resolve().parent
PRIOR=Path('/private/tmp/bex-w8-m144-t006-failure-overlay-20261030')
ORIGINAL=Path('/private/tmp/bex-w8-m144-t006-publish-simulation-20261030')
BASE=Path('/private/tmp/bex-w8-m144-t006-local-20261030')
binding=json.loads((P/'image-binding-plan.json').read_text());ref=binding['reference'];nonce=secrets.token_hex(8);proof=P/('run-'+nonce);proof.mkdir(mode=0o700);name='bex-m144-t006-publish-sim-'+nonce
E=os.environ.copy()
for k in ['DOCKER_CONTEXT','DOCKER_HOST','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','DOCKER_AUTH_CONFIG']:E.pop(k,None)
E['DOCKER_CONFIG']=str(P/'runtime-docker-config');D=['docker','--config',E['DOCKER_CONFIG'],'--host','unix:///Users/tianpan/.orbstack/run/docker.sock']
owner=None;samples=[];receipt={'nonce':nonce,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Full Publish with actual healthy outer LUKS/active mapping and simulated inner no-identifiers; every requested write refused; no actual damaged filesystem or billing proof','image':ref,'name':name}
def docker(*args,check=True,timeout=30):
 r=subprocess.run(D+list(args),env=E,text=True,capture_output=True,timeout=timeout)
 if check and r.returncode:raise RuntimeError('owned docker command failed: '+args[0]+': '+r.stderr[-1000:])
 return r
def state(identity):
 r=docker('inspect',identity,'--format','{{json .}}',check=False)
 return json.loads(r.stdout) if r.returncode==0 else None
def checked(identity):
 x=state(identity)
 if x is None:return None
 assert x['Name']=='/'+name and x['Config']['Labels']['bex.local-proof']==nonce and x['Image']==binding['expected_config_image_ID'],'owned container identity mismatch'
 return x
def capacity(owner_alloc=0,owner_finished=False):
 own=0
 for top in [P,ORIGINAL,PRIOR,BASE]:
  for root,dirs,files in os.walk(top,followlinks=False):
   for n in dirs+files:
    try:own+=(Path(root)/n).lstat().st_blocks*512
    except FileNotFoundError:pass
 build=0
 for f in [PRIOR/'build-cache',PRIOR/'build-tmp',PRIOR/'build-go-path',PRIOR/'volumes-failure.test',P/'build-tmp',P/'build-go-path',P/'volumes-publish-sim.test',ORIGINAL/'build-tmp',ORIGINAL/'build-go-path',ORIGINAL/'volumes-publish-sim.test']:
  if f.is_file():build+=f.stat().st_blocks*512
  elif f.is_dir():
   for root,dirs,files in os.walk(f):
    for item in dirs+files:
     try:build+=(Path(root)/item).lstat().st_blocks*512
     except FileNotFoundError:pass
 A=own+(192<<20)+owner_alloc+(16<<20);remaining=(0 if owner_finished else max(0,(225<<20)-owner_alloc))+(32<<20);free=shutil.disk_usage(P).free
 x={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'own_case_allocated_bytes':own,'compile_allocated_bytes':build,'owner_tmpfs_allocated_bytes':owner_alloc,'A_conservative_bytes':A,'remaining_P_bytes':remaining,'free_bytes':free};samples.append(x)
 assert build<=512<<20 and A+remaining<=960<<20 and free>=(2<<30)+remaining and free>=2<<30,x
 return x
def await_file(filename,seconds=45):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  capacity()
  if (proof/filename).exists():return json.loads((proof/filename).read_text())
  x=checked(owner)
  if not x or not x['State']['Running']:raise RuntimeError('own helper stopped before '+filename)
  time.sleep(.2)
 raise RuntimeError('own helper wait deadline '+filename)
def owner_size():
 r=docker('exec',owner,'du','-sk','/scratch','/run','/tmp','/guard-bin');return sum(int(l.split()[0])*1024 for l in r.stdout.splitlines())
(proof/'intended-owner.json').write_text(json.dumps({'name':name,'nonce':nonce,'image':ref,'configID':binding['expected_config_image_ID']},indent=2)+'\n')
assert hashlib.sha256((P/'bounded_publish_sim_test.go').read_bytes()).hexdigest()=='26a75361132bb68ebd62389136a2af12d6800de82d4384e4c7d059fa27c13e9a'
assert hashlib.sha256((PRIOR/'failure-owner.sh').read_bytes()).hexdigest()=='0e6bcef95e482ac78e61231a8d4789919c9c2a7d682213866a00b17506307686'
def cancelled(signum,frame):raise SystemExit('own runner cancelled '+str(signum))
signal.signal(signal.SIGTERM,cancelled)
try:
 capacity()
 image=json.loads(docker('image','inspect',binding['expected_config_image_ID'],'--format','{{json .}}').stdout)
 assert image['Id']==binding['expected_config_image_ID'] and image['Architecture']==binding['expected_Architecture'] and image['Os']==binding['expected_Os'] and binding['expected_RepoDigest_entry'] in image['RepoDigests'] and image['RootFS']['Layers']==binding['expected_RootFS_Layers'] and image['Size']<=binding['maximum_image_Size'],'fresh exact image binding mismatch'
 receipt['fresh_image_binding']={'ID':image['Id'],'Architecture':image['Architecture'],'Os':image['Os'],'RepoDigests':image['RepoDigests'],'DiffIDs':image['RootFS']['Layers'],'Size':image['Size']}
 holder=state('c38308a5027b4cbdd15fe11ec51a1b0455d41831376dc8487ed439896652f61c')
 assert holder and holder['State']['Running'] and holder['Image']==binding['expected_config_image_ID'],'root held-image custody unavailable'
 receipt['holder_before_start']={'ID':holder['Id'],'running':True,'image':holder['Image']}
 created=docker('run','-d','--pull=never','--platform','linux/arm64','--name',name,'--label','bex.local-proof='+nonce,'--privileged','--network','none','--memory','384m','--log-opt','max-size=1m','--log-opt','max-file=1','--tmpfs','/guard-bin:rw,size=1m,exec,nosuid,nodev','--tmpfs','/scratch:rw,size=192m','--tmpfs','/run:rw,size=16m','--tmpfs','/tmp:rw,size=16m','--mount','type=bind,src='+str(proof)+',dst=/proof','--mount','type=bind,src='+str(PRIOR/'failure-owner.sh')+',dst=/owner.sh,readonly','--mount','type=bind,src='+str(P/'volumes-publish-sim.test')+',dst=/audit.test,readonly','--entrypoint','/bin/sh',binding['expected_config_image_ID'],'/owner.sh',nonce)
 owner=created.stdout.strip();receipt['ownerID']=owner;assert checked(owner)
 ready=await_file('ready.json');receipt['owned_devices']=ready;assert ready['mappingA']=='m144t006-'+nonce+'-a' and ready['mappingB']=='m144t006-'+nonce+'-b'
 allocated=owner_size();capacity(allocated);receipt['owner_tmpfs_ready_bytes']=allocated;print(json.dumps({'stage':'OWN_TWO_FILESYSTEMS_READY','nonce':nonce,'ownerID':owner,'owner_tmpfs_allocated':allocated}),flush=True)
 result=docker('exec','--env','BEX_CSI_PUBLISH_SIM_TEST=1','--env','BEX_CSI_PUBLISH_SIM_NONCE='+nonce,owner,'/audit.test','-test.run','^TestBoundedPublishAmbiguousInnerProbeDoesNotReformat$','-test.v','-test.timeout=45s',check=False,timeout=60)
 (proof/'publish-simulation.log').write_text(result.stdout+result.stderr);receipt['test_exit']=result.returncode
 detail=json.loads((proof/'publish-simulation-result.json').read_text());receipt['simulation_result']=detail
 receipt['controlled_original_criterion_failure']=(result.returncode!=0 and 'ORIGINAL CRITERION REGRESSION' in result.stdout and detail['outerType']=='crypto_LUKS' and detail['mappingActiveBefore'] and detail['innerSimulationCount']==1 and detail['GuardPathResolved'] and detail['GuardPreflightPassed'] and detail['CriterionEvaluated'] and detail['TestFailed'] and detail['MkfsRequested'] and not detail['ResizeRequested'] and detail['mountRequests']==0 and detail['AUnchanged'] and detail['BUnchanged'])
 capacity(owner_size());(proof/'check').touch();receipt['independent_owner_check']=await_file('checked.json',15)
 print(json.dumps({'stage':'SIMULATION_RETAINED','test_exit':result.returncode,'controlled_original_criterion_failure':receipt['controlled_original_criterion_failure'],'independent_check':receipt['independent_owner_check']}),flush=True)

finally:
 (proof/'stop').touch()
 if owner is None:
  candidate=checked(name)
  if candidate:owner=candidate['Id'];receipt['ownerID_recovered_from_exact_intent']=owner
 if owner:
  end=time.monotonic()+30;x=checked(owner)
  while x and x['State']['Running'] and time.monotonic()<end:time.sleep(.2);x=checked(owner)
  logs=docker('logs',owner,check=False);(proof/'owner.log').write_text(logs.stdout+logs.stderr)
  cleanup=json.loads((proof/'cleanup.json').read_text()) if (proof/'cleanup.json').exists() else {'cleanupExit':None,'scope':'unproved; owner retained'};receipt['cleanup']=cleanup;receipt['ownerStopped']=bool(x and not x['State']['Running'])
  if receipt['ownerStopped'] and cleanup.get('cleanupExit')==0:
   removed=docker('rm',owner,check=False);receipt['owner_remove_exit']=removed.returncode;receipt['owner_absent_after']=state(owner) is None
  else:receipt['owner_retained_for_own_recovery']=True
 receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['after_capacity']=capacity(owner_finished=True);receipt['capacity_samples']=samples;receipt['retained_assets']='Exact current image, active16MiB holder and isolated compile cache retained for root-authorized later sequential probe; no shared prune';(proof/'execution-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'proof':str(proof),'test_exit':receipt.get('test_exit'),'cleanup':receipt.get('cleanup'),'owner_absent':receipt.get('owner_absent_after'),'free':shutil.disk_usage(P).free}),flush=True)
assert receipt['controlled_original_criterion_failure'] and receipt['cleanup']['cleanupExit']==0 and receipt['owner_absent_after']
