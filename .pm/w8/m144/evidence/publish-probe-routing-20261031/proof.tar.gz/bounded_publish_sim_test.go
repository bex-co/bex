package volumes

import (
	"context"
	"crypto/sha256"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	mount "k8s.io/mount-utils"
	utilexec "k8s.io/utils/exec"
	fakeexec "k8s.io/utils/exec/testing"
	"log/slog"
	"os"
	osexec "os/exec"
	"path/filepath"
	"reflect"
	"regexp"
	"strings"
	"testing"
)

func TestExt4BytesRejectsCorruptAndOverflowingMetadata(t *testing.T) {
	s := make([]byte, 1024)
	if _, err := ext4Bytes(s); err == nil {
		t.Fatal("accepted bad magic")
	}
	binary.LittleEndian.PutUint16(s[56:], 0xef53)
	binary.LittleEndian.PutUint32(s[24:], 2)
	binary.LittleEndian.PutUint32(s[4:], 262144)
	got, err := ext4Bytes(s)
	if err != nil || got != 1<<30 {
		t.Fatalf("bytes=%d error=%v", got, err)
	}
	binary.LittleEndian.PutUint32(s[96:], 0x80)
	binary.LittleEndian.PutUint32(s[336:], 0xffffffff)
	if _, err := ext4Bytes(s); err == nil {
		t.Fatal("accepted overflowing block count")
	}
}

type failureVolumeState struct {
	UUID     string
	Geometry string
	Sentinel [32]byte
}

func captureFailureState(t *testing.T, device, mountpoint string) failureVolumeState {
	t.Helper()
	readCommand := func(name string, args ...string) string {
		t.Helper()
		out, err := osexec.Command(name, args...).CombinedOutput()
		if err != nil {
			t.Fatalf("read-only %s: %v: %s", name, err, out)
		}
		return strings.TrimSpace(string(out))
	}
	uuid := readCommand("blkid", "-s", "UUID", "-o", "value", device)
	var geometry []string
	for _, line := range strings.Split(readCommand("dumpe2fs", "-h", device), "\n") {
		if strings.HasPrefix(line, "Block count:") || strings.HasPrefix(line, "Block size:") {
			geometry = append(geometry, strings.Join(strings.Fields(line), " "))
		}
	}
	if uuid == "" || len(geometry) != 2 {
		t.Fatal("independent filesystem identity/geometry unavailable")
	}
	data, err := os.ReadFile(filepath.Join(mountpoint, "sentinel"))
	if err != nil {
		t.Fatal(err)
	}
	return failureVolumeState{uuid, strings.Join(geometry, ";"), sha256.Sum256(data)}
}

// Only the inner helper probe is simulated. The real outer probe is read-only.
var errPublishWriteRefused = errors.New("private simulation refused command")

type publishCommand struct {
	Name string   `json:"name"`
	Args []string `json:"args"`
	Kind string   `json:"kind"`
}
type publishProbeExec struct {
	utilexec.Interface
	raw, inner   string
	calls        []publishCommand
	simulated    int
	outerOutputs [][]byte
}

func (e *publishProbeExec) Command(name string, args ...string) utilexec.Cmd {
	return e.CommandContext(context.Background(), name, args...)
}
func (e *publishProbeExec) CommandContext(ctx context.Context, name string, args ...string) utilexec.Cmd {
	outer := name == "blkid" && reflect.DeepEqual(args, []string{"-p", "-s", "TYPE", "-s", "PTTYPE", "-o", "export", e.raw})
	inner := name == "blkid" && reflect.DeepEqual(args, []string{"-p", "-s", "TYPE", "-o", "value", e.inner})
	kind := "refused"
	if outer {
		kind = "actual-read-only-outer"
	}
	if inner {
		kind = "simulated-inner-exit2-empty"
	}
	e.calls = append(e.calls, publishCommand{name, append([]string(nil), args...), kind})
	return &fakeexec.FakeCmd{Argv: append([]string{name}, args...), CombinedOutputScript: []fakeexec.FakeAction{func() ([]byte, []byte, error) {
		if outer {
			b, err := e.Interface.CommandContext(ctx, name, args...).CombinedOutput()
			e.outerOutputs = append(e.outerOutputs, append([]byte(nil), b...))
			return b, nil, err
		}
		if inner {
			e.simulated++
			return nil, nil, utilexec.CodeExitError{Err: errors.New("SIMULATED inner ambiguous blkid result"), Code: 2}
		}
		return nil, nil, fmt.Errorf("%w: %s", errPublishWriteRefused, name)
	}}}
}

type publishSimulationProof struct {
	Scope                                                                   string `json:"scope"`
	BeforeA, BeforeB                                                        failureVolumeState
	AfterA, AfterB                                                          *failureVolumeState
	OuterProbeOutputs                                                       [][]byte `json:"actualOuterProbeOutputs"`
	OuterType                                                               string   `json:"outerType"`
	GuardPathResolved, GuardPreflightPassed                                 bool
	MappingActiveBefore                                                     bool             `json:"mappingActiveBefore"`
	InnerSimulationCount                                                    int              `json:"innerSimulationCount"`
	Commands                                                                []publishCommand `json:"commands"`
	CryptsetupRequests                                                      []string         `json:"cryptsetupRequests"`
	MountRequests                                                           int              `json:"mountRequests"`
	PublishError                                                            string           `json:"publishError"`
	MkfsRequested, ResizeRequested, UnexpectedCommand, UnexpectedCryptsetup bool
	AUnchanged, BUnchanged, CriterionEvaluated, TestFailed                  bool
}

func TestBoundedPublishAmbiguousInnerProbeDoesNotReformat(t *testing.T) {
	if os.Getenv("BEX_CSI_PUBLISH_SIM_TEST") != "1" {
		t.Skip("private explicitly authorized healthy-filesystem simulation")
	}
	if _, err := os.Stat("/.dockerenv"); err != nil {
		t.Fatal("disposable Docker owner required")
	}
	nonce := os.Getenv("BEX_CSI_PUBLISH_SIM_NONCE")
	if !regexp.MustCompile(`^[0-9a-f]{16}$`).MatchString(nonce) {
		t.Fatal("fixed own-device nonce required")
	}
	mapping := "m144t006-" + nonce + "-a"
	deviceA := "/dev/mapper/" + mapping
	deviceB := "/dev/mapper/m144t006-" + nonce + "-b"
	var ready struct {
		LoopA    string `json:"loopA"`
		MappingA string `json:"mappingA"`
		MappingB string `json:"mappingB"`
	}
	data, err := os.ReadFile("/proof/ready.json")
	if err != nil {
		t.Fatal(err)
	}
	if err = json.Unmarshal(data, &ready); err != nil {
		t.Fatal(err)
	}
	if ready.MappingA != mapping || ready.MappingB != "m144t006-"+nonce+"-b" || !regexp.MustCompile(`^/dev/loop[0-9]+$`).MatchString(ready.LoopA) {
		t.Fatal("own ready identity differs")
	}
	beforeA := captureFailureState(t, deviceA, "/scratch/mount-a")
	beforeB := captureFailureState(t, deviceB, "/scratch/mount-b")
	proof := publishSimulationProof{Scope: "Healthy actual own LUKS/ext4; only inner blkid ExitError2/empty is simulated. No metadata modification, unmount, corruption, real formatter/resize/mount or billing/provider/production proof.", BeforeA: beforeA, BeforeB: beforeB}
	guard := &publishProbeExec{Interface: utilexec.New(), inner: deviceA}
	mounts := mount.NewFakeMounter(nil)
	requestLog := "/proof/publish-cryptsetup-requests.log"
	t.Cleanup(func() {
		defer func() {
			proof.TestFailed = t.Failed()
			b, err := json.MarshalIndent(proof, "", "  ")
			if err == nil {
				err = os.WriteFile("/proof/publish-simulation-result.json", append(b, '\n'), 0600)
			}
			if err != nil {
				t.Errorf("persist local result: %v", err)
			}
		}()
		proof.Commands = guard.calls
		proof.OuterProbeOutputs = guard.outerOutputs
		proof.InnerSimulationCount = guard.simulated
		proof.MountRequests = len(mounts.GetLog())
		if b, err := os.ReadFile(requestLog); err == nil {
			proof.CryptsetupRequests = strings.Split(strings.TrimSpace(string(b)), "\n")
		}
		a := captureFailureState(t, deviceA, "/scratch/mount-a")
		b := captureFailureState(t, deviceB, "/scratch/mount-b")
		proof.AfterA = &a
		proof.AfterB = &b
		proof.AUnchanged = a == beforeA
		proof.BUnchanged = b == beforeB
		if !proof.AUnchanged || !proof.BUnchanged {
			t.Errorf("healthy A/B identity/geometry/sentinel changed: %+v", proof)
		}
	})
	// This is an ordinary symlink in own tmpfs, not a device write or remount.
	raw := filepath.Join("/scratch", mapping)
	if err := os.Symlink(ready.LoopA, raw); err != nil {
		t.Fatal(err)
	}
	guard.raw = raw
	t.Cleanup(func() {
		if err := os.Remove(raw); err != nil {
			t.Errorf("remove own symlink: %v", err)
		}
	})
	if GenerateLUKSDeviceName(raw) != mapping {
		t.Fatal("symlink does not select already-owned mapping")
	}
	logger := slog.New(slog.NewTextHandler(io.Discard, nil))
	service := NewLinuxMountService(logger)
	service.mounter = &mount.SafeFormatAndMount{Interface: mounts, Exec: guard}
	outer, err := service.mounter.GetDiskFormat(raw)
	proof.OuterType = outer
	if err != nil || outer != "crypto_LUKS" {
		t.Fatalf("real healthy outer probe differs: %q %v", outer, err)
	}
	realCrypt, err := osexec.LookPath("cryptsetup")
	if err != nil {
		t.Fatal(err)
	}
	realCrypt, err = filepath.Abs(realCrypt)
	if err != nil || !regexp.MustCompile(`^/[A-Za-z0-9_./-]+$`).MatchString(realCrypt) {
		t.Fatal("fixed real cryptsetup path required")
	}
	status, err := osexec.Command(realCrypt, "status", mapping).CombinedOutput()
	if err != nil {
		t.Fatalf("own active mapping precondition: %v: %s", err, status)
	}
	var backing string
	for _, line := range strings.Split(string(status), "\n") {
		fields := strings.Fields(line)
		if len(fields) == 2 && fields[0] == "device:" {
			backing = fields[1]
		}
	}
	if backing != ready.LoopA {
		t.Fatalf("mapping backing %q differs from own loop %q", backing, ready.LoopA)
	}
	proof.MappingActiveBefore = true
	if err := os.WriteFile("/proof/actual-cryptsetup-status.txt", status, 0600); err != nil {
		t.Fatal(err)
	}
	// CryptSetup uses os/exec directly. Its PATH shim delegates only status of
	// this already-active mapping and refuses format/open/resize/close commands.
	bin := "/guard-bin"
	mountInfo, err := os.ReadFile("/proc/self/mountinfo")
	if err != nil {
		t.Fatal(err)
	}
	var guardMount string
	for _, line := range strings.Split(string(mountInfo), "\n") {
		fields := strings.Fields(line)
		if len(fields) > 6 && fields[4] == bin {
			guardMount = line
			break
		}
	}
	if guardMount == "" {
		t.Fatal("dedicated own guard tmpfs absent")
	}
	if err := os.WriteFile("/proof/guard-mountinfo.txt", []byte(guardMount+"\n"), 0600); err != nil {
		t.Fatal(err)
	}
	fields := strings.Fields(guardMount)
	opts := "," + fields[5] + ","
	if !strings.Contains(guardMount, " - tmpfs ") || !strings.Contains(opts, ",nosuid,") || !strings.Contains(opts, ",nodev,") || strings.Contains(opts, ",noexec,") {
		t.Fatalf("guard requires own exec,nosuid,nodev tmpfs: %s", guardMount)
	}
	shim := fmt.Sprintf("#!/bin/sh\nprintf '%%s\\n' \"$*\" >> %s\nif [ \"$#\" -eq 2 ] && [ \"$1\" = status ] && [ \"$2\" = %s ]; then exec %s status %s; fi\nprintf 'blocked cryptsetup mutation\\n' >&2\nexit 125\n", requestLog, mapping, realCrypt, mapping)
	if err := os.WriteFile(filepath.Join(bin, "cryptsetup"), []byte(shim), 0700); err != nil {
		t.Fatal(err)
	}
	t.Setenv("PATH", bin+":"+os.Getenv("PATH"))
	resolved, err := osexec.LookPath("cryptsetup")
	if err != nil || resolved != filepath.Join(bin, "cryptsetup") {
		t.Fatalf("guard PATH resolution differs: %q %v", resolved, err)
	}
	proof.GuardPathResolved = true
	guardStatus, err := osexec.Command("cryptsetup", "status", mapping).CombinedOutput()
	if err != nil {
		t.Fatalf("guard exact status preflight: %v: %s", err, guardStatus)
	}
	if err := os.WriteFile("/proof/guard-status-preflight.txt", guardStatus, 0600); err != nil {
		t.Fatal(err)
	}
	guardLog, err := os.ReadFile(requestLog)
	if err != nil || string(guardLog) != "status "+mapping+"\n" {
		t.Fatalf("guard status preflight log differs: %q %v", guardLog, err)
	}
	proof.GuardPreflightPassed = true
	err = service.Publish(context.Background(), "/scratch/publish-sim-target", raw, MountOpts{FSType: "ext4", EncryptionPassphrase: "disposable-local-t006-key", FilesystemBytes: 1 << 30})
	if err != nil {
		proof.PublishError = err.Error()
	}
	if guard.simulated != 1 {
		t.Fatalf("full Publish did not reach exactly one simulated inner probe: %d", guard.simulated)
	}
	for _, call := range guard.calls {
		proof.MkfsRequested = proof.MkfsRequested || strings.HasPrefix(call.Name, "mkfs")
		proof.ResizeRequested = proof.ResizeRequested || strings.Contains(call.Name, "resize")
		proof.UnexpectedCommand = proof.UnexpectedCommand || call.Kind == "refused"
	}
	requests, readErr := os.ReadFile(requestLog)
	if readErr != nil {
		t.Fatalf("actual Publish cryptsetup-status route unproved: %v", readErr)
	}
	if len(strings.Split(strings.TrimSpace(string(requests)), "\n")) != 2 {
		t.Fatalf("guard must record preflight and actual Publish status: %q", requests)
	}
	for _, line := range strings.Split(strings.TrimSpace(string(requests)), "\n") {
		if line != "status "+mapping {
			proof.UnexpectedCryptsetup = true
		}
	}
	proof.CriterionEvaluated = true
	if err == nil || proof.MkfsRequested || proof.ResizeRequested || proof.UnexpectedCommand || proof.UnexpectedCryptsetup || len(mounts.GetLog()) != 0 {
		t.Errorf("ORIGINAL CRITERION REGRESSION: full Publish with known existing LUKS/active mapping requested forbidden writes or success after SIMULATED inner ambiguity; commands=%+v crypto=%q mounts=%+v error=%v", guard.calls, requests, mounts.GetLog(), err)
	}
	t.Logf("full Publish: actual outer=%s active=true; simulated inner exit2/empty; mkfsRequested=%t resizeRequested=%t; ALL mutations refused; no metadata changed", outer, proof.MkfsRequested, proof.ResizeRequested)
}
