#!/usr/bin/env python3
"""Run only a Go-produced Linux test executable in an owned offline container."""
import os
from pathlib import Path
import subprocess
import sys

executable = Path(sys.argv[1]).resolve()
workspace = Path.cwd().resolve()
args = ["docker", "run", "--rm", "--pull=never", "--network", "none", "--read-only",
        "--tmpfs", "/tmp:rw,size=64m", "--cap-drop", "ALL", "--security-opt", "no-new-privileges=true",
        "--pids-limit", "128", "--memory", "512m", "--mount", "type=bind,src=" + str(executable) + ",dst=/audit.test,readonly",
        "--mount", "type=bind,src=" + str(workspace) + ",dst=" + str(workspace),
        "--workdir", str(workspace), "--entrypoint", "/audit.test", "kindest/node:v1.36.1", *sys.argv[2:]]
raise SystemExit(subprocess.run(args, timeout=180).returncode)
