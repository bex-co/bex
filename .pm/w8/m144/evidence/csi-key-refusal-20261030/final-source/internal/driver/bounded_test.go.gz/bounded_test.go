package driver

import (
	"context"
	proto "github.com/container-storage-interface/spec/lib/go/csi"
	"github.com/hetznercloud/csi-driver/internal/csi"
	"github.com/hetznercloud/csi-driver/internal/mock"
	"github.com/hetznercloud/csi-driver/internal/volumes"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"testing"
)

func boundedCapability() *proto.VolumeCapability {
	return &proto.VolumeCapability{AccessMode: &proto.VolumeCapability_AccessMode{Mode: proto.VolumeCapability_AccessMode_SINGLE_NODE_WRITER}, AccessType: &proto.VolumeCapability_Mount{Mount: &proto.VolumeCapability_MountVolume{FsType: "ext4"}}}
}
func TestBoundedCreateKeepsLogicalCapacityBelowPhysicalFloor(t *testing.T) {
	env := newControllerServiceTestEnv()
	env.volumeService.CreateFunc = func(_ context.Context, opts volumes.CreateOpts) (*csi.Volume, error) {
		if opts.MinSize != 10 || opts.MaxSize != 0 {
			t.Fatalf("provider request=%+v", opts)
		}
		if opts.Labels["bounded-ext4"] != "v1" {
			t.Fatal("missing durable mode label")
		}
		return &csi.Volume{ID: 42, Size: 10, Location: "testloc", BoundedExt4: true}, nil
	}
	resp, err := env.service.CreateVolume(env.ctx, &proto.CreateVolumeRequest{Name: "one-gib", Parameters: map[string]string{"boundedFilesystem": "ext4-v1"}, CapacityRange: &proto.CapacityRange{RequiredBytes: 1 << 30, LimitBytes: 1 << 30}, VolumeCapabilities: []*proto.VolumeCapability{boundedCapability()}})
	if err != nil {
		t.Fatal(err)
	}
	if resp.Volume.CapacityBytes != 1<<30 || resp.Volume.VolumeId != "bounded-ext4-v1:42" || resp.Volume.VolumeContext["boundedFilesystem"] != "ext4-v1" {
		t.Fatalf("response=%+v", resp.Volume)
	}
}
func TestBoundedExpansionWithinProviderFloorRequiresNodeGrowth(t *testing.T) {
	env := newControllerServiceTestEnv()
	calls := 0
	env.volumeService.ResizeFunc = func(_ context.Context, v *csi.Volume, size int) error {
		calls++
		if v.ID != 42 || size != 10 {
			t.Fatalf("physical resize=%+v/%d", v, size)
		}
		return nil
	}
	env.volumeService.GetByIDFunc = func(context.Context, int64) (*csi.Volume, error) {
		return &csi.Volume{ID: 42, Size: 10, BoundedExt4: true}, nil
	}
	resp, err := env.service.ControllerExpandVolume(env.ctx, &proto.ControllerExpandVolumeRequest{VolumeId: "bounded-ext4-v1:42", CapacityRange: &proto.CapacityRange{RequiredBytes: 5 << 30, LimitBytes: 5 << 30}})
	if err != nil {
		t.Fatal(err)
	}
	if calls != 1 || resp.CapacityBytes != 5<<30 || !resp.NodeExpansionRequired {
		t.Fatalf("response=%+v calls=%d", resp, calls)
	}
}
func TestBoundedInvalidCapacityHasNoProviderSideEffect(t *testing.T) {
	env := newControllerServiceTestEnv()
	// Unset provider callbacks panic if validation leaks into a side effect.
	_, err := env.service.ControllerExpandVolume(env.ctx, &proto.ControllerExpandVolumeRequest{VolumeId: "bounded-ext4-v1:42", CapacityRange: &proto.CapacityRange{RequiredBytes: -1}})
	if status.Code(err) != codes.InvalidArgument {
		t.Fatalf("error=%v", err)
	}
}
func TestBoundedPublishRequiresFreshNodeSecret(t *testing.T) {
	env := newNodeServerTestEnv()
	calls := 0
	env.volumeMountService.PublishFunc = func(_ context.Context, _, _ string, opts volumes.MountOpts) error {
		calls++
		if opts.FilesystemBytes != 5<<30 || opts.EncryptionPassphrase != "retained" {
			t.Fatalf("opts=%+v", opts)
		}
		return nil
	}
	req := &proto.NodePublishVolumeRequest{VolumeId: "bounded-ext4-v1:42", TargetPath: "target", PublishContext: map[string]string{"devicePath": "device"}, VolumeContext: map[string]string{"boundedFilesystem": "ext4-v1"}, VolumeCapability: boundedCapability()}
	if _, err := env.service.NodePublishVolume(env.ctx, req); status.Code(err) != codes.InvalidArgument {
		t.Fatalf("missing secret=%v", err)
	}
	req.Secrets = map[string]string{"boundedFilesystem": "ext4-v1", "filesystemSizeBytes": "5368709120", "encryption-passphrase": "retained"}
	if _, err := env.service.NodePublishVolume(env.ctx, req); err != nil {
		t.Fatal(err)
	}
	if calls != 1 {
		t.Fatalf("publish calls=%d", calls)
	}
}

type boundedResizeCapture struct {
	*mock.VolumeResizeService
	bytes int64
}

func (b *boundedResizeCapture) ResizeBounded(_ context.Context, _ string, bytes int64) error {
	b.bytes = bytes
	return nil
}
func TestBoundedNodeExpandCannotFallBackToWholeDevice(t *testing.T) {
	env := newNodeServerTestEnv()
	capture := &boundedResizeCapture{VolumeResizeService: env.volumeResizeService}
	env.service.volumeResizeService = capture
	env.volumeMountService.PathExistsFunc = func(string) (bool, error) { return true, nil }
	req := &proto.NodeExpandVolumeRequest{VolumeId: "bounded-ext4-v1:42", VolumePath: "target", CapacityRange: &proto.CapacityRange{RequiredBytes: 5 << 30}, VolumeCapability: boundedCapability()}
	if _, err := env.service.NodeExpandVolume(env.ctx, req); status.Code(err) != codes.InvalidArgument {
		t.Fatalf("missing secret=%v", err)
	}
	req.Secrets = map[string]string{"boundedFilesystem": "ext4-v1", "filesystemSizeBytes": "1073741824", "encryption-passphrase": "retained"}
	if _, err := env.service.NodeExpandVolume(env.ctx, req); status.Code(err) != codes.Unavailable {
		t.Fatalf("stale secret=%v", err)
	}
	req.Secrets["filesystemSizeBytes"] = "5368709120"
	if _, err := env.service.NodeExpandVolume(env.ctx, req); err != nil {
		t.Fatal(err)
	}
	if capture.bytes != 5<<30 {
		t.Fatalf("bytes=%d", capture.bytes)
	}
}
func TestBoundedListNeverAdvertisesProviderFloor(t *testing.T) {
	env := newControllerServiceTestEnv()
	env.volumeService.AllFunc = func(context.Context) ([]*csi.Volume, error) {
		return []*csi.Volume{{ID: 42, Size: 10, Location: "testloc", BoundedExt4: true}, {ID: 43, Size: 10, Location: "testloc"}}, nil
	}
	resp, err := env.service.ListVolumes(env.ctx, &proto.ListVolumesRequest{})
	if err != nil {
		t.Fatal(err)
	}
	if resp.Entries[0].Volume.CapacityBytes != 0 || resp.Entries[0].Volume.VolumeId != "bounded-ext4-v1:42" || resp.Entries[1].Volume.CapacityBytes != 10<<30 {
		t.Fatalf("response=%+v", resp)
	}
}

func TestBoundedMissingEncryptionKeyHasNoNodeSideEffects(t *testing.T) {
	for _, keyState := range []string{"missing", "empty"} {
		t.Run(keyState, func(t *testing.T) {
			env := newNodeServerTestEnv()
			calls := 0
			env.volumeMountService.PublishFunc = func(context.Context, string, string, volumes.MountOpts) error {
				calls++
				return nil
			}
			secret := map[string]string{"boundedFilesystem": "ext4-v1", "filesystemSizeBytes": "5368709120"}
			if keyState == "empty" {
				secret["encryption-passphrase"] = ""
			}
			publish := &proto.NodePublishVolumeRequest{VolumeId: "bounded-ext4-v1:42", TargetPath: "target", PublishContext: map[string]string{"devicePath": "device"}, VolumeContext: map[string]string{"boundedFilesystem": "ext4-v1"}, VolumeCapability: boundedCapability(), Secrets: secret}
			if _, err := env.service.NodePublishVolume(env.ctx, publish); status.Code(err) != codes.InvalidArgument || calls != 0 {
				t.Fatalf("missing key publish: error=%v mountCalls=%d", err, calls)
			}
			env.volumeMountService.PathExistsFunc = func(string) (bool, error) { return true, nil }
			capture := &boundedResizeCapture{VolumeResizeService: env.volumeResizeService}
			env.service.volumeResizeService = capture
			expand := &proto.NodeExpandVolumeRequest{VolumeId: "bounded-ext4-v1:42", VolumePath: "target", CapacityRange: &proto.CapacityRange{RequiredBytes: 5 << 30}, VolumeCapability: boundedCapability(), Secrets: secret}
			if _, err := env.service.NodeExpandVolume(env.ctx, expand); status.Code(err) != codes.InvalidArgument || capture.bytes != 0 {
				t.Fatalf("missing key expand: error=%v resizedBytes=%d", err, capture.bytes)
			}
		})
	}
}
