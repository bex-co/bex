# Exact Node 14.21.2 V11 preparation — draft only

This package prepares one exact publish-only supplier row. It does not prove publication, runtime success, signatures, scans, common-image compatibility, adoption or live acceptance. No dispatcher, Docker build, registry read or cryptographic verification was executed for this preparation.

`PLAN-PENDING.json` is explicitly a DRAFT bound only to shipped commit `1feba939b4697894e800ed0abb4f25a0bf415641`. Actual run/job/ref remain null. A later board commit advances `main`; a future `--ref main` dispatch therefore MUST NOT be labelled `1feba`. Once an actual run exists, read its literal head and independently review a NEW source-bound adapter/plan against that commit and all critical workflow/recipe/support inputs. Do not edit this historical draft to make a different source appear equivalent or add a source alias. If the actual source differs, this adapter refuses it.

## Narrow implementation

- Copies of the original V11 driver and ranged policy are retained byte-for-byte, SHA checked before import.
- The only existing policy function replaced is `matrix_base`: it accepts only the explicit source/name, reads the actual source-pinned workflow, verifies the complete workflow SHA, and parses the unique literal singleton JSON. The exact official index is `cc748803fe49871926c433ae6aafbfd59b765eed6005dc0843b916eb74f67b12`.
- Existing `recipe_tree`, CI/recovery checks, bundle discovery, exact keyless/source/issuer/subject verification, Rekor V2/RFC3161 checks, negative crypto controls, SPDX/Trivy binders and full blob checks remain unchanged. Metadata adds restrictive actual ref/job/main/output/fresh-build/Node ENV assertions; no source recovery or exception is authorized.
- A 30-file immutable Git source manifest binds factory inputs, selection workflow, transport helper and local freshness support by SHA256, size and mode. Exact source bytes are included under `source-payloads/`; the actual Git commit is still required at execution.
- Original 11-item guard/aggregate/proofs are not imported or written. The resulting future V11 receipt is supplier evidence only. Exact binary/runtime/source-record and target-CVE disposition review plus generated common primary/companion qualification remain separate; metadata ENV alone is not binary runtime proof.

## Offline controls (already run)

```sh
BEX_EXACT_REVIEW_REPO_ROOT=ACTUAL-GIT-CHECKOUT python3 -B test_exact_adapter.py
python3 -B exact-node-v11-adapter.py source \
  --plan PLAN-PENDING.json --repo-root ACTUAL-GIT-CHECKOUT \
  --output-root NEW-OWNED-SOURCE-OUTPUT
```

Eight unittest methods cover real immutable source preparation; wrong source/name/version/hash/base; source closure/mode tampering; wrong/duplicate/extra literal rows; actual-workflow byte mismatch; independently mandatory real run/job/ref; CLI draft refusal before output/cache creation; and unchanged retained method inheritance. These are offline controls, not actual artifact verification. The test repository defaults to the current working directory and accepts `BEX_EXACT_REVIEW_REPO_ROOT`; it has no personal checkout path. Exact argv/results/hashes are in `offline-controls-receipt.json`.

## Future review invocation — NOT executed

After a separately reviewed fresh actual-source plan, real completed job and immutable digest exist:

```sh
python3 -B NEW-REVIEWED-ADAPTER.py review \
  --plan NEW-ACTUAL-SOURCE-PLAN.json --repo-root ACTUAL-GIT-CHECKOUT \
  --output-root NEW-OWNED-REVIEW-ROOT --cache-root NEW-OWNED-CACHE
```

The reviewed actual plan must bind literal source, full workflow hash, exact row/base, full recipe/support manifest, real positive integer run/job IDs and `ghcr.io/bex-co/bex-cnb-run@sha256:...`. It must not be a draft and must record actual-source confirmation. Require successful normal build, both architecture offline/Bullseye probes, complete scans, five signed payload roles and gated immutable output. V11 then still performs its original strict crypto/report/full-byte checks; no valid receipt is produced merely by filling plan scalars.

## Portable dependencies and limits

All Python review sources and raw source inputs are retained locally in this package. Python stdlib, `git`, `gh`, the repository's actual immutable commit and sufficient scratch capacity remain required. The retained policy has a pre-existing fixed Cosign path, `/private/tmp/bex7-native-acceptance-novb586u/cosign`; that path exists here and its bytes are verified as SHA256 `9f9b8cd557cf2e5b3df3373a00baa005a86b02391e3e06dd0ce37b3a1533d3a4` (official v3.1.4 darwin-arm64). It is not duplicated in this small archive. `external-dependencies.json` and the original checksum list preserve its locator. A different host/tool path requires an explicitly reviewed environment relocation preserving the same official verified binary and crypto flags; this package does not silently patch the retained policy.

No execution sizing is inferred from prior images. Before a real review, inspect actual descriptors, satisfy V11 disk limits, and use a new owned output/cache. The CLI's explicit draft/run/job/ref checks fail before review directory creation or network work. The actual producer/run/index are still UNKNOWN.
